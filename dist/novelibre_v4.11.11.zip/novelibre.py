#!/usr/bin/python3
"""A novel organizer for writers. 

Version 4.11.11
Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/novelibre
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import sys

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
from configparser import ConfigParser


class NvConfiguration(Configuration):

    def read(self, iniFile:str):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for app in section:
                self.settings[app] = section[app]

from shutil import copy2
from tkinter import filedialog

from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time
import gettext
import locale

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

import glob
from pathlib import Path
import subprocess




def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass


class LinkProcessor:
    ZIM_NOTE_EXTENSION = '.txt'

    def __init__(self, model):
        self._mdl = model

    def shorten_path(self, linkPath):
        projectDir = os.path.split(self._mdl.prjFile.filePath)[0]
        try:
            linkPath = os.path.relpath(linkPath, projectDir)
        except ValueError:
            pass
        return linkPath.replace('\\', '/')

    def expand_path(self, linkPath):
        if linkPath.startswith('~'):
            homeDir = str(Path.home())
            linkPath = linkPath.replace('~', homeDir, 1)
        else:
            projectDir = os.path.split(self._mdl.prjFile.filePath)[0]
            linkPath = os.path.join(projectDir, linkPath)
        return os.path.realpath(linkPath).replace('\\', '/')

    def open_link(self, linkPath, launchers):
        linkPath = self.expand_path(linkPath)
        extension = None
        try:
            filePath, extension = os.path.splitext(linkPath)
            if extension == self.ZIM_NOTE_EXTENSION:
                launcher = launchers['.zim']
                if os.path.isfile(launcher):
                    pagePath = filePath.split('/')
                    zimPages = []

                    while pagePath:
                        zimPages.insert(0, pagePath.pop())
                        zimPath = '/'.join(pagePath)
                        zimNotebook = glob.glob(norm_path(f'{zimPath}/*.zim'))
                        if zimNotebook:
                            subprocess.Popen([launcher, zimNotebook[0], ":".join(zimPages)])
                            return

        except:
            pass
        launcher = launchers.get(extension, '')
        if os.path.isfile(launcher):
            subprocess.Popen([launcher, linkPath])
            return

        if os.path.isfile(linkPath):
            open_document(linkPath)
            return

        raise FileNotFoundError(f"{_('File not found')}: {norm_path(linkPath)}")

from datetime import datetime


from abc import ABC, abstractmethod


class FileFactory(ABC):

    def __init__(self, fileClasses):
        self._fileClasses = fileClasses

    @abstractmethod
    def make_file_objects(self, sourcePath, **kwargs):
        pass


class ExportTargetFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        suffix = kwargs['suffix']
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX == suffix:
                if suffix is None:
                    suffix = ''
                targetFile = fileClass(f'{fileName}{suffix}{fileClass.EXTENSION}', **kwargs)
                return None, targetFile

        raise Error(f'{_("Export type is not supported")}: "{suffix}".')

from datetime import date

from abc import ABC
from urllib.parse import quote



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.sectionsSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        filePath = filePath.replace('\\', '/')
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def is_locked(self):
        return False

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError

import xml.etree.ElementTree as ET


class BasicElement:

    def __init__(self,
            on_element_change=None,
            title=None,
            desc=None,
            links=None):
        if on_element_change is None:
            self.on_element_change = self.do_nothing
        else:
            self.on_element_change = on_element_change
        self._title = title
        self._desc = desc
        if links is None:
            self._links = {}
        else:
            self._links = links

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._title != newVal:
            self._title = newVal
            self.on_element_change()

    @property
    def desc(self):
        return self._desc

    @desc.setter
    def desc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._desc != newVal:
            self._desc = newVal
            self.on_element_change()

    @property
    def links(self):
        try:
            return self._links.copy()
        except AttributeError:
            return None

    @links.setter
    def links(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) == str
        if self._links != newVal:
            self._links = newVal
            self.on_element_change()

    def do_nothing(self):
        pass

    def from_xml(self, xmlElement):
        self.title = self._get_element_text(xmlElement, 'Title')
        self.desc = self._xml_element_to_text(xmlElement.find('Desc'))
        self.links = self._get_link_dict(xmlElement)

    def to_xml(self, xmlElement):
        if self.title:
            ET.SubElement(xmlElement, 'Title').text = self.title
        if self.desc:
            xmlElement.append(self._text_to_xml_element('Desc', self.desc))
        if self.links:
            for path in self.links:
                xmlLink = ET.SubElement(xmlElement, 'Link')
                ET.SubElement(xmlLink, 'Path').text = path
                if self.links[path]:
                    ET.SubElement(xmlLink, 'FullPath').text = self.links[path]

    def _get_element_text(self, xmlElement, tag, default=None):
        if xmlElement.find(tag) is not None:
            return xmlElement.find(tag).text
        else:
            return default

    def _get_link_dict(self, xmlElement):
        links = {}
        for xmlLink in xmlElement.iterfind('Link'):
            xmlPath = xmlLink.find('Path')
            if xmlPath is not None:
                path = xmlPath.text
                xmlFullPath = xmlLink.find('FullPath')
                if xmlFullPath is not None:
                    fullPath = xmlFullPath.text
                else:
                    fullPath = None
            else:
                path = xmlLink.attrib.get('path', None)
                fullPath = xmlLink.attrib.get('fullPath', None)
            if path:
                links[path] = fullPath
        return links

    def _text_to_xml_element(self, tag, text):
        xmlElement = ET.Element(tag)
        if text:
            for line in text.split('\n'):
                ET.SubElement(xmlElement, 'p').text = line
        return xmlElement

    def _xml_element_to_text(self, xmlElement):
        lines = []
        if xmlElement is not None:
            for paragraph in xmlElement.iterfind('p'):
                lines.append(''.join(t for t in paragraph.itertext()))
        return '\n'.join(lines)



class BasicElementNotes(BasicElement):

    def __init__(self,
            notes=None,
            **kwargs):
        super().__init__(**kwargs)
        self._notes = notes

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.notes = self._xml_element_to_text(xmlElement.find('Notes'))

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.notes:
            xmlElement.append(self._text_to_xml_element('Notes', self.notes))



class Chapter(BasicElementNotes):

    def __init__(self,
            chLevel=None,
            chType=None,
            noNumber=None,
            isTrash=None,
            **kwargs):
        super().__init__(**kwargs)
        self._chLevel = chLevel
        self._chType = chType
        self._noNumber = noNumber
        self._isTrash = isTrash

    @property
    def chLevel(self):
        return self._chLevel

    @chLevel.setter
    def chLevel(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._chLevel != newVal:
            self._chLevel = newVal
            self.on_element_change()

    @property
    def chType(self):
        return self._chType

    @chType.setter
    def chType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._chType != newVal:
            self._chType = newVal
            self.on_element_change()

    @property
    def noNumber(self):
        return self._noNumber

    @noNumber.setter
    def noNumber(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._noNumber != newVal:
            self._noNumber = newVal
            self.on_element_change()

    @property
    def isTrash(self):
        return self._isTrash

    @isTrash.setter
    def isTrash(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._isTrash != newVal:
            self._isTrash = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        typeStr = xmlElement.get('type', '0')
        if typeStr in ('0', '1'):
            self.chType = int(typeStr)
        else:
            self.chType = 1
        chLevel = xmlElement.get('level', None)
        if chLevel == '1':
            self.chLevel = 1
        else:
            self.chLevel = 2
        self.isTrash = xmlElement.get('isTrash', None) == '1'
        self.noNumber = xmlElement.get('noNumber', None) == '1'

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.chType:
            xmlElement.set('type', str(self.chType))
        if self.chLevel == 1:
            xmlElement.set('level', '1')
        if self.isTrash:
            xmlElement.set('isTrash', '1')
        if self.noNumber:
            xmlElement.set('noNumber', '1')


class BasicElementTags(BasicElementNotes):

    def __init__(self,
            tags=None,
            **kwargs):
        super().__init__(**kwargs)
        self._tags = tags

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._tags != newVal:
            self._tags = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        tags = string_to_list(self._get_element_text(xmlElement, 'Tags'))
        strippedTags = []
        for tag in tags:
            strippedTags.append(tag.strip())
        self.tags = strippedTags

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        tagStr = list_to_string(self.tags)
        if tagStr:
            ET.SubElement(xmlElement, 'Tags').text = tagStr



class WorldElement(BasicElementTags):

    def __init__(self,
            aka=None,
            **kwargs):
        super().__init__(**kwargs)
        self._aka = aka

    @property
    def aka(self):
        return self._aka

    @aka.setter
    def aka(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._aka != newVal:
            self._aka = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.aka = self._get_element_text(xmlElement, 'Aka')

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.aka:
            ET.SubElement(xmlElement, 'Aka').text = self.aka



class Character(WorldElement):
    MAJOR_MARKER = 'Major'
    MINOR_MARKER = 'Minor'

    def __init__(self,
            bio=None,
            goals=None,
            fullName=None,
            isMajor=None,
            birthDate=None,
            deathDate=None,
            **kwargs):
        super().__init__(**kwargs)
        self._bio = bio
        self._goals = goals
        self._fullName = fullName
        self._isMajor = isMajor
        self._birthDate = birthDate
        self._deathDate = deathDate

    @property
    def bio(self):
        return self._bio

    @bio.setter
    def bio(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._bio != newVal:
            self._bio = newVal
            self.on_element_change()

    @property
    def goals(self):
        return self._goals

    @goals.setter
    def goals(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._goals != newVal:
            self._goals = newVal
            self.on_element_change()

    @property
    def fullName(self):
        return self._fullName

    @fullName.setter
    def fullName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._fullName != newVal:
            self._fullName = newVal
            self.on_element_change()

    @property
    def isMajor(self):
        return self._isMajor

    @isMajor.setter
    def isMajor(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._isMajor != newVal:
            self._isMajor = newVal
            self.on_element_change()

    @property
    def birthDate(self):
        return self._birthDate

    @birthDate.setter
    def birthDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._birthDate != newVal:
            self._birthDate = newVal
            self.on_element_change()

    @property
    def deathDate(self):
        return self._deathDate

    @deathDate.setter
    def deathDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._deathDate != newVal:
            self._deathDate = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.isMajor = xmlElement.get('major', None) == '1'
        self.fullName = self._get_element_text(xmlElement, 'FullName')
        self.bio = self._xml_element_to_text(xmlElement.find('Bio'))
        self.goals = self._xml_element_to_text(xmlElement.find('Goals'))
        self.birthDate = verified_date(self._get_element_text(xmlElement, 'BirthDate'))
        self.deathDate = verified_date(self._get_element_text(xmlElement, 'DeathDate'))

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.isMajor:
            xmlElement.set('major', '1')
        if self.fullName:
            ET.SubElement(xmlElement, 'FullName').text = self.fullName
        if self.bio:
            xmlElement.append(self._text_to_xml_element('Bio', self.bio))
        if self.goals:
            xmlElement.append(self._text_to_xml_element('Goals', self.goals))
        if self.birthDate:
            ET.SubElement(xmlElement, 'BirthDate').text = self.birthDate
        if self.deathDate:
            ET.SubElement(xmlElement, 'DeathDate').text = self.deathDate



class PlotLine(BasicElementNotes):

    def __init__(self,
            shortName=None,
            sections=None,
            **kwargs):
        super().__init__(**kwargs)

        self._shortName = shortName
        self._sections = sections

    @property
    def shortName(self):
        return self._shortName

    @shortName.setter
    def shortName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._shortName != newVal:
            self._shortName = newVal
            self.on_element_change()

    @property
    def sections(self):
        try:
            return self._sections[:]
        except TypeError:
            return None

    @sections.setter
    def sections(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._sections != newVal:
            self._sections = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.shortName = self._get_element_text(xmlElement, 'ShortName')
        plSections = []
        xmlSections = xmlElement.find('Sections')
        if xmlSections is not None:
            scIds = xmlSections.get('ids', None)
            if scIds is not None:
                for scId in string_to_list(scIds, divider=' '):
                    plSections.append(scId)
        self.sections = plSections

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.shortName:
            ET.SubElement(xmlElement, 'ShortName').text = self.shortName
        if self.sections:
            attrib = {'ids':' '.join(self.sections)}
            ET.SubElement(xmlElement, 'Sections', attrib=attrib)


class PlotPoint(BasicElementNotes):

    def __init__(self,
            sectionAssoc=None,
            **kwargs):
        super().__init__(**kwargs)

        self._sectionAssoc = sectionAssoc

    @property
    def sectionAssoc(self):
        return self._sectionAssoc

    @sectionAssoc.setter
    def sectionAssoc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._sectionAssoc != newVal:
            self._sectionAssoc = newVal
            self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        xmlSectionAssoc = xmlElement.find('Section')
        if xmlSectionAssoc is not None:
            self.sectionAssoc = xmlSectionAssoc.get('id', None)

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.sectionAssoc:
            ET.SubElement(xmlElement, 'Section', attrib={'id': self.sectionAssoc})
from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta
import re

from calendar import isleap
from datetime import date
from datetime import datetime
from datetime import timedelta


def difference_in_years(startDate, endDate):
    diffyears = endDate.year - startDate.year
    difference = endDate - startDate.replace(endDate.year)
    days_in_year = isleap(endDate.year) and 366 or 365
    years = diffyears + (difference.days + difference.seconds / 86400.0) / days_in_year
    return int(years)


def get_age(nowIso, birthDateIso, deathDateIso):
    now = datetime.fromisoformat(nowIso)
    if deathDateIso:
        deathDate = datetime.fromisoformat(deathDateIso)
        if now > deathDate:
            years = difference_in_years(deathDate, now)
            return -1 * years

    birthDate = datetime.fromisoformat(birthDateIso)
    years = difference_in_years(birthDate, now)
    return years


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)


ADDITIONAL_WORD_LIMITS = re.compile(r'--|—|–|\<\/p\>')

NO_WORD_LIMITS = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')


class Section(BasicElementTags):

    SCENE = ['-', 'A', 'R', 'x']

    STATUS = [
        None,
        _('Outline'),
        _('Draft'),
        _('1st Edit'),
        _('2nd Edit'),
        _('Done')
    ]

    NULL_DATE = '0001-01-01'
    NULL_TIME = '00:00:00'

    def __init__(self,
            scType=None,
            scene=None,
            status=None,
            appendToPrev=None,
            goal=None,
            conflict=None,
            outcome=None,
            plotNotes=None,
            scDate=None,
            scTime=None,
            day=None,
            lastsMinutes=None,
            lastsHours=None,
            lastsDays=None,
            characters=None,
            locations=None,
            items=None,
            **kwargs):
        super().__init__(**kwargs)
        self._sectionContent = None
        self.wordCount = 0

        self._scType = scType
        self._scene = scene
        self._status = status
        self._appendToPrev = appendToPrev
        self._goal = goal
        self._conflict = conflict
        self._outcome = outcome
        self._plotlineNotes = plotNotes
        try:
            newDate = date.fromisoformat(scDate)
            self._weekDay = newDate.weekday()
            self._localeDate = newDate.strftime('%x')
            self._date = scDate
        except:
            self._weekDay = None
            self._localeDate = None
            self._date = None
        self._time = scTime
        self._day = day
        self._lastsMinutes = lastsMinutes
        self._lastsHours = lastsHours
        self._lastsDays = lastsDays
        self._characters = characters
        self._locations = locations
        self._items = items

        self.scPlotLines = []
        self.scPlotPoints = {}

    @property
    def sectionContent(self):
        return self._sectionContent

    @sectionContent.setter
    def sectionContent(self, text):
        if text is not None:
            assert type(text) == str
        if self._sectionContent != text:
            self._sectionContent = text
            if text is not None:
                text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
                text = NO_WORD_LIMITS.sub('', text)
                wordList = text.split()
                self.wordCount = len(wordList)
            else:
                self.wordCount = 0
            self.on_element_change()

    @property
    def scType(self):
        return self._scType

    @scType.setter
    def scType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scType != newVal:
            self._scType = newVal
            self.on_element_change()

    @property
    def scene(self):
        return self._scene

    @scene.setter
    def scene(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scene != newVal:
            self._scene = newVal
            self.on_element_change()

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._status != newVal:
            self._status = newVal
            self.on_element_change()

    @property
    def appendToPrev(self):
        return self._appendToPrev

    @appendToPrev.setter
    def appendToPrev(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._appendToPrev != newVal:
            self._appendToPrev = newVal
            self.on_element_change()

    @property
    def goal(self):
        return self._goal

    @goal.setter
    def goal(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._goal != newVal:
            self._goal = newVal
            self.on_element_change()

    @property
    def conflict(self):
        return self._conflict

    @conflict.setter
    def conflict(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._conflict != newVal:
            self._conflict = newVal
            self.on_element_change()

    @property
    def outcome(self):
        return self._outcome

    @outcome.setter
    def outcome(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._outcome != newVal:
            self._outcome = newVal
            self.on_element_change()

    @property
    def plotlineNotes(self):
        try:
            return dict(self._plotlineNotes)
        except TypeError:
            return None

    @plotlineNotes.setter
    def plotlineNotes(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) == str
        if self._plotlineNotes != newVal:
            self._plotlineNotes = newVal
            self.on_element_change()

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._date != newVal:
            if not newVal:
                self._date = None
                self._weekDay = None
                self._localeDate = None
                self.on_element_change()
                return

            try:
                newDate = date.fromisoformat(newVal)
                self._weekDay = newDate.weekday()
            except:
                return

            try:
                self._localeDate = newDate.strftime('%x')
            except:
                self._localeDate = newVal
            self._date = newVal
            self.on_element_change()

    @property
    def weekDay(self):
        return self._weekDay

    @property
    def localeDate(self):
        return self._localeDate

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._time != newVal:
            self._time = newVal
            self.on_element_change()

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._day != newVal:
            self._day = newVal
            self.on_element_change()

    @property
    def lastsMinutes(self):
        return self._lastsMinutes

    @lastsMinutes.setter
    def lastsMinutes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsMinutes != newVal:
            self._lastsMinutes = newVal
            self.on_element_change()

    @property
    def lastsHours(self):
        return self._lastsHours

    @lastsHours.setter
    def lastsHours(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsHours != newVal:
            self._lastsHours = newVal
            self.on_element_change()

    @property
    def lastsDays(self):
        return self._lastsDays

    @lastsDays.setter
    def lastsDays(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsDays != newVal:
            self._lastsDays = newVal
            self.on_element_change()

    @property
    def characters(self):
        try:
            return self._characters[:]
        except TypeError:
            return None

    @characters.setter
    def characters(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._characters != newVal:
            self._characters = newVal
            self.on_element_change()

    @property
    def locations(self):
        try:
            return self._locations[:]
        except TypeError:
            return None

    @locations.setter
    def locations(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._locations != newVal:
            self._locations = newVal
            self.on_element_change()

    @property
    def items(self):
        try:
            return self._items[:]
        except TypeError:
            return None

    @items.setter
    def items(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._items != newVal:
            self._items = newVal
            self.on_element_change()

    def day_to_date(self, referenceDate):
        if self._date:
            return True

        try:
            self.date = get_specific_date(self._day, referenceDate)
            self._day = None
            return True

        except:
            self.date = None
            return False

    def date_to_day(self, referenceDate):
        if self._day:
            return True

        try:
            self._day = get_unspecific_date(self._date, referenceDate)
            self.date = None
            return True

        except:
            self._day = None
            return False

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)

        typeStr = xmlElement.get('type', '0')
        if typeStr in ('0', '1', '2', '3'):
            self.scType = int(typeStr)
        else:
            self.scType = 1
        status = xmlElement.get('status', None)
        if status in ('2', '3', '4', '5'):
            self.status = int(status)
        else:
            self.status = 1
        scene = xmlElement.get('scene', 0)
        if scene in ('1', '2', '3'):
            self.scene = int(scene)
        else:
            self.scene = 0

        if not self.scene:
            sceneKind = xmlElement.get('pacing', None)
            if sceneKind in ('1', '2'):
                self.scene = int(sceneKind) + 1

        self.appendToPrev = xmlElement.get('append', None) == '1'

        self.goal = self._xml_element_to_text(xmlElement.find('Goal'))
        self.conflict = self._xml_element_to_text(xmlElement.find('Conflict'))
        self.outcome = self._xml_element_to_text(xmlElement.find('Outcome'))

        xmlPlotNotes = xmlElement.find('PlotNotes')
        if xmlPlotNotes is None:
            xmlPlotNotes = xmlElement
        plotNotes = {}
        for xmlPlotLineNote in xmlPlotNotes.iterfind('PlotlineNotes'):
            plId = xmlPlotLineNote.get('id', None)
            plotNotes[plId] = self._xml_element_to_text(xmlPlotLineNote)
        self.plotlineNotes = plotNotes

        if xmlElement.find('Date') is not None:
            self.date = verified_date(xmlElement.find('Date').text)
        elif xmlElement.find('Day') is not None:
            self.day = verified_int_string(xmlElement.find('Day').text)

        if xmlElement.find('Time') is not None:
            self.time = verified_time(xmlElement.find('Time').text)

        self.lastsDays = verified_int_string(self._get_element_text(xmlElement, 'LastsDays'))
        self.lastsHours = verified_int_string(self._get_element_text(xmlElement, 'LastsHours'))
        self.lastsMinutes = verified_int_string(self._get_element_text(xmlElement, 'LastsMinutes'))

        scCharacters = []
        xmlCharacters = xmlElement.find('Characters')
        if xmlCharacters is not None:
            crIds = xmlCharacters.get('ids', None)
            if crIds is not None:
                for crId in string_to_list(crIds, divider=' '):
                    scCharacters.append(crId)
        self.characters = scCharacters

        scLocations = []
        xmlLocations = xmlElement.find('Locations')
        if xmlLocations is not None:
            lcIds = xmlLocations.get('ids', None)
            if lcIds is not None:
                for lcId in string_to_list(lcIds, divider=' '):
                    scLocations.append(lcId)
        self.locations = scLocations

        scItems = []
        xmlItems = xmlElement.find('Items')
        if xmlItems is not None:
            itIds = xmlItems.get('ids', None)
            if itIds is not None:
                for itId in string_to_list(itIds, divider=' '):
                    scItems.append(itId)
        self.items = scItems

        xmlContent = xmlElement.find('Content')
        if xmlContent is not None:
            xmlStr = ET.tostring(
                xmlContent,
                encoding='utf-8',
                short_empty_elements=False
                ).decode('utf-8')
            xmlStr = xmlStr.replace('<Content>', '').replace('</Content>', '')

            lines = xmlStr.split('\n')
            newlines = []
            for line in lines:
                newlines.append(line.strip())
            xmlStr = ''.join(newlines)
            if xmlStr:
                self.sectionContent = xmlStr
            else:
                self.sectionContent = '<p></p>'
        elif self.scType < 2:
            self.sectionContent = '<p></p>'

    def get_end_date_time(self):
        endDate = None
        endTime = None
        endDay = None
        if self.lastsDays:
            lastsDays = int(self.lastsDays)
        else:
            lastsDays = 0
        if self.lastsHours:
            lastsSeconds = int(self.lastsHours) * 3600
        else:
            lastsSeconds = 0
        if self.lastsMinutes:
            lastsSeconds += int(self.lastsMinutes) * 60
        sectionDuration = timedelta(days=lastsDays, seconds=lastsSeconds)
        if self.time:
            if self.date:
                try:
                    sectionStart = datetime.fromisoformat(f'{self.date} {self.time}')
                    sectionEnd = sectionStart + sectionDuration
                    endDate, endTime = sectionEnd.isoformat().split('T')
                except:
                    pass
            else:
                try:
                    if self.day:
                        dayInt = int(self.day)
                    else:
                        dayInt = 0
                    startDate = (date.min + timedelta(days=dayInt)).isoformat()
                    sectionStart = datetime.fromisoformat(f'{startDate} {self.time}')
                    sectionEnd = sectionStart + sectionDuration
                    endDate, endTime = sectionEnd.isoformat().split('T')
                    endDay = str((date.fromisoformat(endDate) - date.min).days)
                    endDate = None
                except:
                    pass
        return endDate, endTime, endDay

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.scType:
            xmlElement.set('type', str(self.scType))
        if self.status > 1:
            xmlElement.set('status', str(self.status))
        if self.scene > 0:
            xmlElement.set('scene', str(self.scene))
        if self.appendToPrev:
            xmlElement.set('append', '1')

        if self.goal:
            xmlElement.append(self._text_to_xml_element('Goal', self.goal))
        if self.conflict:
            xmlElement.append(self._text_to_xml_element('Conflict', self.conflict))
        if self.outcome:
            xmlElement.append(self._text_to_xml_element('Outcome', self.outcome))

        if self.plotlineNotes:
            for plId in self.plotlineNotes:
                if not plId in self.scPlotLines:
                    continue

                if not self.plotlineNotes[plId]:
                    continue

                xmlPlotlineNotes = self._text_to_xml_element('PlotlineNotes', self.plotlineNotes[plId])
                xmlPlotlineNotes.set('id', plId)
                xmlElement.append(xmlPlotlineNotes)

        if self.date:
            ET.SubElement(xmlElement, 'Date').text = self.date
        elif self.day:
            ET.SubElement(xmlElement, 'Day').text = self.day
        if self.time:
            ET.SubElement(xmlElement, 'Time').text = self.time

        if self.lastsDays and self.lastsDays != '0':
            ET.SubElement(xmlElement, 'LastsDays').text = self.lastsDays
        if self.lastsHours and self.lastsHours != '0':
            ET.SubElement(xmlElement, 'LastsHours').text = self.lastsHours
        if self.lastsMinutes and self.lastsMinutes != '0':
            ET.SubElement(xmlElement, 'LastsMinutes').text = self.lastsMinutes

        if self.characters:
            attrib = {'ids':' '.join(self.characters)}
            ET.SubElement(xmlElement, 'Characters', attrib=attrib)

        if self.locations:
            attrib = {'ids':' '.join(self.locations)}
            ET.SubElement(xmlElement, 'Locations', attrib=attrib)

        if self.items:
            attrib = {'ids':' '.join(self.items)}
            ET.SubElement(xmlElement, 'Items', attrib=attrib)

        sectionContent = self.sectionContent
        if sectionContent:
            if not sectionContent in ('<p></p>', '<p />'):
                xmlElement.append(ET.fromstring(f'<Content>{sectionContent}</Content>'))


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



def indent(elem, level=0):
    PARAGRAPH_LEVEL = 5

    i = f'\n{level * "  "}'
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        if level < PARAGRAPH_LEVEL:
            for elem in elem:
                indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def get_xml_root(filePath):
    try:
        xmlTree = ET.parse(filePath)
    except Exception as ex:
        raise Error(f'{_("Cannot process file")}: "{norm_path(filePath)}" - {str(ex)}')

    return xmlTree.getroot()


class NovxFile(File):
    DESCRIPTION = _('novelibre project')
    EXTENSION = '.novx'

    MAJOR_VERSION = 1
    MINOR_VERSION = 4

    XML_HEADER = f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE novx SYSTEM "novx_{MAJOR_VERSION}_{MINOR_VERSION}.dtd">
<?xml-stylesheet href="novx.css" type="text/css"?>
'''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.on_element_change = None
        self.xmlTree = None

        self.wcLog = {}

        self.wcLogUpdate = {}

        self.timestamp = None

    def adjust_section_types(self):
        partType = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chLevel == 1:
                partType = self.novel.chapters[chId].chType
            elif partType != 0 and not self.novel.chapters[chId].isTrash:
                self.novel.chapters[chId].chType = partType
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType < self.novel.chapters[chId].chType:
                    self.novel.sections[scId].scType = self.novel.chapters[chId].chType

    def count_words(self):
        count = 0
        totalCount = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if not self.novel.chapters[chId].isTrash:
                for scId in self.novel.tree.get_children(chId):
                    if self.novel.sections[scId].scType < 2:
                        totalCount += self.novel.sections[scId].wordCount
                        if self.novel.sections[scId].scType == 0:
                            count += self.novel.sections[scId].wordCount
        return count, totalCount

    def read(self):
        xmlRoot = get_xml_root(self.filePath)
        self._check_version(xmlRoot)
        try:
            locale = xmlRoot.attrib['{http://www.w3.org/XML/1998/namespace}lang']
            self.novel.languageCode, self.novel.countryCode = locale.split('-')
        except:
            pass
        self.novel.tree.reset()
        try:
            self._read_project(xmlRoot)
            self._read_locations(xmlRoot)
            self._read_items(xmlRoot)
            self._read_characters(xmlRoot)
            self._read_chapters_and_sections(xmlRoot)
            self._read_plot_lines_and_points(xmlRoot)
            self._read_project_notes(xmlRoot)
            self.adjust_section_types()
            self._read_word_count_log(xmlRoot)
        except Exception as ex:
            raise Error(f"{_('Corrupt project data')} ({str(ex)})")
        self._get_timestamp()
        self._keep_word_count()

    def write(self):
        self._update_word_count_log()
        self.adjust_section_types()
        self.novel.get_languages()

        attrib = {
            'version':f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}',
            'xml:lang':f'{self.novel.languageCode}-{self.novel.countryCode}',
        }
        xmlRoot = ET.Element('novx', attrib=attrib)
        self._build_project(xmlRoot)
        self._build_chapters_and_sections(xmlRoot)
        self._build_characters(xmlRoot)
        self._build_locations(xmlRoot)
        self._build_items(xmlRoot)
        self._build_plot_lines_and_points(xmlRoot)
        self._build_project_notes(xmlRoot)
        self._build_word_count_log(xmlRoot)

        indent(xmlRoot)

        self.xmlTree = ET.ElementTree(xmlRoot)
        self._write_element_tree(self)
        self._postprocess_xml_file(self.filePath)
        self._get_timestamp()

    def _build_project(self, root):
        xmlProject = ET.SubElement(root, 'PROJECT')
        self.novel.to_xml(xmlProject)

    def _build_chapters_and_sections(self, root):
        xmlChapters = ET.SubElement(root, 'CHAPTERS')
        for chId in self.novel.tree.get_children(CH_ROOT):
            xmlChapter = ET.SubElement(xmlChapters, 'CHAPTER', attrib={'id':chId})
            self.novel.chapters[chId].to_xml(xmlChapter)
            for scId in self.novel.tree.get_children(chId):
                self.novel.sections[scId].to_xml(ET.SubElement(xmlChapter, 'SECTION', attrib={'id':scId}))

    def _build_characters(self, root):
        xmlCharacters = ET.SubElement(root, 'CHARACTERS')
        for crId in self.novel.tree.get_children(CR_ROOT):
            self.novel.characters[crId].to_xml(ET.SubElement(xmlCharacters, 'CHARACTER', attrib={'id':crId}))

    def _build_locations(self, root):
        xmlLocations = ET.SubElement(root, 'LOCATIONS')
        for lcId in self.novel.tree.get_children(LC_ROOT):
            self.novel.locations[lcId].to_xml(ET.SubElement(xmlLocations, 'LOCATION', attrib={'id':lcId}))

    def _build_items(self, root):
        xmlItems = ET.SubElement(root, 'ITEMS')
        for itId in self.novel.tree.get_children(IT_ROOT):
            self.novel.items[itId].to_xml(ET.SubElement(xmlItems, 'ITEM', attrib={'id':itId}))

    def _build_plot_lines_and_points(self, root):
        xmlPlotLines = ET.SubElement(root, 'ARCS')
        for plId in self.novel.tree.get_children(PL_ROOT):
            xmlPlotLine = ET.SubElement(xmlPlotLines, 'ARC', attrib={'id':plId})
            self.novel.plotLines[plId].to_xml(xmlPlotLine)
            for ppId in self.novel.tree.get_children(plId):
                self.novel.plotPoints[ppId].to_xml(ET.SubElement(xmlPlotLine, 'POINT', attrib={'id':ppId}))

    def _build_project_notes(self, root):
        xmlProjectNotes = ET.SubElement(root, 'PROJECTNOTES')
        for pnId in self.novel.tree.get_children(PN_ROOT):
            self.novel.projectNotes[pnId].to_xml(ET.SubElement(xmlProjectNotes, 'PROJECTNOTE', attrib={'id':pnId}))

    def _build_word_count_log(self, root):
        if not self.wcLog:
            return

        xmlWcLog = ET.SubElement(root, 'PROGRESS')
        wcLastCount = None
        wcLastTotalCount = None
        for wc in self.wcLog:
            if self.novel.saveWordCount:
                if self.wcLog[wc][0] == wcLastCount and self.wcLog[wc][1] == wcLastTotalCount:
                    continue

                wcLastCount = self.wcLog[wc][0]
                wcLastTotalCount = self.wcLog[wc][1]
            xmlWc = ET.SubElement(xmlWcLog, 'WC')
            ET.SubElement(xmlWc, 'Date').text = wc
            ET.SubElement(xmlWc, 'Count').text = self.wcLog[wc][0]
            ET.SubElement(xmlWc, 'WithUnused').text = self.wcLog[wc][1]

    def _check_id(self, elemId, elemPrefix):
        if not elemId.startswith(elemPrefix):
            raise Error(f"bad ID: '{elemId}'")

    def _check_version(self, xmlRoot):
        if xmlRoot.tag != 'novx':
            raise Error(f'{_("No valid xml root element found in file")}: "{norm_path(self.filePath)}".')
        try:
            majorVersionStr, minorVersionStr = xmlRoot.attrib['version'].split('.')
            majorVersion = int(majorVersionStr)
            minorVersion = int(minorVersionStr)
        except:
            raise Error(f'{_("No valid version found in file")}: "{norm_path(self.filePath)}".')
        if majorVersion > self.MAJOR_VERSION:
            raise Error(_('The project "{}" was created with a newer novelibre version.').format(norm_path(self.filePath)))
        elif majorVersion < self.MAJOR_VERSION:
            raise Error(_('The project "{}" was created with an outdated novelibre version.').format(norm_path(self.filePath)))
        elif minorVersion > self.MINOR_VERSION:
            raise Error(_('The project "{}" was created with a newer novelibre version.').format(norm_path(self.filePath)))

    def _get_timestamp(self):
        try:
            self.timestamp = os.path.getmtime(self.filePath)
        except:
            self.timestamp = None

    def _keep_word_count(self):
        if not self.wcLog:
            return

        actualCountInt, actualTotalCountInt = self.count_words()
        actualCount = str(actualCountInt)
        actualTotalCount = str(actualTotalCountInt)
        latestDate = list(self.wcLog)[-1]
        latestCount = self.wcLog[latestDate][0]
        latestTotalCount = self.wcLog[latestDate][1]
        if actualCount != latestCount or actualTotalCount != latestTotalCount:
            try:
                fileDateIso = date.fromtimestamp(self.timestamp).isoformat()
            except:
                fileDateIso = date.today().isoformat()
            self.wcLogUpdate[fileDateIso] = [actualCount, actualTotalCount]

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
            text = strip_illegal_characters(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def _read_chapters_and_sections(self, root):
        xmlChapters = root.find('CHAPTERS')
        if xmlChapters is None:
            return

        for xmlChapter in xmlChapters.iterfind('CHAPTER'):
            chId = xmlChapter.attrib['id']
            self._check_id(chId, CHAPTER_PREFIX)
            self.novel.chapters[chId] = Chapter(on_element_change=self.on_element_change)
            self.novel.chapters[chId].from_xml(xmlChapter)
            self.novel.tree.append(CH_ROOT, chId)

            for xmlSection in xmlChapter.iterfind('SECTION'):
                scId = xmlSection.attrib['id']
                self._check_id(scId, SECTION_PREFIX)
                self._read_section(xmlSection, scId)
                self.novel.tree.append(chId, scId)

    def _read_characters(self, root):
        xmlCharacters = root.find('CHARACTERS')
        if xmlCharacters is None:
            return

        for xmlCharacter in xmlCharacters.iterfind('CHARACTER'):
            crId = xmlCharacter.attrib['id']
            self._check_id(crId, CHARACTER_PREFIX)
            self.novel.characters[crId] = Character(on_element_change=self.on_element_change)
            self.novel.characters[crId].from_xml(xmlCharacter)
            self.novel.tree.append(CR_ROOT, crId)

    def _read_items(self, root):
        xmlItems = root.find('ITEMS')
        if xmlItems is None:
            return

        for xmlItem in xmlItems.iterfind('ITEM'):
            itId = xmlItem.attrib['id']
            self._check_id(itId, ITEM_PREFIX)
            self.novel.items[itId] = WorldElement(on_element_change=self.on_element_change)
            self.novel.items[itId].from_xml(xmlItem)
            self.novel.tree.append(IT_ROOT, itId)

    def _read_locations(self, root):
        xmlLocations = root.find('LOCATIONS')
        if xmlLocations is None:
            return

        for xmlLocation in xmlLocations.iterfind('LOCATION'):
            lcId = xmlLocation.attrib['id']
            self._check_id(lcId, LOCATION_PREFIX)
            self.novel.locations[lcId] = WorldElement(on_element_change=self.on_element_change)
            self.novel.locations[lcId].from_xml(xmlLocation)
            self.novel.tree.append(LC_ROOT, lcId)

    def _read_plot_lines_and_points(self, root):
        xmlPlotLines = root.find('ARCS')
        if xmlPlotLines is None:
            return

        for xmlPlotLine in xmlPlotLines.iterfind('ARC'):
            plId = xmlPlotLine.attrib['id']
            self._check_id(plId, PLOT_LINE_PREFIX)
            self.novel.plotLines[plId] = PlotLine(on_element_change=self.on_element_change)
            self.novel.plotLines[plId].from_xml(xmlPlotLine)
            self.novel.tree.append(PL_ROOT, plId)

            self.novel.plotLines[plId].sections = intersection(self.novel.plotLines[plId].sections, self.novel.sections)

            for scId in self.novel.plotLines[plId].sections:
                self.novel.sections[scId].scPlotLines.append(plId)

            for xmlPlotPoint in xmlPlotLine.iterfind('POINT'):
                ppId = xmlPlotPoint.attrib['id']
                self._check_id(ppId, PLOT_POINT_PREFIX)
                self._read_plot_point(xmlPlotPoint, ppId, plId)
                self.novel.tree.append(plId, ppId)

    def _read_plot_point(self, xmlPlotPoint, ppId, plId):
        self.novel.plotPoints[ppId] = PlotPoint(on_element_change=self.on_element_change)
        self.novel.plotPoints[ppId].from_xml(xmlPlotPoint)

        scId = self.novel.plotPoints[ppId].sectionAssoc
        if scId in self.novel.sections:
            self.novel.sections[scId].scPlotPoints[ppId] = plId
        else:
            self.novel.plotPoints[ppId].sectionAssoc = None

    def _read_project(self, root):
        xmlProject = root.find('PROJECT')
        if xmlProject is None:
            return

        self.novel.from_xml(xmlProject)

    def _read_project_notes(self, root):
        xmlProjectNotes = root.find('PROJECTNOTES')
        if xmlProjectNotes is None:
            return

        for xmlProjectNote in xmlProjectNotes.iterfind('PROJECTNOTE'):
            pnId = xmlProjectNote.attrib['id']
            self._check_id(pnId, PRJ_NOTE_PREFIX)
            self.novel.projectNotes[pnId] = BasicElement()
            self.novel.projectNotes[pnId].from_xml(xmlProjectNote)
            self.novel.tree.append(PN_ROOT, pnId)

    def _read_section(self, xmlSection, scId):
        self.novel.sections[scId] = Section(on_element_change=self.on_element_change)
        self.novel.sections[scId].from_xml(xmlSection)

        self.novel.sections[scId].characters = intersection(self.novel.sections[scId].characters, self.novel.characters)
        self.novel.sections[scId].locations = intersection(self.novel.sections[scId].locations, self.novel.locations)
        self.novel.sections[scId].items = intersection(self.novel.sections[scId].items, self.novel.items)

    def _read_word_count_log(self, xmlRoot):
        xmlWclog = xmlRoot.find('PROGRESS')
        if xmlWclog is None:
            return

        for xmlWc in xmlWclog.iterfind('WC'):
            wcDate = verified_date(xmlWc.find('Date').text)
            wcCount = verified_int_string(xmlWc.find('Count').text)
            wcTotalCount = verified_int_string(xmlWc.find('WithUnused').text)
            if wcDate and wcCount and wcTotalCount:
                self.wcLog[wcDate] = [wcCount, wcTotalCount]

    def _update_word_count_log(self):
        if self.novel.saveWordCount:
            newCountInt, newTotalCountInt = self.count_words()
            newCount = str(newCountInt)
            newTotalCount = str(newTotalCountInt)
            todayIso = date.today().isoformat()
            self.wcLogUpdate[todayIso] = [newCount, newTotalCount]
            for wcDate in self.wcLogUpdate:
                self.wcLog[wcDate] = self.wcLogUpdate[wcDate]
        self.wcLogUpdate = {}

    def _write_element_tree(self, xmlProject):
        backedUp = False
        if os.path.isfile(xmlProject.filePath):
            try:
                os.replace(xmlProject.filePath, f'{xmlProject.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(xmlProject.filePath)}".')
            else:
                backedUp = True
        try:
            xmlProject.xmlTree.write(xmlProject.filePath, xml_declaration=False, encoding='utf-8')
        except:
            if backedUp:
                os.replace(f'{xmlProject.filePath}.bak', xmlProject.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(xmlProject.filePath)}".')



class DataWriter(NovxFile):
    DESCRIPTION = _('novelibre XML data files')
    EXTENSION = '.xml'
    SUFFIX = DATA_SUFFIX

    XML_HEADER = '''<?xml version="1.0" encoding="utf-8"?>
'''

    def _postprocess_xml_file(self, filePath):
        '''Postprocess three xml files created by ElementTree.
        
        Positional argument:
            filePath: str -- path to .novx xml file.
            
        Generate the xml file paths from the .novx path. 
        Read, postprocess and write the characters, locations, and items xml files.        
        Extends the superclass method.
        '''
        path, __ = os.path.splitext(filePath)
        characterPath = f'{path}_Characters.xml'
        super()._postprocess_xml_file(characterPath)
        locationPath = f'{path}_Locations.xml'
        super()._postprocess_xml_file(locationPath)
        itemPath = f'{path}_Items.xml'
        super()._postprocess_xml_file(itemPath)

    def _write_element_tree(self, xmlProject):
        path, __ = os.path.splitext(xmlProject.filePath)
        characterPath = f'{path}_Characters.xml'
        characterSubtree = xmlProject.xmlTree.find('CHARACTERS')
        characterTree = ET.ElementTree(characterSubtree)
        try:
            characterTree.write(characterPath, xml_declaration=False, encoding='utf-8')
        except(PermissionError):
            raise Error(f'{_("File is write protected")}: "{norm_path(characterPath)}".')

        locationPath = f'{path}_Locations.xml'
        locationSubtree = xmlProject.xmlTree.find('LOCATIONS')
        locationTree = ET.ElementTree(locationSubtree)
        try:
            locationTree.write(locationPath, xml_declaration=False, encoding='utf-8')
        except(PermissionError):
            raise Error(f'{_("File is write protected")}: "{norm_path(locationPath)}".')

        itemPath = f'{path}_Items.xml'
        itemSubtree = xmlProject.xmlTree.find('ITEMS')
        itemTree = ET.ElementTree(itemSubtree)
        try:
            itemTree.write(itemPath, xml_declaration=False, encoding='utf-8')
        except(PermissionError):
            raise Error(f'{_("File is write protected")}: "{norm_path(itemPath)}".')

from datetime import datetime
from shutil import rmtree
from string import Template
import tempfile
import zipfile

from string import Template



class Filter:

    def accept(self, source, eId):
        return True

    def get_message(self, source):
        return ''


class FileExport(File):
    SUFFIX = ''
    _fileHeader = ''
    _partTemplate = ''
    _chapterTemplate = ''
    _unusedChapterTemplate = ''
    _sectionTemplate = ''
    _firstSectionTemplate = ''
    _unusedSectionTemplate = ''
    _stage1Template = ''
    _stage2Template = ''
    _sectionDivider = ''
    _chapterEndTemplate = ''
    _unusedChapterEndTemplate = ''
    _characterSectionHeading = ''
    _characterTemplate = ''
    _locationSectionHeading = ''
    _locationTemplate = ''
    _itemSectionHeading = ''
    _itemTemplate = ''
    _fileFooter = ''
    _projectNoteTemplate = ''
    _arcTemplate = ''

    _DIVIDER = ', '

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self.sectionFilter = Filter()
        self.chapterFilter = Filter()
        self.characterFilter = Filter()
        self.locationFilter = Filter()
        self.itemFilter = Filter()
        self.arcFilter = Filter()
        self.turningPointFilter = Filter()

    def write(self):
        text = self._get_text()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

    def _convert_from_novx(self, text, **kwargs):
        if text is None:
            text = ''
        return(text)

    def _get_arcMapping(self, plId):
        arcMapping = dict(
            ID=plId,
            Title=self._convert_from_novx(self.novel.plotLines[plId].title, quick=True),
            Desc=self._convert_from_novx(self.novel.plotLines[plId].desc),
            Notes=self._convert_from_novx(self.novel.plotLines[plId].notes),
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        return arcMapping

    def _get_arcs(self):
        lines = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            if self.arcFilter.accept(self, plId):
                if self._arcTemplate:
                    template = Template(self._arcTemplate)
                    lines.append(template.safe_substitute(self._get_arcMapping(plId)))
        return lines

    def _get_chapterMapping(self, chId, chapterNumber):
        if chapterNumber == 0:
            chapterNumber = ''

        chapterMapping = dict(
            ID=chId,
            ChapterNumber=chapterNumber,
            Title=self._convert_from_novx(self.novel.chapters[chId].title, quick=True),
            Desc=self._convert_from_novx(self.novel.chapters[chId].desc),
            Notes=self._convert_from_novx(self.novel.chapters[chId].notes),
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
            ManuscriptSuffix=MANUSCRIPT_SUFFIX,
        )
        return chapterMapping

    def _get_chapters(self):
        lines = []
        chapterNumber = 0
        sectionNumber = 0
        wordsTotal = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            dispNumber = 0
            if not self.chapterFilter.accept(self, chId):
                continue

            template = None
            if self.novel.chapters[chId].chType == 1:
                if self._unusedChapterTemplate:
                    template = Template(self._unusedChapterTemplate)
            elif self.novel.chapters[chId].chLevel == 1 and self._partTemplate:
                template = Template(self._partTemplate)
            else:
                template = Template(self._chapterTemplate)
                chapterNumber += 1
                dispNumber = chapterNumber
            if template is not None:
                lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))

            sectionLines, sectionNumber, wordsTotal = self._get_sections(chId, sectionNumber, wordsTotal)
            lines.extend(sectionLines)

            template = None
            if self.novel.chapters[chId].chType == 1:
                if self._unusedChapterEndTemplate:
                    template = Template(self._unusedChapterEndTemplate)
            elif self._chapterEndTemplate:
                template = Template(self._chapterEndTemplate)
            if template is not None:
                lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))
        return lines

    def _get_characterMapping(self, crId):
        if self.novel.characters[crId].tags is not None:
            tags = list_to_string(self.novel.characters[crId].tags, divider=self._DIVIDER)
        else:
            tags = ''
        if self.novel.characters[crId].isMajor:
            characterStatus = Character.MAJOR_MARKER
        else:
            characterStatus = Character.MINOR_MARKER

        __, __, __, __, __, __, chrBio, chrGls = self._get_renamings()

        characterMapping = dict(
            ID=crId,
            Title=self._convert_from_novx(self.novel.characters[crId].title, quick=True),
            Desc=self._convert_from_novx(self.novel.characters[crId].desc),
            Tags=self._convert_from_novx(tags),
            AKA=self._convert_from_novx(self.novel.characters[crId].aka, quick=True),
            Notes=self._convert_from_novx(self.novel.characters[crId].notes),
            Bio=self._convert_from_novx(self.novel.characters[crId].bio),
            Goals=self._convert_from_novx(self.novel.characters[crId].goals),
            FullName=self._convert_from_novx(self.novel.characters[crId].fullName, quick=True),
            Status=characterStatus,
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            CharactersSuffix=CHARACTERS_SUFFIX,
            CustomChrBio=chrBio,
            CustomChrGoals=chrGls
        )
        return characterMapping

    def _get_characters(self):
        if self._characterSectionHeading:
            lines = [self._characterSectionHeading]
        else:
            lines = []
        template = Template(self._characterTemplate)
        for crId in self.novel.tree.get_children(CR_ROOT):
            if self.characterFilter.accept(self, crId):
                lines.append(template.safe_substitute(self._get_characterMapping(crId)))
        return lines

    def _get_fileFooter(self):
        lines = []
        template = Template(self._fileFooter)
        lines.append(template.safe_substitute(self._get_fileFooterMapping()))
        return lines

    def _get_fileFooterMapping(self):
        return []

    def _get_fileHeader(self):
        lines = []
        template = Template(self._fileHeader)
        lines.append(template.safe_substitute(self._get_fileHeaderMapping()))
        return lines

    def _get_fileHeaderMapping(self):
        filterMessages = []
        expFilters = [
            self.chapterFilter,
            self.sectionFilter,
            self.characterFilter,
            self.locationFilter,
            self.itemFilter,
            self.arcFilter,
            self.turningPointFilter,
            ]
        for expFilter in expFilters:
            message = expFilter.get_message(self)
            if message:
                filterMessages.append(message)
            if filterMessages:
                filters = self._convert_from_novx('\n'.join(filterMessages))
            else:
                filters = ''
            pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()

        fileHeaderMapping = dict(
            Title=self._convert_from_novx(self.novel.title, quick=True),
            Filters=filters,
            Desc=self._convert_from_novx(self.novel.desc),
            AuthorName=self._convert_from_novx(self.novel.authorName, quick=True),
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
            CustomPlotProgress=pltPrgs,
            CustomCharacterization=chrczn,
            CustomWorldBuilding=wrldbld,
            CustomGoal=goal,
            CustomConflict=cflct,
            CustomOutcome=outcm,
            CustomChrBio=chrBio,
            CustomChrGoals=chrGls
        )
        return fileHeaderMapping

    def _get_itemMapping(self, itId):
        if self.novel.items[itId].tags is not None:
            tags = list_to_string(self.novel.items[itId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        itemMapping = dict(
            ID=itId,
            Title=self._convert_from_novx(self.novel.items[itId].title, quick=True),
            Desc=self._convert_from_novx(self.novel.items[itId].desc),
            Notes=self._convert_from_novx(self.novel.items[itId].notes),
            Tags=self._convert_from_novx(tags, quick=True),
            AKA=self._convert_from_novx(self.novel.items[itId].aka, quick=True),
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            ItemsSuffix=ITEMS_SUFFIX,
        )
        return itemMapping

    def _get_items(self):
        if self._itemSectionHeading:
            lines = [self._itemSectionHeading]
        else:
            lines = []
        template = Template(self._itemTemplate)
        for itId in self.novel.tree.get_children(IT_ROOT):
            if self.itemFilter.accept(self, itId):
                lines.append(template.safe_substitute(self._get_itemMapping(itId)))
        return lines

    def _get_locationMapping(self, lcId):
        if self.novel.locations[lcId].tags is not None:
            tags = list_to_string(self.novel.locations[lcId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        locationMapping = dict(
            ID=lcId,
            Title=self._convert_from_novx(self.novel.locations[lcId].title, quick=True),
            Desc=self._convert_from_novx(self.novel.locations[lcId].desc),
            Notes=self._convert_from_novx(self.novel.locations[lcId].notes),
            Tags=self._convert_from_novx(tags, quick=True),
            AKA=self._convert_from_novx(self.novel.locations[lcId].aka, quick=True),
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            LocationsSuffix=LOCATIONS_SUFFIX,
        )
        return locationMapping

    def _get_locations(self):
        if self._locationSectionHeading:
            lines = [self._locationSectionHeading]
        else:
            lines = []
        template = Template(self._locationTemplate)
        for lcId in self.novel.tree.get_children(LC_ROOT):
            if self.locationFilter.accept(self, lcId):
                lines.append(template.safe_substitute(self._get_locationMapping(lcId)))
        return lines

    def _get_renamings(self):
        if self.novel.customPlotProgress:
            pltPrgs = self.novel.customPlotProgress
        else:
            pltPrgs = _('Plot progress')
        if self.novel.customCharacterization:
            chrczn = self.novel.customCharacterization
        else:
            chrczn = _('Characterization')
        if self.novel.customWorldBuilding:
            wrldbld = self.novel.customWorldBuilding
        else:
            wrldbld = _('World building')
        if self.novel.customGoal:
            goal = self.novel.customGoal
        else:
            goal = _('Opening')
        if self.novel.customConflict:
            cflct = self.novel.customConflict
        else:
            cflct = _('Peak em. moment')
        if self.novel.customOutcome:
            outcm = self.novel.customOutcome
        else:
            outcm = _('Ending')
        if self.novel.customChrBio:
            chrBio = self.novel.customChrBio
        else:
            chrBio = _('Bio')
        if self.novel.customChrGoals:
            chrGls = self.novel.customChrGoals
        else:
            chrGls = _('Goals')
        return pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, firstInChapter=False):

        if sectionNumber == 0:
            sectionNumber = ''
        if self.novel.sections[scId].tags is not None:
            tags = list_to_string(self.novel.sections[scId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        if self.novel.sections[scId].characters is not None:
            sChList = []
            for crId in self.novel.sections[scId].characters:
                sChList.append(self.novel.characters[crId].title)
            sectionChars = list_to_string(sChList, divider=self._DIVIDER)

            if sChList:
                viewpointChar = sChList[0]
            else:
                viewpointChar = ''
        else:
            sectionChars = ''
            viewpointChar = ''

        if self.novel.sections[scId].locations is not None:
            sLcList = []
            for lcId in self.novel.sections[scId].locations:
                sLcList.append(self.novel.locations[lcId].title)
            sectionLocs = list_to_string(sLcList, divider=self._DIVIDER)
        else:
            sectionLocs = ''

        if self.novel.sections[scId].items is not None:
            sItList = []
            for itId in self.novel.sections[scId].items:
                sItList.append(self.novel.items[itId].title)
            sectionItems = list_to_string(sItList, divider=self._DIVIDER)
        else:
            sectionItems = ''

        if self.novel.sections[scId].date is not None and self.novel.sections[scId].date != Section.NULL_DATE:
            scDay = ''
            isoDate = self.novel.sections[scId].date
            cmbDate = self.novel.sections[scId].localeDate
            yearStr, monthStr, dayStr = isoDate.split('-')
            dtMonth = MONTHS[int(monthStr) - 1]
            dtWeekday = WEEKDAYS[self.novel.sections[scId].weekDay]
        else:
            isoDate = ''
            yearStr = ''
            monthStr = ''
            dayStr = ''
            dtMonth = ''
            dtWeekday = ''
            if self.novel.sections[scId].day is not None:
                scDay = self.novel.sections[scId].day
                cmbDate = f'{_("Day")} {self.novel.sections[scId].day}'
            else:
                scDay = ''
                cmbDate = ''

        if self.novel.sections[scId].time is not None:
            h, m, s = self.novel.sections[scId].time.split(':')
            scTime = f'{h}:{m}'
            odsTime = f'PT{h}H{m}M{s}S'
        else:
            scTime = ''
            odsTime = ''

        if self.novel.sections[scId].lastsDays is not None and self.novel.sections[scId].lastsDays != '0':
            lastsDays = self.novel.sections[scId].lastsDays
            days = f'{self.novel.sections[scId].lastsDays}d '
        else:
            lastsDays = ''
            days = ''

        if self.novel.sections[scId].lastsHours is not None and self.novel.sections[scId].lastsHours != '0':
            lastsHours = self.novel.sections[scId].lastsHours
            hours = f'{self.novel.sections[scId].lastsHours}h '
        else:
            lastsHours = ''
            hours = ''

        if self.novel.sections[scId].lastsMinutes is not None and self.novel.sections[scId].lastsMinutes != '0':
            lastsMinutes = self.novel.sections[scId].lastsMinutes
            minutes = f'{self.novel.sections[scId].lastsMinutes}min'
        else:
            lastsMinutes = ''
            minutes = ''

        duration = f'{days}{hours}{minutes}'

        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, __, __ = self._get_renamings()
        sectionMapping = dict(
            ID=scId,
            SectionNumber=sectionNumber,
            Title=self._convert_from_novx(
                self.novel.sections[scId].title,
                quick=True
                ),
            Desc=self._convert_from_novx(
                self.novel.sections[scId].desc,
                append=self.novel.sections[scId].appendToPrev
                ),
            WordCount=str(self.novel.sections[scId].wordCount),
            WordsTotal=wordsTotal,
            Status=int(self.novel.sections[scId].status),
            SectionContent=self._convert_from_novx(
                        self.novel.sections[scId].sectionContent,
                        append=self.novel.sections[scId].appendToPrev,
                        firstInChapter=firstInChapter,
                        xml=True
                        ),
            Date=isoDate,
            Time=scTime,
            OdsTime=odsTime,
            Day=scDay,
            ScDate=cmbDate,
            DateYear=yearStr,
            DateMonth=monthStr,
            DateDay=dayStr,
            DateWeekday=dtWeekday,
            MonthName=dtMonth,
            LastsDays=lastsDays,
            LastsHours=lastsHours,
            LastsMinutes=lastsMinutes,
            Duration=duration,
            Scene=Section.SCENE[self.novel.sections[scId].scene],
            Goal=self._convert_from_novx(self.novel.sections[scId].goal),
            Conflict=self._convert_from_novx(self.novel.sections[scId].conflict),
            Outcome=self._convert_from_novx(self.novel.sections[scId].outcome),
            Tags=self._convert_from_novx(tags, quick=True),
            Characters=sectionChars,
            Viewpoint=viewpointChar,
            Locations=sectionLocs,
            Items=sectionItems,
            Notes=self._convert_from_novx(self.novel.sections[scId].notes),
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
            ManuscriptSuffix=MANUSCRIPT_SUFFIX,
            SectionsSuffix=SECTIONS_SUFFIX,
            CustomPlotProgress=pltPrgs,
            CustomCharacterization=chrczn,
            CustomWorldBuilding=wrldbld,
            CustomGoal=goal,
            CustomConflict=cflct,
            CustomOutcome=outcm
        )
        return sectionMapping

    def _get_sections(self, chId, sectionNumber, wordsTotal):
        lines = []
        firstSectionInChapter = True
        for scId in self.novel.tree.get_children(chId):
            template = None
            dispNumber = 0
            if not self.sectionFilter.accept(self, scId):
                continue

            sectionContent = self.novel.sections[scId].sectionContent
            if sectionContent is None:
                sectionContent = ''

            if self.novel.sections[scId].scType == 2:
                if self._stage1Template:
                    template = Template(self._stage1Template)
                else:
                    continue

            elif self.novel.sections[scId].scType == 3:
                if self._stage2Template:
                    template = Template(self._stage2Template)
                else:
                    continue

            elif self.novel.sections[scId].scType == 1 or self.novel.chapters[chId].chType == 1:
                if self._unusedSectionTemplate:
                    template = Template(self._unusedSectionTemplate)
                else:
                    continue

            else:
                sectionNumber += 1
                dispNumber = sectionNumber
                wordsTotal += self.novel.sections[scId].wordCount
                template = Template(self._sectionTemplate)
                if firstSectionInChapter and self._firstSectionTemplate:
                    template = Template(self._firstSectionTemplate)
            if not (firstSectionInChapter or self.novel.sections[scId].appendToPrev or self.novel.sections[scId].scType > 1):
                lines.append(self._sectionDivider)
            if template is not None:
                lines.append(
                    template.safe_substitute(
                        self._get_sectionMapping(
                            scId, dispNumber,
                            wordsTotal,
                            firstInChapter=firstSectionInChapter,
                            )
                        )
                    )
            if self.novel.sections[scId].scType < 2:
                firstSectionInChapter = False
        return lines, sectionNumber, wordsTotal

    def _get_prjNoteMapping(self, pnId):
        noteMapping = dict(
            ID=pnId,
            Title=self._convert_from_novx(self.novel.projectNotes[pnId].title, quick=True),
            Desc=self._convert_from_novx(self.novel.projectNotes[pnId].desc),
            ProjectName=self._convert_from_novx(self.projectName, quick=True),
            ProjectPath=self.projectPath,
        )
        return noteMapping

    def _get_projectNotes(self):
        lines = []
        template = Template(self._projectNoteTemplate)
        for pnId in self.novel.tree.get_children(PN_ROOT):
            pnMap = self._get_prjNoteMapping(pnId)
            lines.append(template.safe_substitute(pnMap))
        return lines

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_arcs())
        lines.extend(self._get_projectNotes())
        lines.extend(self._get_fileFooter())
        return ''.join(lines)



def odf_is_locked(filePath):
    prjPath, fileName = os.path.split(filePath)
    return os.path.isfile(f'{prjPath}/.~lock.{fileName}#')



class OdfFile(FileExport):
    _ODF_COMPONENTS = []
    _MIMETYPE = ''
    _SETTINGS_XML = ''
    _MANIFEST_XML = ''
    _STYLES_XML = ''
    _META_XML = ''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._tempDir = tempfile.mkdtemp(suffix='.tmp', prefix='odf_')
        self._originalPath = self._filePath

    def __del__(self):
        self._tear_down()

    def is_locked(self):
        return odf_is_locked(self.filePath)

    def write_content_xml(self):
        super().write()

    def write(self):

        self._set_up()

        self._originalPath = self._filePath
        self._filePath = f'{self._tempDir}/content.xml'
        self.write_content_xml()
        self._filePath = self._originalPath

        workdir = os.getcwd()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            with zipfile.ZipFile(self.filePath, 'w') as odfTarget:
                os.chdir(self._tempDir)
                for file in self._ODF_COMPONENTS:
                    odfTarget.write(file, compress_type=zipfile.ZIP_DEFLATED)
        except:
            os.chdir(workdir)
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot create file")}: "{norm_path(self.filePath)}".')

        os.chdir(workdir)
        self._tear_down()
        return f'{_("File written")}: "{norm_path(self.filePath)}".'

    def _set_up(self):

        try:
            self._tear_down()
            os.mkdir(self._tempDir)
            os.mkdir(f'{self._tempDir}/META-INF')
        except:
            raise Error(f'{_("Cannot create directory")}: "{norm_path(self._tempDir)}".')

        try:
            with open(f'{self._tempDir}/mimetype', 'w', encoding='utf-8') as f:
                f.write(self._MIMETYPE)
        except:
            raise Error(f'{_("Cannot write file")}: "mimetype"')

        try:
            with open(f'{self._tempDir}/settings.xml', 'w', encoding='utf-8') as f:
                f.write(self._SETTINGS_XML)
        except:
            raise Error(f'{_("Cannot write file")}: "settings.xml"')

        try:
            with open(f'{self._tempDir}/META-INF/manifest.xml', 'w', encoding='utf-8') as f:
                f.write(self._MANIFEST_XML)
        except:
            raise Error(f'{_("Cannot write file")}: "manifest.xml"')

        self.novel.check_locale()
        localeMapping = dict(
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        template = Template(self._STYLES_XML)
        text = template.safe_substitute(localeMapping)
        try:
            with open(f'{self._tempDir}/styles.xml', 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "styles.xml"')

        metaMapping = dict(
            Author=self.novel.authorName,
            Title=self.novel.title,
            Summary=f'<![CDATA[{self.novel.desc}]]>',
            Datetime=datetime.today().replace(microsecond=0).isoformat(),
        )
        template = Template(self._META_XML)
        text = template.safe_substitute(metaMapping)
        try:
            with open(f'{self._tempDir}/meta.xml', 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "meta.xml".')

    def _tear_down(self):
        try:
            rmtree(self._tempDir)
        except:
            pass



class OdsWriter(OdfFile):
    EXTENSION = '.ods'
    _ODF_COMPONENTS = [
        'META-INF',
        'content.xml',
        'meta.xml',
        'mimetype',
        'settings.xml',
        'styles.xml',
        'META-INF/manifest.xml'
    ]


    _CONTENT_XML_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:xforms="http://www.w3.org/2002/xforms" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0" office:version="1.2">
 <office:scripts/>
 <office:font-face-decls>
  <style:font-face style:name="Calibri" svg:font-family="&apos;Calibri&apos;" style:font-adornments="Standard" style:font-family-generic="swiss" style:font-pitch="variable"/>
 </office:font-face-decls>
 <office:automatic-styles>
  <style:style style:name="co1" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="2.000cm"/>
  </style:style>
  <style:style style:name="co2" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="3.000cm"/>
  </style:style>
  <style:style style:name="co3" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="4.000cm"/>
  </style:style>
  <style:style style:name="co4" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="8.000cm"/>
  </style:style>
  <style:style style:name="ro1" style:family="table-row">
   <style:table-row-properties style:row-height="1.157cm" fo:break-before="auto" style:use-optimal-row-height="true"/>
  </style:style>
  <style:style style:name="ro2" style:family="table-row">
   <style:table-row-properties style:row-height="2.053cm" fo:break-before="auto" style:use-optimal-row-height="true"/>
  </style:style>
  <style:style style:name="ta1" style:family="table" style:master-page-name="Default">
   <style:table-properties table:display="true" style:writing-mode="lr-tb"/>
  </style:style>
  <number:date-style style:name="N36" number:automatic-order="true">
   <number:day number:style="long"/>
   <number:text>.</number:text>
   <number:month number:style="long"/>
   <number:text>.</number:text>
   <number:year number:style="long"/>
  </number:date-style>
  <number:time-style style:name="N40">
   <number:hours number:style="long"/>
   <number:text>:</number:text>
   <number:minutes number:style="long"/>
  </number:time-style>
  <style:style style:name="ce1" style:family="table-cell" style:parent-style-name="Heading" style:data-style-name="N36"/>
  <style:style style:name="ce2" style:family="table-cell" style:parent-style-name="Default" style:data-style-name="N36"/>
  <style:style style:name="ce3" style:family="table-cell" style:parent-style-name="Heading" style:data-style-name="N40"/>
  <style:style style:name="ce4" style:family="table-cell" style:parent-style-name="Default" style:data-style-name="N40"/>
 </office:automatic-styles>
 <office:body>
  <office:spreadsheet>
   <table:table table:name="'''

    _CONTENT_XML_FOOTER = '''   </table:table>
  </office:spreadsheet>
 </office:body>
</office:document-content>
'''

    _META_XML = '''<?xml version="1.0" encoding="utf-8"?>
<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:grddl="http://www.w3.org/2003/g/data-view#" office:version="1.2">
  <office:meta>
    <meta:generator>novxlib</meta:generator>
    <dc:title>$Title</dc:title>
    <dc:description>$Summary</dc:description>
    <dc:subject></dc:subject>
    <meta:keyword></meta:keyword>
    <meta:initial-creator>$Author</meta:initial-creator>
    <dc:creator></dc:creator>
    <meta:creation-date>${Datetime}Z</meta:creation-date>
    <dc:date></dc:date>
  </office:meta>
</office:document-meta>
'''
    _MANIFEST_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
 <manifest:file-entry manifest:media-type="application/vnd.oasis.opendocument.spreadsheet" manifest:version="1.2" manifest:full-path="/"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="content.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="styles.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="meta.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="settings.xml"/>
</manifest:manifest>    
'''
    _SETTINGS_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-settings xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0" xmlns:ooo="http://openoffice.org/2004/office" office:version="1.2">
 <office:settings>
  <config:config-item-set config:name="ooo:view-settings">
   <config:config-item config:name="VisibleAreaTop" config:type="int">0</config:config-item>
   <config:config-item config:name="VisibleAreaLeft" config:type="int">0</config:config-item>
   <config:config-item config:name="VisibleAreaWidth" config:type="int">44972</config:config-item>
   <config:config-item config:name="VisibleAreaHeight" config:type="int">18999</config:config-item>
   <config:config-item-map-indexed config:name="Views">
    <config:config-item-map-entry>
     <config:config-item config:name="ViewId" config:type="string">view1</config:config-item>
     <config:config-item-map-named config:name="Tables">
      <config:config-item-map-entry config:name="Tabelle1">
       <config:config-item config:name="CursorPositionX" config:type="int">5</config:config-item>
       <config:config-item config:name="CursorPositionY" config:type="int">1</config:config-item>
       <config:config-item config:name="HorizontalSplitMode" config:type="short">0</config:config-item>
       <config:config-item config:name="VerticalSplitMode" config:type="short">0</config:config-item>
       <config:config-item config:name="HorizontalSplitPosition" config:type="int">0</config:config-item>
       <config:config-item config:name="VerticalSplitPosition" config:type="int">0</config:config-item>
       <config:config-item config:name="ActiveSplitRange" config:type="short">2</config:config-item>
       <config:config-item config:name="PositionLeft" config:type="int">0</config:config-item>
       <config:config-item config:name="PositionRight" config:type="int">0</config:config-item>
       <config:config-item config:name="PositionTop" config:type="int">0</config:config-item>
       <config:config-item config:name="PositionBottom" config:type="int">0</config:config-item>
       <config:config-item config:name="ZoomType" config:type="short">0</config:config-item>
       <config:config-item config:name="ZoomValue" config:type="int">100</config:config-item>
       <config:config-item config:name="PageViewZoomValue" config:type="int">60</config:config-item>
      </config:config-item-map-entry>
     </config:config-item-map-named>
     <config:config-item config:name="ActiveTable" config:type="string">Tabelle1</config:config-item>
     <config:config-item config:name="HorizontalScrollbarWidth" config:type="int">270</config:config-item>
     <config:config-item config:name="ZoomType" config:type="short">0</config:config-item>
     <config:config-item config:name="ZoomValue" config:type="int">100</config:config-item>
     <config:config-item config:name="PageViewZoomValue" config:type="int">60</config:config-item>
     <config:config-item config:name="ShowPageBreakPreview" config:type="boolean">false</config:config-item>
     <config:config-item config:name="ShowZeroValues" config:type="boolean">true</config:config-item>
     <config:config-item config:name="ShowNotes" config:type="boolean">true</config:config-item>
     <config:config-item config:name="ShowGrid" config:type="boolean">true</config:config-item>
     <config:config-item config:name="GridColor" config:type="long">12632256</config:config-item>
     <config:config-item config:name="ShowPageBreaks" config:type="boolean">true</config:config-item>
     <config:config-item config:name="HasColumnRowHeaders" config:type="boolean">true</config:config-item>
     <config:config-item config:name="HasSheetTabs" config:type="boolean">true</config:config-item>
     <config:config-item config:name="IsOutlineSymbolsSet" config:type="boolean">true</config:config-item>
     <config:config-item config:name="IsSnapToRaster" config:type="boolean">false</config:config-item>
     <config:config-item config:name="RasterIsVisible" config:type="boolean">false</config:config-item>
     <config:config-item config:name="RasterResolutionX" config:type="int">1000</config:config-item>
     <config:config-item config:name="RasterResolutionY" config:type="int">1000</config:config-item>
     <config:config-item config:name="RasterSubdivisionX" config:type="int">1</config:config-item>
     <config:config-item config:name="RasterSubdivisionY" config:type="int">1</config:config-item>
     <config:config-item config:name="IsRasterAxisSynchronized" config:type="boolean">true</config:config-item>
    </config:config-item-map-entry>
   </config:config-item-map-indexed>
  </config:config-item-set>
  <config:config-item-set config:name="ooo:configuration-settings">
   <config:config-item config:name="IsKernAsianPunctuation" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsRasterAxisSynchronized" config:type="boolean">true</config:config-item>
   <config:config-item config:name="LinkUpdateMode" config:type="short">3</config:config-item>
   <config:config-item config:name="SaveVersionOnClose" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AllowPrintJobCancel" config:type="boolean">true</config:config-item>
   <config:config-item config:name="HasSheetTabs" config:type="boolean">true</config:config-item>
   <config:config-item config:name="ShowPageBreaks" config:type="boolean">true</config:config-item>
   <config:config-item config:name="RasterResolutionX" config:type="int">1000</config:config-item>
   <config:config-item config:name="PrinterSetup" config:type="base64Binary"/>
   <config:config-item config:name="RasterResolutionY" config:type="int">1000</config:config-item>
   <config:config-item config:name="LoadReadonly" config:type="boolean">false</config:config-item>
   <config:config-item config:name="RasterSubdivisionX" config:type="int">1</config:config-item>
   <config:config-item config:name="ShowNotes" config:type="boolean">true</config:config-item>
   <config:config-item config:name="ShowZeroValues" config:type="boolean">true</config:config-item>
   <config:config-item config:name="RasterSubdivisionY" config:type="int">1</config:config-item>
   <config:config-item config:name="ApplyUserData" config:type="boolean">true</config:config-item>
   <config:config-item config:name="GridColor" config:type="long">12632256</config:config-item>
   <config:config-item config:name="RasterIsVisible" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsSnapToRaster" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrinterName" config:type="string"/>
   <config:config-item config:name="ShowGrid" config:type="boolean">true</config:config-item>
   <config:config-item config:name="CharacterCompressionType" config:type="short">0</config:config-item>
   <config:config-item-map-indexed config:name="ForbiddenCharacters">
    <config:config-item-map-entry>
     <config:config-item config:name="Language" config:type="string">$Language</config:config-item>
     <config:config-item config:name="Country" config:type="string">$Country</config:config-item>
     <config:config-item config:name="Variant" config:type="string"/>
     <config:config-item config:name="BeginLine" config:type="string"/>
     <config:config-item config:name="EndLine" config:type="string"/>
    </config:config-item-map-entry>
   </config:config-item-map-indexed>
   <config:config-item config:name="IsOutlineSymbolsSet" config:type="boolean">true</config:config-item>
   <config:config-item config:name="AutoCalculate" config:type="boolean">true</config:config-item>
   <config:config-item config:name="IsDocumentShared" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UpdateFromTemplate" config:type="boolean">true</config:config-item>
  </config:config-item-set>
 </office:settings>
</office:document-settings>
'''
    _STYLES_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" office:version="1.2">
 <office:font-face-decls>
  <style:font-face style:name="Calibri" svg:font-family="&apos;Calibri&apos;" style:font-adornments="Standard" style:font-family-generic="swiss" style:font-pitch="variable"/>
 </office:font-face-decls>
 <office:styles>
  <style:default-style style:family="table-cell">
   <style:paragraph-properties style:tab-stop-distance="1.25cm"/>
   <style:text-properties style:font-name="Arial" fo:language="$Language" fo:country="$Country" style:font-name-asian="Arial Unicode MS" style:language-asian="zh" style:country-asian="CN" style:font-name-complex="Tahoma" style:language-complex="hi" style:country-complex="IN"/>
  </style:default-style>
  <number:number-style style:name="N0">
   <number:number number:min-integer-digits="1"/>
  </number:number-style>
  <style:style style:name="Default" style:family="table-cell">
   <style:table-cell-properties style:text-align-source="fix" style:repeat-content="false" fo:background-color="transparent" fo:wrap-option="wrap" fo:padding="0.136cm" style:vertical-align="top"/>
   <style:paragraph-properties fo:text-align="start"/>
   <style:text-properties style:font-name="Calibri" fo:font-size="10.5pt" style:font-name-asian="Microsoft YaHei" style:font-name-complex="Lucida Sans"/>
  </style:style>
  <style:style style:name="Result" style:family="table-cell" style:parent-style-name="Default">
   <style:text-properties fo:font-style="italic" style:text-underline-style="solid" style:text-underline-width="auto" style:text-underline-color="font-color" fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Result2" style:family="table-cell" style:parent-style-name="Result"/>
  <style:style style:name="Heading" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#cfe7f5" style:text-align-source="fix" style:repeat-content="false"/>
   <style:paragraph-properties fo:text-align="start"/>
   <style:text-properties fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Heading1" style:family="table-cell" style:parent-style-name="Heading">
   <style:table-cell-properties style:rotation-angle="90"/>
  </style:style>
 </office:styles>
 <office:automatic-styles>
  <style:page-layout style:name="Mpm1">
   <style:page-layout-properties style:writing-mode="lr-tb"/>
   <style:header-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-bottom="0.25cm"/>
   </style:header-style>
   <style:footer-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.25cm"/>
   </style:footer-style>
  </style:page-layout>
  <style:page-layout style:name="Mpm2">
   <style:page-layout-properties style:writing-mode="lr-tb"/>
   <style:header-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-bottom="0.25cm" fo:border="0.088cm solid #000000" fo:padding="0.018cm" fo:background-color="#c0c0c0">
     <style:background-image/>
    </style:header-footer-properties>
   </style:header-style>
   <style:footer-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.25cm" fo:border="0.088cm solid #000000" fo:padding="0.018cm" fo:background-color="#c0c0c0">
     <style:background-image/>
    </style:header-footer-properties>
   </style:footer-style>
  </style:page-layout>
 </office:automatic-styles>
 <office:master-styles>
  <style:master-page style:name="Default" style:page-layout-name="Mpm1">
   <style:header>
    <text:p><text:sheet-name>???</text:sheet-name></text:p>
   </style:header>
   <style:header-left style:display="false"/>
   <style:footer>
    <text:p>Seite <text:page-number>1</text:page-number></text:p>
   </style:footer>
   <style:footer-left style:display="false"/>
  </style:master-page>
  <style:master-page style:name="Report" style:page-layout-name="Mpm2">
   <style:header>
    <style:region-left>
     <text:p><text:sheet-name>???</text:sheet-name> (<text:title>???</text:title>)</text:p>
    </style:region-left>
    <style:region-right>
     <text:p><text:date style:data-style-name="N2" text:date-value="2021-03-15">15.03.2021</text:date>, <text:time>15:34:40</text:time></text:p>
    </style:region-right>
   </style:header>
   <style:header-left style:display="false"/>
   <style:footer>
    <text:p>Seite <text:page-number>1</text:page-number> / <text:page-count>99</text:page-count></text:p>
   </style:footer>
   <style:footer-left style:display="false"/>
  </style:master-page>
 </office:master-styles>
</office:document-styles>
'''
    _MIMETYPE = 'application/vnd.oasis.opendocument.spreadsheet'

    def _convert_from_novx(self, text, isLink=False, **kwargs):
        if not text:
            return ''

        text = text.rstrip()
        ODS_REPLACEMENTS = [
            ('&', '&amp;'),  # must be first!
            ("'", '&apos;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('\n', '</text:p>\n<text:p>'),
        ]
        if isLink:
            ODS_REPLACEMENTS.append(('"', '&apos;'))
        else:
            ODS_REPLACEMENTS.append(('"', '&quot;'))
        for nv, ods in ODS_REPLACEMENTS:
            text = text.replace(nv, ods)
        return text



class OdsWCharList(OdsWriter):

    DESCRIPTION = _('Character list')
    SUFFIX = CHARLIST_SUFFIX

    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:number-columns-repeated="3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:number-columns-repeated="1014" table:default-cell-style-name="Default"/>
     <table:table-row table:style-name="ro1" table:visibility="collapse">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Full name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Aka</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Bio</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Goals</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Importance</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Notes</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>
     <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Name")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Full name")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Aka")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Description")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomChrBio</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomChrGoals</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Importance")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Tags")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Notes")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>

'''
    _characterTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$FullName</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$AKA</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Bio</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Goals</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Status</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Notes</text:p>
     </table:table-cell>
     <table:table-cell table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER
from string import Template



class OdsWGrid(OdsWriter):

    DESCRIPTION = _('Plot grid')
    SUFFIX = GRID_SUFFIX



    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:visibility="collapse" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="ce2"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="ce4"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
$ArcColumns
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-row table:style-name="ro1" table:visibility="collapse">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Section</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce1" office:value-type="string">
      <text:p>Date</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce3" office:value-type="string">
      <text:p>Time</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Day</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Title</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Viewpoint</text:p>
     </table:table-cell>
$ArcIdCells
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Goal</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Conflict</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Outcome</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Notes</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1003"/>
    </table:table-row>
    <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Section")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce1" office:value-type="string">
      <text:p>{_("Date")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce3" office:value-type="string">
      <text:p>{_("Time")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Day")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Title")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Description")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Viewpoint")}</text:p>
     </table:table-cell>
$ArcTitleCells
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Tags")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Scene")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomPlotProgress / {_("Goal")} / {_("Reaction")} / $CustomGoal</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomCharacterization / {_("Conflict")} / {_("Dilemma")} / $CustomConflict</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomWorldBuilding / {_("Outcome")} / {_("Choice")} / $CustomOutcome</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Notes")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1003"/>
    </table:table-row>

'''

    _sectionTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>$ID</text:p>
     </table:table-cell>
     <table:table-cell table:formula="of:=HYPERLINK(&quot;file:///$ProjectPath/$ProjectName$ManuscriptSuffix.odt#$ID%7Cregion&quot;;&quot;$SectionNumber&quot;)" office:value-type="string" office:string-value="$SectionNumber">
      <text:p>$SectionNumber</text:p>
     </table:table-cell>
$DateCell     
$TimeCell
     <table:table-cell office:value-type="string">
      <text:p>$Day</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Viewpoint</text:p>
     </table:table-cell>
$ArcNoteCells
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Scene</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Goal</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Conflict</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Outcome</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Notes</text:p>
     </table:table-cell>
    </table:table-row>

'''

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER

    _emptyDateCell = '     <table:table-cell table:style-name="ce2"/>'
    _validDateCell = '''     <table:table-cell office:value-type="date" office:date-value="$Date">
      <text:p>$Date</text:p>
     </table:table-cell>'''
    _emptyTimeCell = '     <table:table-cell table:style-name="ce4"/>'
    _validTimeCell = '''     <table:table-cell office:value-type="time" office:time-value="$OdsTime">
      <text:p>$Time</text:p>
     </table:table-cell>'''

    _arcNoteCell = '''     <table:table-cell office:value-type="string">
      <text:p>$ArcNote</text:p>
     </table:table-cell>'''

    _arcIdCell = '''     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$ArcId</text:p>
     </table:table-cell>'''

    _arcTitleCell = '''     <table:table-cell $Link table:style-name="Heading" office:value-type="string">
      <text:p>$ArcTitle</text:p>
     </table:table-cell>'''

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()

        arcColumns = []
        arcIdCells = []
        arcTitleCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            arcColumns.append('    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>')
            mapping = dict(
                ArcId=plId,
                ArcTitle=self.novel.plotLines[plId].title,
                Link=f'table:formula="of:=HYPERLINK(&quot;file:///{self.projectPath}/{self._convert_from_novx(self.projectName)}{PLOTLINES_SUFFIX}.odt#{plId}&quot;;&quot;{self._convert_from_novx(self.novel.plotLines[plId].title, isLink=True)}&quot;)"',
            )
            arcIdCells.append(Template(self._arcIdCell).safe_substitute(mapping))
            arcTitleCells.append(Template(self._arcTitleCell).safe_substitute(mapping))
        fileHeaderMapping['ArcColumns'] = '\n'.join(arcColumns)
        fileHeaderMapping['ArcIdCells'] = '\n'.join(arcIdCells)
        fileHeaderMapping['ArcTitleCells'] = '\n'.join(arcTitleCells)

        return fileHeaderMapping

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, **kwargs):
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal)

        if sectionMapping['Date']:
            sectionMapping['DateCell'] = Template(self._validDateCell).safe_substitute(sectionMapping)
        else:
            sectionMapping['DateCell'] = self._emptyDateCell

        if sectionMapping['Time']:
            sectionMapping['TimeCell'] = Template(self._validTimeCell).safe_substitute(sectionMapping)
        else:
            sectionMapping['TimeCell'] = self._emptyTimeCell

        arcNoteCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            plotlineNotes = self.novel.sections[scId].plotlineNotes
            if plotlineNotes:
                arcNote = plotlineNotes.get(plId, '')
            else:
                arcNote = ''
            mapping = {'ArcNote':arcNote}
            arcNoteCells.append(Template(self._arcNoteCell).safe_substitute(mapping))
        sectionMapping['ArcNoteCells'] = '\n'.join(arcNoteCells)

        return sectionMapping



class OdsWItemList(OdsWriter):

    DESCRIPTION = _('Item list')
    SUFFIX = ITEMLIST_SUFFIX

    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:number-columns-repeated="1014" table:default-cell-style-name="Default"/>
     <table:table-row table:style-name="ro1" table:visibility="collapse">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Aka</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>
     <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Name")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Description")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Aka")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Tags")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _itemTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$AKA</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER


class OdsWLocList(OdsWriter):
    DESCRIPTION = _('Location list')
    SUFFIX = LOCLIST_SUFFIX

    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:number-columns-repeated="1014" table:default-cell-style-name="Default"/>
     <table:table-row table:style-name="ro1" table:visibility="collapse">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Aka</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>
     <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Name")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Description")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Aka")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Tags")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _locationTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$AKA</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell table:number-columns-repeated="1014"/>
    </table:table-row>

'''
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER


class OdsWPlotList(OdsWriter):
    DESCRIPTION = _('ODS Plot list')
    SUFFIX = PLOTLIST_SUFFIX

    _CE_OFFSET = 6
    _ADDITIONAL_STYLES = '''
  <style:style style:name="ce5" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties style:text-align-source="value-type" style:repeat-content="false"/>
   <style:paragraph-properties fo:margin-left="0cm"/>
   <style:text-properties fo:color="#ff0000" fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold"/>
  </style:style>
  <style:style style:name="ce6" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#b0c4de"/>
  </style:style>
  <style:style style:name="ce7" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#ffd700"/>
  </style:style>
  <style:style style:name="ce8" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#ff7f50"/>
  </style:style>
  <style:style style:name="ce9" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#9acd32"/>
  </style:style>
  <style:style style:name="ce10" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#48d1cc"/>
  </style:style>
  <style:style style:name="ce11" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#dda0dd"/>
  </style:style>
 </office:automatic-styles>'''

    _fileHeader = OdsWriter._CONTENT_XML_HEADER.replace(' </office:automatic-styles>', _ADDITIONAL_STYLES)
    _fileHeader = f'{_fileHeader}{DESCRIPTION}" table:style-name="ta1" table:print="false">'

    def write_content_xml(self):

        def create_cell(text, attr='', link=''):
            if link:
                attr = f'{attr} table:formula="of:=HYPERLINK(&quot;file:///{self.projectPath}/{self._convert_from_novx(self.projectName)}{link}&quot;;&quot;{self._convert_from_novx(text, isLink=True)}&quot;)"'
                text = ''
            else:
                text = f'\n      <text:p>{self._convert_from_novx(text)}</text:p>'
            return f'     <table:table-cell {attr} office:value-type="string">{text}\n     </table:table-cell>'

        odsText = [
            self._fileHeader,
            '<table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>',
        ]

        plotLineColorsTotal = 6

        if self.novel.tree.get_children(PL_ROOT) is not None:
            plotLines = self.novel.tree.get_children(PL_ROOT)
        else:
            plotLines = []

        for plId in plotLines:
            odsText.append('<table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>')

        odsText.append('   <table:table-row table:style-name="ro2">')
        odsText.append(create_cell(''))
        for i, plId in enumerate(plotLines):
            colorIndex = (i % plotLineColorsTotal) + self._CE_OFFSET
            odsText.append(
                create_cell(
                    self.novel.plotLines[plId].title,
                    attr=f'table:style-name="ce{colorIndex}"',
                    link=f'{PLOTLINES_SUFFIX}.odt#{plId}'
                )
            )
        odsText.append('    </table:table-row>')

        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    odsText.append('   <table:table-row table:style-name="ro2">')
                    odsText.append(
                        create_cell(
                            self.novel.sections[scId].title,
                            link=f'{MANUSCRIPT_SUFFIX}.odt#{scId}%7Cregion'
                        )
                    )
                    for i, plId in enumerate(plotLines):
                        colorIndex = (i % plotLineColorsTotal) + self._CE_OFFSET
                        if scId in self.novel.plotLines[plId].sections:
                            plotPoints = []
                            for ppId in self.novel.tree.get_children(plId):
                                if scId == self.novel.plotPoints[ppId].sectionAssoc:
                                    plotPoints.append(self.novel.plotPoints[ppId].title)
                            odsText.append(
                                create_cell(
                                    list_to_string(plotPoints),
                                    attr=f'table:style-name="ce{colorIndex}" '
                                )
                            )
                        else:
                            odsText.append(create_cell(''))
                    odsText.append(f'    </table:table-row>')

        odsText.append(self._CONTENT_XML_FOOTER)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(odsText))


class OdsWSectionList(OdsWGrid):

    DESCRIPTION = _('Section list')
    SUFFIX = SECTIONLIST_SUFFIX



    _fileHeader = f'''{OdsWGrid._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:visibility="collapse" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="ce2"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="ce4"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-row table:style-name="ro1" table:visibility="collapse">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Section</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Title</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Viewpoint</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce1" office:value-type="string">
      <text:p>Date</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce3" office:value-type="string">
      <text:p>Time</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Day</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Duration</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Section notes</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Goal</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Conflict</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Outcome</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Status</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Words total</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Word count</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Characters</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Locations</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Items</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1003"/>
    </table:table-row>
    <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Section")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Title")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Description")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Viewpoint")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce1" office:value-type="string">
      <text:p>{_("Date")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="ce3" office:value-type="string">
      <text:p>{_("Time")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Day")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Duration")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Tags")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Section notes")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Scene")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomPlotProgress / {_("Goal")} / {_("Reaction")} / $CustomGoal</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomCharacterization / {_("Conflict")} / {_("Dilemma")} / $CustomConflict</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$CustomWorldBuilding / {_("Outcome")} / {_("Choice")} / $CustomOutcome</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Status")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Words total")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Section word count")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Characters")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Locations")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>{_("Items")}</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1003"/>
    </table:table-row>

'''

    _sectionTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>$ID</text:p>
     </table:table-cell>
     <table:table-cell table:formula="of:=HYPERLINK(&quot;file:///$ProjectPath/$ProjectName$ManuscriptSuffix.odt#$ID%7Cregion&quot;;&quot;$SectionNumber&quot;)" office:value-type="string" office:string-value="$SectionNumber">
      <text:p>$SectionNumber</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Viewpoint</text:p>
     </table:table-cell>
$DateCell     
$TimeCell
     <table:table-cell office:value-type="string">
      <text:p>$Day</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Duration</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Notes</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Scene</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Goal</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Conflict</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Outcome</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Status</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$WordsTotal">
      <text:p>$WordsTotal</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$WordCount">
      <text:p>$WordCount</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Characters</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Locations</text:p>
     </table:table-cell>
     <table:table-cell>
      <text:p>$Items</text:p>
     </table:table-cell>
    </table:table-row>

'''

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, **kwargs):
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal)
        sectionMapping['Status'] = Section.STATUS[sectionMapping['Status']]
        return sectionMapping
from xml.sax.saxutils import escape

from xml import sax



class NovxToOdt(sax.ContentHandler):

    def __init__(self):
        super().__init__()
        self.odtLines = None
        self._languages = None
        self._indentParagraph = None
        self._note = None
        self._comment = None

    def feed(self, xmlString, languages, append, firstInChapter):
        self._languages = languages
        self._firstParagraphInChapter = firstInChapter
        self._indentParagraph = append
        self._note = None
        self._comment = False
        self.odtLines = []
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):
        content = sax.saxutils.escape(content)
        self.odtLines.append(content)
        self._indentParagraph = True

    def endElement(self, name):
        if name == 'p':
            self.odtLines.append('</text:p>')
            return

        if name in ('em', 'strong', 'span'):
            self.odtLines.append('</text:span>')
            return

        if name == 'li':
            self.odtLines.append('</text:list-item>')
            return

        if name == 'creator':
            self.odtLines.append('</dc:creator>')
            return

        if name == 'date':
            self.odtLines.append('</dc:date>')
            return

        if name == 'note-citation':
            self.odtLines.append('</text:note-citation><text:note-body>')
            return

        if name == 'ul':
            self._list = False
            self._indentParagraph = False
            self.odtLines.append('</text:list>')
            return

        if name == 'comment':
            self.odtLines.append('</office:annotation>')
            self._comment = False
            return

        if name == 'note':
            self._note = None
            self.odtLines.append('</text:note-body></text:note>')

    def startElement(self, name, attrs):
        xmlAttributes = {}
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            xmlAttributes[attrKey] = attrValue

        if name == 'p':
            if xmlAttributes.get('style', None) == 'quotations':
                self.odtLines.append('<text:p text:style-name="Quotations">')
            elif self._note:
                self.odtLines.append(f'<text:p text:style-name="{self._note.title()}">')
            elif self._comment:
                self.odtLines.append('<text:p>')
            elif self._firstParagraphInChapter:
                self.odtLines.append(f'<text:p text:style-name="{_("Chapter_20_beginning")}">')
            elif self._indentParagraph:
                self.odtLines.append('<text:p text:style-name="First_20_line_20_indent">')
            else:
                self.odtLines.append('<text:p text:style-name="Text_20_body">')
            self._firstParagraphInChapter = False
            self._indentParagraph = False
            return

        if name == 'em':
            self.odtLines.append('<text:span text:style-name="Emphasis">')
            return

        if name == 'strong':
            self.odtLines.append('<text:span text:style-name="Strong_20_Emphasis">')
            return

        if name == 'span':
            language = xmlAttributes.get('xml:lang', None)
            if language:
                i = self._languages.index(language) + 1
                self.odtLines.append(f'<text:span text:style-name="T{i}">')
            return

        if name == 'ul':
            self._list = True
            self.odtLines.append('<text:list>')
            return

        if name == 'comment':
            self._comment = True
            self.odtLines.append('<office:annotation>')
            return

        if name == 'note':
            self._note = xmlAttributes.get('class', 'footnote')
            self.odtLines.append(f'<text:note text:note-class="{self._note}">')
            return

        if name == 'creator':
            self.odtLines.append('<dc:creator>')
            return

        if name == 'date':
            self.odtLines.append('<dc:date>')
            return

        if name == 'note-citation':
            self.odtLines.append('<text:note-citation>')
            return

        if name == 'li':
            self.odtLines.append('<text:list-item>')


class OdtWriter(OdfFile):

    EXTENSION = '.odt'

    _ODF_COMPONENTS = ['manifest.rdf', 'META-INF', 'content.xml', 'meta.xml', 'mimetype',
                      'settings.xml', 'styles.xml', 'META-INF/manifest.xml']

    _CONTENT_XML_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:xforms="http://www.w3.org/2002/xforms" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0" office:version="1.2">
 <office:scripts/>
 <office:font-face-decls>
  <style:font-face style:name="StarSymbol" svg:font-family="StarSymbol" style:font-charset="x-symbol"/>
  <style:font-face style:name="Consolas" svg:font-family="Consolas" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  <style:font-face style:name="Courier New" svg:font-family="&apos;Courier New&apos;" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
 </office:font-face-decls>
 <office:automatic-styles/>
 <office:body>
  <office:text text:use-soft-page-breaks="true">

'''

    _CONTENT_XML_FOOTER = '''  </office:text>
 </office:body>
</office:document-content>
'''

    _META_XML = '''<?xml version="1.0" encoding="utf-8"?>
<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:grddl="http://www.w3.org/2003/g/data-view#" office:version="1.2">
  <office:meta>
    <meta:generator>novxlib</meta:generator>
    <dc:title>$Title</dc:title>
    <dc:description>$Summary</dc:description>
    <dc:subject></dc:subject>
    <meta:keyword></meta:keyword>
    <meta:initial-creator>$Author</meta:initial-creator>
    <dc:creator></dc:creator>
    <meta:creation-date>${Datetime}Z</meta:creation-date>
    <dc:date></dc:date>
  </office:meta>
</office:document-meta>
'''
    _MANIFEST_XML = '''<?xml version="1.0" encoding="utf-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
  <manifest:file-entry manifest:media-type="application/vnd.oasis.opendocument.text" manifest:full-path="/" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="content.xml" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/rdf+xml" manifest:full-path="manifest.rdf" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="styles.xml" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="meta.xml" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="settings.xml" manifest:version="1.2" />
</manifest:manifest>    
'''
    _MANIFEST_RDF = '''<?xml version="1.0" encoding="utf-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about="styles.xml">
    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/odf#StylesFile"/>
  </rdf:Description>
  <rdf:Description rdf:about="">
    <ns0:hasPart xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" rdf:resource="styles.xml"/>
  </rdf:Description>
  <rdf:Description rdf:about="content.xml">
    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/odf#ContentFile"/>
  </rdf:Description>
  <rdf:Description rdf:about="">
    <ns0:hasPart xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" rdf:resource="content.xml"/>
  </rdf:Description>
  <rdf:Description rdf:about="">
    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#Document"/>
  </rdf:Description>
</rdf:RDF>
'''
    _SETTINGS_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-settings xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0" xmlns:ooo="http://openoffice.org/2004/office" office:version="1.2">
 <office:settings>
  <config:config-item-set config:name="ooo:view-settings">
   <config:config-item config:name="ViewAreaTop" config:type="int">0</config:config-item>
   <config:config-item config:name="ViewAreaLeft" config:type="int">0</config:config-item>
   <config:config-item config:name="ViewAreaWidth" config:type="int">30508</config:config-item>
   <config:config-item config:name="ViewAreaHeight" config:type="int">27783</config:config-item>
   <config:config-item config:name="ShowRedlineChanges" config:type="boolean">true</config:config-item>
   <config:config-item config:name="InBrowseMode" config:type="boolean">false</config:config-item>
   <config:config-item-map-indexed config:name="Views">
    <config:config-item-map-entry>
     <config:config-item config:name="ViewId" config:type="string">view2</config:config-item>
     <config:config-item config:name="ViewLeft" config:type="int">8079</config:config-item>
     <config:config-item config:name="ViewTop" config:type="int">3501</config:config-item>
     <config:config-item config:name="VisibleLeft" config:type="int">0</config:config-item>
     <config:config-item config:name="VisibleTop" config:type="int">0</config:config-item>
     <config:config-item config:name="VisibleRight" config:type="int">30506</config:config-item>
     <config:config-item config:name="VisibleBottom" config:type="int">27781</config:config-item>
     <config:config-item config:name="ZoomType" config:type="short">0</config:config-item>
     <config:config-item config:name="ViewLayoutColumns" config:type="short">1</config:config-item>
     <config:config-item config:name="ViewLayoutBookMode" config:type="boolean">false</config:config-item>
     <config:config-item config:name="ZoomFactor" config:type="short">100</config:config-item>
     <config:config-item config:name="IsSelectedFrame" config:type="boolean">false</config:config-item>
    </config:config-item-map-entry>
   </config:config-item-map-indexed>
  </config:config-item-set>
  <config:config-item-set config:name="ooo:configuration-settings">
   <config:config-item config:name="AddParaSpacingToTableCells" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintPaperFromSetup" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsKernAsianPunctuation" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintReversed" config:type="boolean">false</config:config-item>
   <config:config-item config:name="LinkUpdateMode" config:type="short">1</config:config-item>
   <config:config-item config:name="DoNotCaptureDrawObjsOnPage" config:type="boolean">false</config:config-item>
   <config:config-item config:name="SaveVersionOnClose" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintEmptyPages" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintSingleJobs" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AllowPrintJobCancel" config:type="boolean">true</config:config-item>
   <config:config-item config:name="AddFrameOffsets" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintLeftPages" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintTables" config:type="boolean">true</config:config-item>
   <config:config-item config:name="ProtectForm" config:type="boolean">false</config:config-item>
   <config:config-item config:name="ChartAutoUpdate" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintControls" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrinterSetup" config:type="base64Binary">8gT+/0hQIExhc2VySmV0IFAyMDE0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASFAgTGFzZXJKZXQgUDIwMTQAAAAAAAAAAAAAAAAAAAAWAAEAGAQAAAAAAAAEAAhSAAAEdAAAM1ROVwIACABIAFAAIABMAGEAcwBlAHIASgBlAHQAIABQADIAMAAxADQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQQDANwANAMPnwAAAQAJAJoLNAgAAAEABwBYAgEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU0RETQAGAAAABgAASFAgTGFzZXJKZXQgUDIwMTQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAEAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAAAAAABAAAAAQAAABoEAAAAAAAAAAAAAAAAAAAPAAAALQAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAgICAAP8AAAD//wAAAP8AAAD//wAAAP8A/wD/AAAAAAAAAAAAAAAAAAAAAAAoAAAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADeAwAA3gMAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrjvBgNAMAAAAAAAAAAAAABIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABIAQ09NUEFUX0RVUExFWF9NT0RFCgBEVVBMRVhfT0ZG</config:config-item>
   <config:config-item config:name="CurrentDatabaseDataSource" config:type="string"/>
   <config:config-item config:name="LoadReadonly" config:type="boolean">false</config:config-item>
   <config:config-item config:name="CurrentDatabaseCommand" config:type="string"/>
   <config:config-item config:name="ConsiderTextWrapOnObjPos" config:type="boolean">false</config:config-item>
   <config:config-item config:name="ApplyUserData" config:type="boolean">true</config:config-item>
   <config:config-item config:name="AddParaTableSpacing" config:type="boolean">true</config:config-item>
   <config:config-item config:name="FieldAutoUpdate" config:type="boolean">true</config:config-item>
   <config:config-item config:name="IgnoreFirstLineIndentInNumbering" config:type="boolean">false</config:config-item>
   <config:config-item config:name="TabsRelativeToIndent" config:type="boolean">true</config:config-item>
   <config:config-item config:name="IgnoreTabsAndBlanksForLineCalculation" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintAnnotationMode" config:type="short">0</config:config-item>
   <config:config-item config:name="AddParaTableSpacingAtStart" config:type="boolean">true</config:config-item>
   <config:config-item config:name="UseOldPrinterMetrics" config:type="boolean">false</config:config-item>
   <config:config-item config:name="TableRowKeep" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrinterName" config:type="string">HP LaserJet P2014</config:config-item>
   <config:config-item config:name="PrintFaxName" config:type="string"/>
   <config:config-item config:name="UnxForceZeroExtLeading" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintTextPlaceholder" config:type="boolean">false</config:config-item>
   <config:config-item config:name="DoNotJustifyLinesWithManualBreak" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintRightPages" config:type="boolean">true</config:config-item>
   <config:config-item config:name="CharacterCompressionType" config:type="short">0</config:config-item>
   <config:config-item config:name="UseFormerTextWrapping" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsLabelDocument" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AlignTabStopPosition" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintHiddenText" config:type="boolean">false</config:config-item>
   <config:config-item config:name="DoNotResetParaAttrsForNumFont" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintPageBackground" config:type="boolean">true</config:config-item>
   <config:config-item config:name="CurrentDatabaseCommandType" config:type="int">0</config:config-item>
   <config:config-item config:name="OutlineLevelYieldsNumbering" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintProspect" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintGraphics" config:type="boolean">true</config:config-item>
   <config:config-item config:name="SaveGlobalDocumentLinks" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintProspectRTL" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UseFormerLineSpacing" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AddExternalLeading" config:type="boolean">true</config:config-item>
   <config:config-item config:name="UseFormerObjectPositioning" config:type="boolean">false</config:config-item>
   <config:config-item config:name="RedlineProtectionKey" config:type="base64Binary"/>
   <config:config-item config:name="MathBaselineAlignment" config:type="boolean">false</config:config-item>
   <config:config-item config:name="ClipAsCharacterAnchoredWriterFlyFrames" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UseOldNumbering" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintDrawings" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrinterIndependentLayout" config:type="string">disabled</config:config-item>
   <config:config-item config:name="TabAtLeftIndentForParagraphsInList" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintBlackFonts" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UpdateFromTemplate" config:type="boolean">true</config:config-item>
  </config:config-item-set>
 </office:settings>
</office:document-settings>
'''
    _STYLES_XML = f'''<?xml version="1.0" encoding="UTF-8"?>

<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:loext="urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0">
 <office:font-face-decls>
  <style:font-face style:name="StarSymbol" svg:font-family="StarSymbol" style:font-charset="x-symbol"/>
  <style:font-face style:name="Calibri" svg:font-family="&apos;Calibri&apos;"/>
  <style:font-face style:name="Courier New" svg:font-family="&apos;Courier New&apos;" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  <style:font-face style:name="Consolas" svg:font-family="Consolas" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  </office:font-face-decls>
 <office:styles>
  <style:default-style style:family="graphic">
   <style:graphic-properties svg:stroke-color="#3465a4" draw:fill-color="#729fcf" fo:wrap-option="no-wrap" draw:shadow-offset-x="0.3cm" draw:shadow-offset-y="0.3cm" draw:start-line-spacing-horizontal="0.283cm" draw:start-line-spacing-vertical="0.283cm" draw:end-line-spacing-horizontal="0.283cm" draw:end-line-spacing-vertical="0.283cm" style:flow-with-text="true"/>
   <style:paragraph-properties style:text-autospace="ideograph-alpha" style:line-break="strict" style:writing-mode="lr-tb" style:font-independent-line-spacing="false">
    <style:tab-stops/>
   </style:paragraph-properties>
   <style:text-properties fo:color="#000000" fo:font-size="10pt" fo:language="$Language" fo:country="$Country" style:font-size-asian="10pt" style:language-asian="zxx" style:country-asian="none" style:font-size-complex="1pt" style:language-complex="zxx" style:country-complex="none"/>
  </style:default-style>
  <style:default-style style:family="paragraph">
   <style:paragraph-properties fo:hyphenation-ladder-count="no-limit" style:text-autospace="ideograph-alpha" style:punctuation-wrap="hanging" style:line-break="strict" style:tab-stop-distance="1.251cm" style:writing-mode="lr-tb"/>
   <style:text-properties fo:color="#000000" style:font-name="Calibri" fo:font-size="10.5pt" fo:language="$Language" fo:country="$Country" style:font-name-asian="Calibri" style:font-size-asian="10pt" style:language-asian="zxx" style:country-asian="none" style:font-name-complex="Segoe UI" style:font-size-complex="1pt" style:language-complex="zxx" style:country-complex="none" fo:hyphenate="false" fo:hyphenation-remain-char-count="2" fo:hyphenation-push-char-count="2"/>
  </style:default-style>
  <style:style style:name="Standard" style:family="paragraph" style:class="text" style:master-page-name="">
   <style:paragraph-properties fo:line-height="0.73cm" style:page-number="auto"/>
   <style:text-properties style:font-name="Courier New" fo:font-size="12pt" fo:font-weight="normal"/>
  </style:style>
  <style:style style:name="Text_20_body" style:display-name="Text body" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="First_20_line_20_indent" style:class="text" style:master-page-name="">
   <style:paragraph-properties style:page-number="auto">
    <style:tab-stops/>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="First_20_line_20_indent" style:display-name="First line indent" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0.499cm" style:auto-text-indent="false" style:page-number="auto"/>
  </style:style>
  <style:style style:name="Hanging_20_indent" style:display-name="Hanging indent" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="text">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="1cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="-0.499cm" style:auto-text-indent="false">
    <style:tab-stops>
     <style:tab-stop style:position="0cm"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Text_20_body_20_indent" style:display-name="Text body indent" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="text">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="0.499cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0cm" style:auto-text-indent="false"/>
  </style:style>
  <style:style style:name="Heading" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Text_20_body" style:class="text" style:master-page-name="">
   <style:paragraph-properties fo:line-height="0.73cm" fo:text-align="center" style:justify-single-word="false" style:page-number="auto" fo:keep-with-next="always">
    <style:tab-stops/>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Heading_20_1" style:display-name="Heading 1" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="1" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="1.461cm" fo:margin-bottom="0.73cm" style:page-number="auto">
    <style:tab-stops/>
   </style:paragraph-properties>
   <style:text-properties fo:text-transform="uppercase" fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Heading_20_2" style:display-name="Heading 2" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="2" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="1.461cm" fo:margin-bottom="0.73cm" style:page-number="auto"/>
   <style:text-properties fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Heading_20_3" style:display-name="Heading 3" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="3" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="0.73cm" fo:margin-bottom="0.73cm" style:page-number="auto"/>
   <style:text-properties fo:font-style="italic"/>
  </style:style>
  <style:style style:name="Heading_20_4" style:display-name="Heading 4" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties fo:margin-top="0.73cm" fo:margin-bottom="0.73cm" style:page-number="auto"/>
  </style:style>
  <style:style style:name="Heading_20_5" style:display-name="Heading 5" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties style:page-number="auto"/>
  </style:style>
  <style:style style:name="Heading_20_6" style:display-name="Heading 6" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_7" style:display-name="Heading 7" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_8" style:display-name="Heading 8" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_9" style:display-name="Heading 9" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_10" style:display-name="Heading 10" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="10" style:list-style-name="" style:class="text">
   <style:text-properties fo:font-size="75%" fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Header" style:family="paragraph" style:parent-style-name="Standard" style:class="extra" style:master-page-name="">
   <style:paragraph-properties fo:text-align="end" style:justify-single-word="false" style:page-number="auto" fo:padding="0.049cm" fo:border-left="none" fo:border-right="none" fo:border-top="none" fo:border-bottom="0.002cm solid #000000" style:shadow="none">
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
   <style:text-properties fo:font-variant="normal" fo:text-transform="none" fo:font-style="italic"/>
  </style:style>
  <style:style style:name="Header_20_left" style:display-name="Header left" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Header_20_right" style:display-name="Header right" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Footer" style:family="paragraph" style:parent-style-name="Standard" style:class="extra" style:master-page-name="">
   <style:paragraph-properties fo:text-align="center" style:justify-single-word="false" style:page-number="auto" text:number-lines="false" text:line-number="0">
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
   <style:text-properties fo:font-size="11pt"/>
  </style:style>
  <style:style style:name="Footer_20_left" style:display-name="Footer left" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Footer_20_right" style:display-name="Footer right" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Title" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Subtitle" style:class="chapter" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.000cm" fo:margin-bottom="0cm" fo:line-height="200%" fo:text-align="center" style:justify-single-word="false" fo:text-indent="0cm" style:auto-text-indent="false" style:page-number="auto" fo:background-color="transparent" fo:padding="0cm" fo:border="none" text:number-lines="false" text:line-number="0">
    <style:tab-stops/>
    <style:background-image/>
   </style:paragraph-properties>
   <style:text-properties fo:text-transform="uppercase" fo:font-weight="normal" style:letter-kerning="false"/>
  </style:style>
  <style:style style:name="Subtitle" style:family="paragraph" style:parent-style-name="Title" style:class="chapter" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="0cm" fo:margin-bottom="0cm" style:page-number="auto"/>
   <style:text-properties fo:font-variant="normal" fo:text-transform="none" fo:letter-spacing="normal" fo:font-style="italic" fo:font-weight="normal"/>
  </style:style>
  <style:style style:name="Quotations" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="html">
   <style:paragraph-properties fo:margin="100%" fo:margin-left="1cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0cm" style:auto-text-indent="false"/>
   <style:text-properties style:font-name="Consolas"/>
  </style:style>
  <style:style style:name="{_('Chapter_20_beginning')}" style:display-name="{_('Chapter beginning')}" style:family="paragraph" style:parent-style-name="Text_20_body" style:next-style-name="First_20_line_20_indent" style:class="text">
  </style:style>
  <style:style style:name="{_('Section_20_mark')}" style:display-name="{_('Section mark')}" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Text_20_body" style:class="text">
   <style:text-properties fo:color="#008000" fo:font-size="10pt" fo:language="zxx" fo:country="none"/>
  </style:style>
  <style:style style:name="{_('Section_20_mark_20_unused')}" style:display-name="{_('Section mark unused')}" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Text_20_body" style:class="text">
   <style:text-properties fo:color="#808080" fo:font-size="10pt" fo:language="zxx" fo:country="none"/>
  </style:style>
  <style:style style:name="{_('Heading_20_3_20_invisible')}" style:display-name="{_('Heading 3 invisible')}" style:family="paragraph" style:parent-style-name="Heading_20_3" style:class="text">
   <style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0cm" fo:line-height="100%"/>
   <style:text-properties text:display="none"/>
  </style:style>
  <style:style style:name="Emphasis" style:family="text">
   <style:text-properties fo:font-style="italic" fo:background-color="transparent"/>
  </style:style>
  <style:style style:name="Strong_20_Emphasis" style:display-name="Strong Emphasis" style:family="text">
   <style:text-properties fo:text-transform="uppercase"/>
  </style:style>
 </office:styles>
 <office:automatic-styles>
  <style:page-layout style:name="Mpm1">
   <style:page-layout-properties fo:page-width="21.001cm" fo:page-height="29.7cm" style:num-format="1" style:paper-tray-name="[From printer settings]" style:print-orientation="portrait" fo:margin-top="3.2cm" fo:margin-bottom="2.499cm" fo:margin-left="2.701cm" fo:margin-right="3cm" style:writing-mode="lr-tb" style:layout-grid-color="#c0c0c0" style:layout-grid-lines="20" style:layout-grid-base-height="0.706cm" style:layout-grid-ruby-height="0.353cm" style:layout-grid-mode="none" style:layout-grid-ruby-below="false" style:layout-grid-print="false" style:layout-grid-display="false" style:footnote-max-height="0cm">
    <style:columns fo:column-count="1" fo:column-gap="0cm"/>
    <style:footnote-sep style:width="0.018cm" style:distance-before-sep="0.101cm" style:distance-after-sep="0.101cm" style:adjustment="left" style:rel-width="25%" style:color="#000000"/>
   </style:page-layout-properties>
   <style:header-style/>
   <style:footer-style>
    <style:header-footer-properties fo:min-height="1.699cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="1.199cm" style:shadow="none" style:dynamic-spacing="false"/>
   </style:footer-style>
  </style:page-layout>
 </office:automatic-styles>
 <office:master-styles>
  <style:master-page style:name="Standard" style:page-layout-name="Mpm1">
   <style:footer>
    <text:p text:style-name="Footer"><text:page-number text:select-page="current"/></text:p>
   </style:footer>
  </style:master-page>
 </office:master-styles>
</office:document-styles>
'''
    _MIMETYPE = 'application/vnd.oasis.opendocument.text'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._contentParser = NovxToOdt()

    def write(self):
        if self.novel.languages is None:
            self.novel.get_languages()
        return super().write()

    def _convert_from_novx(self, text, quick=False, append=False, firstInChapter=False, xml=False):
        if not text:
            return ''

        if quick:
            return escape(text)

        if xml:
            self._contentParser.feed(text, self.novel.languages, append, firstInChapter)
            return ''.join(self._contentParser.odtLines)

        lines = text.split('\n')
        text = '</text:p><text:p text:style-name="First_20_line_20_indent">'.join(lines)
        if append:
            return f'<text:p text:style-name="First_20_line_20_indent">{text}</text:p>'

        return f'<text:p text:style-name="Text_20_body">{text}</text:p>'

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        filterMessage = fileHeaderMapping['Filters']
        if filterMessage:
            fileHeaderMapping['Filters'] = filterMessage.replace(
                'First_20_line_20_indent',
                'Text_20_body'
                ).replace('<text:p', '\n<text:p')
        return fileHeaderMapping

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, **kwargs):
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal, **kwargs)
        sectionMapping['sectionTitle'] = _('Section')
        return sectionMapping

    def _set_up(self):

        super()._set_up()

        try:
            with open(f'{self._tempDir}/manifest.rdf', 'w', encoding='utf-8') as f:
                f.write(self._MANIFEST_RDF)
        except:
            raise Error(f'{_("Cannot write file")}: "manifest.rdf"')



class OdtWBriefSynopsis(OdtWriter):
    DESCRIPTION = _('Brief synopsis')
    SUFFIX = BRF_SYNOPSIS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sectionTemplate = '''<text:p text:style-name="Text_20_body">$Title</text:p>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWChapterDesc(OdtWriter):
    DESCRIPTION = _('Chapter descriptions')
    SUFFIX = CHAPTERS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:section text:style-name="Sect1" text:name="$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#$Title|outline">$Title</text:a></text:h>
$Desc
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWCharacters(OdtWriter):
    DESCRIPTION = _('Character descriptions')
    SUFFIX = CHARACTERS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _characterTemplate = f'''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$FullName$AKA</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Description")}</text:h>
<text:section text:style-name="Sect1" text:name="desc:$ID">
$Desc
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">$CustomChrBio</text:h>
<text:section text:style-name="Sect1" text:name="bio:$ID">
$Bio
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">$CustomChrGoals</text:h>
<text:section text:style-name="Sect1" text:name="goals:$ID">
$Goals
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Notes")}</text:h>
<text:section text:style-name="Sect1" text:name="notes:$ID">
$Notes
</text:section>
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_characterMapping(self, crId):
        characterMapping = OdtWriter._get_characterMapping(self, crId)
        if self.novel.characters[crId].aka:
            characterMapping['AKA'] = f' ("{self.novel.characters[crId].aka}")'
        if self.novel.characters[crId].fullName:
            characterMapping['FullName'] = f'/{self.novel.characters[crId].fullName}'

        return characterMapping
from string import Template



class OdtWFormatted(OdtWriter):
    _CONTENT_XML_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:xforms="http://www.w3.org/2002/xforms" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0" office:version="1.2">
 <office:scripts/>
 <office:font-face-decls>
  <style:font-face style:name="StarSymbol" svg:font-family="StarSymbol" style:font-charset="x-symbol"/>
  <style:font-face style:name="Consolas" svg:font-family="Consolas" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  <style:font-face style:name="Courier New" svg:font-family="&apos;Courier New&apos;" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
 </office:font-face-decls>
 $automaticStyles
 <office:body>
  <office:text text:use-soft-page-breaks="true">

'''

    def _get_fileHeaderMapping(self):
        styleMapping = {}
        if self.novel.languages:
            lines = ['<office:automatic-styles>']
            for i, language in enumerate(self.novel.languages, 1):
                try:
                    lngCode, ctrCode = language.split('-')
                except:
                    lngCode = 'zxx'
                    ctrCode = 'none'
                lines.append((f'  <style:style style:name="T{i}" style:family="text">\n'
                              f'   <style:text-properties fo:language="{lngCode}" fo:country="{ctrCode}" '
                              f'style:language-asian="{lngCode}" style:country-asian="{ctrCode}" '
                              f'style:language-complex="{lngCode}" style:country-complex="{ctrCode}"/>\n'
                              '  </style:style>'))
            lines.append(' </office:automatic-styles>')
            styleMapping['automaticStyles'] = '\n'.join(lines)
        else:
            styleMapping['automaticStyles'] = '<office:automatic-styles/>'
        template = Template(self._CONTENT_XML_HEADER)
        projectTemplateMapping = super()._get_fileHeaderMapping()
        projectTemplateMapping['ContentHeader'] = template.safe_substitute(styleMapping)
        return projectTemplateMapping

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.append(self._fileFooter)
        text = ''.join(lines)
        return text



class OdtWExport(OdtWFormatted):
    DESCRIPTION = _('manuscript')
    _fileHeader = f'''$ContentHeader<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sectionTemplate = '''$SectionContent
'''

    _sectionDivider = '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'
    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER



class OdtWItems(OdtWriter):
    DESCRIPTION = _('Item descriptions')
    SUFFIX = ITEMS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _itemTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$AKA</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_itemMapping(self, itId):
        itemMapping = super()._get_itemMapping(itId)
        if self.novel.items[itId].aka:
            itemMapping['AKA'] = f' ("{self.novel.items[itId].aka}")'
        return itemMapping


class OdtWLocations(OdtWriter):
    DESCRIPTION = _('Location descriptions')
    SUFFIX = LOCATIONS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _locationTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$AKA</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_locationMapping(self, lcId):
        locationMapping = super()._get_locationMapping(lcId)
        if self.novel.locations[lcId].aka:
            locationMapping['AKA'] = f' ("{self.novel.locations[lcId].aka}")'
        return locationMapping


class OdtWManuscript(OdtWFormatted):
    DESCRIPTION = _('Editable manuscript')
    SUFFIX = MANUSCRIPT_SUFFIX

    _fileHeader = f'''$ContentHeader<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sectionTemplate = f'''<text:h text:style-name="{_('Heading_20_3_20_invisible')}" text:outline-level="3">$Title</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$SectionContent
</text:section>
'''
    _sectionDivider = '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'

    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER



class OdtWPartDesc(OdtWriter):
    DESCRIPTION = _('Part descriptions')
    SUFFIX = PARTS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:section text:style-name="Sect1" text:name="$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1"><text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#$Title|outline">$Title</text:a></text:h>
$Desc
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER
from string import Template



class OdtWPlotlines(OdtWriter):
    DESCRIPTION = _('Plot lines')
    SUFFIX = PLOTLINES_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _arcHeadingTemplate = f'''<text:h text:style-name="Heading_20_1" text:outline-level="1">{_('Plot lines')}</text:h>
'''

    _arcTemplate = '''$Heading<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:bookmark text:name="$ID"/>$Title</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
$TurningPoints
'''
    _plotPointTemplate = '''<text:h text:style-name="Heading_20_3" text:outline-level="3"><text:bookmark text:name="$ID"/>$Title</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
'''
    _assocSectionTemplate = '''<text:p text:style-name="Text_20_body" />
<text:p text:style-name="Text_20_body">$Section: <text:span text:style-name="Emphasis">$SectionTitle</text:span></text:p>    
<text:p text:style-name="Text_20_body">→ <text:a xlink:href="../$ProjectName$SectionsSuffix.odt#$scID%7Cregion">$Description</text:a></text:p>
<text:p text:style-name="Text_20_body">→ <text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#$scID%7Cregion">$Manuscript</text:a></text:p>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def write(self):
        self._firstPlotLine = True
        super().write()

    def _get_arcMapping(self, plId):
        arcMapping = super()._get_arcMapping(plId)
        if self._firstPlotLine:
            arcMapping['Heading'] = self._arcHeadingTemplate
            self._firstPlotLine = False
        else:
            arcMapping['Heading'] = ''
        plotPoints = []
        for ppId in self.novel.tree.get_children(plId):
            plotPointMapping = dict(
                ID=ppId,
                Title=self.novel.plotPoints[ppId].title,
                Desc=self._convert_from_novx(self.novel.plotPoints[ppId].desc),
            )
            template = Template(self._plotPointTemplate)
            plotPoints.append(template.safe_substitute(plotPointMapping))
            scId = self.novel.plotPoints[ppId].sectionAssoc
            if scId:
                sectionAssocMapping = dict(
                    SectionTitle=self.novel.sections[scId].title,
                    ProjectName=self._convert_from_novx(self.projectName, True),
                    Section=_('Section'),
                    Description=_('Description'),
                    Manuscript=_('Manuscript'),
                    scID=scId,
                    ManuscriptSuffix=MANUSCRIPT_SUFFIX,
                    SectionsSuffix=SECTIONS_SUFFIX,
                )
                template = Template(self._assocSectionTemplate)
                plotPoints.append(template.safe_substitute(sectionAssocMapping))
        arcMapping['TurningPoints'] = '\n'.join(plotPoints)
        return arcMapping



class OdtWProof(OdtWFormatted):
    DESCRIPTION = _('Tagged manuscript for proofing')
    SUFFIX = PROOF_SUFFIX

    _fileHeader = f'''$ContentHeader<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sectionTemplate = f'''<text:h text:style-name="Heading_20_3" text:outline-level="3">$Title</text:h>
<text:p text:style-name="{_('Section_20_mark')}">[$ID]</text:p>
$SectionContent
<text:p text:style-name="{_('Section_20_mark')}">[/{SECTION_PREFIX}]</text:p>
'''

    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER

    def _convert_from_novx(self, text, quick=False, append=False, firstInChapter=False, xml=False):
        return super()._convert_from_novx(text, quick=quick, append=append, firstInChapter=False, xml=xml)


class OdtWSectionDesc(OdtWriter):
    DESCRIPTION = _('Section descriptions')
    SUFFIX = SECTIONS_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters
'''

    _partTemplate = '''<text:section text:style-name="Sect1" text:name="$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:section text:style-name="Sect1" text:name="$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#$Title|outline">$Title</text:a></text:h>
'''

    _sectionTemplate = f'''<text:h text:style-name="{_('Heading_20_3_20_invisible')}" text:outline-level="3">$Title</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
'''

    _sectionDivider = '''<text:p text:style-name="Heading_20_4">* * *</text:p>
'''

    _chapterEndTemplate = '''</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, **kwargs):
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal, **kwargs)
        sectionMapping['Manuscript'] = _('Manuscript')
        return sectionMapping


class OdtWStages(OdtWriter):
    DESCRIPTION = _('Story structure')
    SUFFIX = STAGES_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>

<text:h text:style-name="Heading_20_1" text:outline-level="1">{_('Story structure')}</text:h>
'''

    _stage1Template = '''<text:h text:style-name="Heading_20_1" text:outline-level="1"><text:bookmark text:name="$ID"/>$Title</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
'''

    _stage2Template = '''<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:bookmark text:name="$ID"/>$Title</text:h>
<text:section text:style-name="Sect1" text:name="$ID">
$Desc
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

from string import Template

from datetime import date


LANGUAGE_TAG = re.compile(r'\<span xml\:lang=\"(.*?)\"\>')


class Novel(BasicElement):

    def __init__(self,
            authorName=None,
            wordTarget=None,
            wordCountStart=None,
            languageCode=None,
            countryCode=None,
            renumberChapters=None,
            renumberParts=None,
            renumberWithinParts=None,
            romanChapterNumbers=None,
            romanPartNumbers=None,
            saveWordCount=None,
            workPhase=None,
            chapterHeadingPrefix=None,
            chapterHeadingSuffix=None,
            partHeadingPrefix=None,
            partHeadingSuffix=None,
            customPlotProgress=None,
            customCharacterization=None,
            customWorldBuilding=None,
            customGoal=None,
            customConflict=None,
            customOutcome=None,
            customChrBio=None,
            customChrGoals=None,
            referenceDate=None,
            tree=None,
            **kwargs):
        super().__init__(**kwargs)
        self._authorName = authorName
        self._wordTarget = wordTarget
        self._wordCountStart = wordCountStart
        self._languageCode = languageCode
        self._countryCode = countryCode
        self._renumberChapters = renumberChapters
        self._renumberParts = renumberParts
        self._renumberWithinParts = renumberWithinParts
        self._romanChapterNumbers = romanChapterNumbers
        self._romanPartNumbers = romanPartNumbers
        self._saveWordCount = saveWordCount
        self._workPhase = workPhase
        self._chapterHeadingPrefix = chapterHeadingPrefix
        self._chapterHeadingSuffix = chapterHeadingSuffix
        self._partHeadingPrefix = partHeadingPrefix
        self._partHeadingSuffix = partHeadingSuffix
        self._customPlotProgress = customPlotProgress
        self._customCharacterization = customCharacterization
        self._customWorldBuilding = customWorldBuilding
        self._customGoal = customGoal
        self._customConflict = customConflict
        self._customOutcome = customOutcome
        self._customChrBio = customChrBio
        self._customChrGoals = customChrGoals

        self.chapters = {}
        self.sections = {}
        self.plotPoints = {}
        self.languages = None
        self.plotLines = {}
        self.locations = {}
        self.items = {}
        self.characters = {}
        self.projectNotes = {}
        try:
            self.referenceWeekDay = date.fromisoformat(referenceDate).weekday()
            self._referenceDate = referenceDate
        except:
            self.referenceWeekDay = None
            self._referenceDate = None
        self.tree = tree

    @property
    def authorName(self):
        return self._authorName

    @authorName.setter
    def authorName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._authorName != newVal:
            self._authorName = newVal
            self.on_element_change()

    @property
    def wordTarget(self):
        return self._wordTarget

    @wordTarget.setter
    def wordTarget(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._wordTarget != newVal:
            self._wordTarget = newVal
            self.on_element_change()

    @property
    def wordCountStart(self):
        return self._wordCountStart

    @wordCountStart.setter
    def wordCountStart(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._wordCountStart != newVal:
            self._wordCountStart = newVal
            self.on_element_change()

    @property
    def languageCode(self):
        return self._languageCode

    @languageCode.setter
    def languageCode(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._languageCode != newVal:
            self._languageCode = newVal
            self.on_element_change()

    @property
    def countryCode(self):
        return self._countryCode

    @countryCode.setter
    def countryCode(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._countryCode != newVal:
            self._countryCode = newVal
            self.on_element_change()

    @property
    def renumberChapters(self):
        return self._renumberChapters

    @renumberChapters.setter
    def renumberChapters(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberChapters != newVal:
            self._renumberChapters = newVal
            self.on_element_change()

    @property
    def renumberParts(self):
        return self._renumberParts

    @renumberParts.setter
    def renumberParts(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberParts != newVal:
            self._renumberParts = newVal
            self.on_element_change()

    @property
    def renumberWithinParts(self):
        return self._renumberWithinParts

    @renumberWithinParts.setter
    def renumberWithinParts(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberWithinParts != newVal:
            self._renumberWithinParts = newVal
            self.on_element_change()

    @property
    def romanChapterNumbers(self):
        return self._romanChapterNumbers

    @romanChapterNumbers.setter
    def romanChapterNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._romanChapterNumbers != newVal:
            self._romanChapterNumbers = newVal
            self.on_element_change()

    @property
    def romanPartNumbers(self):
        return self._romanPartNumbers

    @romanPartNumbers.setter
    def romanPartNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._romanPartNumbers != newVal:
            self._romanPartNumbers = newVal
            self.on_element_change()

    @property
    def saveWordCount(self):
        return self._saveWordCount

    @saveWordCount.setter
    def saveWordCount(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._saveWordCount != newVal:
            self._saveWordCount = newVal
            self.on_element_change()

    @property
    def workPhase(self):
        return self._workPhase

    @workPhase.setter
    def workPhase(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._workPhase != newVal:
            self._workPhase = newVal
            self.on_element_change()

    @property
    def chapterHeadingPrefix(self):
        return self._chapterHeadingPrefix

    @chapterHeadingPrefix.setter
    def chapterHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._chapterHeadingPrefix != newVal:
            self._chapterHeadingPrefix = newVal
            self.on_element_change()

    @property
    def chapterHeadingSuffix(self):
        return self._chapterHeadingSuffix

    @chapterHeadingSuffix.setter
    def chapterHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._chapterHeadingSuffix != newVal:
            self._chapterHeadingSuffix = newVal
            self.on_element_change()

    @property
    def partHeadingPrefix(self):
        return self._partHeadingPrefix

    @partHeadingPrefix.setter
    def partHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._partHeadingPrefix != newVal:
            self._partHeadingPrefix = newVal
            self.on_element_change()

    @property
    def partHeadingSuffix(self):
        return self._partHeadingSuffix

    @partHeadingSuffix.setter
    def partHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._partHeadingSuffix != newVal:
            self._partHeadingSuffix = newVal
            self.on_element_change()

    @property
    def customPlotProgress(self):
        return self._customPlotProgress

    @customPlotProgress.setter
    def customPlotProgress(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customPlotProgress != newVal:
            self._customPlotProgress = newVal
            self.on_element_change()

    @property
    def customCharacterization(self):
        return self._customCharacterization

    @customCharacterization.setter
    def customCharacterization(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customCharacterization != newVal:
            self._customCharacterization = newVal
            self.on_element_change()

    @property
    def customWorldBuilding(self):
        return self._customWorldBuilding

    @customWorldBuilding.setter
    def customWorldBuilding(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customWorldBuilding != newVal:
            self._customWorldBuilding = newVal
            self.on_element_change()

    @property
    def customGoal(self):
        return self._customGoal

    @customGoal.setter
    def customGoal(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customGoal != newVal:
            self._customGoal = newVal
            self.on_element_change()

    @property
    def customConflict(self):
        return self._customConflict

    @customConflict.setter
    def customConflict(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customConflict != newVal:
            self._customConflict = newVal
            self.on_element_change()

    @property
    def customOutcome(self):
        return self._customOutcome

    @customOutcome.setter
    def customOutcome(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customOutcome != newVal:
            self._customOutcome = newVal
            self.on_element_change()

    @property
    def customChrBio(self):
        return self._customChrBio

    @customChrBio.setter
    def customChrBio(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customChrBio != newVal:
            self._customChrBio = newVal
            self.on_element_change()

    @property
    def customChrGoals(self):
        return self._customChrGoals

    @customChrGoals.setter
    def customChrGoals(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customChrGoals != newVal:
            self._customChrGoals = newVal
            self.on_element_change()

    @property
    def referenceDate(self):
        return self._referenceDate

    @referenceDate.setter
    def referenceDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._referenceDate != newVal:
            if not newVal:
                self._referenceDate = None
                self.referenceWeekDay = None
                self.on_element_change()
            else:
                try:
                    self.referenceWeekDay = date.fromisoformat(newVal).weekday()
                except:
                    pass
                else:
                    self._referenceDate = newVal
                    self.on_element_change()

    def check_locale(self):
        if not self._languageCode or self._languageCode == 'None':
            try:
                sysLng, sysCtr = locale.getlocale()[0].split('_')
            except:
                sysLng, sysCtr = locale.getdefaultlocale()[0].split('_')
            self._languageCode = sysLng
            self._countryCode = sysCtr
            self.on_element_change()
            return

        try:
            if len(self._languageCode) == 2:
                if len(self._countryCode) == 2:
                    return
        except:
            pass
        self._languageCode = 'zxx'
        self._countryCode = 'none'
        self.on_element_change()

    def from_xml(self, xmlElement):
        super().from_xml(xmlElement)
        self.renumberChapters = xmlElement.get('renumberChapters', None) == '1'
        self.renumberParts = xmlElement.get('renumberParts', None) == '1'
        self.renumberWithinParts = xmlElement.get('renumberWithinParts', None) == '1'
        self.romanChapterNumbers = xmlElement.get('romanChapterNumbers', None) == '1'
        self.romanPartNumbers = xmlElement.get('romanPartNumbers', None) == '1'
        self.saveWordCount = xmlElement.get('saveWordCount', None) == '1'
        workPhase = xmlElement.get('workPhase', None)
        if workPhase in ('1', '2', '3', '4', '5'):
            self.workPhase = int(workPhase)
        else:
            self.workPhase = None

        self.authorName = self._get_element_text(xmlElement, 'Author')

        self.chapterHeadingPrefix = self._get_element_text(xmlElement, 'ChapterHeadingPrefix')
        self.chapterHeadingSuffix = self._get_element_text(xmlElement, 'ChapterHeadingSuffix')

        self.partHeadingPrefix = self._get_element_text(xmlElement, 'PartHeadingPrefix')
        self.partHeadingSuffix = self._get_element_text(xmlElement, 'PartHeadingSuffix')

        self.customPlotProgress = self._get_element_text(xmlElement, 'CustomPlotProgress')
        self.customCharacterization = self._get_element_text(xmlElement, 'CustomCharacterization')
        self.customWorldBuilding = self._get_element_text(xmlElement, 'CustomWorldBuilding')

        self.customGoal = self._get_element_text(xmlElement, 'CustomGoal')
        self.customConflict = self._get_element_text(xmlElement, 'CustomConflict')
        self.customOutcome = self._get_element_text(xmlElement, 'CustomOutcome')

        self.customChrBio = self._get_element_text(xmlElement, 'CustomChrBio')
        self.customChrGoals = self._get_element_text(xmlElement, 'CustomChrGoals')

        if xmlElement.find('WordCountStart') is not None:
            self.wordCountStart = int(xmlElement.find('WordCountStart').text)
        if xmlElement.find('WordTarget') is not None:
            self.wordTarget = int(xmlElement.find('WordTarget').text)

        self.referenceDate = verified_date(self._get_element_text(xmlElement, 'ReferenceDate'))

    def get_languages(self):

        def languages(text):
            if not text:
                return

            m = LANGUAGE_TAG.search(text)
            while m:
                text = text[m.span()[1]:]
                yield m.group(1)
                m = LANGUAGE_TAG.search(text)

        self.languages = []
        for scId in self.sections:
            text = self.sections[scId].sectionContent
            if not text:
                continue

            for language in languages(text):
                if not language in self.languages:
                    self.languages.append(language)

    def to_xml(self, xmlElement):
        super().to_xml(xmlElement)
        if self.renumberChapters:
            xmlElement.set('renumberChapters', '1')
        if self.renumberParts:
            xmlElement.set('renumberParts', '1')
        if self.renumberWithinParts:
            xmlElement.set('renumberWithinParts', '1')
        if self.romanChapterNumbers:
            xmlElement.set('romanChapterNumbers', '1')
        if self.romanPartNumbers:
            xmlElement.set('romanPartNumbers', '1')
        if self.saveWordCount:
            xmlElement.set('saveWordCount', '1')
        if self.workPhase is not None:
            xmlElement.set('workPhase', str(self.workPhase))

        if self.authorName:
            ET.SubElement(xmlElement, 'Author').text = self.authorName

        if self.chapterHeadingPrefix:
            ET.SubElement(xmlElement, 'ChapterHeadingPrefix').text = self.chapterHeadingPrefix
        if self.chapterHeadingSuffix:
            ET.SubElement(xmlElement, 'ChapterHeadingSuffix').text = self.chapterHeadingSuffix

        if self.partHeadingPrefix:
            ET.SubElement(xmlElement, 'PartHeadingPrefix').text = self.partHeadingPrefix
        if self.partHeadingSuffix:
            ET.SubElement(xmlElement, 'PartHeadingSuffix').text = self.partHeadingSuffix

        if self.customPlotProgress:
            ET.SubElement(xmlElement, 'CustomPlotProgress').text = self.customPlotProgress
        if self.customCharacterization:
            ET.SubElement(xmlElement, 'CustomCharacterization').text = self.customCharacterization
        if self.customWorldBuilding:
            ET.SubElement(xmlElement, 'CustomWorldBuilding').text = self.customWorldBuilding

        if self.customGoal:
            ET.SubElement(xmlElement, 'CustomGoal').text = self.customGoal
        if self.customConflict:
            ET.SubElement(xmlElement, 'CustomConflict').text = self.customConflict
        if self.customOutcome:
            ET.SubElement(xmlElement, 'CustomOutcome').text = self.customOutcome

        if self.customChrBio:
            ET.SubElement(xmlElement, 'CustomChrBio').text = self.customChrBio
        if self.customChrGoals:
            ET.SubElement(xmlElement, 'CustomChrGoals').text = self.customChrGoals

        if self.wordCountStart:
            ET.SubElement(xmlElement, 'WordCountStart').text = str(self.wordCountStart)
        if self.wordTarget:
            ET.SubElement(xmlElement, 'WordTarget').text = str(self.wordTarget)

        if self.referenceDate:
            ET.SubElement(xmlElement, 'ReferenceDate').text = self.referenceDate

    def update_plot_lines(self):
        for scId in self.sections:
            self.sections[scId].scPlotPoints = {}
            self.sections[scId].scPlotLines = []
            for plId in self.plotLines:
                if scId in self.plotLines[plId].sections:
                    self.sections[scId].scPlotLines.append(plId)
                    for ppId in self.tree.get_children(plId):
                        if self.plotPoints[ppId].sectionAssoc == scId:
                            self.sections[scId].scPlotPoints[ppId] = plId
                            break



class CrossReferences:

    def __init__(self):

        self.scnPerChr = {}
        self.scnPerLoc = {}
        self.scnPerItm = {}
        self.scnPerTag = {}
        self.chrPerTag = {}
        self.locPerTag = {}
        self.itmPerTag = {}
        self.chpPerScn = {}
        self.srtSections = None

    def generate_xref(self, novel: Novel):
        self.scnPerChr = {}
        self.scnPerLoc = {}
        self.scnPerItm = {}
        self.scnPerTag = {}
        self.chrPerTag = {}
        self.locPerTag = {}
        self.itmPerTag = {}
        self.chpPerScn = {}
        self.srtSections = []

        for crId in novel.tree.get_children(CR_ROOT):
            self.scnPerChr[crId] = []
            if novel.characters[crId].tags:
                for tag in novel.characters[crId].tags:
                    if not tag in self.chrPerTag:
                        self.chrPerTag[tag] = []
                    self.chrPerTag[tag].append(crId)

        for lcId in novel.tree.get_children(LC_ROOT):
            self.scnPerLoc[lcId] = []
            if novel.locations[lcId].tags:
                for tag in novel.locations[lcId].tags:
                    if not tag in self.locPerTag:
                        self.locPerTag[tag] = []
                    self.locPerTag[tag].append(lcId)

        for itId in novel.tree.get_children(IT_ROOT):
            self.scnPerItm[itId] = []
            if novel.items[itId].tags:
                for tag in novel.items[itId].tags:
                    if not tag in self.itmPerTag:
                        self.itmPerTag[tag] = []
                    self.itmPerTag[tag].append(itId)

        for chId in novel.tree.get_children(CH_ROOT):

            for scId in novel.tree.get_children(chId):
                self.srtSections.append(scId)
                self.chpPerScn[scId] = chId

                if novel.sections[scId].characters:
                    for crId in novel.sections[scId].characters:
                        self.scnPerChr[crId].append(scId)

                if novel.sections[scId].locations:
                    for lcId in novel.sections[scId].locations:
                        self.scnPerLoc[lcId].append(scId)

                if novel.sections[scId].items:
                    for itId in novel.sections[scId].items:
                        self.scnPerItm[itId].append(scId)

                if novel.sections[scId].tags:
                    for tag in novel.sections[scId].tags:
                        if not tag in self.scnPerTag:
                            self.scnPerTag[tag] = []
                        self.scnPerTag[tag].append(scId)


class OdtWXref(OdtWriter):
    DESCRIPTION = _('Cross reference')
    SUFFIX = XREF_SUFFIX

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''
    _sectionTemplate = f'''<text:p text:style-name="{_('Section_20_mark')}">
<text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#$ID%7Cregion">$SectionNumber</text:a> (Ch $Chapter) $Title
</text:p>
'''
    _unusedSectionTemplate = f'''<text:p text:style-name="{_('Section_20_mark_20_unused')}">
$SectionNumber (Ch $Chapter) $Title (Unused)
</text:p>
'''
    _characterTemplate = '''<text:p text:style-name="Text_20_body">
<text:a xlink:href="../$ProjectName$CharactersSuffix.odt#$ID%7Cregion">$Title</text:a> $FullName
</text:p>
'''
    _locationTemplate = '''<text:p text:style-name="Text_20_body">
<text:a xlink:href="../$ProjectName$LocationsSuffix.odt#$ID%7Cregion">$Title</text:a>
</text:p>
'''
    _itemTemplate = '''<text:p text:style-name="Text_20_body">
<text:a xlink:href="../$ProjectName$ItemsSuffix.odt#$ID%7Cregion">$Title</text:a>
</text:p>
'''
    _scnPerChrTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Sections with Character $Title:</text:h>
'''
    _scnPerLocTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Sections with Location $Title:</text:h>
'''
    _scnPerItmTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Sections with Item $Title:</text:h>
'''
    _chrPerTagTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Characters tagged $Tag:</text:h>
'''
    _locPerTagTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Locations tagged $Tag:</text:h>
'''
    _itmPerTagTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Items tagged $Tag:</text:h>
'''
    _scnPerTagtemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Sections tagged $Tag:</text:h>
'''
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._xr = CrossReferences()

    def _get_characters(self):
        lines = []
        headerTemplate = Template(self._scnPerChrTemplate)
        for crId in self._xr.scnPerChr:
            if self._xr.scnPerChr[crId]:
                lines.append(headerTemplate.safe_substitute(self._get_characterMapping(crId)))
                lines.extend(self._get_sections(self._xr.scnPerChr[crId]))
        return lines

    def _get_characterTags(self):
        lines = []
        headerTemplate = Template(self._chrPerTagTemplate)
        template = Template(self._characterTemplate)
        for tag in self._xr.chrPerTag:
            if self._xr.chrPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                for crId in self._xr.chrPerTag[tag]:
                    lines.append(template.safe_substitute(self._get_characterMapping(crId)))
        return lines

    def _get_items(self):
        lines = []
        headerTemplate = Template(self._scnPerItmTemplate)
        for itId in self._xr.scnPerItm:
            if self._xr.scnPerItm[itId]:
                lines.append(headerTemplate.safe_substitute(self._get_itemMapping(itId)))
                lines.extend(self._get_sections(self._xr.scnPerItm[itId]))
        return lines

    def _get_itemTags(self):
        lines = []
        headerTemplate = Template(self._itmPerTagTemplate)
        template = Template(self._itemTemplate)
        for tag in self._xr.itmPerTag:
            if self._xr.itmPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                for itId in self._xr.itmPerTag[tag]:
                    lines.append(template.safe_substitute(self._get_itemMapping(itId)))
        return lines

    def _get_locations(self):
        lines = []
        headerTemplate = Template(self._scnPerLocTemplate)
        for lcId in self._xr.scnPerLoc:
            if self._xr.scnPerLoc[lcId]:
                lines.append(headerTemplate.safe_substitute(self._get_locationMapping(lcId)))
                lines.extend(self._get_sections(self._xr.scnPerLoc[lcId]))
        return lines

    def _get_locationTags(self):
        lines = []
        headerTemplate = Template(self._locPerTagTemplate)
        template = Template(self._locationTemplate)
        for tag in self._xr.locPerTag:
            if self._xr.locPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                for lcId in self._xr.locPerTag[tag]:
                    lines.append(template.safe_substitute(self._get_locationMapping(lcId)))
        return lines

    def _get_sectionMapping(self, scId, **kwargs):
        sectionNumber = self._xr.srtSections.index(scId) + 1
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, 0, **kwargs)
        chapterNumber = self.novel.tree.get_children(CH_ROOT).index(self._xr.chpPerScn[scId]) + 1
        sectionMapping['Chapter'] = str(chapterNumber)
        return sectionMapping

    def _get_sections(self, sections):
        lines = []
        for scId in sections:
            if self.novel.sections[scId].scType == 0:
                template = Template(self._sectionTemplate)
            elif self.novel.sections[scId].scType == 1:
                template = Template(self._unusedSectionTemplate)
            else:
                continue

            lines.append(template.safe_substitute(self._get_sectionMapping(scId)))
        return lines

    def _get_sectionTags(self):
        lines = []
        headerTemplate = Template(self._scnPerTagtemplate)
        for tag in self._xr.scnPerTag:
            if self._xr.scnPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                lines.extend(self._get_sections(self._xr.scnPerTag[tag]))
        return lines

    def _get_tagMapping(self, tag):
        tagMapping = dict(
            Tag=tag,
        )
        return tagMapping

    def _get_text(self):
        self._xr.generate_xref(self.novel)
        lines = self._get_fileHeader()
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_sectionTags())
        lines.extend(self._get_characterTags())
        lines.extend(self._get_locationTags())
        lines.extend(self._get_itemTags())
        lines.append(self._fileFooter)
        return ''.join(lines)


class ScVpFilter:

    def __init__(self, crId):
        self._crId = crId

    def accept(self, source, scId):
        try:
            if self._crId == source.novel.sections[scId].characters[0]:
                return True

        except:
            pass
        return False

    def get_message(self, source):
        return f'{_("Sections from viewpoint")}: {source.novel.characters[self._crId].title}'


class ScAcFilter:

    def __init__(self, plId):
        self._plId = plId

    def accept(self, source, scId):
        try:
            if self._plId in source.novel.sections[scId].scPlotLines:
                return True

        except:
            pass
        return False

    def get_message(self, source):
        return f'{_("Sections belonging to plot line")}: "{source.novel.plotLines[self._plId].title}"'


class ChVpFilter:

    def __init__(self, crId):
        self._crId = crId

    def accept(self, source, chId):
        for scId in source.novel.tree.get_children(chId):
            try:
                if self._crId == source.novel.sections[scId].characters[0]:
                    return True

            except:
                pass
        return False

    def get_message(self, source):
        return f'{_("Chapters from viewpoint")}: {source.novel.characters[self._crId].title}'


class ChAcFilter:

    def __init__(self, plId):
        self._plId = plId

    def accept(self, source, chId):
        for scId in source.novel.tree.get_children(chId):
            try:
                if self._plId in source.novel.sections[scId].scPlotLines:
                    return True

            except:
                pass
        return False

    def get_message(self, source):
        return f'{_("Chapters belonging to plot line")}: "{source.novel.plotLines[self._plId].title}"'


class FilterFactory:

    @staticmethod
    def get_section_filter(filterElementId):
        if filterElementId.startswith(CHARACTER_PREFIX):
            return ScVpFilter(filterElementId)

        elif filterElementId.startswith(PLOT_LINE_PREFIX):
            return ScAcFilter(filterElementId)

        else:
            return Filter()

    @staticmethod
    def get_chapter_filter(filterElementId):
        if filterElementId.startswith(CHARACTER_PREFIX):
            return ChVpFilter(filterElementId)

        elif filterElementId.startswith(PLOT_LINE_PREFIX):
            return ChAcFilter(filterElementId)

        else:
            return Filter()
from datetime import date
import webbrowser


prefs = {}

HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/'
HOME_URL = 'https://github.com/peter88213/novelibre/'


def to_string(text):
    if text is None:
        return ''

    return str(text)


def open_help(page):
    webbrowser.open(f'{HELP_URL}{page}')


def datestr(isoDate):
    if prefs['localize_date']:
        return date.fromisoformat(isoDate).strftime("%x")
    else:
        return isoDate


def get_section_date_str(section):
    if prefs['localize_date']:
        return section.localeDate
    else:
        return section.date
from tkinter import messagebox
from tkinter import ttk

import tkinter as tk


class SimpleDialog:

    def __init__(self, master,
                 text='', buttons=[], default=None, cancel=None,
                 title=None, class_=None):
        if class_:
            self.root = tk.Toplevel(master, class_=class_)
        else:
            self.root = tk.Toplevel(master)
        if title:
            self.root.title(title)
            self.root.iconname(title)

        _setup_dialog(self.root)

        self.message = tk.Message(self.root, text=text, aspect=400, bg='white')
        self.message.pack(expand=1, fill='both')
        self.frame = tk.Frame(self.root)
        self.frame.pack()
        self.num = default
        self.cancel = cancel
        self.default = default
        self.root.bind('<Return>', self.return_event)
        for num in range(len(buttons)):
            s = buttons[num]
            b = ttk.Button(
                self.frame,
                text=s,
                command=(lambda self=self, num=num: self.done(num))
                )
            if num == default:
                b.configure(default='active')
            b.pack(side='left', fill='both', expand=1, padx=5, pady=10)
        self.root.protocol('WM_DELETE_WINDOW', self.wm_delete_window)
        self.root.transient(master)
        _place_window(self.root, master)

    def go(self):
        self.root.wait_visibility()
        self.root.grab_set()
        self.root.mainloop()
        self.root.destroy()
        return self.num

    def return_event(self, event):
        if self.default is None:
            self.root.bell()
        else:
            self.done(self.default)

    def wm_delete_window(self):
        if self.cancel is None:
            self.root.bell()
        else:
            self.done(self.cancel)

    def done(self, num):
        self.num = num
        self.root.quit()


class Dialog(tk.Toplevel):


    def __init__(self, parent, title=None):
        master = parent
        tk.Toplevel.__init__(self, master)

        self.withdraw()  # remain invisible for now
        if parent is not None and parent.winfo_viewable():
            self.transient(parent)

        if title:
            self.title(title)

        _setup_dialog(self)

        self.parent = parent

        self.result = None

        body = tk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        if self.initial_focus is None:
            self.initial_focus = self

        self.protocol('WM_DELETE_WINDOW', self.cancel)

        _place_window(self, parent)

        self.initial_focus.focus_set()

        self.wait_visibility()
        self.grab_set()
        self.wait_window(self)

    def destroy(self):
        self.initial_focus = None
        tk.Toplevel.destroy(self)


    def body(self, master):
        pass

    def buttonbox(self):

        box = tk.Frame(self)

        w = ttk.Button(box, text=_('OK'), width=10, command=self.ok, default='active')
        w.pack(side='left', padx=5, pady=10)
        w = ttk.Button(box, text=_('Cancel'), width=10, command=self.cancel)
        w.pack(side='left', padx=5, pady=10)

        self.bind('<Return>', self.ok)
        self.bind('<Escape>', self.cancel)

        box.pack()


    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set()  # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        try:
            self.apply()
        finally:
            self.cancel()

    def cancel(self, event=None):

        if self.parent is not None:
            self.parent.focus_set()
        self.destroy()


    def validate(self):

        return 1  # override

    def apply(self):

        pass  # override


def _place_window(w, parent=None):
    w.wm_withdraw()  # Remain invisible while we figure out the geometry
    w.update_idletasks()  # Actualize geometry information

    minwidth = w.winfo_reqwidth()
    minheight = w.winfo_reqheight()
    maxwidth = w.winfo_vrootwidth()
    maxheight = w.winfo_vrootheight()
    if parent is not None and parent.winfo_ismapped():
        x = parent.winfo_rootx() + (parent.winfo_width() - minwidth) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - minheight) // 2
        vrootx = w.winfo_vrootx()
        vrooty = w.winfo_vrooty()
        x = min(x, vrootx + maxwidth - minwidth)
        x = max(x, vrootx)
        y = min(y, vrooty + maxheight - minheight)
        y = max(y, vrooty)
        if w._windowingsystem == 'aqua':
            y = max(y, 22)
    else:
        x = (w.winfo_screenwidth() - minwidth) // 2
        y = (w.winfo_screenheight() - minheight) // 2

    w.wm_maxsize(maxwidth, maxheight)
    w.wm_geometry('+%d+%d' % (x, y))
    w.wm_deiconify()  # Become visible at the desired location


def _setup_dialog(w):
    if w._windowingsystem == 'aqua':
        w.tk.call('::tk::unsupported::MacWindowStyle', 'style',
                  w, 'moveableModal', '')
    elif w._windowingsystem == 'x11':
        w.wm_attributes('-type', 'dialog')



class _QueryDialog(Dialog):

    def __init__(self, title, prompt,
                 initialvalue=None,
                 minvalue=None, maxvalue=None,
                 parent=None):

        self.prompt = prompt
        self.minvalue = minvalue
        self.maxvalue = maxvalue

        self.initialvalue = initialvalue

        Dialog.__init__(self, parent, title)

    def destroy(self):
        self.entry = None
        Dialog.destroy(self)

    def body(self, master):

        w = ttk.Label(master, text=self.prompt, justify='left')
        w.grid(row=0, padx=5, sticky='w')

        self.entry = ttk.Entry(master, name='entry')
        self.entry.grid(row=1, padx=5, pady=5, sticky='w' + 'e')

        if self.initialvalue is not None:
            self.entry.insert(0, self.initialvalue)
            self.entry.select_range(0, 'end')

        return self.entry

    def validate(self):
        try:
            result = self.getresult()
        except ValueError:
            messagebox.showwarning(
                _('Illegal value'),
                f'{self.errormessage}\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.minvalue is not None and result < self.minvalue:
            messagebox.showwarning(
                _('Too small'),
                f'{_("The allowed minimum value is")} {self.minvalue}.\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.maxvalue is not None and result > self.maxvalue:
            messagebox.showwarning(
                _('Too large'),
                f'{_("The allowed maximum value is")} {self.maxvalue}.\n{_("Please try again")}.',
                parent=self
            )
            return 0

        self.result = result

        return 1


class _QueryInteger(_QueryDialog):
    errormessage = _('Not an integer.')

    def getresult(self):
        return self.getint(self.entry.get())


def askinteger(title, prompt, **kw):
    d = _QueryInteger(title, prompt, **kw)
    return d.result


class _QueryFloat(_QueryDialog):
    errormessage = _('Not a floating point value.')

    def getresult(self):
        return self.getdouble(self.entry.get())


def askfloat(title, prompt, **kw):
    d = _QueryFloat(title, prompt, **kw)
    return d.result


class _QueryString(_QueryDialog):

    def __init__(self, *args, **kw):
        if 'show' in kw:
            self.__show = kw['show']
            del kw['show']
        else:
            self.__show = None
        _QueryDialog.__init__(self, *args, **kw)

    def body(self, master):
        entry = _QueryDialog.body(self, master)
        if self.__show is not None:
            entry.configure(show=self.__show)
        return entry

    def getresult(self):
        return self.entry.get()


def askstring(title, prompt, **kw):
    d = _QueryString(title, prompt, **kw)
    return d.result



class NvDocExporter:
    EXPORT_TARGET_CLASSES = [
        DataWriter,
        OdsWCharList,
        OdsWGrid,
        OdsWItemList,
        OdsWLocList,
        OdsWPlotList,
        OdsWSectionList,
        OdtWBriefSynopsis,
        OdtWChapterDesc,
        OdtWCharacters,
        OdtWExport,
        OdtWItems,
        OdtWLocations,
        OdtWManuscript,
        OdtWPartDesc,
        OdtWPlotlines,
        OdtWProof,
        OdtWSectionDesc,
        OdtWStages,
        OdtWXref,
        ]

    def __init__(self, ui):
        self._ui = ui
        self.exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)
        self._source = None
        self._target = None

    def run(self, source, suffix, **kwargs):
        self._source = source
        self._isNewer = False
        __, self._target = self.exportTargetFactory.make_file_objects(self._source.filePath, suffix=suffix)
        if os.path.isfile(self._target.filePath):
            targetTimestamp = os.path.getmtime(self._target.filePath)
            try:
                if  targetTimestamp > self._source.timestamp:
                    timeStatus = _('Newer than the project file')
                    self._isNewer = True
                    defaultButton = 1
                else:
                    timeStatus = _('Older than the project file')
                    defaultButton = 0
            except:
                timeStatus = ''
                defaultButton = 0
            self._targetFileDate = datetime.fromtimestamp(targetTimestamp).strftime('%c')
            title = _('Export document')
            message = _('{0} already exists.\n(last saved on {2})\n{1}.\n\nOpen this document instead of overwriting it?').format(
                        norm_path(self._target.DESCRIPTION), timeStatus, self._targetFileDate)
            askOverwrite = SimpleDialog(
                None,
                text=message,
                buttons=[_('Overwrite'), _('Open existing'), _('Cancel')],
                default=defaultButton,
                cancel=2,
                title=title
                )
            values = [False, True, None]
            openExisting = values[askOverwrite.go()]
            if openExisting is None:
                raise Error(f'{_("Action canceled by user")}.')

            elif openExisting:
                open_document(self._target.filePath)
                if self._isNewer:
                    prefix = ''
                else:
                    prefix = '!'
                return f'{prefix}{_("Opened existing {0} (last saved on {1})").format(self._target.DESCRIPTION, self._targetFileDate)}.'

        filterElementId = kwargs.get('filter', '')
        self._target.sectionFilter = FilterFactory.get_section_filter(filterElementId)
        self._target.chapterFilter = FilterFactory.get_chapter_filter(filterElementId)
        self._target.novel = self._source.novel
        self._target.write()
        self._targetFileDate = datetime.now().replace(microsecond=0).isoformat(sep=' ')
        if kwargs.get('show', True):
            askOpen = kwargs.get('ask', True) and prefs['ask_doc_open']
            if not askOpen or self._ui.ask_yes_no(
                _('{} created.\n\nOpen now?').format(norm_path(self._target.DESCRIPTION)),
                title=self._target.novel.title,
                ):
                open_document(self._target.filePath)
        return _('Created {0} on {1}.').format(self._target.DESCRIPTION, self._targetFileDate)


from html import escape


class HtmlReport(FileExport):
    DESCRIPTION = 'HTML report'
    EXTENSION = '.html'
    SUFFIX = '_report'

    _fileHeader = '''<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

<style type="text/css">
body {font-family: sans-serif}
p.title {font-size: larger; font-weight: bold}
td {padding: 10}
tr.heading {font-size:smaller; font-weight: bold; background-color:rgb(240,240,240)}
table {border-spacing: 0}
table, td {border: rgb(240,240,240) solid 1px; vertical-align: top}
td.chtitle {font-weight: bold}
</style>

'''

    _fileFooter = '''</table>
</body>
</html>
'''

    def _convert_from_novx(self, text, quick=False, **kwargs):
        if not text:
            return ''

        text = escape(text.rstrip())
        if quick:
            return text.replace('\n', ' ')

        newlines = []
        for line in text.split('\n'):
            newlines.append(f'<p>{line}</p>')
        return '\n'.join(newlines)



class HtmlCharacters(HtmlReport):
    DESCRIPTION = 'HTML charcters report'
    EXTENSION = '.html'
    SUFFIX = CHARACTER_REPORT_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Characters')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Characters')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('Full name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
<td>$CustomChrBio</td>
<td>$CustomChrGoals</td>
<td>{_('Notes')}</td>
</tr>
'''

    _characterTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$FullName</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
<td>$Bio</td>
<td>$Goals</td>
<td>$Notes</td>
</tr>
'''



class HtmlItems(HtmlReport):
    DESCRIPTION = 'HTML items report'
    EXTENSION = '.html'
    SUFFIX = ITEM_REPORT_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Items')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Items')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
</tr>
'''

    _itemTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
</tr>
'''



class HtmlLocations(HtmlReport):
    DESCRIPTION = 'HTML locations report'
    EXTENSION = '.html'
    SUFFIX = LOCATION_REPORT_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Locations')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Locations')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
</tr>
'''

    _locationTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
</tr>
'''



class HtmlPlotList(HtmlReport):
    DESCRIPTION = _('HTML Plot list')
    SUFFIX = PLOTLIST_SUFFIX

    def write(self):

        def create_cell(text, attr=''):
            return f'<td {attr}>{self._convert_from_novx(text)}</td>'

        htmlText = [self._fileHeader]
        htmlText.append(f'''<title>{self.novel.title}</title>
</head>
<body>
<p class=title>{self.novel.title} - {_("Plot")}</p>
<table>''')
        plotLineColors = (
            'LightSteelBlue',
            'Gold',
            'Coral',
            'YellowGreen',
            'MediumTurquoise',
            'Plum',
            )

        if self.novel.tree.get_children(PL_ROOT) is not None:
            plotLines = self.novel.tree.get_children(PL_ROOT)
        else:
            plotLines = []

        htmlText.append('<tr class="heading">')
        htmlText.append(create_cell(''))
        for i, plId in enumerate(plotLines):
            colorIndex = i % len(plotLineColors)
            htmlText.append(create_cell(self.novel.plotLines[plId].title, attr=f'style="background: {plotLineColors[colorIndex]}"'))
        htmlText.append('</tr>')

        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    htmlText.append(f'<tr>')
                    htmlText.append(create_cell(self.novel.sections[scId].title))
                    for i, plId in enumerate(plotLines):
                        colorIndex = i % len(plotLineColors)
                        if scId in self.novel.plotLines[plId].sections:
                            plotPoints = []
                            for ppId in self.novel.tree.get_children(plId):
                                if scId == self.novel.plotPoints[ppId].sectionAssoc:
                                    plotPoints.append(self.novel.plotPoints[ppId].title)
                            htmlText.append(create_cell(list_to_string(plotPoints), attr=f'style="background: {plotLineColors[colorIndex]}"'))
                        else:
                            htmlText.append(create_cell(''))
                    htmlText.append(f'</tr>')

        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))


class HtmlProjectNotes(HtmlReport):
    DESCRIPTION = 'HTML project notes report'
    EXTENSION = '.html'
    SUFFIX = PROJECTNOTES_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Project notes')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Project notes')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Title')}</td>
<td>{_('Text')}</td>
</tr>
'''

    _projectNoteTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$Desc</td>
</tr>
'''



class NvHtmlReporter:
    EXPORT_TARGET_CLASSES = [
        HtmlCharacters,
        HtmlLocations,
        HtmlItems,
        HtmlPlotList,
        HtmlProjectNotes,
        ]

    def __init__(self):
        self._exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)

    def run(self, source, suffix, tempdir='.'):
        kwargs = {'suffix':suffix}
        __, target = self._exportTargetFactory.make_file_objects(source.filePath, **kwargs)
        __, filename = os.path.split(target.filePath)
        target.filePath = f'{tempdir}/{filename}'
        target.novel = source.novel
        target.write()
        open_document(target.filePath)

from tkinter import ttk


class PickList(tk.Toplevel):

    def __init__(self, title, geometry, sourceElements, pickButtonLabel, command):
        super().__init__()
        self._command = command
        self.title(title)
        self.geometry(geometry)
        self.grab_set()
        self.focus()
        self.pickList = ttk.Treeview(self, selectmode='extended')
        scrollY = ttk.Scrollbar(self.pickList, orient='vertical', command=self.pickList.yview)
        self.pickList.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self.pickList.pack(fill='both', expand=True)
        ttk.Button(self, text=pickButtonLabel, command=self._pick_element).pack()
        for elemId in sourceElements:
            self.pickList.insert('', 'end', elemId, text=sourceElements[elemId].title)

    def _pick_element(self):
        selection = self.pickList.selection()
        self.destroy()
        self._command(selection)


def create_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'



class CharacterDataReader(NovxFile):
    DESCRIPTION = _('XML character data file')
    EXTENSION = '.xml'

    def read(self):
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        self._read_characters(root)



class ItemDataReader(NovxFile):
    DESCRIPTION = _('XML item data file')
    EXTENSION = '.xml'

    def read(self):
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        self._read_items(root)



class LocationDataReader(NovxFile):
    DESCRIPTION = _('XML location data file')
    EXTENSION = '.xml'

    def read(self):
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        self._read_locations(root)



class NvDataImporter:

    def __init__(self, model, view, controller, filePath, elemPrefix):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        sources = {
            CHARACTER_PREFIX:CharacterDataReader,
            LOCATION_PREFIX:LocationDataReader,
            ITEM_PREFIX:ItemDataReader,
        }
        source = sources[elemPrefix](filePath)
        source.novel = self._mdl.nvService.make_novel()
        errorMessages = {
            CHARACTER_PREFIX:_('No character data found'),
            LOCATION_PREFIX:_('No location data found'),
            ITEM_PREFIX:_('No item data found'),
        }
        try:
            source.read()
        except:
            self._ui.set_status(f"!{errorMessages[elemPrefix]}: {norm_path(filePath)}")
            return

        sourceElements = {
            CHARACTER_PREFIX:source.novel.characters,
            LOCATION_PREFIX:source.novel.locations,
            ITEM_PREFIX:source.novel.items,
        }
        targetElements = {
            CHARACTER_PREFIX:self._mdl.novel.characters,
            LOCATION_PREFIX:self._mdl.novel.locations,
            ITEM_PREFIX:self._mdl.novel.items,
        }
        elemParents = {
            CHARACTER_PREFIX:CR_ROOT,
            LOCATION_PREFIX:LC_ROOT,
            ITEM_PREFIX:IT_ROOT,
        }
        windowTitles = {
            CHARACTER_PREFIX:_('Select characters'),
            LOCATION_PREFIX:_('Select locations'),
            ITEM_PREFIX:_('Select items'),
        }
        self._elemPrefix = elemPrefix
        self._sourceElements = sourceElements[elemPrefix]
        self._targetElements = targetElements[elemPrefix]
        self._elemParent = elemParents[elemPrefix]
        pickButtonLabel = _('Import selected elements')
        offset = 50
        size = '300x400'
        __, x, y = self._ui.root.geometry().split('+')
        windowGeometry = f'{size}+{int(x)+offset}+{int(y)+offset}'
        PickList(
            windowTitles[elemPrefix],
            windowGeometry,
            self._sourceElements,
            pickButtonLabel,
            self._pick_element
            )

    def _pick_element(self, elements):
        i = 0
        for  elemId in elements:
            newId = create_id(self._targetElements, prefix=self._elemPrefix)
            self._targetElements[newId] = self._sourceElements[elemId]
            self._mdl.novel.tree.append(self._elemParent, newId)
            i += 1
        if i > 0:
            self._ui.tv.go_to_node(newId)
            self._ui.set_status(f'{i} {_("elements imported")}')



class ImportSourceFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX is not None:
                if sourcePath.endswith(f'{fileClass.SUFFIX }{fileClass.EXTENSION}'):
                    sourceFile = fileClass(sourcePath, **kwargs)
                    return sourceFile, None

        raise Error(f'{_("This document is not meant to be written back")}.')



class ImportTargetFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        sourceSuffix = kwargs['suffix']
        if sourceSuffix:
            e = fileName.split(sourceSuffix)
            if len(e) > 1:
                e.pop()
            ywPathBasis = ''.join(e)
        else:
            ywPathBasis = fileName

        for fileClass in self._fileClasses:
            if os.path.isfile(f'{ywPathBasis}{fileClass.EXTENSION}'):
                targetFile = fileClass(f'{ywPathBasis}{fileClass.EXTENSION}', **kwargs)
                return None, targetFile

        raise Error(f'{_("No novelibre project to write")}.')

from xml.sax.saxutils import unescape




class Splitter:
    PART_SEPARATOR = '#'
    CHAPTER_SEPARATOR = '##'
    SCENE_SEPARATOR = '###'
    APPENDED_SCENE_SEPARATOR = '####'
    DESC_SEPARATOR = '|'
    _CLIP_TITLE = 20

    def split_sections(self, novel):

        def create_chapter(chapterId, title, desc, level):
            newChapter = Chapter()
            newChapter.title = title
            newChapter.desc = desc
            newChapter.chLevel = level
            newChapter.chType = 0
            novel.chapters[chapterId] = newChapter

        def create_section(sectionId, parent, splitCount, title, desc, appendToPrev):
            WARNING = '(!)'

            newSection = Section(appendToPrev=appendToPrev)
            if title:
                newSection.title = title
            elif parent.title:
                if len(parent.title) > self._CLIP_TITLE:
                    title = f'{parent.title[:self._CLIP_TITLE]}...'
                else:
                    title = parent.title
                newSection.title = f'{title} Split: {splitCount}'
            else:
                newSection.title = f'{_("New Section")} Split: {splitCount}'
            if desc:
                newSection.desc = desc
            if parent.desc and not parent.desc.startswith(WARNING):
                parent.desc = f'{WARNING}{parent.desc}'
            if parent.goal and not parent.goal.startswith(WARNING):
                parent.goal = f'{WARNING}{parent.goal}'
            if parent.conflict and not parent.conflict.startswith(WARNING):
                parent.conflict = f'{WARNING}{parent.conflict}'
            if parent.outcome and not parent.outcome.startswith(WARNING):
                parent.outcome = f'{WARNING}{parent.outcome}'

            if parent.status > 2:
                parent.status = 2
            newSection.status = parent.status
            newSection.scType = parent.scType
            newSection.scene = parent.scene
            newSection.date = parent.date
            newSection.time = parent.time
            newSection.day = parent.day
            newSection.lastsDays = parent.lastsDays
            newSection.lastsHours = parent.lastsHours
            newSection.lastsMinutes = parent.lastsMinutes
            novel.sections[sectionId] = newSection

        sectionsSplit = False
        chIndex = 0
        for scanChId in novel.tree.get_children(CH_ROOT):
            scList = novel.tree.get_children(scanChId)
            novel.tree.delete_children(scanChId)
            chId = scanChId
            for scanScId in scList:
                scId = scanScId
                novel.tree.append(chId, scId)
                if not novel.sections[scId].sectionContent:
                    continue

                if not '#' in novel.sections[scId].sectionContent:
                    continue

                sectionContent = novel.sections[scanScId].sectionContent.replace('</p>', '</p>\n')
                lines = sectionContent.split('\n')
                newLines = []
                inSection = True
                sectionSplitCount = 0

                for line in lines:
                    plainLine = re.sub(r'\<.*?\>', '', line)

                    if '#' in plainLine:
                        heading = plainLine.strip('# ').split(self.DESC_SEPARATOR)
                        title = heading[0]
                        desc = ''
                        if len(heading) > 1:
                            desc = heading[1]

                    if plainLine.startswith(self.SCENE_SEPARATOR):
                        if inSection:
                            novel.sections[scId].sectionContent = ''.join(newLines)
                        newLines = []
                        sectionSplitCount += 1
                        newScId = create_id(novel.sections, prefix=SECTION_PREFIX)
                        create_section(
                            newScId,
                            novel.sections[scId],
                            sectionSplitCount,
                            title,
                            desc,
                            plainLine.startswith(self.APPENDED_SCENE_SEPARATOR)
                        )
                        novel.tree.append(chId, newScId)
                        scId = newScId
                        sectionsSplit = True
                        inSection = True

                    elif plainLine.startswith(self.CHAPTER_SEPARATOR):
                        if inSection:
                            novel.sections[scId].sectionContent = ''.join(newLines)
                            newLines = []
                            sectionSplitCount = 0
                            inSection = False
                        newChId = create_id(novel.chapters, prefix=CHAPTER_PREFIX)
                        if not title:
                            title = _('New Chapter')
                        create_chapter(newChId, title, desc, 2)
                        chIndex += 1
                        novel.tree.insert(CH_ROOT, chIndex, newChId)
                        chId = newChId
                        sectionsSplit = True

                    elif plainLine.startswith(self.PART_SEPARATOR):
                        if inSection:
                            novel.sections[scId].sectionContent = ''.join(newLines)
                            newLines = []
                            sectionSplitCount = 0
                            inSection = False
                        newChId = create_id(novel.chapters, prefix=CHAPTER_PREFIX)
                        if not title:
                            title = _('New Part')
                        create_chapter(newChId, title, desc, 1)
                        chIndex += 1
                        novel.tree.insert(CH_ROOT, chIndex, newChId)
                        chId = newChId

                    elif not inSection:
                        newLines.append(line)
                        sectionSplitCount += 1
                        newScId = create_id(novel.sections, prefix=SECTION_PREFIX)
                        create_section(newScId, novel.sections[scId], sectionSplitCount, '', '', False)
                        novel.tree.append(chId, newScId)
                        scId = newScId
                        sectionsSplit = True
                        inSection = True

                    else:
                        newLines.append(line)

                if inSection:
                    novel.sections[scId].sectionContent = '\n'.join(newLines)
            chIndex += 1
        return sectionsSplit
from abc import ABC

from abc import ABC



class OdfReader(File, ABC):

    def is_locked(self):
        return odf_is_locked(self.filePath)
from xml import sax



class OdtParser(sax.ContentHandler):

    def __init__(self, client):
        super().__init__()

        self._emTags = ['Emphasis']

        self._strongTags = ['Strong_20_Emphasis']

        self._blockquoteTags = ['Quotations']

        self._languageTags = {}

        self._headingTags = {}

        self._heading = None

        self._getData = False

        self._span = []

        self._paraSpan = []

        self._style = None

        self._languageCode = None
        self._countryCode = None

        self._client = client

    def feed_file(self, filePath):
        namespaces = dict(
            office='urn:oasis:names:tc:opendocument:xmlns:office:1.0',
            style='urn:oasis:names:tc:opendocument:xmlns:style:1.0',
            fo='urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0',
            dc='http://purl.org/dc/elements/1.1/',
            meta='urn:oasis:names:tc:opendocument:xmlns:meta:1.0'
        )
        styles, meta, content = self._unzip_odt_file(filePath)
        self._read_styles_xml(styles, namespaces)
        self._read_meta_xml(meta, namespaces)
        sax.parseString(content, self)

    def characters(self, content):
        if self._getData:
            self._client.handle_data(sax.saxutils.escape(content))

    def endElement(self, name):
        if name in ('text:p', 'text:h'):
            try:
                span = self._paraSpan.pop()
                if span is not None:
                    self._client.handle_endtag(span)
            except:
                pass
            self._getData = False
            if self._heading:
                self._client.handle_endtag(self._heading)
                self._heading = None
            else:
                self._client.handle_endtag('p')
            return

        if name == 'text:span':
            try:
                spans = self._span.pop()
                for span in reversed(spans):
                    if span is not None:
                        self._client.handle_endtag(span)
                return

            except:
                return

        if name == 'text:section':
            self._client.handle_endtag('div')
            return

        if name == 'office:annotation':
            self._client.handle_endtag('comment')
            self._getData = True
            return

        if name == 'dc:creator':
            self._client.handle_endtag('creator')
            self._getData = False
            return

        if name == 'dc:date':
            self._client.handle_endtag('date')
            self._getData = False
            return

        if name == 'text:note':
            self._client.handle_endtag('note')
            self._getData = True
            return

        if name == 'text:note-citation':
            self._client.handle_endtag('note-citation')
            self._getData = False
            return

        if name == 'text:h':
            self._client.handle_endtag(self._heading)
            self._heading = None
            return

        if name == 'text:list-item':
            self._client.handle_endtag('li')
            return

        if name == 'text:list':
            self._client.handle_endtag('ul')
            return

        if name == 'style:style':
            self._style = None

    def startElement(self, name, attrs):
        xmlAttributes = {}
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            xmlAttributes[attrKey] = attrValue
        style = xmlAttributes.get('text:style-name', '')

        if name in ('text:p', 'text:h'):
            self._getData = True
            param = []
            if style in self._languageTags:
                param.append(('lang', self._languageTags[style]))
            if style in self._blockquoteTags:
                param.append(('style', 'quotations'))
                self._client.handle_starttag('p', param)
            elif style.startswith('Heading'):
                self._heading = f'h{style[-1]}'
                self._client.handle_starttag(self._heading, [()])
            elif style in self._headingTags:
                self._heading = self._headingTags[style]
                self._client.handle_starttag(self._heading, [()])
            else:
                if not param:
                    param = [()]
                self._client.handle_starttag('p', param)
            if style in self._strongTags:
                self._paraSpan.append('strong')
                self._client.handle_starttag('strong', [()])
            elif style in self._emTags:
                self._paraSpan.append('em')
                self._client.handle_starttag('em', [()])
            else:
                self._paraSpan.append(None)
            return

        if name == 'text:span':
            spans = []
            if style in self._emTags:
                spans.append('em')
                self._client.handle_starttag('em', [()])
            elif style in self._strongTags:
                spans.append('strong')
                self._client.handle_starttag('strong', [()])
            if style in self._languageTags:
                spans.append('lang')
                self._client.handle_starttag('lang', [('lang', self._languageTags[style])])
            if not spans:
                spans.append(None)
            self._span.append(spans)
            return

        if name == 'text:section':
            self._client.handle_starttag('div', [('id', xmlAttributes['text:name'])])
            return

        if name == 'office:annotation':
            self._client.handle_starttag('comment', [()])
            self._getData = False
            return

        if name == 'dc:date':
            self._client.handle_starttag('date', [()])
            self._getData = True
            return

        if name == 'dc:creator':
            self._client.handle_starttag('creator', [()])
            self._getData = True
            return

        if name == 'text:note':
            self._client.handle_starttag('note', [
                ('id', xmlAttributes.get('text:id', '')),
                ('class', xmlAttributes.get('text:note-class', ''))
                ]
            )
            self._getData = False
            return

        if name == 'text:note-citation':
            self._client.handle_starttag('note-citation', [()])
            self._getData = True
            return

        if name == 'text:h':
            try:
                self._heading = f'h{xmlAttributes["text:outline-level"]}'
            except:
                self._heading = f'h{style[-1]}'
            self._client.handle_starttag(self._heading, [()])
            return

        if name == 'text:list-item':
            self._client.handle_starttag('li', [()])
            return

        if name == 'text:list':
            self._client.handle_starttag('ul', [()])
            return

        if name == 'style:style':
            self._style = xmlAttributes.get('style:name', None)
            styleName = xmlAttributes.get('style:parent-style-name', '')
            if styleName.startswith('Heading'):
                self._headingTags[self._style] = f'h{styleName[-1]}'
            elif styleName == 'Quotations':
                self._blockquoteTags.append(self._style)
            return

        if name == 'style:text-properties':

            if xmlAttributes.get('fo:font-style', None) == 'italic':
                self._emTags.append(self._style)

            if xmlAttributes.get('fo:font-weight', None) == 'bold':
                self._strongTags.append(self._style)

            if xmlAttributes.get('fo:language', False):
                languageCode = xmlAttributes['fo:language']
                countryCode = xmlAttributes['fo:country']
                if languageCode == self._languageCode:
                    if countryCode == self._countryCode:
                        return

                if countryCode != 'none':
                    locale = f'{languageCode}-{countryCode}'
                else:
                    locale = languageCode
                self._languageTags[self._style] = locale
            return

        if name == 'text:s':
            self._client.handle_starttag('s', [()])

    def _read_meta_xml(self, meta, namespaces):
        if meta is None:
            return

        root = ET.fromstring(meta)
        meta = root.find('office:meta', namespaces)
        title = meta.find('dc:title', namespaces)
        if title is not None:
            if title.text:
                self._client.handle_starttag('title', [()])
                self._client.handle_data(title.text)
                self._client.handle_endtag('title')
        author = meta.find('meta:initial-creator', namespaces)
        if author is not None:
            if author.text:
                self._client.handle_starttag('meta', [('', 'author'), ('', author.text)])
        desc = meta.find('dc:description', namespaces)
        if desc is not None:
            if desc.text:
                self._client.handle_starttag('meta', [('', 'description'), ('', desc.text)])

    def _read_styles_xml(self, styles, namespaces):
        root = ET.fromstring(styles)
        styles = root.find('office:styles', namespaces)
        for defaultStyle in styles.iterfind('style:default-style', namespaces):
            if defaultStyle.get(f'{{{namespaces["style"]}}}family') == 'paragraph':
                textProperties = defaultStyle.find('style:text-properties', namespaces)
                self._languageCode = textProperties.get(f'{{{namespaces["fo"]}}}language')
                self._countryCode = textProperties.get(f'{{{namespaces["fo"]}}}country')
                self._client.handle_starttag('body', [('language', self._languageCode), ('country', self._countryCode)])
                return

    def _unzip_odt_file(self, filePath):
        try:
            with zipfile.ZipFile(filePath, 'r') as odfFile:
                content = odfFile.read('content.xml')
                styles = odfFile.read('styles.xml')
                try:
                    meta = odfFile.read('meta.xml')
                except KeyError:
                    meta = None
                return styles, meta, content

        except:
            raise Error(f'{_("Cannot read file")}: "{norm_path(filePath)}".')



class OdtReader(OdfReader, ABC):
    EXTENSION = '.odt'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._lines = []
        self._scId = None
        self._chId = None
        self._plId = None
        self._ppId = None
        self._skip_data = False

    def handle_data(self, data):
        pass

    def handle_endtag(self, tag):
        pass

    def handle_starttag(self, tag, attrs):
        if tag == 'div':

            if attrs[0][0] == 'id':
                if attrs[0][1].startswith(SECTION_PREFIX):
                    self._scId = attrs[0][1]
                    return

                if attrs[0][1].startswith(CHAPTER_PREFIX):
                    self._chId = attrs[0][1]
                    return

                if attrs[0][1].startswith(PLOT_LINE_PREFIX):
                    self._plId = attrs[0][1]
                    return

                if attrs[0][1].startswith(PLOT_POINT_PREFIX):
                    self._ppId = attrs[0][1]
            return

        if tag == 's':
            self._lines.append(' ')

    def read(self):
        parser = OdtParser(self)
        try:
            parser.feed_file(self.filePath)
        except Exception as ex:
            raise Error(f'{_("Cannot parse File")}: {norm_path(self.filePath)} - {str(ex)}')



class OdtRFormatted(OdtReader):

    def read(self):
        self.novel.languages = []
        super().read()

        sectionSplitter = Splitter()
        self.sectionsSplit = sectionSplitter.split_sections(self.novel)



class OdtRImport(OdtRFormatted):
    DESCRIPTION = _('Work in progress')
    SUFFIX = ''
    _SCENE_DIVIDER = '* * *'
    _LOW_WORDCOUNT = 10

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._chCount = 0
        self._scCount = 0

    def handle_data(self, data):
        if self._scId is not None and self._SCENE_DIVIDER in data:
            self._scId = None
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if tag == 'p':
            self._lines.append('</p>')
            if self._scId is None:
                return

            sectionText = ''.join(self._lines).rstrip()
            self.novel.sections[self._scId].sectionContent = sectionText
            if self.novel.sections[self._scId].wordCount < self._LOW_WORDCOUNT:
                self.novel.sections[self._scId].status = 1
            else:
                self.novel.sections[self._scId].status = 2
            return

        if tag in ('em', 'strong', 'comment', 'creator', 'date', 'note', 'note-citation', 'ul', 'li'):
            self._lines.append(f'</{tag}>')
            return

        if tag == 'lang':
            self._lines.append('</span>')
            return

        if tag in ('h1', 'h2'):
            self.novel.chapters[self._chId].title = unescape(re.sub('<.*?>', '', ''.join(self._lines)))
            self._lines = []
            return

        if tag == 'title':
            self.novel.title = ''.join(self._lines)

    def handle_starttag(self, tag, attrs):
        if tag == 'p':
            if self._scId is None and self._chId is not None:
                self._lines = []
                self._scCount += 1
                self._scId = f'{SECTION_PREFIX}{self._scCount}'
                self.novel.sections[self._scId] = Section(title=f'{_("Section")} {self._scCount}',
                                                      scType=0,
                                                      scene=0,
                                                      status=1,
                                                      )
                self.novel.tree.append(self._chId, self._scId)
            attributes = ''
            try:
                for att in attrs:
                    attributes = f'{attributes} {att[0]}="{att[1]}"'
                    if att[0] == 'lang':
                        if not att[1] in self.novel.languages:
                            self.novel.languages.append(att[1])
            except:
                pass
            self._lines.append(f'<p{attributes}>')
            return

        if tag in('em', 'strong', 'comment', 'creator', 'date', 'note-citation', 'ul', 'li'):
            self._lines.append(f'<{tag}>')
            return

        if tag == 'lang':
            if attrs[0][0] == 'lang':
                if not attrs[0][1] in self.novel.languages:
                    self.novel.languages.append(attrs[0][1])
                self._lines.append(f'<span xml:lang="{attrs[0][1]}">')
            return

        if tag == 'note':
            attributes = ''
            for att in attrs:
                attributes = f'{attributes} {att[0]}="{att[1]}"'
            self._lines.append(f'<note {attributes}>')
            return

        if tag in ('h1', 'h2'):
            self._scId = None
            self._lines = []
            self._chCount += 1
            self._chId = f'{CHAPTER_PREFIX}{self._chCount}'
            self.novel.chapters[self._chId] = Chapter(chType=0)
            self.novel.tree.append(CH_ROOT, self._chId)
            if tag == 'h1':
                self.novel.chapters[self._chId].chLevel = 1
            else:
                self.novel.chapters[self._chId].chLevel = 2
            return

        if tag == 'div':
            self._scId = None
            self._chId = None
            return

        if tag == 'meta':
            if attrs[0][1] == 'author':
                self.novel.authorName = attrs[1][1]
            if attrs[0][1] == 'description':
                self.novel.desc = attrs[1][1]
            return

        if tag == 'title':
            self._lines = []
            return

        if tag == 'body':
            for attr in attrs:
                if attr[0] == 'language':
                    if attr[1]:
                        self.novel.languageCode = attr[1]
                elif attr[0] == 'country':
                    if attr[1]:
                        self.novel.countryCode = attr[1]
            return

        if tag == 's':
            self._lines.append(' ')

    def read(self):
        self.novel.languages = []
        super().read()

from xml.sax.saxutils import unescape



class OdtROutline(OdtReader):
    DESCRIPTION = _('Novel outline')
    SUFFIX = ''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._chCount = 0
        self._scCount = 0

    def handle_data(self, data):
        self._lines.append(data)

    def handle_endtag(self, tag):
        text = ''.join(self._lines)
        if tag == 'p':
            self._lines = [f'{text.strip()}\n']
            if self._scId is not None:
                self.novel.sections[self._scId].desc = text
                return

            if self._chId is not None:
                self.novel.chapters[self._chId].desc = text
            return

        if tag in ('h1', 'h2'):
            self.novel.chapters[self._chId].title = unescape(re.sub('<.*?>', '', text).strip())
            self._lines = []
            return

        if tag == 'h3':
            self.novel.sections[self._scId].title = unescape(re.sub('<.*?>', '', text).strip())
            self._lines = []
            return

        if tag == 'title':
            self.novel.title = text.strip()

    def handle_starttag(self, tag, attrs):
        if tag in ('h1', 'h2'):
            self._scId = None
            self._lines = []
            self._chCount += 1
            self._chId = f'{CHAPTER_PREFIX}{self._chCount}'
            self.novel.chapters[self._chId] = Chapter(chType=0)
            self.novel.tree.append(CH_ROOT, self._chId)
            if tag == 'h1':
                self.novel.chapters[self._chId].chLevel = 1
            else:
                self.novel.chapters[self._chId].chLevel = 2
            return

        if tag == 'h3':
            self._lines = []
            self._scCount += 1
            self._scId = f'{SECTION_PREFIX}{self._scCount}'
            self.novel.sections[self._scId] = Section(
                scType=0,
                scene=0,
                status=1,
            )
            self.novel.tree.append(self._chId, self._scId)
            self.novel.sections[self._scId].sectionContent = ''
            return

        if tag == 'div':
            self._scId = None
            self._chId = None
            return

        if tag == 'meta':
            if attrs[0][1] == 'author':
                self.novel.authorName = attrs[1][1]
                return

            if attrs[0][1] == 'description':
                self.novel.desc = attrs[1][1]
            return

        if tag == 'title':
            self._lines = []
            return

        if tag == 'body':
            for attr in attrs:
                if attr[0] == 'language':
                    if attr[1]:
                        self.novel.languageCode = attr[1]
                if attr[0] == 'country':
                    if attr[1]:
                        self.novel.countryCode = attr[1]
            return

        if tag == 's':
            self._lines.append(' ')


class NewProjectFactory(FileFactory):
    DO_NOT_IMPORT = [XREF_SUFFIX, BRF_SYNOPSIS_SUFFIX]

    def make_file_objects(self, sourcePath, **kwargs):
        if not self._canImport(sourcePath):
            raise Error(f'{_("This document is not meant to be written back")}.')

        fileName, __ = os.path.splitext(sourcePath)
        targetFile = NovxFile(f'{fileName}{NovxFile.EXTENSION}', **kwargs)
        if sourcePath.endswith('.odt'):
            try:
                with zipfile.ZipFile(sourcePath, 'r') as odfFile:
                    content = odfFile.read('content.xml')
            except:
                raise Error(f'{_("Cannot read file")}: "{norm_path(sourcePath)}".')

            if bytes('Heading_20_3', encoding='utf-8') in content:
                sourceFile = OdtROutline(sourcePath, **kwargs)
            else:
                sourceFile = OdtRImport(sourcePath, **kwargs)
            return sourceFile, targetFile

        else:
            for fileClass in self._fileClasses:
                if fileClass.SUFFIX is not None:
                    if sourcePath.endswith(f'{fileClass.SUFFIX}{fileClass.EXTENSION}'):
                        sourceFile = fileClass(sourcePath, **kwargs)
                        return sourceFile, targetFile

            raise Error(f'{_("File type is not supported")}: "{norm_path(sourcePath)}".')

    def _canImport(self, sourcePath):
        fileName, __ = os.path.splitext(sourcePath)
        for suffix in self.DO_NOT_IMPORT:
            if fileName.endswith(suffix):
                return False

        return True
from abc import ABC, abstractmethod




class OdsParser:

    def __init__(self):
        super().__init__()
        self._rows = []
        self._cells = []
        self._inCell = None
        self.__cellsPerRow = 0

    def get_rows(self, filePath, cellsPerRow):
        namespaces = dict(
            office='urn:oasis:names:tc:opendocument:xmlns:office:1.0',
            text='urn:oasis:names:tc:opendocument:xmlns:text:1.0',
            table='urn:oasis:names:tc:opendocument:xmlns:table:1.0',
        )
        content = self._unzip_ods_file(filePath)
        root = ET.fromstring(content)

        body = root.find('office:body', namespaces)
        spreadsheet = body.find('office:spreadsheet', namespaces)
        table = spreadsheet.find('table:table', namespaces)
        rows = []
        for row in table.iterfind('table:table-row', namespaces):
            cells = []
            i = 0
            for cell in row.iterfind('table:table-cell', namespaces):
                content = ''
                odfDate = cell.get(f'{{{namespaces["office"]}}}date-value')
                odfTime = cell.get(f'{{{namespaces["office"]}}}time-value')
                if odfDate:
                    cells.append(odfDate)
                elif odfTime:
                    t = re.search(r'PT(..)H(..)M(..)S', odfTime)
                    cells.append(f'{t.group(1)}:{t.group(2)}:{t.group(3)}')
                elif cell.find('text:p', namespaces) is not None:
                    lines = []
                    for paragraph in cell.iterfind('text:p', namespaces):
                        lines.append(''.join(t for t in paragraph.itertext()))
                    content = '\n'.join(lines)
                    cells.append(content)
                elif i > 0:
                    cells.append(content)
                else:
                    break

                i += 1
                if i >= cellsPerRow:
                    break

                attribute = cell.get(f'{{{namespaces["table"]}}}number-columns-repeated')
                if attribute:
                    repeat = int(attribute) - 1
                    for __ in range(repeat):
                        if i >= cellsPerRow:
                            break

                        cells.append(content)
                        i += 1
            if cells:
                rows.append(cells)
        return rows

    def _unzip_ods_file(self, filePath):
        try:
            with zipfile.ZipFile(filePath, 'r') as odfFile:
                content = odfFile.read('content.xml')
            return content

        except:
            raise Error(f'{_("Cannot read file")}: "{norm_path(filePath)}".')



class OdsReader(OdfReader, ABC):
    EXTENSION = '.ods'
    _SEPARATOR = ','
    _columnTitles = []
    _idPrefix = '??'

    _DIVIDER = FileExport._DIVIDER

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._columns = {}

    @abstractmethod
    def read(self):
        self._rows = []
        cellsPerRow = len(self._columnTitles)
        parser = OdsParser()
        rows = parser.get_rows(self.filePath, cellsPerRow)
        for row in rows:
            if len(row) != cellsPerRow:
                print(row)
                print(len(row), cellsPerRow)
                raise Error(f'{_("Wrong table structure")}.')

        for title in rows[0]:
            self._columns[title] = {}
        for row in rows:
            if row[0].startswith(self._idPrefix):
                for i, col in enumerate(self._columns):
                    self._columns[col][row[0]] = row[i]



class OdsRCharList(OdsReader):
    DESCRIPTION = _('Character list')
    SUFFIX = CHARLIST_SUFFIX
    _columnTitles = ['ID', 'Name', 'Full name', 'Aka', 'Description', 'Bio', 'Goals', 'Importance', 'Tags', 'Notes']
    _idPrefix = CHARACTER_PREFIX

    def read(self):
        super().read()

        for crId in self.novel.characters:

            try:
                title = self._columns['Name'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].title = title.rstrip()

            try:
                fullName = self._columns['Full name'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].fullName = fullName.rstrip()

            try:
                desc = self._columns['Description'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].desc = desc.rstrip()

            try:
                desc = self._columns['Aka'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].aka = desc.rstrip()

            try:
                tags = self._columns['Tags'][crId]
            except:
                pass
            else:
                if tags:
                    self.novel.characters[crId].tags = string_to_list(tags, divider=self._DIVIDER)

            try:
                notes = self._columns['Section notes'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].notes = notes.rstrip()

            try:
                goals = self._columns['Goals'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].goals = goals.rstrip()

            try:
                bio = self._columns['Bio'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].bio = bio.rstrip()

            try:
                importance = self._columns['Importance'][crId]
            except:
                pass
            else:
                if Character.MAJOR_MARKER in importance:
                    self.novel.characters[crId].isMajor = True
                else:
                    self.novel.characters[crId].isMajor = False

from datetime import date, time



class OdsRGrid(OdsReader):
    DESCRIPTION = _('Plot grid')
    SUFFIX = GRID_SUFFIX
    _columnTitles = [
        'Link',
        'Section',
        'Date',
        'Time',
        'Day',
        'Title',
        'Description',
        'Viewpoint',
        'Tags',
        'Scene',
        'Goal',
        'Conflict',
        'Outcome',
        'Notes',
    ]
    _idPrefix = SECTION_PREFIX

    def read(self):
        plotLines = self.novel.tree.get_children(PL_ROOT)
        for plId in plotLines:
            self._columnTitles.append(plId)
        super().read()
        for scId in self.novel.sections:

            for plId in plotLines:
                try:
                    odsPlotLineNotes = self._columns[plId][scId]
                except:
                    continue

                plotlineNotes = self.novel.sections[scId].plotlineNotes
                if not plotlineNotes:
                    plotlineNotes = {}
                plotlineNotes[plId] = odsPlotLineNotes.strip()
                self.novel.sections[scId].plotlineNotes = plotlineNotes
                if plotlineNotes[plId] and not plId in self.novel.sections[scId].scPlotLines:
                    scPlotLines = self.novel.sections[scId].scPlotLines
                    scPlotLines.append(plId)
                    self.novel.sections[scId].scPlotLines = scPlotLines
                    plSections = self.novel.plotLines[plId].sections
                    plSections.append(scId)
                    self.novel.plotLines[plId].sections = plSections

            try:
                scDate = self._columns['Date'][scId]
                date.fromisoformat(scDate)
            except:
                pass
            else:
                self.novel.sections[scId].date = scDate

            try:
                scTime = self._columns['Time'][scId]
                time.fromisoformat(scTime)
            except:
                pass
            else:
                self.novel.sections[scId].time = scTime

            try:
                day = self._columns['Day'][scId]
                int(day)
            except:
                pass
            else:
                self.novel.sections[scId].day = day.strip()

            try:
                title = self._columns['Title'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].title = title.strip()

            try:
                desc = self._columns['Description'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].desc = desc.strip()

            try:
                viewpoint = self._columns['Viewpoint'][scId]
            except:
                pass
            else:
                viewpoint = viewpoint.strip()

                vpId = None
                for crId in self.novel.characters:
                    if self.novel.characters[crId].title == viewpoint:
                        vpId = crId
                        break

                if vpId is not None:
                    scCharacters = self.novel.sections[scId].characters
                    if scCharacters is None:
                        scCharacters = []

                    if vpId in scCharacters:
                        scCharacters.remove(vpId)
                    scCharacters.insert(0, vpId)
                    self.novel.sections[scId].characters = scCharacters

            try:
                tags = self._columns['Tags'][scId]
            except:
                pass
            else:
                if tags:
                    self.novel.sections[scId].tags = string_to_list(tags, divider=self._DIVIDER)
                elif tags is not None:
                    self.novel.sections[scId].tags = None

            try:
                ar = self._columns['Scene'][scId]
            except:
                pass
            else:
                if ar:
                    try:
                        self.novel.sections[scId].scene = Section.SCENE.index(ar)
                    except ValueError:
                        pass

            try:
                goal = self._columns['Goal'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].goal = goal.strip()

            try:
                conflict = self._columns['Conflict'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].conflict = conflict.strip()

            try:
                outcome = self._columns['Outcome'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].outcome = outcome.strip()

            try:
                notes = self._columns['Notes'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].notes = notes.strip()



class OdsRItemList(OdsReader):
    DESCRIPTION = _('Item list')
    SUFFIX = ITEMLIST_SUFFIX
    _columnTitles = ['ID', 'Name', 'Description', 'Aka', 'Tags']
    _idPrefix = ITEM_PREFIX

    def read(self):
        super().read()
        for itId in self.novel.items:

            try:
                title = self._columns['Name'][itId]
            except:
                pass
            else:
                self.novel.items[itId].title = title.rstrip()

            try:
                desc = self._columns['Description'][itId]
            except:
                pass
            else:
                self.novel.items[itId].desc = desc.rstrip()

            try:
                desc = self._columns['Aka'][itId]
            except:
                pass
            else:
                self.novel.items[itId].aka = desc.rstrip()

            try:
                tags = self._columns['Tags'][itId]
            except:
                pass
            else:
                if tags:
                    self.novel.items[itId].tags = string_to_list(tags, divider=self._DIVIDER)



class OdsRLocList(OdsReader):
    DESCRIPTION = _('Location list')
    SUFFIX = LOCLIST_SUFFIX
    _columnTitles = ['ID', 'Name', 'Description', 'Aka', 'Tags']
    _idPrefix = LOCATION_PREFIX

    def read(self):
        super().read()
        for lcId in self.novel.locations:

            try:
                title = self._columns['Name'][lcId]
            except:
                pass
            else:
                self.novel.locations[lcId].title = title.rstrip()

            try:
                desc = self._columns['Description'][lcId]
            except:
                pass
            else:
                self.novel.locations[lcId].desc = desc.rstrip()

            try:
                desc = self._columns['Aka'][lcId]
            except:
                pass
            else:
                self.novel.locations[lcId].aka = desc.rstrip()

            try:
                tags = self._columns['Tags'][lcId]
            except:
                pass
            else:
                if tags:
                    self.novel.locations[lcId].tags = string_to_list(tags, divider=self._DIVIDER)



class OdtRChapterDesc(OdtReader):
    DESCRIPTION = _('Chapter descriptions')
    SUFFIX = CHAPTERS_SUFFIX

    def handle_data(self, data):
        if self._chId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._chId is None:
            return

        if tag == 'div':
            self.novel.chapters[self._chId].desc = ''.join(self._lines).rstrip()
            self._lines = []
            self._chId = None
            return

        if tag == 'p':
            self._lines.append('\n')
            return

        if tag == 'h1' or tag == 'h2':
            if not self.novel.chapters[self._chId].title:
                self.novel.chapters[self._chId].title = ''.join(self._lines)
            self._lines = []




class OdtRCharacters(OdtReader):
    DESCRIPTION = _('Character descriptions')
    SUFFIX = CHARACTERS_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._crId = None
        self._section = None

    def handle_data(self, data):
        if self._section is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._crId is None:
            return

        if tag == 'div':

            if self._section == 'desc':
                self.novel.characters[self._crId].desc = ''.join(self._lines).rstrip()
                self._lines = []
                self._section = None
                return

            if self._section == 'bio':
                self.novel.characters[self._crId].bio = ''.join(self._lines).rstrip()
                self._lines = []
                self._section = None
                return

            if self._section == 'goals':
                self.novel.characters[self._crId].goals = ''.join(self._lines).rstrip()
                self._lines = []
                self._section = None
                return

            if self._section == 'notes':
                self.novel.characters[self._crId].notes = ''.join(self._lines).rstrip()
                self._lines = []
                self._section = None
            return

        if tag == 'p':
            self._lines.append('\n')

    def handle_starttag(self, tag, attrs):
        if tag == 'div':
            if attrs[0][0] == 'id':

                if attrs[0][1].startswith('desc'):
                    self._crId = f"{CHARACTER_PREFIX}{re.search('[0-9]+', attrs[0][1]).group()}"
                    if not self._crId in self.novel.characters:
                        self.novel.tree.append(CR_ROOT, self._crId)
                        self.novel.characters[self._crId] = Character()
                    self._section = 'desc'
                    return

                if attrs[0][1].startswith('bio'):
                    self._section = 'bio'
                    return

                if attrs[0][1].startswith('goals'):
                    self._section = 'goals'
                    return

                if attrs[0][1].startswith('notes'):
                    self._section = 'notes'
            return

        if tag == 's':
            self._lines.append(' ')



class OdtRItems(OdtReader):
    DESCRIPTION = _('Item descriptions')
    SUFFIX = ITEMS_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._itId = None

    def handle_data(self, data):
        if self._itId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._itId is None:
            return

        if tag == 'div':
            self.novel.items[self._itId].desc = ''.join(self._lines).rstrip()
            self._lines = []
            self._itId = None
            return

        if tag == 'p':
            self._lines.append('\n')

    def handle_starttag(self, tag, attrs):
        if tag == 'div':
            if attrs[0][0] == 'id':
                if attrs[0][1].startswith('ItID'):
                    self._itId = f"{ITEM_PREFIX}{re.search('[0-9]+', attrs[0][1]).group()}"
                    if not self._itId in self.novel.items:
                        self.novel.tree.append(IT_ROOT, self._itId)
                        self.novel.items[self._itId] = WorldElement()
            return

        if tag == 's':
            self._lines.append(' ')



class OdtRLocations(OdtReader):
    DESCRIPTION = _('Location descriptions')
    SUFFIX = LOCATIONS_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._lcId = None

    def handle_data(self, data):
        if self._lcId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._lcId is None:
            return

        if tag == 'div':
            self.novel.locations[self._lcId].desc = ''.join(self._lines).rstrip()
            self._lines = []
            self._lcId = None
            return

        if tag == 'p':
            self._lines.append('\n')

    def handle_starttag(self, tag, attrs):
        if tag == 'div':
            if attrs[0][0] == 'id':
                if attrs[0][1].startswith('LcID'):
                    self._lcId = f"{LOCATION_PREFIX}{re.search('[0-9]+', attrs[0][1]).group()}"
                    if not self._lcId in self.novel.locations:
                        self.novel.tree.append(LC_ROOT, self._lcId)
                        self.novel.locations[self._lcId] = WorldElement()
            return

        if tag == 's':
            self._lines.append(' ')


class OdtRManuscript(OdtRFormatted):
    DESCRIPTION = _('Editable manuscript')
    SUFFIX = MANUSCRIPT_SUFFIX

    def handle_data(self, data):
        if self._scId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._scId is None:
            return

        if tag == 'p':
            self._lines.append('</p>')
            return

        if tag in ('em', 'strong', 'comment', 'creator', 'date', 'note', 'note-citation', 'ul', 'li'):
            self._lines.append(f'</{tag}>')
            return

        if tag == 'lang':
            self._lines.append('</span>')
            return

        if tag == 'div':
            text = ''.join(self._lines)
            self.novel.sections[self._scId].sectionContent = text
            self._lines = []
            self._scId = None
            return

        if tag == 'h1':
            self._lines.append('\n')
            return

        if tag == 'h2':
            self._lines.append('\n')

    def handle_starttag(self, tag, attrs):
        super().handle_starttag(tag, attrs)

        if self._scId is None:
            if tag == 'body':
                for attr in attrs:
                    if attr[0] == 'language':
                        if attr[1]:
                            self.novel.languageCode = attr[1]
                    elif attr[0] == 'country':
                        if attr[1]:
                            self.novel.countryCode = attr[1]
            return

        if tag == 'p':
            attributes = ''
            try:
                for att in attrs:
                    attributes = f'{attributes} {att[0]}="{att[1]}"'
                    if att[0] == 'lang':
                        if not att[1] in self.novel.languages:
                            self.novel.languages.append(att[1])
            except:
                pass
            self._lines.append(f'<p{attributes}>')
            return

        if tag in('em', 'strong', 'comment', 'creator', 'date', 'note-citation', 'ul', 'li'):
            self._lines.append(f'<{tag}>')
            return

        if tag == 'lang':
            if attrs[0][0] == 'lang':
                if not attrs[0][1] in self.novel.languages:
                    self.novel.languages.append(attrs[0][1])
                self._lines.append(f'<span xml:lang="{attrs[0][1]}">')
            return

        if tag == 'h2':
            self._lines.append(f'{Splitter.CHAPTER_SEPARATOR} ')
            return

        if tag == 'h1':
            self._lines.append(f'{Splitter.PART_SEPARATOR} ')
            return

        if tag == 'note':
            attributes = ''
            for att in attrs:
                attributes = f'{attributes} {att[0]}="{att[1]}"'
            self._lines.append(f'<note {attributes}>')



class OdtRPartDesc(OdtRChapterDesc):
    DESCRIPTION = _('Part descriptions')
    SUFFIX = PARTS_SUFFIX


class OdtRPlotlines(OdtReader):
    DESCRIPTION = _('Plot lines')
    SUFFIX = PLOTLINES_SUFFIX

    def handle_data(self, data):
        if self._plId is not None or self._ppId is not None:
            self._lines.append(data)

    def handle_endtag(self, tag):
        if self._plId is not None:
            if tag == 'div':
                text = ''.join(self._lines)
                self.novel.plotLines[self._plId].desc = text.rstrip()
                self._lines = []
                self._plId = None
                return

            if tag == 'p':
                self._lines.append('\n')
            return

        if self._ppId is not None:
            if tag == 'div':
                text = ''.join(self._lines)
                self.novel.plotPoints[self._ppId].desc = text.rstrip()
                self._lines = []
                self._ppId = None
                return

            if tag == 'p':
                self._lines.append('\n')




class OdtRProof(OdtRFormatted):
    DESCRIPTION = _('Tagged manuscript for proofing')
    SUFFIX = PROOF_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._content = False

    def handle_data(self, data):
        try:
            if f'[{SECTION_PREFIX}' in data:
                self._scId = f"{SECTION_PREFIX}{re.search('[0-9]+', data).group()}"
                self._lines = []
                return

            if f'[/{SECTION_PREFIX}]' in data:
                if self._scId in self.novel.sections:
                    self._lines.pop()
                    text = ''.join(self._lines)
                    self.novel.sections[self._scId].sectionContent = text.strip()
                    self._lines = []
                self._scId = None
                self._content = False
                return

            if self._scId is not None:
                self._lines.append(data)
        except:
            raise Error(f'{_("Corrupt marker")}: "{data}"')

    def handle_endtag(self, tag):
        if tag == 'p':
            if self._content:
                self._lines.append('</p>')
                return

            if self._scId:
                self._content = True
            return

        if tag in ('em', 'strong', 'comment', 'creator', 'date', 'note', 'note-citation', 'ul', 'li'):
            self._lines.append(f'</{tag}>')
            return

        if tag == 'lang':
            self._lines.append('</span>')
            return

        if tag == 'div':
            text = ''.join(self._lines)
            self.novel.sections[self._scId].sectionContent = text
            self._lines = []
            self._scId = None
            return

        if tag == 'h1':
            self._lines.append('\n')
            return

        if tag == 'h2':
            self._lines.append('\n')

    def handle_starttag(self, tag, attrs):
        if self._content:

            if tag == 'p':
                attributes = ''
                try:
                    for att in attrs:
                        attributes = f'{attributes} {att[0]}="{att[1]}"'
                        if att[0] == 'lang':
                            if not att[1] in self.novel.languages:
                                self.novel.languages.append(att[1])
                except:
                    pass
                self._lines.append(f'<p{attributes}>')
                return

            if tag in('em', 'strong', 'comment', 'creator', 'date', 'note-citation', 'ul', 'li'):
                self._lines.append(f'<{tag}>')
                return

            if tag == 'lang':
                if attrs[0][0] == 'lang':
                    if not attrs[0][1] in self.novel.languages:
                        self.novel.languages.append(attrs[0][1])
                    self._lines.append(f'<span xml:lang="{attrs[0][1]}">')
                return

            if tag == 'h2':
                self._lines.append(f'{Splitter.CHAPTER_SEPARATOR} ')
                return

            if tag == 'h1':
                self._lines.append(f'{Splitter.PART_SEPARATOR} ')
                return

            if tag == 's':
                self._lines.append(' ')
                return

            if tag == 'note':
                attributes = ''
                for att in attrs:
                    attributes = f'{attributes} {att[0]}="{att[1]}"'
                self._lines.append(f'<note {attributes}>')
                return

            if tag == 'body':
                for attr in attrs:
                    if attr[0] == 'language':
                        if attr[1]:
                            self.novel.languageCode = attr[1]
                    elif attr[0] == 'country':
                        if attr[1]:
                            self.novel.countryCode = attr[1]



class OdtRSectionDesc(OdtReader):
    DESCRIPTION = _('Section descriptions')
    SUFFIX = SECTIONS_SUFFIX

    def handle_data(self, data):
        if self._scId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._scId is not None:
            if tag == 'div':
                text = ''.join(self._lines)
                self.novel.sections[self._scId].desc = text.rstrip()
                self._lines = []
                self._scId = None
                return

            if tag == 'p':
                self._lines.append('\n')
            return

        if self._chId is not None:
            if tag == 'div':
                self._chId = None



class OdtRStages(OdtRSectionDesc):
    DESCRIPTION = _('Story structure')
    SUFFIX = STAGES_SUFFIX



class NvDocImporter:
    IMPORT_SOURCE_CLASSES = [
        OdsRCharList,
        OdsRGrid,
        OdsRItemList,
        OdsRLocList,
        OdtRChapterDesc,
        OdtRCharacters,
        OdtRItems,
        OdtRLocations,
        OdtRManuscript,
        OdtRPartDesc,
        OdtRPlotlines,
        OdtRProof,
        OdtRSectionDesc,
        OdtRStages,
        ]
    CREATE_SOURCE_CLASSES = []

    def __init__(self, ui):
        self._ui = ui
        self.importSourceFactory = ImportSourceFactory(self.IMPORT_SOURCE_CLASSES)
        self.newProjectFactory = NewProjectFactory(self.CREATE_SOURCE_CLASSES)
        self.importTargetFactory = ImportTargetFactory([NovxFile])
        self.newFile = None

    def run(self, sourcePath, **kwargs):
        self.newFile = None
        if not os.path.isfile(sourcePath):
            raise Error(f'{_("File not found")}: "{norm_path(sourcePath)}".')

        try:
            source, __ = self.importSourceFactory.make_file_objects(sourcePath, **kwargs)
        except Error:

            source, target = self.newProjectFactory.make_file_objects(sourcePath, **kwargs)
            if os.path.isfile(target.filePath):
                raise Error(f'{_("File already exists")}: "{norm_path(target.filePath)}".')

            self._check(source, target)
            source.novel = kwargs['nv_service'].make_novel()
            source.read()
            target.novel = source.novel
            target.write()
            self.newFile = target.filePath
            return f'{_("File written")}: "{norm_path(target.filePath)}".'

        else:

            kwargs['suffix'] = source.SUFFIX
            __, target = self.importTargetFactory.make_file_objects(sourcePath, **kwargs)
            self.newFile = None
            self._check(source, target)
            target.novel = kwargs['nv_service'].make_novel()
            target.read()
            source.novel = target.novel
            source.read()
            if source.sectionsSplit and source.is_locked():
                raise Error(f'{_("Please close the document first")}.')

            if os.path.isfile(target.filePath):
                if not self._ui.ask_yes_no(
                    _('Update the project?'),
                    title=source.DESCRIPTION,
                    ):
                    raise Error(f'{_("Action canceled by user")}.')

            target.novel = source.novel
            target.write()
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self.newFile = target.filePath
            if source.sectionsSplit:
                os.replace(source.filePath, f'{source.filePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
            return message

    def _check(self, source, target):
        if source.filePath is None:
            raise Error(f'{_("File type is not supported")}.')

        if not os.path.isfile(source.filePath):
            raise Error(f'{_("File not found")}: "{norm_path(source.filePath)}".')

        if source.is_locked():
            if not prefs['import_mode'] == '2':
                raise Error(f'{_("Please close the document first")}.')

import math


def get_moon_phase_day(isoDate):
    try:
        y, m, d = isoDate.split('-')
        year = int(y)
        month = int(m)
        day = int(d)
        r = year % 100
        r %= 19
        if r > 9:
            r -= 19
        r = ((r * 11) % 30) + month + day
        if month < 3:
            r += 2
        if year < 2000:
            r -= 4
        else:
            r -= 8.3
        r = math.floor(r + 0.5) % 30
        if r < 0:
            r += 30
    except:
        r = None
    return r


def get_moon_phase_string(isoDate):
    moonViews = [
        '🌑',
        '🌑',
        '🌒',
        '🌒',
        '🌒',
        '🌒',
        '🌓',
        '🌓',
        '🌓',
        '🌓',
        '🌔',
        '🌔',
        '🌔',
        '🌔',
        '🌕',
        '🌕',
        '🌕',
        '🌖',
        '🌖',
        '🌖',
        '🌖',
        '🌗',
        '🌗',
        '🌗',
        '🌗',
        '🌘',
        '🌘',
        '🌘',
        '🌘',
        '🌑'
    ]
    moonFractions = '00¼¼¼¼½½½½¾¾¾¾111¾¾¾¾½½½½¼¼¼¼0'
    moonPhaseDay = get_moon_phase_day(isoDate)
    if moonPhaseDay is not None:
        display = f'{moonPhaseDay} {moonViews[moonPhaseDay]} {moonFractions[moonPhaseDay]}'
    else:
        display = ''
    return display



class NvTree:

    def __init__(self):
        self.roots = {
            CH_ROOT:[],
            CR_ROOT:[],
            LC_ROOT:[],
            IT_ROOT:[],
            PL_ROOT:[],
            PN_ROOT:[],
        }
        self.srtSections = {}
        self.srtTurningPoints = {}

    def append(self, parent, iid):
        if parent in self.roots:
            self.roots[parent].append(iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtTurningPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].append(iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtTurningPoints:
                self.srtTurningPoints[parent].append(iid)
            else:
                self.srtTurningPoints[parent] = [iid]

    def delete(self, *items):
        raise NotImplementedError

    def delete_children(self, parent):
        if parent in self.roots:
            self.roots[parent] = []
            if parent == CH_ROOT:
                self.srtSections = {}
                return

            if parent == PL_ROOT:
                self.srtTurningPoints = {}
            return

        if parent.startswith(CHAPTER_PREFIX):
            self.srtSections[parent] = []
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            self.srtTurningPoints[parent] = []

    def get_children(self, item):
        if item in self.roots:
            return self.roots[item]

        if item.startswith(CHAPTER_PREFIX):
            return self.srtSections.get(item, [])

        if item.startswith(PLOT_LINE_PREFIX):
            return self.srtTurningPoints.get(item, [])

    def index(self, item):
        raise NotImplementedError

    def insert(self, parent, index, iid):
        if parent in self.roots:
            self.roots[parent].insert(index, iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtTurningPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].insert(index, iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtTurningPoints:
                self.srtTurningPoints[parent].insert(index, iid)
            else:
                self.srtTurningPoints[parent] = [iid]

    def move(self, item, parent, index):
        raise NotImplementedError

    def next(self, item):
        raise NotImplementedError

    def parent(self, item):
        raise NotImplementedError

    def prev(self, item):
        raise NotImplementedError

    def reset(self):
        for item in self.roots:
            self.roots[item] = []
        self.srtSections = {}
        self.srtTurningPoints = {}

    def set_children(self, item, newchildren):
        if item in self.roots:
            self.roots[item] = newchildren[:]
            if item == CH_ROOT:
                self.srtSections = {}
                return

            if item == PL_ROOT:
                self.srtTurningPoints = {}
            return

        if item.startswith(CHAPTER_PREFIX):
            self.srtSections[item] = newchildren[:]
            return

        if item.startswith(PLOT_LINE_PREFIX):
            self.srtTurningPoints[item] = newchildren[:]



class NovxService:

    def get_novx_file_extension(self):
        return NovxFile.EXTENSION

    def make_basic_element(self, **kwargs):
        return BasicElement(**kwargs)

    def make_chapter(self, **kwargs):
        return Chapter(**kwargs)

    def make_character(self, **kwargs):
        return Character(**kwargs)

    def make_novel(self, **kwargs):
        kwargs['tree'] = kwargs.get('tree', NvTree())
        return Novel(**kwargs)

    def make_nv_tree(self, **kwargs):
        return NvTree(**kwargs)

    def make_plot_line(self, **kwargs):
        return PlotLine(**kwargs)

    def make_plot_point(self, **kwargs):
        return PlotPoint(**kwargs)

    def make_section(self, **kwargs):
        return Section(**kwargs)

    def make_world_element(self, **kwargs):
        return WorldElement(**kwargs)

    def make_novx_file(self, filePath, **kwargs):
        return NovxFile(filePath, **kwargs)

from tkinter import ttk



class NvTreeview(ttk.Treeview):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.on_element_change = self.do_nothing

        self.append('', CH_ROOT)
        self.append('', CR_ROOT)
        self.append('', LC_ROOT)
        self.append('', IT_ROOT)
        self.append('', PL_ROOT)
        self.append('', PN_ROOT)

    def append(self, parent, iid, text=None):
        if text is None:
            text = iid
        self.insert(parent, 'end', iid, text=text)

    def delete(self, *items):
        super().delete(*items)
        self.on_element_change()

    def delete_children(self, parent):
        for child in self.get_children(parent):
            self.delete(child)

    def insert(self, parent, index, iid=None, **kw):
        super().insert(parent, index, iid, **kw)
        self.on_element_change()

    def move(self, item, parent, index):
        super().move(item, parent, index)
        self.on_element_change()

    def reset(self):
        self.on_element_change = self.do_nothing
        for rootElement in self.get_children(''):
            for child in self.get_children(rootElement):
                self.delete(child)

    def do_nothing(self):
        pass


class NvService(NovxService):

    def get_moon_phase_str(self, isoDate):
        return get_moon_phase_string(isoDate)

    def make_configuration(self, **kwargs):
        return Configuration(**kwargs)

    def make_novel(self, **kwargs):
        kwargs['tree'] = kwargs.get('tree', NvTreeview())
        return Novel(**kwargs)

    def make_nv_tree(self, **kwargs):
        return NvTreeview(**kwargs)
from datetime import datetime



class NvWorkFile(NovxFile):
    DESCRIPTION = _('novelibre project')
    _LOCKFILE_PREFIX = '.LOCK.'
    _LOCKFILE_SUFFIX = '#'

    @property
    def fileDate(self):
        if self.timestamp is None:
            return _('Never')
        else:
            return datetime.fromtimestamp(self.timestamp).strftime('%c')

    def adjust_section_types(self):
        super().adjust_section_types()
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].isTrash and self.novel.tree.next(chId):
                self.novel.tree.move(chId, CH_ROOT, 'end')
                return

    def has_changed_on_disk(self):
        try:
            if self.timestamp != os.path.getmtime(self.filePath):
                return True
            else:
                return False

        except:
            return False

    def has_lockfile(self):
        if not self.filePath:
            return

        head, tail = self._split_file_path()
        lockfilePath = f'{head}{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        return os.path.isfile(lockfilePath)

    def lock(self):
        if not self.filePath:
            return

        head, tail = self._split_file_path()
        lockfilePath = f'{head}{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        if not os.path.isfile(lockfilePath):
            with open(lockfilePath, 'w') as f:
                f.write('')

    def read(self):
        super().read()
        self.novel.check_locale()

    def unlock(self):
        if not self.filePath:
            return

        head, tail = self._split_file_path()
        lockfilePath = f'{head}{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        try:
            os.remove(lockfilePath)
        except:
            pass

    def _split_file_path(self):
        head, tail = os.path.split(self.filePath)
        if head:
            head = f'{head}/'
        else:
            head = './'
        return head, tail



class NvModel:

    def __init__(self):
        self.tree = None
        self.prjFile = None
        self.novel = None
        self._clients = []

        self.trashBin = None
        self.wordCount = 0
        self._internalModificationFlag = False

        self.nvService = NvService()

    @property
    def isModified(self):
        return self._internalModificationFlag

    @isModified.setter
    def isModified(self, setFlag):
        self._internalModificationFlag = setFlag
        for client in self._clients:
            client.refresh()

    def add_chapter(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(SECTION_PREFIX):
            targetNode = self.tree.parent(targetNode)
        if targetNode.startswith(CHAPTER_PREFIX):
            index = self.tree.index(targetNode) + 1
            targetNode = self.tree.parent(targetNode)
        chId = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[chId] = self.nvService.make_chapter(
            title=kwargs.get('title', f'{_("New Chapter")} ({chId})'),
            desc='',
            chLevel=2,
            chType=kwargs.get('chType', 0),
            noNumber=kwargs.get('NoNumber', False),
            isTrash=False,
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(CH_ROOT, index, chId)
        return chId

    def add_character(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(CHARACTER_PREFIX):
            index = self.tree.index(targetNode) + 1
        crId = create_id(self.novel.characters, prefix=CHARACTER_PREFIX)
        self.novel.characters[crId] = self.nvService.make_character(
            title=kwargs.get('title', f'{_("New Character")} ({crId})'),
            desc='',
            aka='',
            tags='',
            notes='',
            bio='',
            goals='',
            fullName='',
            isMajor=kwargs.get('isMajor', False),
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(CR_ROOT, index, crId)
        return crId

    def add_item(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(ITEM_PREFIX):
            index = self.tree.index(targetNode) + 1
        itId = create_id(self.novel.items, prefix=ITEM_PREFIX)
        self.novel.items[itId] = self.nvService.make_world_element(
            title=kwargs.get('title', f'{_("New Item")} ({itId})'),
            desc='',
            aka='',
            tags='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(IT_ROOT, index, itId)
        return itId

    def add_location(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(LOCATION_PREFIX):
            index = self.tree.index(targetNode) + 1
        lcId = create_id(self.novel.locations, prefix=LOCATION_PREFIX)
        self.novel.locations[lcId] = self.nvService.make_world_element(
            title=kwargs.get('title', f'{_("New Location")} ({lcId})'),
            desc='',
            aka='',
            tags='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(LC_ROOT, index, lcId)
        return lcId

    def add_part(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(SECTION_PREFIX):
            targetNode = self.tree.parent(targetNode)
        if targetNode.startswith(CHAPTER_PREFIX):
            index = self.tree.index(targetNode) + 1
            targetNode = self.tree.parent(targetNode)
        chId = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[chId] = self.nvService.make_chapter(
            title=kwargs.get('title', f'{_("New Part")} ({chId})'),
            desc='',
            chLevel=1,
            chType=kwargs.get('chType', 0),
            noNumber=kwargs.get('NoNumber', False),
            isTrash=False,
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(CH_ROOT, index, chId)
        return chId

    def add_plot_line(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(PLOT_LINE_PREFIX):
            index = self.tree.index(targetNode) + 1
        plId = create_id(self.novel.plotLines, prefix=PLOT_LINE_PREFIX)
        self.novel.plotLines[plId] = self.nvService.make_plot_line(
            title=kwargs.get('title', f'{_("New Plot line")} ({plId})'),
            desc='',
            shortName=plId,
            sections=[],
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(PL_ROOT, index, plId)
        return plId

    def add_plot_point(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        index = 'end'
        if targetNode.startswith(PLOT_POINT_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(PLOT_LINE_PREFIX):
            parent = targetNode
        else:
            return

        ppId = create_id(self.novel.plotPoints, prefix=PLOT_POINT_PREFIX)
        self.novel.plotPoints[ppId] = self.nvService.make_plot_point(
            title=kwargs.get('title', f'{_("New Plot point")} ({ppId})'),
            desc='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(parent, index, ppId)
        return ppId

    def add_project_note(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(PRJ_NOTE_PREFIX):
            index = self.tree.index(targetNode) + 1
        pnId = create_id(self.novel.projectNotes, prefix=PRJ_NOTE_PREFIX)
        self.novel.projectNotes[pnId] = self.nvService.make_basic_element(
            title=kwargs.get('title', f'{_("New Note")} ({pnId})'),
            desc='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(PN_ROOT, index, pnId)
        return pnId

    def add_section(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        if targetNode.startswith(SECTION_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(CHAPTER_PREFIX):
            parent = targetNode
            index = 'end'
        else:
            return

        parentType = self.novel.chapters[parent].chType
        if parentType != 0:
            newType = parentType
        else:
            newType = kwargs.get('scType', 0)
        scId = create_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[scId] = self.nvService.make_section(
            title=kwargs.get('title', f'{_("New Section")} ({scId})'),
            desc=kwargs.get('desc', ''),
            scType=newType,
            scene=kwargs.get('scene', 0),
            status=kwargs.get('status', 1),
            appendToPrev=kwargs.get('appendToPrev', False),
            characters=[],
            locations=[],
            items=[],
            links={},
            on_element_change=self.on_element_change,
            )
        self.novel.sections[scId].sectionContent = '<p></p>'
        self.tree.insert(parent, index, scId)
        return scId

    def add_stage(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        if targetNode.startswith(SECTION_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(CHAPTER_PREFIX):
            parent = targetNode
            index = 0
        else:
            return

        scId = create_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[scId] = self.nvService.make_section(
            title=kwargs.get('title', f'{_("Stage")}'),
            desc=kwargs.get('desc', ''),
            scType=kwargs.get('scType', 3),
            status=0,
            scene=0,
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(parent, index, scId)
        return scId

    def close_project(self):
        self.isModified = False
        self.tree.on_element_change = self.tree.do_nothing
        self.novel = None
        self.prjFile = None

    def delete_element(self, elemId):

        def waste_sections(elemId):
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    self.tree.move(elemId, self.trashBin, 0)
                    self.novel.sections[elemId].scType = 1
                    arcReferences = self.novel.sections[elemId].scPlotLines
                    tpReferences = self.novel.sections[elemId].scPlotPoints
                    self.novel.sections[elemId].scPlotLines = []
                    self.novel.sections[elemId].scPlotPoints = {}
                    for plId in arcReferences:
                        sections = self.novel.plotLines[plId].sections
                        sections.remove(elemId)
                        self.novel.plotLines[plId].sections = sections
                    for ppId in tpReferences:
                        self.novel.plotPoints[ppId].sectionAssoc = None
                else:
                    self.tree.delete(elemId)
                    del self.novel.sections[elemId]
            else:
                for childNode in self.tree.get_children(elemId):
                    waste_sections(childNode)
                del self.novel.chapters[elemId]

        if elemId == self.trashBin:
            for scId in self.tree.get_children(elemId):
                del self.novel.sections[scId]
            del self.novel.chapters[elemId]
            self.tree.delete(elemId)
            self.trashBin = None
        elif elemId.startswith(CHARACTER_PREFIX):
            self.tree.delete(elemId)
            del self.novel.characters[elemId]
            for scId in self.novel.sections:
                try:
                    scCharacters = self.novel.sections[scId].characters
                    scCharacters.remove(elemId)
                    self.novel.sections[scId].characters = scCharacters
                except:
                    pass
        elif elemId.startswith(LOCATION_PREFIX):
            self.tree.delete(elemId)
            del self.novel.locations[elemId]
            for scId in self.novel.sections:
                try:
                    scLocations = self.novel.sections[scId].locations
                    scLocations.remove(elemId)
                    self.novel.sections[scId].locations = scLocations
                except:
                    pass
        elif elemId.startswith(ITEM_PREFIX):
            self.tree.delete(elemId)
            del self.novel.items[elemId]
            for scId in self.novel.sections:
                try:
                    scItems = self.novel.sections[scId].items
                    scItems.remove(elemId)
                    self.novel.sections[scId].items = scItems
                except:
                    pass
        elif elemId.startswith(PLOT_LINE_PREFIX):
            if self.novel.plotLines[elemId].sections:
                for scId in self.novel.plotLines[elemId].sections:
                    self.novel.sections[scId].scPlotLines.remove(elemId)
                for ppId in self.tree.get_children(elemId):
                    scId = self.novel.plotPoints[ppId].sectionAssoc
                    if scId is not None:
                        del(self.novel.sections[scId].scPlotPoints[ppId])
                    del self.novel.plotPoints[ppId]
            del self.novel.plotLines[elemId]
            self.tree.delete(elemId)
        elif elemId.startswith(PLOT_POINT_PREFIX):
            scId = self.novel.plotPoints[elemId].sectionAssoc
            if scId is not None:
                del(self.novel.sections[scId].scPlotPoints[elemId])
            del self.novel.plotPoints[elemId]
            self.tree.delete(elemId)
        elif elemId.startswith(PRJ_NOTE_PREFIX):
            self.tree.delete(elemId)
            del self.novel.projectNotes[elemId]
        else:
            if self.trashBin is None:
                self.trashBin = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
                self.novel.chapters[self.trashBin] = self.nvService.make_chapter(
                    title=_('Trash'),
                    desc='',
                    chLevel=2,
                    chType=3,
                    noNumber=True,
                    isTrash=True,
                    on_element_change=self.on_element_change,
                    )
                self.tree.append(CH_ROOT, self.trashBin)
            if elemId.startswith(SECTION_PREFIX):
                if self.tree.parent(elemId) == self.trashBin:
                    self.tree.delete(elemId)
                    del self.novel.sections[elemId]
                else:
                    waste_sections(elemId)
            else:
                waste_sections(elemId)
                self.tree.delete(elemId)
            self.set_type(3, [self.trashBin])

    def get_counts(self):
        partCount = 0
        chapterCount = 0
        sectionCount = 0
        wordCount = 0
        for chId in self.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chType == 0:
                for scId in self.tree.get_children(chId):
                    if self.novel.sections[scId].scType == 0:
                        sectionCount += 1
                        wordCount += self.novel.sections[scId].wordCount
                if self.novel.chapters[chId].chLevel == 1:
                    partCount += 1
                else:
                    chapterCount += 1
        self.wordCount = wordCount
        return wordCount, sectionCount, chapterCount, partCount

    def get_status_counts(self):
        counts = [None, 0, 0, 0, 0, 0]
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                if self.novel.sections[scId].status is not None:
                    counts[self.novel.sections[scId].status] += self.novel.sections[scId].wordCount
        return counts

    def join_sections(self, ScId0, ScId1):

        def join_str(text0, text1, newline='\n'):
            if text0 is None:
                text0 = ''
            if text1 is None:
                text1 = ''
            if text0 or text1:
                text0 = f'{text0}{newline}{text1}'.strip()
            return text0

        def join_lst(list0, list1):
            if list1:
                for elemId in list1:
                    if not list0:
                        list0 = []
                    if not elemId in list0:
                        list0.append(elemId)

        if not ScId1.startswith(SECTION_PREFIX):
            return

        if self.novel.sections[ScId1].scType != self.novel.sections[ScId0].scType:
            raise Error(_('The sections are not of the same type'))

        if self.novel.sections[ScId1].characters:
            if self.novel.sections[ScId1].characters:
                if self.novel.sections[ScId0].characters:
                    if self.novel.sections[ScId1].characters[0] != self.novel.sections[ScId0].characters[0]:
                        raise Error(_('The sections have different viewpoints'))

                else:
                    self.novel.sections[ScId0].characters.append(self.novel.sections[ScId1].characters[0])

        joinedTitles = f'{self.novel.sections[ScId0].title} & {self.novel.sections[ScId1].title}'
        self.novel.sections[ScId0].title = joinedTitles

        content0 = self.novel.sections[ScId0].sectionContent
        content1 = self.novel.sections[ScId1].sectionContent
        self.novel.sections[ScId0].sectionContent = join_str(content0, content1, newline='')

        self.novel.sections[ScId0].desc = join_str(self.novel.sections[ScId0].desc, self.novel.sections[ScId1].desc)
        self.novel.sections[ScId0].goal = join_str(self.novel.sections[ScId0].goal, self.novel.sections[ScId1].goal)
        self.novel.sections[ScId0].conflict = join_str(self.novel.sections[ScId0].conflict, self.novel.sections[ScId1].conflict)
        self.novel.sections[ScId0].outcome = join_str(self.novel.sections[ScId0].outcome, self.novel.sections[ScId1].outcome)
        self.novel.sections[ScId0].notes = join_str(self.novel.sections[ScId0].notes, self.novel.sections[ScId1].notes)

        join_lst(self.novel.sections[ScId0].characters, self.novel.sections[ScId1].characters)
        join_lst(self.novel.sections[ScId0].locations, self.novel.sections[ScId1].locations)
        join_lst(self.novel.sections[ScId0].items, self.novel.sections[ScId1].items)
        join_lst(self.novel.sections[ScId0].tags, self.novel.sections[ScId1].tags)

        for scPlotLine in self.novel.sections[ScId1].scPlotLines:
            self.novel.plotLines[scPlotLine].sections.remove(ScId1)
            if not ScId0 in self.novel.plotLines[scPlotLine].sections:
                self.novel.plotLines[scPlotLine].sections.append(ScId0)
            if not scPlotLine in self.novel.sections[ScId0].scPlotLines:
                self.novel.sections[ScId0].scPlotLines.append(scPlotLine)

        for ppId in self.novel.sections[ScId1].scPlotPoints:
            self.novel.plotPoints[ppId].sectionAssoc = ScId0
            self.novel.sections[ScId0].scPlotPoints[ppId] = self.novel.sections[ScId1].scPlotPoints[ppId]

        try:
            lastsMin1 = int(self.novel.sections[ScId1].lastsMinutes)
        except:
            lastsMin1 = 0
        try:
            lastsMin0 = int(self.novel.sections[ScId0].lastsMinutes)
        except:
            lastsMin0 = 0
        hoursLeft, lastsMin0 = divmod((lastsMin0 + lastsMin1), 60)
        self.novel.sections[ScId0].lastsMinutes = str(lastsMin0)
        try:
            lastsHours1 = int(self.novel.sections[ScId1].lastsHours)
        except:
            lastsHours1 = 0
        try:
            lastsHours0 = int(self.novel.sections[ScId0].lastsHours)
        except:
            lastsHours0 = 0
        daysLeft, lastsHours0 = divmod((lastsHours0 + lastsHours1 + hoursLeft), 24)
        self.novel.sections[ScId0].lastsHours = str(lastsHours0)
        try:
            lastsDays1 = int(self.novel.sections[ScId1].lastsDays)
        except:
            lastsDays1 = 0
        try:
            LastsDays0 = int(self.novel.sections[ScId0].lastsDays)
        except:
            LastsDays0 = 0
        LastsDays0 = LastsDays0 + lastsDays1 + daysLeft
        self.novel.sections[ScId0].lastsDays = str(LastsDays0)
        del(self.novel.sections[ScId1])
        self.tree.delete(ScId1)

    def move_node(self, node, targetNode):
        if node == self.trashBin:
            return

        if node[:2] == targetNode[:2]:
            self.tree.move(node, self.tree.parent(targetNode), self.tree.index(targetNode))
        elif (node.startswith(SECTION_PREFIX) and targetNode.startswith(CHAPTER_PREFIX)
              )or (node.startswith(PLOT_POINT_PREFIX) and targetNode.startswith(PLOT_LINE_PREFIX)):
            if not self.tree.get_children(targetNode):
                self.tree.move(node, targetNode, 0)
            elif self.tree.prev(targetNode):
                self.tree.move(node, self.tree.prev(targetNode), 'end')

    def new_project(self, tree):
        self.novel = self.nvService.make_novel(
            title='',
            desc='',
            authorName='',
            wordTarget=0,
            wordCountStart=0,
            languageCode='',
            countryCode='',
            renumberChapters=False,
            renumberParts=False,
            renumberWithinParts=False,
            romanChapterNumbers=False,
            romanPartNumbers=False,
            saveWordCount=True,
            workPhase=None,
            chapterHeadingPrefix=f"{_('Chapter')} ",
            chapterHeadingSuffix='',
            partHeadingPrefix=f"{_('Part')} ",
            partHeadingSuffix='',
            customGoal='',
            customConflict='',
            customOutcome='',
            customChrBio='',
            customChrGoals='',
            links=[],
            tree=tree,
            on_element_change=self.on_element_change,
            )
        self.novel.check_locale()
        self.prjFile = NvWorkFile('')
        self.prjFile.novel = self.novel
        self._initialize_tree(self.on_element_change)

    def on_element_change(self):
        self.isModified = True

    def open_project(self, filePath):
        self.novel = self.nvService.make_novel(tree=self.tree, links={})
        self.prjFile = NvWorkFile(filePath)
        self.prjFile.novel = self.novel
        self.prjFile.read()
        if self.prjFile.wcLogUpdate and self.novel.saveWordCount:
            self.isModified = True
        else:
            self.isModified = False
        self._initialize_tree(self.on_element_change)

    def register_client(self, client):
        if not client in self._clients:
            self._clients.append(client)

    def renumber_chapters(self):
        ROMAN = [
            (1000, 'M'),
            (900, 'CM'),
            (500, 'D'),
            (400, 'CD'),
            (100, 'C'),
            (90, 'XC'),
            (50, 'L'),
            (40, 'XL'),
            (10, 'X'),
            (9, 'IX'),
            (5, 'V'),
            (4, 'IV'),
            (1, 'I'),
        ]

        def number_to_roman(n):
            result = []
            for (arabic, roman) in ROMAN:
                (factor, n) = divmod(n, arabic)
                result.append(roman * factor)
                if n == 0:
                    break

            return "".join(result)

        chapterCount = 0
        partCount = 0
        for chId in self.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].noNumber:
                continue

            if self.novel.chapters[chId].chType != 0:
                continue

            if self.novel.chapters[chId].chLevel == 2:
                if not self.novel.renumberChapters:
                    continue

            else:
                if self.novel.renumberWithinParts:
                    chapterCount = 0
                if not self.novel.renumberParts:
                    continue

            headingPrefix = ''
            headingSuffix = ''
            if self.novel.chapters[chId].chLevel == 2:
                chapterCount += 1
                if self.novel.romanChapterNumbers:
                    number = number_to_roman(chapterCount)
                else:
                    number = str(chapterCount)
                if self.novel.chapterHeadingPrefix is not None:
                    headingPrefix = self.novel.chapterHeadingPrefix
                if self.novel.chapterHeadingSuffix is not None:
                    headingSuffix = self.novel.chapterHeadingSuffix
            else:
                partCount += 1
                if self.novel.romanPartNumbers:
                    number = number_to_roman(partCount)
                else:
                    number = str(partCount)
                if self.novel.partHeadingPrefix is not None:
                    headingPrefix = self.novel.partHeadingPrefix
                if self.novel.partHeadingSuffix is not None:
                    headingSuffix = self.novel.partHeadingSuffix
            self.novel.chapters[chId].title = f'{headingPrefix}{number}{headingSuffix}'

    def reset_tree(self):
        self.tree.reset()
        self.trashBin = None

    def save_project(self, filePath=None):
        if filePath is not None:
            self.prjFile.filePath = filePath
        self.prjFile.write()
        self.isModified = False

    def set_level(self, newLevel, elemIds):
        for elemId in elemIds:
            if elemId.startswith(CHAPTER_PREFIX):
                self.novel.chapters[elemId].chLevel = newLevel
            elif elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType > 1:
                    self.novel.sections[elemId].scType = newLevel + 1

    def set_character_status(self, isMajor, elemIds):
        for crId in elemIds:
            if crId.startswith(CHARACTER_PREFIX):
                self.novel.characters[crId].isMajor = isMajor
            elif crId == CR_ROOT:
                self.set_character_status(isMajor, self.tree.get_children(crId))

    def set_completion_status(self, newStatus, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    self.novel.sections[elemId].status = newStatus
            elif elemId.startswith(CHAPTER_PREFIX) or elemId.startswith(CH_ROOT):
                self.set_completion_status(newStatus, self.tree.get_children(elemId))

    def set_type(self, newType, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    parentType = self.novel.chapters[self.tree.parent(elemId)].chType
                    if parentType > 0:
                        newType = parentType
                    self.novel.sections[elemId].scType = newType
            elif elemId.startswith(CHAPTER_PREFIX):
                chapter = self.novel.chapters[elemId]
                if chapter.isTrash:
                    newType = 1
                chapter.chType = newType
                if newType > 0:
                    self.set_type(newType, self.tree.get_children(elemId))

    def unregister_client(self, client):
        try:
            self._clients.remove(client)
        except:
            pass

    def _initialize_tree(self, on_element_change):

        def initialize_branch(node):
            for elemId in self.tree.get_children(node):
                if elemId.startswith(SECTION_PREFIX):
                    self.novel.sections[elemId].on_element_change = on_element_change
                elif elemId.startswith(CHARACTER_PREFIX):
                    self.novel.characters[elemId].on_element_change = on_element_change
                elif elemId.startswith(LOCATION_PREFIX):
                    self.novel.locations[elemId].on_element_change = on_element_change
                elif elemId.startswith(ITEM_PREFIX):
                    self.novel.items[elemId].on_element_change = on_element_change
                elif elemId.startswith(CHAPTER_PREFIX):
                    initialize_branch(elemId)
                    self.novel.chapters[elemId].on_element_change = on_element_change
                    if self.novel.chapters[elemId].isTrash:
                        self.trashBin = elemId
                elif elemId.startswith(PLOT_LINE_PREFIX):
                    initialize_branch(elemId)
                    self.novel.plotLines[elemId].on_element_change = on_element_change
                elif elemId.startswith(PLOT_POINT_PREFIX):
                    self.novel.plotPoints[elemId].on_element_change = on_element_change
                else:
                    initialize_branch(elemId)

        self.trashBin = None
        initialize_branch('')
        self.novel.on_element_change = on_element_change
        self.tree.on_element_change = on_element_change

import importlib



class RejectedPlugin:
    VERSION = '-'
    API_VERSION = '-'
    URL = ''

    def __init__(self, filePath, message):
        self.filePath = filePath
        self.isActive = False
        self.isRejected = True
        self.DESCRIPTION = message



class PluginCollection(dict):

    def __init__(self, model, view, controller):
        super().__init__()
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        versionStr = '4.11.11'

        try:
            majorStr, minorStr, patchStr = versionStr.split('.')
            self.majorVersion = int(majorStr)
            self.minorVersion = int(minorStr)
            self.patchlevel = int(patchStr)
        except ValueError:
            self.majorVersion = 4
            self.minorVersion = 11
            self.patchlevel = 0

    def delete_file(self, moduleName):
        if moduleName in self:
            try:
                if self[moduleName].filePath:
                    if self._ui.ask_yes_no(f'{_("Delete file")} "{self[moduleName].filePath}"?'):
                        os.remove(self[moduleName].filePath)
                        self[moduleName].filePath = ''
                        return True

            except Exception as ex:
                print(str(ex))
        return False

    def load_file(self, filePath):
        try:
            moduleName = os.path.split(filePath)[1][:-3]

            module = importlib.import_module(moduleName)

            pluginObject = module.Plugin()
            try:
                apiVerStr = pluginObject.API_VERSION
                isCompatible = True
            except AttributeError:
                apiVerStr = pluginObject.NOVELTREE_API
                isCompatible = False
            majorStr, minorStr = apiVerStr.split('.')
            apiMajorVersion = int(majorStr)
            apiMinorVersion = int(minorStr)
            if apiMajorVersion != self.majorVersion:
                isCompatible = False
            if apiMinorVersion > self.minorVersion:
                isCompatible = False
            if isCompatible:
                pluginObject.install(self._mdl, self._ui, self._ctrl, prefs)

            pluginObject.isActive = isCompatible
            pluginObject.isRejected = False

            self[moduleName] = pluginObject

            pluginObject.filePath = filePath
            return True

        except Exception as ex:
            self[moduleName] = RejectedPlugin(filePath, str(ex))
            return False

    def load_plugins(self, pluginPath):
        if not os.path.isdir(pluginPath):
            print('Plugin directory not found.')
            return False

        self._ui.tv.tree.bind('<Double-1>', self.open_node)
        self._ui.tv.tree.bind('<Return>', self.open_node)

        sys.path.append(pluginPath)
        for file in glob.iglob(f'{pluginPath}/nv_*.py'):
            self.load_file(file)

        return True

    def disable_menu(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].disable_menu()
                except:
                    pass

    def enable_menu(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].enable_menu()
                except:
                    pass

    def lock(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].lock()
                except:
                    pass

    def unlock(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].unlock()
                except:
                    pass

    def on_quit(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].on_quit()
                except:
                    pass

    def on_close(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].on_close()
                except:
                    pass

    def open_node(self, event=None):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].open_node()
                except:
                    pass

from tkinter import ttk

import platform



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Alt-Shift-N>', 'Cmd-Alt-Shift-N')
    CHAPTER_LEVEL = ('<Command-Alt-c>', 'Cmd-Alt-C')
    DETACH_PROPERTIES = ('<Command-Alt-d>', 'Cmd-Alt-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Alt-t>', 'Cmd-Alt-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')


class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()



class PluginManager(tk.Toplevel):

    def __init__(self, size, view, controller, **kw):
        self._ui = view
        self._ctrl = controller
        super().__init__(**kw)
        self.title(f'{_("Installed plugins")} - novelibre 4.11.11')
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(fill='both', expand=True)

        columns = 'Module', 'Version', 'novelibre API', 'Description'
        self._moduleCollection = ttk.Treeview(window, columns=columns, show='headings', selectmode='browse')
        self._moduleCollection.pack(fill='both', expand=True)
        self._moduleCollection.bind('<<TreeviewSelect>>', self._on_select_module)
        self._moduleCollection.tag_configure('rejected', foreground='red')
        self._moduleCollection.tag_configure('inactive', foreground='gray')

        self._moduleCollection.column('Module', width=150, minwidth=120, stretch=False)
        self._moduleCollection.heading('Module', text=_('Module'), anchor='w')
        self._moduleCollection.column('Version', width=100, minwidth=100, stretch=False)
        self._moduleCollection.heading('Version', text=_('Version'), anchor='w')
        self._moduleCollection.column('novelibre API', width=100, minwidth=100, stretch=False)
        self._moduleCollection.heading('novelibre API', text=_('novelibre API'), anchor='w')
        self._moduleCollection.column('Description', width=400, stretch=True)
        self._moduleCollection.heading('Description', text=_('Description'), anchor='w')

        for moduleName in self._ctrl.plugins:
            nodeTags = []
            try:
                version = self._ctrl.plugins[moduleName].VERSION
            except AttributeError:
                version = _('unknown')
            try:
                description = self._ctrl.plugins[moduleName].DESCRIPTION
            except AttributeError:
                description = _('No description')
            try:
                apiRequired = self._ctrl.plugins[moduleName].API_VERSION
            except AttributeError:
                try:
                    apiRequired = self._ctrl.plugins[moduleName].NOVELTREE_API
                except AttributeError:
                    apiRequired = _('unknown')
            columns = [moduleName, version, apiRequired, description]
            if self._ctrl.plugins[moduleName].isRejected:
                nodeTags.append('rejected')
            elif not self._ctrl.plugins[moduleName].isActive:
                nodeTags.append('inactive')
            self._moduleCollection.insert('', 'end', moduleName, values=columns, tags=tuple(nodeTags))

        self._homeButton = ttk.Button(window, text=_('Home page'), command=self._open_home_page, state='disabled')
        self._homeButton.pack(padx=5, pady=5, side='left')

        self._deleteButton = ttk.Button(window, text=_('Delete'), command=self._delete_module, state='disabled')
        self._deleteButton.pack(padx=5, pady=5, side='left')

        ttk.Button(window, text=_('Close'), command=self.destroy).pack(padx=5, pady=5, side='right')

        ttk.Button(
            window,
            text=_('Online help'),
            command=self._open_help
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _delete_module(self, event=None):
        moduleName = self._moduleCollection.selection()[0]
        if moduleName:
            if self._ctrl.plugins.delete_file(moduleName):
                self._deleteButton.configure(state='disabled')
                if self._ctrl.plugins[moduleName].isActive:
                    self._ui.show_info(_('The plugin remains active until next start.'), title=f'{moduleName} {_("deleted")}')
                else:
                    self._moduleCollection.delete(moduleName)

    def _on_select_module(self, event):
        moduleName = self._moduleCollection.selection()[0]
        homeButtonState = 'disabled'
        deleteButtonState = 'disabled'
        if moduleName:
            try:
                if self._ctrl.plugins[moduleName].URL:
                    homeButtonState = 'normal'
            except:
                pass
            try:
                if self._ctrl.plugins[moduleName].filePath:
                    deleteButtonState = 'normal'
            except:
                pass
        self._homeButton.configure(state=homeButtonState)
        self._deleteButton.configure(state=deleteButtonState)

    def _open_help(self, event=None):
        open_help(f'tools_menu.html#{_("plugin-manager").lower()}')

    def _open_home_page(self, event=None):
        moduleName = self._moduleCollection.selection()[0]
        if moduleName:
            try:
                url = self._ctrl.plugins[moduleName].URL
                if url:
                    webbrowser.open(url)
            except:
                pass

from tkinter import messagebox
from tkinter import ttk



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import ttk

from xml import sax


class ContentViewParser(sax.ContentHandler):
    BULLET = '•'

    def __init__(self):
        super().__init__()
        self.textTag = ''
        self.xmlTag = ''
        self.emTag = ''
        self.strongTag = ''
        self.commentTag = ''
        self.commentXmlTag = ''
        self.noteTag = ''
        self.noteXmlTag = ''

        self.taggedText = None

        self._list = None
        self._comment = None
        self._note = None
        self._em = None
        self._strong = None

    def feed(self, xmlString):
        self.taggedText = []
        self._list = False
        self._comment = False
        self._note = False
        self._em = False
        self._strong = False
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):
        tag = self.textTag
        if self._em:
            tag = self.emTag
        elif self._strong:
            tag = self.strongTag
        if self._comment:
            tag = self.commentTag
        elif self._note:
            tag = self.noteTag
        self.taggedText.append((content, tag))

    def endElement(self, name):
        tag = self.xmlTag
        suffix = ''
        if self._comment:
            tag = self.commentXmlTag
        elif self._note:
            tag = self.noteXmlTag
        if name == 'p' and not self._list:
            suffix = '\n'
        elif name == 'em':
            self._em = False
        elif name == 'strong':
            self._strong = False
        elif name in ('li', 'creator', 'date', 'note-citation'):
            suffix = '\n'
        elif name == 'ul':
            self._list = False
            if self.showTags:
                suffix = '\n'
        elif name == 'comment':
            self._comment = False
        elif name == 'note':
            self._note = False
        if self.showTags:
            self.taggedText.append((f'</{name}>{suffix}', tag))
        else:
            self.taggedText.append((suffix, tag))

    def startElement(self, name, attrs):
        attributes = ''
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            attributes = f'{attributes} {attrKey}="{attrValue}"'
        tag = self.xmlTag
        suffix = ''
        if name == 'em':
            self._em = True
        elif name == 'strong':
            self._strong = True
        elif name == 'ul':
            self._list = True
            if self.showTags:
                suffix = '\n'
        elif name == 'comment':
            self._comment = True
            suffix = '\n'
        elif name == 'note':
            self._note = True
            suffix = '\n'
        elif name == 'li' and not self.showTags:
            suffix = f'{self.BULLET} '
        if self._comment:
            tag = self.commentXmlTag
        elif self._note:
            tag = self.noteXmlTag
        if self.showTags:
            self.taggedText.append((f'<{name}{attributes}>{suffix}', tag))
        else:
            self.taggedText.append((suffix, tag))
from tkinter import font as tkFont
from tkinter import font as tkFont
from tkinter import ttk


class RichTextTk(tk.Text):
    H1_TAG = 'h1'
    H2_TAG = 'h2'
    H3_TAG = 'h3'
    ITALIC_TAG = 'italic'
    BOLD_TAG = 'bold'
    CENTER_TAG = 'center'
    BULLET_TAG = 'bullet'

    H1_SIZE = 1.2
    H2_SIZE = 1.1
    H3_SIZE = 1.0
    H1_SPACING = 2
    H2_SPACING = 2
    H3_SPACING = 1.5
    CENTER_SPACING = 1.5

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        defaultFont = tkFont.nametofont(self.cget('font'))

        em = defaultFont.measure('m')
        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE), weight='bold')
        h2Font.configure(size=int(defaultSize * self.H2_SIZE), weight='bold')
        h3Font.configure(size=int(defaultSize * self.H3_SIZE), slant='italic')

        self.tag_configure(self.BOLD_TAG, font=boldFont)
        self.tag_configure(self.ITALIC_TAG, font=italicFont)
        self.tag_configure(self.H1_TAG, font=h1Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H1_SPACING)
        self.tag_configure(self.H2_TAG, font=h2Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H2_SPACING)
        self.tag_configure(self.H3_TAG, font=h3Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H3_SPACING)
        self.tag_configure(self.CENTER_TAG, justify='center', spacing1=defaultSize * self.CENTER_SPACING)

        lmargin2 = em + defaultFont.measure('\u2022 ')
        self.tag_configure(self.BULLET_TAG, lmargin1=em, lmargin2=lmargin2)

    def insert_bullet(self, index, text):
        self.insert(index, f'\u2022 {text}', self.BULLET_TAG)


class RichTextNv(RichTextTk):
    H1_NOTES_TAG = 'h1Notes'
    H1_TODO_TAG = 'h1Todo'
    H1_UNUSED_TAG = 'h1Unused'
    H2_NOTES_TAG = 'h2Notes'
    H2_TODO_TAG = 'h2Todo'
    H2_UNUSED_TAG = 'h2Unused'
    H3_NOTES_TAG = 'h3Notes'
    H3_TODO_TAG = 'h3Todo'
    H3_UNUSED_TAG = 'h3Unused'
    TODO_TAG = 'todo'
    NOTES_TAG = 'notes'
    UNUSED_TAG = 'unused'
    STAGE1_TAG = 'stage1'
    STAGE2_TAG = 'stage2'
    XML_TAG = 'xmlTag'
    COMMENT_TAG = 'commentTag'
    COMMENT_XML_TAG = 'commentXmlTag'
    NOTE_TAG = 'noteTag'
    NOTE_XML_TAG = 'noteXmlTag'
    EM_TAG = 'emTag'
    STRONG_TAG = 'strongTag'

    COLOR_XML_TAG = 'cornflower blue'
    COLOR_COMMENT_TAG = 'lemon chiffon'
    COLOR_NOTE_TAG = 'bisque'

    def __init__(self, *args, **kwargs):
        super().__init__(*args,
                height=20,
                width=60,
                spacing1=10,
                spacing2=2,
                wrap='word',
                padx=10,
                bg=kwargs['color_text_bg'],
                fg=kwargs['color_text_fg'],
                )
        defaultFont = tkFont.nametofont(self.cget('font'))

        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE),
                         weight='bold',
                         )
        h2Font.configure(size=int(defaultSize * self.H2_SIZE),
                         weight='bold',
                         )
        h3Font.configure(size=int(defaultSize * self.H3_SIZE),
                         slant='italic',
                         )
        self.tag_configure(self.XML_TAG,
                           foreground=self.COLOR_XML_TAG,
                           )
        self.tag_configure(self.EM_TAG,
                           font=italicFont,
                           )
        self.tag_configure(self.STRONG_TAG,
                           font=boldFont,
                           )
        self.tag_configure(self.COMMENT_TAG,
                           background=self.COLOR_COMMENT_TAG,
                           )
        self.tag_configure(self.COMMENT_XML_TAG,
                           foreground=self.COLOR_XML_TAG,
                           background=self.COLOR_COMMENT_TAG,
                           )
        self.tag_configure(self.NOTE_TAG,
                           background=self.COLOR_NOTE_TAG,
                           )
        self.tag_configure(self.NOTE_XML_TAG,
                           foreground=self.COLOR_XML_TAG,
                           background=self.COLOR_NOTE_TAG,
                           )
        self.tag_configure(self.H1_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_chapter'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H1_UNUSED_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H2_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_chapter'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H2_UNUSED_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H3_UNUSED_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )
        self.tag_configure(self.UNUSED_TAG,
                           foreground=kwargs['color_unused'],
                           )
        self.tag_configure(self.STAGE1_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_stage'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.STAGE2_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_stage'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )



class ContentsViewer(RichTextNv):
    NO_TEXT = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')

    def __init__(self, parent, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        super().__init__(parent, **prefs)
        self.pack(expand=True, fill='both')
        self.showMarkup = tk.BooleanVar(parent, value=prefs['show_markup'])
        ttk.Checkbutton(parent, text=_('Show markup'), variable=self.showMarkup).pack(anchor='w')
        self.showMarkup.trace('w', self.refresh)
        self._textMarks = {}
        self._index = '1.0'
        self._parent = parent
        self._contentParser = ContentViewParser()
        self._contentParser.xmlTag = self.XML_TAG
        self._contentParser.emTag = self.EM_TAG
        self._contentParser.strongTag = self.STRONG_TAG
        self._contentParser.commentTag = self.COMMENT_TAG
        self._contentParser.commentXmlTag = self.COMMENT_XML_TAG
        self._contentParser.noteTag = self.NOTE_TAG
        self._contentParser.noteXmlTag = self.NOTE_XML_TAG

    def reset_view(self):
        self.config(state='normal')
        self.delete('1.0', 'end')
        self.config(state='disabled')

    def see(self, idStr):
        try:
            self._index = self._textMarks[idStr]
            super().see(self._index)
        except KeyError:
            pass

    def refresh(self, event=None, *args):
        if self._mdl.prjFile is None:
            return

        if self._parent.winfo_manager():
            self.view_text()
            try:
                super().see(self._index)
            except KeyError:
                pass

    def view_text(self):

        def convert_from_novx(text):
            if not self.showMarkup.get():
                self._contentParser.showTags = False
            else:
                self._contentParser.showTags = True
            self._contentParser.textTag = textTag
            self._contentParser.feed(text)
            return self._contentParser.taggedText[1:-1]

        taggedText = []
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            chapter = self._mdl.novel.chapters[chId]
            taggedText.append(chId)
            if chapter.chLevel == 2:
                if chapter.chType == 0:
                    headingTag = self.H2_TAG
                else:
                    headingTag = self.H2_UNUSED_TAG
            else:
                if chapter.chType == 0:
                    headingTag = self.H1_TAG
                else:
                    headingTag = self.H1_UNUSED_TAG
            if chapter.title:
                heading = f'{chapter.title}\n'
            else:
                    heading = f"[{_('Unnamed')}]\n"
            taggedText.append((heading, headingTag))

            for scId in self._mdl.novel.tree.get_children(chId):
                section = self._mdl.novel.sections[scId]
                taggedText.append(scId)
                textTag = ''
                if section.scType == 3:
                    headingTag = self.STAGE2_TAG
                elif section.scType == 2:
                    headingTag = self.STAGE1_TAG
                elif section.scType == 0:
                    headingTag = self.H3_TAG
                else:
                    headingTag = self.H3_UNUSED_TAG
                    textTag = self.UNUSED_TAG
                if section.title:
                    heading = f'[{section.title}]\n'
                else:
                    heading = f"[{_('Unnamed')}]\n"
                taggedText.append((heading, headingTag))

                if section.sectionContent:
                    textTuples = convert_from_novx(section.sectionContent)
                    taggedText.extend(textTuples)

        if not taggedText:
            taggedText.append((f'({_("No text available")})', self.ITALIC_TAG))
        self._textMarks = {}

        self.config(state='normal')
        self.delete('1.0', 'end')

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index
        self.config(state='disabled')




class Icons:

    def __init__(self):
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            iconPath = f'{os.path.dirname(sys.argv[0])}/icons/{size}'
        except:
            iconPath = None
        try:
            self.addIcon = tk.PhotoImage(file=f'{iconPath}/add.png')
        except:
            self.addIcon = None
        try:
            self.addChildIcon = tk.PhotoImage(file=f'{iconPath}/addChild.png')
        except:
            self.addChildIcon = None
        try:
            self.addParentIcon = tk.PhotoImage(file=f'{iconPath}/addParent.png')
        except:
            self.addParentIcon = None
        try:
            self.goBackIcon = tk.PhotoImage(file=f'{iconPath}/goBack.png')
        except:
            self.goBackIcon = None
        try:
            self.goForwardIcon = tk.PhotoImage(file=f'{iconPath}/goForward.png')
        except:
            self.goForwardIcon = None
        try:
            self.gotoIcon = tk.PhotoImage(file=f'{iconPath}/goto.png')
        except:
            self.gotoIcon = None
        try:
            self.lockIcon = tk.PhotoImage(file=f'{iconPath}/lock.png')
        except:
            self.lockIcon = None
        try:
            self.manuscriptIcon = tk.PhotoImage(file=f'{iconPath}/manuscript.png')
        except:
            self.manuscriptIcon = None
        try:
            self.propertiesIcon = tk.PhotoImage(file=f'{iconPath}/properties.png')
        except:
            self.propertiesIcon = None
        try:
            self.removeIcon = tk.PhotoImage(file=f'{iconPath}/remove.png')
        except:
            self.removeIcon = None
        try:
            self.saveIcon = tk.PhotoImage(file=f'{iconPath}/save.png')
        except:
            self.saveIcon = None
        try:
            self.updateFromManuscriptIcon = tk.PhotoImage(file=f'{iconPath}/updateFromManuscript.png')
        except:
            self.updateFromManuscriptIcon = None
        try:
            self.viewPlotLinesIcon = tk.PhotoImage(file=f'{iconPath}/viewArcs.png')
        except:
            self.viewPlotLinesIcon = None
        try:
            self.viewBookIcon = tk.PhotoImage(file=f'{iconPath}/viewBook.png')
        except:
            self.viewBookIcon = None
        try:
            self.viewCharactersIcon = tk.PhotoImage(file=f'{iconPath}/viewCharacters.png')
        except:
            self.viewCharactersIcon = None
        try:
            self.viewItemsIcon = tk.PhotoImage(file=f'{iconPath}/viewItems.png')
        except:
            self.viewItemsIcon = None
        try:
            self.viewLocationsIcon = tk.PhotoImage(file=f'{iconPath}/viewLocations.png')
        except:
            self.viewLocationsIcon = None
        try:
            self.viewProjectnotesIcon = tk.PhotoImage(file=f'{iconPath}/viewProjectnotes.png')
        except:
            self.viewProjectnotesIcon = None
        try:
            self.viewerIcon = tk.PhotoImage(file=f'{iconPath}/viewer.png')
        except:
            self.viewerIcon = None
from tkinter import ttk



class ExportOptionsWindow(tk.Toplevel):

    def __init__(self, size, view, **kw):
        super().__init__(**kw)
        self.title(_('"Export" options'))
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(
            fill='both',
            padx=5,
            pady=5
            )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')

        self._askDocOpen = tk.BooleanVar(frame1, value=prefs['ask_doc_open'])
        ttk.Checkbutton(
            frame1,
            text=_('Ask before opening exported documents'),
            variable=self._askDocOpen
            ).pack(padx=5, pady=5, anchor='w')
        self._askDocOpen.trace('w', self._change_ask_doc_open)

        self._lockOnExport = tk.BooleanVar(frame1, value=prefs['lock_on_export'])
        ttk.Checkbutton(
            frame1,
            text=_('Lock the project after document export for editing'),
            variable=self._lockOnExport
            ).pack(padx=5, pady=5, anchor='w')
        self._lockOnExport.trace('w', self._change_lock_on_export)

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy
            ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_ask_doc_open(self, *args):
        prefs['ask_doc_open'] = self._askDocOpen.get()

    def _change_lock_on_export(self, *args):
        prefs['lock_on_export'] = self._lockOnExport.get()

    def _open_help(self, event=None):
        open_help(f'export_menu.html#{_("options").lower()}')
from tkinter import ttk



class DragDropListbox(tk.Listbox):

    def __init__(self, master, **kw):
        kw['selectmode'] = 'single'
        tk.Listbox.__init__(self, master, kw)
        self.bind('<Button-1>', self._set_current)
        self.bind('<B1-Motion>', self._shift_selection)
        self.curIndex = None

    def _set_current(self, event):
        self.curIndex = self.nearest(event.y)

    def _shift_selection(self, event):
        i = self.nearest(event.y)
        if i < self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i + 1, x)
            self.curIndex = i
        elif i > self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i - 1, x)
            self.curIndex = i


class ViewOptionsWindow(tk.Toplevel):

    def __init__(self, size, view, **kw):
        self._ui = view
        super().__init__(**kw)
        self.title(_('"View" options'))
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(
            fill='both',
            padx=5,
            pady=5
            )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')

        ttk.Separator(window, orient='vertical').pack(fill='y', padx=10, side='left')
        frame2 = ttk.Frame(window)
        frame2.pack(fill='both', side='left')

        self._coloringModeStr = tk.StringVar(value=self._ui.tv.COLORING_MODES[self._ui.tv.coloringMode])
        self._coloringModeStr.trace('w', self._change_colors)
        ttk.Label(
            frame1,
            text=_('Coloring mode')
            ).pack(padx=5, pady=5, anchor='w')
        ttk.Combobox(
            frame1,
            textvariable=self._coloringModeStr,
            values=self._ui.tv.COLORING_MODES,
            width=20
            ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(frame1, orient='horizontal').pack(fill='x', pady=10)

        self._largeIcons = tk.BooleanVar(frame1, value=prefs['large_icons'])
        ttk.Checkbutton(
            frame1,
            text=_('Large toolbar icons'),
            variable=self._largeIcons,
            command=self._change_icon_size,
            ).pack(padx=5, pady=5, anchor='w')

        self._localizeDate = tk.BooleanVar(frame1, value=prefs['localize_date'])
        ttk.Checkbutton(
            frame1,
            text=_('Display localized dates'),
            variable=self._localizeDate,
            command=self._change_localize_date,
            ).pack(padx=5, pady=5, anchor='w')

        ttk.Label(
            frame2,
            text=_('Columns')
            ).pack(padx=5, pady=5, anchor='w')
        self._coIdsByTitle = {}
        for coId, title, __ in self._ui.tv.columns:
            self._coIdsByTitle[title] = coId
        self._colEntries = tk.Variable(value=list(self._coIdsByTitle))
        DragDropListbox(
            frame2,
            listvariable=self._colEntries,
            width=20
            ).pack(padx=5, pady=5, anchor='w')
        ttk.Button(
            frame2,
            text=_('Apply'),
            command=self._change_column_order
            ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy
            ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_colors(self, *args, **kwargs):
        cmStr = self._coloringModeStr.get()
        self._ui.tv.coloringMode = self._ui.tv.COLORING_MODES.index(cmStr)
        self._ui.tv.refresh()

    def _change_column_order(self, *args, **kwargs):
        srtColumns = []
        titles = self._colEntries.get()
        for title in titles:
            srtColumns.append(self._coIdsByTitle[title])
        prefs['column_order'] = list_to_string(srtColumns)
        self._ui.tv.configure_columns()
        self._ui.tv.refresh()

    def _change_icon_size(self, *args):
        prefs['large_icons'] = self._largeIcons.get()
        self._ui.show_info(_('The change takes effect after next startup.'), title=f'{_("Change icon size")}')

    def _change_localize_date(self, *args):
        prefs['localize_date'] = self._localizeDate.get()
        self._ui.tv.refresh()
        self._ui.propertiesView.refresh()

    def _open_help(self, event=None):
        open_help(f'view_menu.html#{_("options").lower()}')
from tkinter import ttk

from tkinter import ttk

from abc import ABC, abstractmethod
from tkinter import filedialog
from tkinter import ttk

from tkinter import ttk



class CollectionBox(ttk.Frame):

    def __init__(
            self,
            master,
            cmdAdd=None, lblAdd=None, iconAdd=None,
            cmdOpen=None, lblOpen=None, iconOpen=None,
            cmdRemove=None, lblRemove=None, iconRemove=None,
            cmdActivate=None, cmdSelect=None,
            **kw
            ):
        super().__init__(master, **kw)
        if cmdActivate is None:
            cmdActivate = self.enable_buttons

        listFrame = ttk.Frame(self)
        listFrame.pack(side='left', fill='both', expand=True)
        self.cList = tk.StringVar()
        self.cListbox = tk.Listbox(listFrame, listvariable=self.cList, selectmode='single')
        vbar = ttk.Scrollbar(listFrame, orient='vertical', command=self.cListbox.yview)
        vbar.pack(side='right', fill='y')
        self.cListbox.pack(side='left', fill='both', expand=True)
        self.cListbox.config(yscrollcommand=vbar.set)

        self.cListbox.bind('<FocusIn>', cmdActivate)
        self.cListbox.bind('<<ListboxSelect>>', self._on_change_selection)

        buttonbar = ttk.Frame(self)
        buttonbar.pack(anchor='n', side='right', fill='x', padx=5)
        self.inputWidgets = []

        self._cmdSelect = cmdSelect

        kwargs = dict(
            command=cmdOpen,
            image=iconOpen,
            )
        if lblOpen is None:
            kwargs['text'] = _('Open')
        else:
            kwargs['text'] = lblOpen
        self.btnOpen = ttk.Button(buttonbar, **kwargs)
        if cmdOpen is not None:
            self.btnOpen.pack(fill='x', expand=True)
            self.cListbox.bind('<Double-1>', cmdOpen)
            self.cListbox.bind('<Return>', cmdOpen)

        kwargs = dict(
            command=cmdAdd,
            image=iconAdd,
            )
        if lblAdd is None:
            kwargs['text'] = _('Add')
        else:
            kwargs['text'] = lblAdd
        self.btnAdd = ttk.Button(buttonbar, **kwargs)
        if cmdAdd is not None:
            self.btnAdd.pack(fill='x', expand=True)
            self.inputWidgets.append(self.btnAdd)

        kwargs = dict(
            command=cmdRemove,
            image=iconRemove,
            )
        if lblRemove is None:
            kwargs['text'] = _('Remove')
        else:
            kwargs['text'] = lblRemove
        self.btnRemove = ttk.Button(buttonbar, **kwargs)
        if cmdRemove is not None:
            self.btnRemove.pack(fill='x', expand=True)
            self.inputWidgets.append(self.btnRemove)
            self.cListbox.bind(KEYS.DELETE[0], cmdRemove)

        self._set_hovertips()

    def enable_buttons(self, event=None):
        self.btnOpen.config(state='normal')
        self.btnRemove.config(state='normal')

    def disable_buttons(self, event=None):
        self.btnOpen.config(state='disabled')
        self.btnRemove.config(state='disabled')

    def _on_change_selection(self, event=None):
        self.enable_buttons()
        if self._cmdSelect is not None:
            try:
                self._cmdSelect(self.cListbox.curselection()[0])
            except:
                pass

    def _set_hovertips(self):
        if not prefs['enable_hovertips']:
            return

        try:
            from idlelib.tooltip import Hovertip
        except ModuleNotFoundError:
            return

        Hovertip(self.btnAdd, self.btnAdd['text'])
        Hovertip(self.btnOpen, self.btnOpen['text'])
        Hovertip(self.btnRemove, f"{self.btnRemove['text']} ({KEYS.DELETE[1]})")
from tkinter import ttk


class FoldingFrame(ttk.Frame):
    _PREFIX_SHOW = '▽  '
    _PREFIX_HIDE = '▷  '

    def __init__(self, parent, buttonText, command, **kw):
        super().__init__(parent, **kw)
        self.buttonText = buttonText
        self._toggleButton = ttk.Label(parent)
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self._toggleButton.pack(fill='x', pady=2)
        self._toggleButton.bind('<Button-1>', command)

    def show(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_SHOW}{self.buttonText}'
        self.pack(after=self._toggleButton, fill='x', pady=5)

    def hide(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self.pack_forget()

from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return strip_illegal_characters(text)

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self):
        value = super().get()
        if value == '':
            value = None
        return value


class IndexCard(tk.Frame):

    def __init__(self, master=None, cnf={}, fg='black', bg='white', font=None, scrollbar=True, **kw):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            self,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
            )
        self.titleEntry.config({
            'background': bg,
            'foreground': fg,
            'insertbackground': fg,
            })
        self.titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
            )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')


class BasicView(ttk.Frame, ABC):
    _HEIGHT_LIMIT = 10

    _LBL_X = 10

    def __init__(self, parent, model, view, controller):
        super().__init__(parent)

        self._mdl = model
        self._ui = view
        self._ctrl = controller

        self._elementId = None
        self._element = None
        self._tagsStr = ''
        self._parent = parent
        self._inputWidgets = []

        self._pickingMode = False
        self._pickCommand = None
        self._uiEscBinding = ''
        self._uiBtn1Binding = ''

        self.doNotUpdate = False
        self._isLocked = False

        self._propertiesFrame = ttk.Frame(self)
        self._propertiesFrame.pack(expand=True, fill='both')

        self._prefsShowLinks = None
        self._create_frames()

    def _activate_link_buttons(self, event=None):
        if self._element.links:
            self._linkCollection.enable_buttons()
        else:
            self._linkCollection.disable_buttons()

    def apply_changes(self, event=None):
        if self._element is None:
            return

        titleStr = self._indexCard.title.get()
        if titleStr:
            titleStr = titleStr.strip()
        self._element.title = titleStr

        if self._indexCard.bodyBox.hasChanged:
            self._element.desc = self._indexCard.bodyBox.get_text()

        if hasattr(self._element, 'notes') and self._notesWindow.hasChanged:
            self._element.notes = self._notesWindow.get_text()

    def focus_title(self):
        self._indexCard.titleEntry.focus()
        self._indexCard.titleEntry.icursor(0)
        self._indexCard.titleEntry.selection_range(0, 'end')

    def hide(self):
        self.pack_forget()

    def lock(self):
        self._indexCard.lock()
        try:
            self._notesWindow.config(state='disabled')
        except:
            pass
        for widget in self._inputWidgets:
            widget.config(state='disabled')
        self._isLocked = True

    @abstractmethod
    def set_data(self, elementId):
        self._elementId = elementId
        self._tagsStr = ''
        if self._element is not None:

            self._indexCard.title.set(self._element.title)

            self._indexCard.bodyBox.clear()
            self._indexCard.bodyBox.set_text(self._element.desc)

            if hasattr(self._element, 'links'):
                if prefs[self._prefsShowLinks]:
                    self._linksWindow.show()
                else:
                    self._linksWindow.hide()
                linkList = []
                for path in self._element.links:
                    linkList.append(os.path.split(path)[1])
                self._linkCollection.cList.set(linkList)
                listboxSize = len(linkList)
                if listboxSize > self._HEIGHT_LIMIT:
                    listboxSize = self._HEIGHT_LIMIT
                self._linkCollection.cListbox.config(height=listboxSize)
                if not self._linkCollection.cListbox.curselection() or not self._linkCollection.cListbox.focus_get():
                    self._linkCollection.disable_buttons()

            if hasattr(self._element, 'notes'):
                self._notesWindow.clear()
                self._notesWindow.set_text(self._element.notes)

    def show(self):
        self.pack(expand=True, fill='both')

    def unlock(self):
        self._indexCard.unlock()
        try:
            self._notesWindow.config(state='normal')
        except:
            pass
        for widget in self._inputWidgets:
            widget.config(state='normal')
        self._isLocked = False

    def _add_link(self):
        fileTypes = [
            (_('Image file'), '.jpg'),
            (_('Image file'), '.jpeg'),
            (_('Image file'), '.png'),
            (_('Image file'), '.gif'),
            (_('Text file'), '.txt'),
            (_('Text file'), '.md'),
            (_('ODF document'), '.odt'),
            (_('ODF document'), '.ods'),
            (_('All files'), '.*'),
            ]
        selectedPath = filedialog.askopenfilename(filetypes=fileTypes)
        if selectedPath:
            shortPath = self._ctrl.linkProcessor.shorten_path(selectedPath)
            links = self._element.links
            if links is None:
                links = {}
            links[shortPath] = selectedPath
            self._element.links = links

    def _add_separator(self):
        ttk.Separator(self._propertiesFrame, orient='horizontal').pack(fill='x')

    def _create_button_bar(self):
        self._buttonBar = ttk.Frame(self)
        self._buttonBar.pack(fill='x')

        ttk.Button(self._buttonBar, text=_('Previous'), command=self._load_prev).pack(side='left', fill='x', expand=True, padx=1, pady=2)

        ttk.Button(self._buttonBar, text=_('Next'), command=self._load_next).pack(side='left', fill='x', expand=True, padx=1, pady=2)

    def _create_element_info_window(self):
        self._elementInfoWindow = ttk.Frame(self._propertiesFrame)
        self._elementInfoWindow.pack(fill='x')

    @abstractmethod
    def _create_frames(self):
        pass

    def _create_index_card(self):
        self._indexCard = IndexCard(
            self._propertiesFrame,
            bd=2,
            fg=prefs['color_text_fg'],
            bg=prefs['color_text_bg'],
            relief='ridge'
            )
        self._indexCard.bodyBox['height'] = prefs['index_card_height']
        self._indexCard.pack(expand=False, fill='both')
        self._indexCard.titleEntry.bind('<Return>', self.apply_changes)
        self._indexCard.titleEntry.bind('<FocusOut>', self.apply_changes)
        self._indexCard.bodyBox.bind('<FocusOut>', self.apply_changes)

    def _create_links_window(self):
        ttk.Separator(self._propertiesFrame, orient='horizontal').pack(fill='x')
        self._linksWindow = FoldingFrame(self._propertiesFrame, _('Links'), self._toggle_links_window)
        self._linksWindow.pack(fill='x')
        self._linkCollection = CollectionBox(
            self._linksWindow,
            cmdAdd=self._add_link,
            cmdRemove=self._remove_link,
            cmdOpen=self._open_link,
            cmdActivate=self._activate_link_buttons,
            lblOpen=_('Open link'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._inputWidgets.extend(self._linkCollection.inputWidgets)
        self._linkCollection.pack(fill='x')

    def _create_notes_window(self):
        self._notesWindow = TextBox(
            self._propertiesFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=0,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_notes_bg'],
            fg=prefs['color_notes_fg'],
            insertbackground=prefs['color_notes_fg'],
            )
        self._notesWindow.pack(expand=True, fill='both')
        self._notesWindow.bind('<FocusOut>', self.apply_changes)

    def _end_picking_mode(self, event=None):
        if self._pickingMode:
            if self._pickCommand is not None:
                self._pickCommand()
                self._pickCommand = None
            self._ui.root.bind('<Button-1>', self._uiBtn1Binding)
            self._ui.root.bind('<Escape>', self._uiEscBinding)
            self._ui.tv.config(cursor='arrow')
            self._ui.tv.see_node(self._lastSelected)
            self._ui.tv.tree.selection_set(self._lastSelected)
            self._pickingMode = False
        self._ui.restore_status()

    def _load_next(self):
        thisNode = self._ui.tv.tree.selection()[0]
        nextNode = self._ui.tv.next_node(thisNode)
        if nextNode:
            self._ui.tv.see_node(nextNode)
            self._ui.tv.tree.selection_set(nextNode)

    def _load_prev(self):
        thisNode = self._ui.tv.tree.selection()[0]
        prevNode = self._ui.tv.prev_node(thisNode)
        if prevNode:
            self._ui.tv.see_node(prevNode)
            self._ui.tv.tree.selection_set(prevNode)

    def _open_link(self, event=None):
        try:
            selection = self._linkCollection.cListbox.curselection()[0]
        except:
            return

        self._ctrl.open_link(self._element, selection)

    def _remove_link(self, event=None):
        try:
            selection = self._linkCollection.cListbox.curselection()[0]
        except:
            return

        linkPath = list(self._element.links)[selection]
        if self._ui.ask_yes_no(f'{_("Remove link")}: "{self._element.links[linkPath]}"?'):
            links = self._element.links
            try:
                del links[linkPath]
            except:
                pass
            else:
                self._element.links = links

    def _show_missing_date_message(self):
        self._ui.show_error(
            _('Please enter either a section date or a day and a reference date.'),
            title=_('Date information is missing'))

    def _show_missing_reference_date_message(self):
        self._ui.show_error(
            _('Please enter a reference date.'),
            title=_('Cannot convert date/days'))

    def _start_picking_mode(self, event=None, command=None):
        self._pickCommand = command
        if not self._pickingMode:
            self._lastSelected = self._ui.tv.tree.selection()[0]
            self._ui.tv.config(cursor='plus')
            self._ui.tv.open_children('')
            self._uiEscBinding = self._ui.root.bind('<Escape>')
            self._ui.root.bind('<Escape>', self._end_picking_mode)
            self._uiBtn1Binding = self._ui.root.bind('<Button-1>')
            self._ui.root.bind('<Button-1>', self._end_picking_mode)
            self._pickingMode = True
        self._ui.set_status(_('Pick Mode (click here or press Esc to exit)'), colors=('maroon', 'white'))

    def _toggle_links_window(self, event=None):
        if prefs[self._prefsShowLinks]:
            self._linksWindow.hide()
            prefs[self._prefsShowLinks] = False
        else:
            self._linksWindow.show()
            prefs[self._prefsShowLinks] = True

from tkinter import ttk


class LabelEntry(ttk.Frame):

    def __init__(self, parent, text, textvariable, command, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self.entry = ttk.Entry(self, textvariable=textvariable)
        self.entry.pack(side='left', fill='x', expand=True)
        self.entry.bind('<Return>', command)

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None, state=None):
        if text is not None:
            self._label['text'] = text
        if state is not None:
            self.entry.config(state=state)


class PlotLineView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._lastSelected = ''

        self._shortName = MyStringVar()
        self._shortNameEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Short name'),
            textvariable=self._shortName,
            command=self.apply_changes,
            lblWidth=22
            )
        self._shortNameEntry.pack(anchor='w')
        inputWidgets.append(self._shortNameEntry)

        self._plotFrame = ttk.Frame(self._elementInfoWindow)
        self._plotFrame.pack(fill='x')
        self._nrSections = ttk.Label(self._plotFrame)
        self._nrSections.pack(side='left')
        self._clearButton = ttk.Button(self._plotFrame, text=_('Clear section assignments'), command=self._remove_sections)
        self._clearButton.pack(padx=1, pady=2)
        inputWidgets.append(self._clearButton)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pl_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        self._element.shortName = self._shortName.get()

    def set_data(self, elementId):
        self._element = self._mdl.novel.plotLines[elementId]
        super().set_data(elementId)

        self._shortName.set(self._element.shortName)

        if self._element.sections is not None:
            self._nrSections['text'] = f'{_("Number of sections")}: {len(self._element.sections)}'

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _remove_sections(self):
        if self._ui.ask_yes_no(f'{_("Remove all sections from the plot line")} "{self._element.shortName}"?'):
            if self._element.sections:
                self.doNotUpdate = True
                for scId in self._element.sections:
                    self._mdl.novel.sections[scId].scPlotLines.remove(self._elementId)
                for ppId in self._mdl.novel.tree.get_children(self._elementId):
                    scId = self._mdl.novel.plotPoints[ppId].sectionAssoc
                    if scId is not None:
                        del(self._mdl.novel.sections[scId].scPlotPoints[ppId])
                        self._mdl.novel.plotPoints[ppId].sectionAssoc = None
                self._element.sections = []
                self.set_data(self._elementId)
                self.doNotUpdate = False

from tkinter import ttk



class ChapterView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._isUnused = tk.BooleanVar()
        self._isUnusedCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            text=_('Unused'),
            variable=self._isUnused,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._isUnusedCheckbox.pack(anchor='w')
        inputWidgets.append(self._isUnusedCheckbox)

        self._noNumber = tk.BooleanVar()
        self._noNumberCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            variable=self._noNumber,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._noNumberCheckbox.pack(anchor='w')
        inputWidgets.append(self._noNumberCheckbox)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_ch_links'

    def apply_changes(self, event=None):
        if self._element.isTrash:
            return

        super().apply_changes()

        if self._isUnused.get():
            self._ctrl.set_type(1, [self._elementId])
        else:
            self._ctrl.set_type(0, [self._elementId])

        self._element.noNumber = self._noNumber.get()

    def set_data(self, elementId):
        self._element = self._mdl.novel.chapters[elementId]
        super().set_data(elementId)

        if self._element.chType > 0:
            self._isUnused.set(True)
        else:
            self._isUnused.set(False)

        if self._element.chLevel == 1:
            labelText = _('Do not auto-number this part')
        else:
            labelText = _('Do not auto-number this chapter')
        self._noNumberCheckbox.configure(text=labelText)
        if self._element.noNumber:
            self._noNumber.set(True)
        else:
            self._noNumber.set(False)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

from datetime import date
from tkinter import ttk

from abc import ABC, abstractmethod
from tkinter import ttk



class WorldElementView(BasicView, ABC):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._fullNameFrame = ttk.Frame(self._elementInfoWindow)
        self._fullNameFrame.pack(anchor='w', fill='x')

        self._aka = MyStringVar()
        self._akaEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('AKA'),
            textvariable=self._aka,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._akaEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._akaEntry)

        self._tags = MyStringVar()
        self._tagsEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Tags'),
            textvariable=self._tags,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._tagsEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._tagsEntry)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

    def apply_changes(self, event=None):
        super().apply_changes()

        self._element.aka = self._aka.get()

        newTags = self._tags.get()
        self._element.tags = string_to_list(newTags)

    @abstractmethod
    def set_data(self, elementId):
        super().set_data(elementId)

        self._aka.set(self._element.aka)

        if self._element.tags is not None:
            self._tagsStr = list_to_string(self._element.tags)
        else:
            self._tagsStr = ''
        self._tags.set(self._tagsStr)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()



class CharacterView(WorldElementView):
    _LBL_X = 15

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._fullName = MyStringVar()
        self._fullNameEntry = LabelEntry(
            self._fullNameFrame,
            text=_('Full name'),
            textvariable=self._fullName,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._fullNameEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._fullNameEntry)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._bioFrame = FoldingFrame(self._elementInfoWindow, '', self._toggle_bio_window)

        self._birthDate = MyStringVar()
        self._birthDateEntry = LabelEntry(
            self._bioFrame,
            text=_('Birth date'),
            textvariable=self._birthDate,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._birthDateEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._birthDateEntry)

        self._deathDate = MyStringVar()
        self._deathDateEntry = LabelEntry(
            self._bioFrame,
            text=_('Death date'),
            textvariable=self._deathDate,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._deathDateEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._deathDateEntry)

        self._bioEntry = TextBox(self._bioFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=10,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._bioEntry.pack(fill='x')
        inputWidgets.append(self._bioEntry)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._goalsFrame = FoldingFrame(self._elementInfoWindow, '', self._toggle_goals_window)
        self._goalsEntry = TextBox(self._goalsFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=10,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._goalsEntry.pack(fill='x')
        inputWidgets.append(self._goalsEntry)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_cr_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        self._element.fullName = self._fullName.get()

        if self._bioEntry.hasChanged:
            self._element.bio = self._bioEntry.get_text()

        birthDateStr = self._birthDate.get()
        if not birthDateStr:
            self._element.birthDate = None
        elif birthDateStr != self._element.birthDate:
            try:
                date.fromisoformat(birthDateStr)
            except:
                self._birthDate.set(self._element.birthDate)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{birthDateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.birthDate = birthDateStr

        deathDateStr = self._deathDate.get()
        if not deathDateStr:
            self._element.deathDate = None
        elif deathDateStr != self._element.deathDate:
            try:
                date.fromisoformat(deathDateStr)
            except:
                self._deathDate.set(self._element.deathDate)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{deathDateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.deathDate = deathDateStr

        if self._goalsEntry.hasChanged:
            self._element.goals = self._goalsEntry.get_text()

    def set_data(self, elementId):
        self._element = self._mdl.novel.characters[elementId]
        super().set_data(elementId)

        self._fullName.set(self._element.fullName)

        if self._mdl.novel.customChrBio:
            self._bioFrame.buttonText = self._mdl.novel.customChrBio
        else:
            self._bioFrame.buttonText = _('Bio')
        if prefs['show_cr_bio']:
            self._bioFrame.show()
        else:
            self._bioFrame.hide()
        self._bioEntry.set_text(self._element.bio)

        self._birthDate.set(self._element.birthDate)
        self._deathDate.set(self._element.deathDate)

        if self._mdl.novel.customChrGoals:
            self._goalsFrame.buttonText = self._mdl.novel.customChrGoals
        else:
            self._goalsFrame.buttonText = _('Goals')
        if prefs['show_cr_goals']:
            self._goalsFrame.show()
        else:
            self._goalsFrame.hide()
        self._goalsEntry.set_text(self._element.goals)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _toggle_bio_window(self, event=None):
        if prefs['show_cr_bio']:
            self._bioFrame.hide()
            prefs['show_cr_bio'] = False
        else:
            self._bioFrame.show()
            prefs['show_cr_bio'] = True

    def _toggle_goals_window(self, event=None):
        if prefs['show_cr_goals']:
            self._goalsFrame.hide()
            prefs['show_cr_goals'] = False
        else:
            self._goalsFrame.show()
            prefs['show_cr_goals'] = True

from tkinter import ttk

from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta
from tkinter import ttk

from tkinter import ttk



class RelatedSectionView(BasicView):
    _HEIGHT_LIMIT = 10

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._tags = MyStringVar()
        self._tagsEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Tags'),
            textvariable=self._tags,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._tagsEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._tagsEntry)

        self._sectionExtraFrame = ttk.Frame(self._elementInfoWindow)
        self._sectionExtraFrame.pack(anchor='w', fill='x')

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._relationFrame = FoldingFrame(self._elementInfoWindow, _('Relationships'), self._toggle_relation_frame)

        self._crTitles = ''
        crHeading = ttk.Frame(self._relationFrame)
        self._characterLabel = ttk.Label(crHeading, text=_('Characters'))
        self._characterLabel.pack(anchor='w', side='left')
        ttk.Button(crHeading, text=_('Show ages'), command=self._show_ages).pack(anchor='e')
        crHeading.pack(fill='x')
        self._characterCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self._pick_character,
            cmdRemove=self._remove_character,
            cmdOpen=self._go_to_character,
            cmdActivate=self._activate_character_buttons,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._characterCollection.pack(fill='x')
        inputWidgets.extend(self._characterCollection.inputWidgets)

        self._lcTitles = ''
        self._locationLabel = ttk.Label(self._relationFrame, text=_('Locations'))
        self._locationLabel.pack(anchor='w')
        self._locationCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self._pick_location,
            cmdRemove=self._remove_location,
            cmdOpen=self._go_to_location,
            cmdActivate=self._activate_location_buttons,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._locationCollection.pack(fill='x')
        inputWidgets.extend(self._locationCollection.inputWidgets)

        self._itTitles = ''
        self._itemLabel = ttk.Label(self._relationFrame, text=_('Items'))
        self._itemLabel.pack(anchor='w')
        self._itemCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self._pick_item,
            cmdRemove=self._remove_item,
            cmdOpen=self._go_to_item,
            cmdActivate=self._activate_item_buttons,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._itemCollection.pack(fill='x')
        inputWidgets.extend(self._itemCollection.inputWidgets)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_sc_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        newTags = self._tags.get()
        if self._tagsStr or newTags:
            self._element.tags = string_to_list(newTags)

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        self._tagsStr = list_to_string(self._element.tags)
        self._tags.set(self._tagsStr)

        if prefs['show_relationships']:
            self._relationFrame.show()
        else:
            self._relationFrame.hide()

        self._crTitles = self._get_element_titles(self._element.characters, self._mdl.novel.characters)
        self._characterCollection.cList.set(self._crTitles)
        listboxSize = len(self._crTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._characterCollection.cListbox.config(height=listboxSize)
        if not self._characterCollection.cListbox.curselection() or not self._characterCollection.cListbox.focus_get():
            self._characterCollection.disable_buttons()

        self._lcTitles = self._get_element_titles(self._element.locations, self._mdl.novel.locations)
        self._locationCollection.cList.set(self._lcTitles)
        listboxSize = len(self._lcTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._locationCollection.cListbox.config(height=listboxSize)
        if not self._locationCollection.cListbox.curselection() or not self._locationCollection.cListbox.focus_get():
            self._locationCollection.disable_buttons()

        self._itTitles = self._get_element_titles(self._element.items, self._mdl.novel.items)
        self._itemCollection.cList.set(self._itTitles)
        listboxSize = len(self._itTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._itemCollection.cListbox.config(height=listboxSize)
        if not self._itemCollection.cListbox.curselection() or not self._itemCollection.cListbox.focus_get():
            self._itemCollection.disable_buttons()

    def _activate_character_buttons(self, event=None):
        if self._element.characters:
            self._characterCollection.enable_buttons()
        else:
            self._characterCollection.disable_buttons()

    def _activate_location_buttons(self, event=None):
        if self._element.locations:
            self._locationCollection.enable_buttons()
        else:
            self._locationCollection.disable_buttons()

    def _activate_item_buttons(self, event=None):
        if self._element.items:
            self._itemCollection.enable_buttons()
        else:
            self._itemCollection.disable_buttons()

    def _add_character(self, event=None):
        crList = self._element.characters
        crId = self._ui.tv.tree.selection()[0]
        if crId.startswith(CHARACTER_PREFIX) and not crId in crList:
            crList.append(crId)
            self._element.characters = crList

    def _add_location(self, event=None):
        lcList = self._element.locations
        lcId = self._ui.tv.tree.selection()[0]
        if lcId.startswith(LOCATION_PREFIX)and not lcId in lcList:
            lcList.append(lcId)
            self._element.locations = lcList

    def _add_item(self, event=None):
        itList = self._element.items
        itId = self._ui.tv.tree.selection()[0]
        if itId.startswith(ITEM_PREFIX)and not itId in itList:
            itList.append(itId)
            self._element.items = itList

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _get_relation_id_list(self, newTitleStr, oldTitleStr, elements):
        if newTitleStr or oldTitleStr:
            if oldTitleStr != newTitleStr:
                elemIds = []
                for elemTitle in string_to_list(newTitleStr):
                    for elemId in elements:
                        if elements[elemId].title == elemTitle:
                            elemIds.append(elemId)
                            break
                    else:
                        self._ui.show_error(f'{_("Wrong name")}: "{elemTitle}"', title=_('Input rejected'))
                return elemIds

        return None

    def _get_element_titles(self, elemIds, elements):
        elemTitles = []
        if elemIds:
            for elemId in elemIds:
                try:
                    elemTitles.append(elements[elemId].title)
                except:
                    pass
        return elemTitles

    def _go_to_character(self, event=None):
        try:
            selection = self._characterCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.characters[selection])

    def _go_to_location(self, event=None):
        try:
            selection = self._locationCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.locations[selection])

    def _go_to_item(self, event=None):
        try:
            selection = self._itemCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.items[selection])

    def _pick_character(self, event=None):
        self._start_picking_mode(command=self._add_character)
        self._ui.tv.see_node(CR_ROOT)

    def _pick_location(self, event=None):
        self._start_picking_mode(command=self._add_location)
        self._ui.tv.see_node(LC_ROOT)

    def _pick_item(self, event=None):
        self._start_picking_mode(command=self._add_item)
        self._ui.tv.see_node(IT_ROOT)

    def _remove_character(self, event=None):
        try:
            selection = self._characterCollection.cListbox.curselection()[0]
        except:
            return

        crId = self._element.characters[selection]
        title = self._mdl.novel.characters[crId].title
        if self._ui.ask_yes_no(f'{_("Remove character")}: "{title}"?'):
            crList = self._element.characters
            del crList[selection]
            self._element.characters = crList

    def _remove_location(self, event=None):
        try:
            selection = self._locationCollection.cListbox.curselection()[0]
        except:
            return

        lcId = self._element.locations[selection]
        title = self._mdl.novel.locations[lcId].title
        if self._ui.ask_yes_no(f'{_("Remove location")}: "{title}"?'):
            lcList = self._element.locations
            del lcList[selection]
            self._element.locations = lcList

    def _remove_item(self, event=None):
        try:
            selection = self._itemCollection.cListbox.curselection()[0]
        except:
            return

        itId = self._element.items[selection]
        title = self._mdl.novel.items[itId].title
        if self._ui.ask_yes_no(f'{_("Remove item")}: "{title}"?'):
            itList = self._element.items
            del itList[selection]
            self._element.items = itList

    def _show_ages(self, event=None):
        if self._element.date is not None:
            now = self._element.date
        else:
            try:
                now = get_specific_date(
                    self._element.day,
                    self._mdl.novel.referenceDate
                    )
            except:
                self._show_missing_date_message()
                return

        charList = []
        for crId in self._element.characters:
            birthDate = self._mdl.novel.characters[crId].birthDate
            deathDate = self._mdl.novel.characters[crId].deathDate
            try:
                years = get_age(now, birthDate, deathDate)
                if years < 0:
                    years *= -1
                    suffix = _('years after death')
                else:
                    suffix = _('years old')
                charList.append(f'{self._mdl.novel.characters[crId].title}: {years} {suffix}')
            except:
                charList.append(f'{self._mdl.novel.characters[crId].title}: ({_("no data")})')

        if charList:
            self._ui.show_info(
                '\n'.join(charList),
                title=f'{_("Date")}: {datestr(now)}'
                )

    def _toggle_relation_frame(self, event=None):
        if prefs['show_relationships']:
            self._relationFrame.hide()
            prefs['show_relationships'] = False
        else:
            self._relationFrame.show()
            prefs['show_relationships'] = True



class DatedSectionView(RelatedSectionView):
    _DATE_TIME_LBL_X = 15

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._dateTimeFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Date/Time'),
            self._toggle_date_time_frame)
        sectionStartFrame = ttk.Frame(self._dateTimeFrame
                                      )
        sectionStartFrame.pack(fill='x')
        localeDateFrame = ttk.Frame(sectionStartFrame)
        localeDateFrame.pack(fill='x')
        ttk.Label(localeDateFrame, text=_('Start'), width=self._DATE_TIME_LBL_X).pack(side='left')

        self._startDate = MyStringVar()
        self._startDateEntry = LabelEntry(
            sectionStartFrame,
            text=_('Date'),
            textvariable=self._startDate,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._startDateEntry.pack(anchor='w')
        inputWidgets.append(self._startDateEntry)

        self._startTime = MyStringVar()
        self._startTimeEntry = LabelEntry(
            sectionStartFrame,
            text=_('Time'),
            textvariable=self._startTime,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._startTimeEntry.pack(anchor='w')
        inputWidgets.append(self._startTimeEntry)

        self._startDay = MyStringVar()
        self._startDayEntry = LabelEntry(
            sectionStartFrame,
            text=_('Day'),
            textvariable=self._startDay,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._startDayEntry.pack(anchor='w')
        inputWidgets.append(self._startDayEntry)
        self._startDayEntry.entry.bind('<Return>', self._change_day)

        self._weekDay = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._weekDay).pack(side='left')

        self._localeDate = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._localeDate).pack(side='left')

        ttk.Label(localeDateFrame, textvariable=self._startTime).pack(side='left')

        ttk.Button(
            localeDateFrame,
            text=_('Moon phase'),
            command=self._show_moonphase
            ).pack(anchor='e')

        self._clearDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Clear date/time'),
            command=self._clear_start
            )
        self._clearDateButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._clearDateButton)

        self._generateDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Generate'),
            command=self._auto_set_date
            )
        self._generateDateButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._generateDateButton)

        self._toggleDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Convert date/day'),
            command=self._toggle_date
            )
        self._toggleDateButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._toggleDateButton)

        ttk.Separator(self._dateTimeFrame, orient='horizontal').pack(fill='x', pady=2)

        sectionDurationFrame = ttk.Frame(self._dateTimeFrame)
        sectionDurationFrame.pack(fill='x')
        ttk.Label(sectionDurationFrame, text=_('Duration')).pack(anchor='w')

        self._lastsDays = MyStringVar()
        self._lastsDaysEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Days'),
            textvariable=self._lastsDays,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._lastsDaysEntry.pack(anchor='w')
        inputWidgets.append(self._lastsDaysEntry)

        self._lastsHours = MyStringVar()
        self._lastsHoursEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Hours'),
            textvariable=self._lastsHours,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._lastsHoursEntry.pack(anchor='w')
        inputWidgets.append(self._lastsHoursEntry)

        self._lastsMinutes = MyStringVar()
        self._lastsMinutesEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Minutes'),
            textvariable=self._lastsMinutes,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._lastsMinutesEntry.pack(anchor='w')
        inputWidgets.append(self._lastsMinutesEntry)

        self._clearDurationButton = ttk.Button(
            sectionDurationFrame,
            text=_('Clear duration'),
            command=self._clear_duration
            )
        self._clearDurationButton.pack(side='left', padx=1, pady=2)
        inputWidgets.append(self._clearDurationButton)

        self._generatDurationButton = ttk.Button(
            sectionDurationFrame,
            text=_('Generate'),
            command=self._auto_set_duration
            )
        self._generatDurationButton.pack(side='left', padx=1, pady=2)
        inputWidgets.append(self._generatDurationButton)


        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

    def _change_day(self, event=None):
            dayStr = self._startDay.get()
            if dayStr or self._element.day:
                if dayStr != self._element.day:
                    if not dayStr:
                        self._element.day = None
                    else:
                        try:
                            int(dayStr)
                        except ValueError:
                            self._startDay.set(self._element.day)
                            self._ui.show_error(
                                f'{_("Wrong entry: number required")}.',
                                title=_('Input rejected')
                                )
                        else:
                            self._element.day = dayStr
                            self._element.date = None

    def apply_changes(self, event=None):
        super().apply_changes()


        dateStr = self._startDate.get()
        if not dateStr:
            self._element.date = None
        elif dateStr != self._element.date:
            try:
                date.fromisoformat(dateStr)
            except ValueError:
                self._startDate.set(self._element.date)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{dateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.date = dateStr

        timeStr = self._startTime.get()
        if not timeStr:
            self._element.time = None
        else:
            if self._element.time:
                dispTime = self._element.time.rsplit(':', 1)[0]
            else:
                dispTime = ''
            if timeStr != dispTime:
                try:
                    time.fromisoformat(timeStr)
                except ValueError:
                    self._startTime.set(dispTime)
                    self._ui.show_error(
                        f'{_("Wrong time")}: "{timeStr}"\n{_("Required")}: {_("hh:mm")}',
                        title=_('Input rejected')
                        )
                else:
                    while timeStr.count(':') < 2:
                        timeStr = f'{timeStr}:00'
                    self._element.time = timeStr
                    dispTime = self._element.time.rsplit(':', 1)[0]
                    self._startTime.set(dispTime)

        if self._element.date:
            self._element.day = None
        else:
            self._change_day()

        wrongEntry = False
        newEntry = False

        hoursLeft = 0
        lastsMinutesStr = self._lastsMinutes.get()
        if lastsMinutesStr or self._element.lastsMinutes:
            if lastsMinutesStr != self._element.lastsMinutes:
                if not lastsMinutesStr:
                    lastsMinutesStr = 0
                try:
                    minutes = int(lastsMinutesStr)
                except ValueError:
                    wrongEntry = True
                else:
                    hoursLeft, minutes = divmod(minutes, 60)
                    if minutes > 0:
                        lastsMinutesStr = str(minutes)
                    else:
                        lastsMinutesStr = None
                    self._lastsMinutes.set(lastsMinutesStr)
                    newEntry = True

        daysLeft = 0
        lastsHoursStr = self._lastsHours.get()
        if hoursLeft or lastsHoursStr or self._element.lastsHours:
            if hoursLeft or lastsHoursStr != self._element.lastsHours:
                try:
                    if lastsHoursStr:
                        hoursLeft += int(lastsHoursStr)
                    daysLeft, hoursLeft = divmod(hoursLeft, 24)
                    if hoursLeft > 0:
                        lastsHoursStr = str(hoursLeft)
                    else:
                        lastsHoursStr = None
                    self._lastsHours.set(lastsHoursStr)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        lastsDaysStr = self._lastsDays.get()
        if daysLeft or lastsDaysStr or self._element.lastsDays:
            if daysLeft or lastsDaysStr != self._element.lastsDays:
                try:
                    if lastsDaysStr:
                        daysLeft += int(lastsDaysStr)
                    if daysLeft > 0:
                        lastsDaysStr = str(daysLeft)
                    else:
                        lastsDaysStr = None
                    self._lastsDays.set(lastsDaysStr)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        if wrongEntry:
            self._lastsMinutes.set(self._element.lastsMinutes)
            self._lastsHours.set(self._element.lastsHours)
            self._lastsDays.set(self._element.lastsDays)
            self._ui.show_error(f'{_("Wrong entry: number required")}.', title=_('Input rejected'))
        elif newEntry:
            self._element.lastsMinutes = lastsMinutesStr
            self._element.lastsHours = lastsHoursStr
            self._element.lastsDays = lastsDaysStr

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        if self._element.date and self._element.weekDay is not None:
            self._weekDay.set(WEEKDAYS[self._element.weekDay])
        elif self._element.day and self._mdl.novel.referenceWeekDay is not None:
            self._weekDay.set(WEEKDAYS[(int(self._element.day) + self._mdl.novel.referenceWeekDay) % 7])
        else:
            self._weekDay.set('')
        self._startDate.set(self._element.date)
        if self._element.localeDate:
            displayDate = get_section_date_str(self._element)
        elif self._element.day:
            displayDate = f'{_("Day")} {self._element.day}'
        else:
            displayDate = ''
        self._localeDate.set(displayDate)

        if self._element.time:
            dispTime = self._element.time.rsplit(':', 1)[0]
        else:
            dispTime = ''
        self._startTime.set(dispTime)

        self._startDay.set(self._element.day)
        self._lastsDays.set(self._element.lastsDays)
        self._lastsHours.set(self._element.lastsHours)
        self._lastsMinutes.set(self._element.lastsMinutes)

        if prefs['show_date_time']:
            self._dateTimeFrame.show()
        else:
            self._dateTimeFrame.hide()

    def _auto_set_date(self):
        prevScId = self._ui.tv.prev_node(self._elementId)
        if not prevScId:
            return

        newDate, newTime, newDay = self._mdl.novel.sections[prevScId].get_end_date_time()
        if newTime is None:
            self._ui.show_error(
                _('The previous section has no time set.'),
                title=_('Cannot generate date/time')
                )
            return

        self._element.date = newDate
        self._element.time = newTime
        self._element.day = newDay
        self._startDate.set(newDate)
        self._startTime.set(newTime.rsplit(':', 1)[0])
        self._startDay.set(newDay)

    def _auto_set_duration(self):

        def day_to_date(day, refDate):
            deltaDays = timedelta(days=int(day))
            return date.isoformat(refDate + deltaDays)

        nextScId = self._ui.tv.next_node(self._elementId)
        if not nextScId:
            return

        thisTimeIso = self._element.time
        if not thisTimeIso:
            self._ui.show_error(
                _('This section has no time set.'),
                title=_('Cannot generate duration')
                )
            return

        nextTimeIso = self._mdl.novel.sections[nextScId].time
        if not nextTimeIso:
            self._ui.show_error(
                _('The next section has no time set.'),
                title=_('Cannot generate duration')
                )
            return

        try:
            refDateIso = self._mdl.novel.referenceDate
            refDate = date.fromisoformat(refDateIso)
        except:
            refDate = date.today()
            refDateIso = date.isoformat(refDate)
        if self._mdl.novel.sections[nextScId].date:
            nextDateIso = self._mdl.novel.sections[nextScId].date
        elif self._mdl.novel.sections[nextScId].day:
            nextDateIso = day_to_date(self._mdl.novel.sections[nextScId].day, refDate)
        elif self._element.day:
            nextDateIso = self._element.day
        else:
            nextDateIso = refDateIso
        if self._element.date:
            thisDateIso = self._element.date
        elif self._element.day:
            thisDateIso = day_to_date(self._element.day, refDate)
        else:
            thisDateIso = nextDateIso

        StartDateTime = datetime.fromisoformat(f'{thisDateIso}T{thisTimeIso}')
        endDateTime = datetime.fromisoformat(f'{nextDateIso}T{nextTimeIso}')
        sectionDuration = endDateTime - StartDateTime
        lastsHours = sectionDuration.seconds // 3600
        lastsMinutes = (sectionDuration.seconds % 3600) // 60
        if sectionDuration.days:
            newDays = str(sectionDuration.days)
        else:
            newDays = None
        if lastsHours:
            newHours = str(lastsHours)
        else:
            newHours = None
        if lastsMinutes:
            newMinutes = str(lastsMinutes)
        else:
            newMinutes = None

        self.doNotUpdate = True
        self._element.lastsDays = newDays
        self._element.lastsHours = newHours
        self._element.lastsMinutes = newMinutes
        self.doNotUpdate = False
        self._lastsDays.set(newDays)
        self._lastsHours.set(newHours)
        self._lastsMinutes.set(newMinutes)

    def _clear_duration(self):
        durationData = [
            self._element.lastsDays,
            self._element.lastsHours,
            self._element.lastsMinutes,
            ]
        hasData = False
        for dataElement in durationData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(_('Clear duration from this section?')):
            self._element.lastsDays = None
            self._element.lastsHours = None
            self._element.lastsMinutes = None

    def _clear_start(self):
        startData = [
            self._element.date,
            self._element.time,
            self._element.day,
            ]
        hasData = False
        for dataElement in startData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(_('Clear date/time from this section?')):
            self._element.date = None
            self._element.time = None
            self._element.day = None

    def _show_moonphase(self, event=None):
        if self._element.date is not None:
            now = self._element.date
        else:
            try:
                now = get_specific_date(
                    self._element.day,
                    self._mdl.novel.referenceDate
                    )
            except:
                self._show_missing_date_message()
                return

        self._ui.show_info(
            f'{_("Moon phase")}: '\
            f'{self._mdl.nvService.get_moon_phase_str(now)}',
            title=f'{_("Date")}: {datestr(now)}'
            )

    def _toggle_date(self, event=None):
        if not self._mdl.novel.referenceDate:
            self._show_missing_reference_date_message()
            return

        self.doNotUpdate = True
        if self._element.date:
            self._element.date_to_day(self._mdl.novel.referenceDate)
        elif self._element.day:
            self._element.day_to_date(self._mdl.novel.referenceDate)
        else:
            self._show_missing_date_message()
            return

        self.doNotUpdate = False
        self.set_data(self._elementId)

    def _toggle_date_time_frame(self, event=None):
        if prefs['show_date_time']:
            self._dateTimeFrame.hide()
            prefs['show_date_time'] = False
        else:
            self._dateTimeFrame.show()
            prefs['show_date_time'] = True

from tkinter import ttk


class LabelCombo(ttk.Frame):

    def __init__(self, parent, text, textvariable, values, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self.combo = ttk.Combobox(self, textvariable=textvariable, values=values)
        self.combo.pack(side='left', fill='x', expand=True)

    def current(self):
        return self.combo.current()

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None, values=None, state=None):
        if text is not None:
            self._label['text'] = text
        if values is not None:
            self.combo['values'] = values
        if state is not None:
            self.combo.config(state=state)


class FullSectionView(DatedSectionView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._viewpoint = MyStringVar()
        self._characterCombobox = LabelCombo(
            self._sectionExtraFrame,
            text=_('Viewpoint'),
            textvariable=self._viewpoint,
            values=[],
            )
        self._characterCombobox.pack(anchor='w', pady=2)
        inputWidgets.append(self._characterCombobox)
        self._characterCombobox.combo.bind('<<ComboboxSelected>>', self.apply_changes)
        self._vpList = []

        self._isUnused = tk.BooleanVar()
        self._isUnusedCheckbox = ttk.Checkbutton(
            self._sectionExtraFrame,
            text=_('Unused'),
            variable=self._isUnused,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._isUnusedCheckbox.pack(anchor='w')
        inputWidgets.append(self._isUnusedCheckbox)

        self._appendToPrev = tk.BooleanVar()
        self._appendToPrevCheckbox = ttk.Checkbutton(
            self._sectionExtraFrame,
            text=_('Append to previous section'),
            variable=self._appendToPrev,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._appendToPrevCheckbox.pack(anchor='w')
        inputWidgets.append(self._appendToPrevCheckbox)

        ttk.Separator(self._sectionExtraFrame, orient='horizontal').pack(fill='x')

        self._plotFrame = FoldingFrame(self._sectionExtraFrame, _('Plot'), self._toggle_plot_frame)

        self._plotlineTitles = ''
        self._plotlineLabel = ttk.Label(self._plotFrame, text=_('Plot lines'))
        self._plotlineLabel.pack(anchor='w')
        self._plotlineCollection = CollectionBox(
            self._plotFrame,
            cmdAdd=self._pick_plotline,
            cmdRemove=self._remove_plotline,
            cmdOpen=self._go_to_arc,
            cmdActivate=self._activate_arc_buttons,
            cmdSelect=self._on_select_plotline,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._plotlineCollection.pack(fill='x')
        inputWidgets.extend(self._plotlineCollection.inputWidgets)
        self._selectedPlotline = None

        ttk.Label(self._plotFrame, text=_('Notes on the selected plot line')).pack(anchor='w')
        self._plotNotesWindow = TextBox(
            self._plotFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._plotNotesWindow.pack(fill='x')
        inputWidgets.append(self._plotNotesWindow)

        ttk.Label(self._plotFrame, text=_('Plot points')).pack(anchor='w')
        self._plotPointsDisplay = tk.Label(self._plotFrame, anchor='w', bg='white')
        self._plotPointsDisplay.pack(anchor='w', fill='x')

        ttk.Separator(self._sectionExtraFrame, orient='horizontal').pack(fill='x')

        self._sceneFrame = FoldingFrame(self._sectionExtraFrame, _('Scene'), self._toggle_scene_frame)

        selectionFrame = ttk.Frame(self._sceneFrame)
        self._customPlotProgress = ''
        self._customCharacterization = ''
        self._customWorldBuilding = ''
        self._customGoal = ''
        self._customConflict = ''
        self._customOutcome = ''
        self._scene = tk.IntVar()

        self._notApplicableRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Not a scene'),
            variable=self._scene,
            value=0, command=self._set_not_applicable,
            )
        self._notApplicableRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._notApplicableRadiobutton)

        self._actionRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Action'),
            variable=self._scene,
            value=1, command=self._set_action_scene,
            )
        self._actionRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._actionRadiobutton)

        self._reactionRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Reaction'),
            variable=self._scene,
            value=2,
            command=self._set_reaction_scene,
            )
        self._reactionRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._reactionRadiobutton)

        self._customRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Other'),
            variable=self._scene,
            value=3,
            command=self._set_custom_scene
            )
        self._customRadiobutton.pack(anchor='w')
        inputWidgets.append(self._customRadiobutton)

        selectionFrame.pack(fill='x')

        self._goalLabel = ttk.Label(self._sceneFrame)
        self._goalLabel.pack(anchor='w')
        self._goalWindow = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._goalWindow.pack(fill='x')
        inputWidgets.append(self._goalWindow)

        self._conflictLabel = ttk.Label(self._sceneFrame)
        self._conflictLabel.pack(anchor='w')
        self._conflictWindow = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._conflictWindow.pack(fill='x')
        inputWidgets.append(self._conflictWindow)

        self._outcomeLabel = ttk.Label(self._sceneFrame)
        self._outcomeLabel.pack(anchor='w')
        self._outcomeWindow = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._outcomeWindow.pack(fill='x')
        inputWidgets.append(self._outcomeWindow)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

    def apply_changes(self, event=None):
        super().apply_changes()

        option = self._characterCombobox.current()
        if option >= 0:
            vpId = self._vpList[option]
            scCharacters = self._element.characters
            if scCharacters:
                    if vpId in scCharacters:
                        scCharacters.remove(vpId)
                    scCharacters.insert(0, vpId)
            else:
                scCharacters = [vpId]
            self._element.characters = scCharacters

        if self._isUnused.get():
            self._element.scType = 1
        else:
            self._element.scType = 0

        self._element.appendToPrev = self._appendToPrev.get()

        self._save_plot_notes()

        if self._goalWindow.hasChanged:
            self._element.goal = self._goalWindow.get_text()
        if self._conflictWindow.hasChanged:
            self._element.conflict = self._conflictWindow.get_text()

        if self._outcomeWindow.hasChanged:
            self._element.outcome = self._outcomeWindow.get_text()

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        charNames = []
        self._vpList = []
        for crId in self._mdl.novel.tree.get_children(CR_ROOT):
            charNames.append(self._mdl.novel.characters[crId].title)
            self._vpList.append(crId)
        self._characterCombobox.configure(values=charNames)
        if self._element.characters:
            vp = self._mdl.novel.characters[self._element.characters[0]].title
        else:
            vp = ''
        self._viewpoint.set(value=vp)

        self._plotlineTitles = self._get_plotline_titles(self._element.scPlotLines, self._mdl.novel.plotLines)
        self._plotlineCollection.cList.set(self._plotlineTitles)
        listboxSize = len(self._plotlineTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._plotlineCollection.cListbox.config(height=listboxSize)
        if not self._plotlineCollection.cListbox.curselection() or not self._plotlineCollection.cListbox.focus_get():
            self._plotlineCollection.disable_buttons()

        self._plotNotesWindow.clear()
        self._plotNotesWindow.config(state='disabled')
        self._plotNotesWindow.config(bg='light gray')
        if self._plotlineTitles:
            self._plotlineCollection.cListbox.select_clear(0, 'end')
            self._plotlineCollection.cListbox.select_set('end')
            self._selectedPlotline = -1
            self._on_select_plotline(-1)
        else:
            self._selectedPlotline = None

        plotPointTitles = []
        for ppId in self._element.scPlotPoints:
            plId = self._element.scPlotPoints[ppId]
            plotPointTitles.append(f'{self._mdl.novel.plotLines[plId].shortName}: {self._mdl.novel.plotPoints[ppId].title}')
        self._plotPointsDisplay.config(text=list_to_string(plotPointTitles))

        if self._element.scType > 0:
            self._isUnused.set(True)
        else:
            self._isUnused.set(False)

        if self._element.appendToPrev:
            self._appendToPrev.set(True)
        else:
            self._appendToPrev.set(False)

        if self._mdl.novel.customPlotProgress:
            self._customPlotProgress = self._mdl.novel.customPlotProgress
        else:
            self._customPlotProgress = ''

        if self._mdl.novel.customCharacterization:
            self._customCharacterization = self._mdl.novel.customCharacterization
        else:
            self._customCharacterization = ''

        if self._mdl.novel.customWorldBuilding:
            self._customWorldBuilding = self._mdl.novel.customWorldBuilding
        else:
            self._customWorldBuilding = ''

        if self._mdl.novel.customGoal:
            self._customGoal = self._mdl.novel.customGoal
        else:
            self._customGoal = ''

        if self._mdl.novel.customConflict:
            self._customConflict = self._mdl.novel.customConflict
        else:
            self._customConflict = ''

        if self._mdl.novel.customOutcome:
            self._customOutcome = self._mdl.novel.customOutcome
        else:
            self._customOutcome = ''

        if prefs['show_plot']:
            self._plotFrame.show()
        else:
            self._plotFrame.hide()

        if prefs['show_scene']:
            self._sceneFrame.show()
        else:
            self._sceneFrame.hide()

        self._scene.set(self._element.scene)

        self._goalWindow.set_text(self._element.goal)

        self._conflictWindow.set_text(self._element.conflict)

        self._outcomeWindow.set_text(self._element.outcome)

        if self._element.scene == 3:
            self._set_custom_scene()
        elif self._element.scene == 2:
            self._set_reaction_scene()
        elif self._element.scene == 1:
            self._set_action_scene()
        else:
            self._set_not_applicable()

    def unlock(self):
        super().unlock()
        if self._selectedPlotline is None:
            self._plotNotesWindow.config(state='disabled')

    def _activate_arc_buttons(self, event=None):
        if self._element.scPlotLines:
            self._plotlineCollection.enable_buttons()
        else:
            self._plotlineCollection.disable_buttons()

    def _add_plotline(self, event=None):
        plotlineList = self._element.scPlotLines
        plId = self._ui.tv.tree.selection()[0]
        if plId.startswith(PLOT_LINE_PREFIX) and not plId in plotlineList:
            plotlineList.append(plId)
            self._element.scPlotLines = plotlineList
            plotlineSections = self._mdl.novel.plotLines[plId].sections
            if not self._elementId in plotlineSections:
                plotlineSections.append(self._elementId)
                self._mdl.novel.plotLines[plId].sections = plotlineSections


    def _get_plotline_titles(self, elemIds, elements):
        elemTitles = []
        if elemIds:
            for elemId in elemIds:
                try:
                    elemTitles.append(f'({elements[elemId].shortName}) {elements[elemId].title}')
                except:
                    pass
        return elemTitles

    def _get_relation_id_list(self, newTitleStr, oldTitleStr, elements):
        if newTitleStr or oldTitleStr:
            if oldTitleStr != newTitleStr:
                elemIds = []
                for elemTitle in string_to_list(newTitleStr):
                    for elemId in elements:
                        if elements[elemId].title == elemTitle:
                            elemIds.append(elemId)
                            break
                    else:
                        self._ui.show_error(f'{_("Wrong name")}: "{elemTitle}"', title=_('Input rejected'))
                return elemIds

        return None

    def _go_to_arc(self, event=None):
        try:
            selection = self._plotlineCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.scPlotLines[selection])

    def _on_select_plotline(self, selection):
        self._save_plot_notes()
        self._selectedPlotline = self._element.scPlotLines[selection]
        self._plotNotesWindow.config(state='normal')
        if self._element.plotlineNotes:
            self._plotNotesWindow.set_text(self._element.plotlineNotes.get(self._selectedPlotline, ''))
        else:
            self._plotNotesWindow.clear()
        if self._isLocked:
            self._plotNotesWindow.config(state='disabled')
        self._plotNotesWindow.config(bg='white')

    def _pick_plotline(self, event=None):
        self._start_picking_mode(command=self._add_plotline)
        self._ui.tv.see_node(PL_ROOT)

    def _remove_plotline(self, event=None):
        try:
            selection = self._plotlineCollection.cListbox.curselection()[0]
        except:
            return

        plId = self._element.scPlotLines[selection]
        title = self._mdl.novel.plotLines[plId].title
        if not self._ui.ask_yes_no(f'{_("Remove plot line")}: "{title}"?'):
            return

        arcList = self._element.scPlotLines
        del arcList[selection]
        self._element.scPlotLines = arcList

        arcSections = self._mdl.novel.plotLines[plId].sections
        if self._elementId in arcSections:
            arcSections.remove(self._elementId)
            self._mdl.novel.plotLines[plId].sections = arcSections

            for ppId in list(self._element.scPlotPoints):
                if self._element.scPlotPoints[ppId] == plId:
                    del(self._element.scPlotPoints[ppId])
                    self._mdl.novel.plotPoints[ppId].sectionAssoc = None

    def _save_plot_notes(self):
        if self._selectedPlotline and self._plotNotesWindow.hasChanged:
            plotlineNotes = self._element.plotlineNotes
            if plotlineNotes is None:
                plotlineNotes = {}
            plotlineNotes[self._selectedPlotline] = self._plotNotesWindow.get_text()
            self.doNotUpdate = True
            self._element.plotlineNotes = plotlineNotes
            self.doNotUpdate = False

    def _set_action_scene(self, event=None):
        self._goalLabel.config(text=_('Goal'))
        self._conflictLabel.config(text=_('Conflict'))
        self._outcomeLabel.config(text=_('Outcome'))
        self._element.scene = self._scene.get()

    def _set_custom_scene(self, event=None):
        if self._customGoal:
            self._goalLabel.config(text=self._customGoal)
        else:
            self._goalLabel.config(text=_('Opening'))

        if self._customConflict:
            self._conflictLabel.config(text=self._customConflict)
        else:
            self._conflictLabel.config(text=_('Peak emotional moment'))

        if self._customOutcome:
            self._outcomeLabel.config(text=self._customOutcome)
        else:
            self._outcomeLabel.config(text=_('Ending'))

        self._element.scene = self._scene.get()

    def _set_not_applicable(self, event=None):
        if self._customPlotProgress:
            self._goalLabel.config(text=self._customPlotProgress)
        else:
            self._goalLabel.config(text=_('Plot progress'))

        if self._customCharacterization:
            self._conflictLabel.config(text=self._customCharacterization)
        else:
            self._conflictLabel.config(text=_('Characterization'))

        if self._customWorldBuilding:
            self._outcomeLabel.config(text=self._customWorldBuilding)
        else:
            self._outcomeLabel.config(text=_('World building'))

        self._element.scene = self._scene.get()

    def _set_reaction_scene(self, event=None):
        self._goalLabel.config(text=_('Reaction'))
        self._conflictLabel.config(text=_('Dilemma'))
        self._outcomeLabel.config(text=_('Choice'))
        self._element.scene = self._scene.get()

    def _toggle_plot_frame(self, event=None):
        if prefs['show_plot']:
            self._plotFrame.hide()
            prefs['show_plot'] = False
        else:
            self._plotFrame.show()
            prefs['show_plot'] = True

    def _toggle_scene_frame(self, event=None):
        if prefs['show_scene']:
            self._sceneFrame.hide()
            prefs['show_scene'] = False
        else:
            self._sceneFrame.show()
            prefs['show_scene'] = True



class ItemView(WorldElementView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_it_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.items[elementId]
        super().set_data(elementId)


class LocationView(WorldElementView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_lc_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.locations[elementId]
        super().set_data(elementId)


class NoView(BasicView):

    def focus_title(self):
        pass

    def set_data(self, elementId):
        super().set_data(elementId)

    def _create_frames(self):
        pass
from datetime import date
from tkinter import ttk

from tkinter import ttk


class LabelDisp(ttk.Frame):

    def __init__(self, parent, text, textvariable, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._leftLabel = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._leftLabel.pack(side='left')
        self._rightLabel = ttk.Label(self, textvariable=textvariable, anchor='w')
        self._rightLabel.pack(side='left', fill='x', expand=True)

    def configure(self, text=None):
        if text is not None:
            self._leftLabel['text'] = text


class ProjectView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._authorName = MyStringVar()
        self._authorNameEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Author'),
            textvariable=self._authorName,
            command=self.apply_changes,
            lblWidth=20
            )
        self._authorNameEntry.pack(anchor='w')
        inputWidgets.append(self._authorNameEntry)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._languageFrame = FoldingFrame(self._elementInfoWindow, _('Document language'), self._toggle_language_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._languageCode = MyStringVar()
        self._languageCodeEntry = LabelEntry(
            self._languageFrame,
            text=_('Language code'),
            textvariable=self._languageCode,
            command=self.apply_changes,
            lblWidth=20
            )
        self._languageCodeEntry.pack(anchor='w')
        inputWidgets.append(self._languageCodeEntry)

        self._countryCode = MyStringVar()
        self._countryCodeEntry = LabelEntry(
            self._languageFrame,
            text=_('Country code'),
            textvariable=self._countryCode,
            command=self.apply_changes,
            lblWidth=20
            )
        self._countryCodeEntry.pack(anchor='w')
        inputWidgets.append(self._countryCodeEntry)

        self._numberingFrame = FoldingFrame(self._elementInfoWindow, _('Auto numbering'), self._toggle_numbering_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._renumberChapters = tk.BooleanVar(value=False)
        self._renumberChaptersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Auto number chapters when refreshing the tree'),
            variable=self._renumberChapters,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._renumberChaptersCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberChaptersCheckbox)

        self._chapterHeadingPrefix = MyStringVar()
        self._chapterHeadingPrefixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Chapter number prefix'),
            textvariable=self._chapterHeadingPrefix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._chapterHeadingPrefixEntry.pack(anchor='w')
        inputWidgets.append(self._chapterHeadingPrefixEntry)

        self._chapterHeadingSuffix = MyStringVar()
        self._chapterHeadingSuffixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Chapter number suffix'),
            textvariable=self._chapterHeadingSuffix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._chapterHeadingSuffixEntry.pack(anchor='w')
        inputWidgets.append(self._chapterHeadingSuffixEntry)

        self._romanChapterNumbers = tk.BooleanVar()
        self._romanChapterNumbersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Use Roman chapter numbers'),
            variable=self._romanChapterNumbers,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._romanChapterNumbersCheckbox.pack(anchor='w')
        inputWidgets.append(self._romanChapterNumbersCheckbox)

        self._renumberWithinParts = tk.BooleanVar()
        self._renumberWithinPartsCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Restart chapter numbering at part beginning'),
            variable=self._renumberWithinParts,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._renumberWithinPartsCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberWithinPartsCheckbox)

        self._renumberParts = tk.BooleanVar()
        self._renumberPartsCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Auto number parts when refreshing the tree'),
            variable=self._renumberParts,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._renumberPartsCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberPartsCheckbox)

        self._partHeadingPrefix = MyStringVar()
        self._partHeadingPrefixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Part number prefix'),
            textvariable=self._partHeadingPrefix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._partHeadingPrefixEntry.pack(anchor='w')
        inputWidgets.append(self._partHeadingPrefixEntry)

        self._partHeadingSuffix = MyStringVar()
        self._partHeadingSuffixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Part number suffix'),
            textvariable=self._partHeadingSuffix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._partHeadingSuffixEntry.pack(anchor='w')
        inputWidgets.append(self._partHeadingSuffixEntry)

        self._romanPartNumbers = tk.BooleanVar()
        self._romanPartNumbersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Use Roman part numbers'),
            variable=self._romanPartNumbers,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._romanPartNumbersCheckbox.pack(anchor='w')
        inputWidgets.append(self._romanPartNumbersCheckbox)

        self._renamingsFrame = FoldingFrame(self._elementInfoWindow, _('Renamings'), self._toggle_renamings_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')
        ttk.Label(self._renamingsFrame, text=_('Not a scene')).pack(anchor='w')

        self._customPlotProgress = MyStringVar()
        self._customPlotProgressEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Plot progress'),
            textvariable=self._customPlotProgress,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customPlotProgressEntry.pack(anchor='w')
        inputWidgets.append(self._customPlotProgressEntry)

        self._customCharacterization = MyStringVar()
        self._customCharacterizationEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Characterization'),
            textvariable=self._customCharacterization,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customCharacterizationEntry.pack(anchor='w')
        inputWidgets.append(self._customCharacterizationEntry)

        self._customWorldBuilding = MyStringVar()
        self.__customWorldBuildingEntry = LabelEntry(
            self._renamingsFrame,
            text=_('World building'),
            textvariable=self._customWorldBuilding,
            command=self.apply_changes,
            lblWidth=20
            )
        self.__customWorldBuildingEntry.pack(anchor='w')
        inputWidgets.append(self.__customWorldBuildingEntry)

        ttk.Separator(self._renamingsFrame, orient='horizontal').pack(fill='x', pady=5)
        ttk.Label(self._renamingsFrame, text=_('Other scene')).pack(anchor='w')

        self._customGoal = MyStringVar()
        self._customGoalEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Opening'),
            textvariable=self._customGoal,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customGoalEntry.pack(anchor='w')
        inputWidgets.append(self._customGoalEntry)

        self._customConflict = MyStringVar()
        self._customConflictEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Peak em. moment'),
            textvariable=self._customConflict,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customConflictEntry.pack(anchor='w')
        inputWidgets.append(self._customConflictEntry)

        self._customOutcome = MyStringVar()
        self._customOutcomeEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Ending'),
            textvariable=self._customOutcome,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customOutcomeEntry.pack(anchor='w')
        inputWidgets.append(self._customOutcomeEntry)

        ttk.Separator(self._renamingsFrame, orient='horizontal').pack(fill='x', pady=5)
        ttk.Label(self._renamingsFrame, text=_('Character')).pack(anchor='w')

        self._customChrBio = MyStringVar()
        self._customChrBioEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Bio'),
            textvariable=self._customChrBio,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customChrBioEntry.pack(anchor='w')
        inputWidgets.append(self._customChrBioEntry)

        self._customChrGoals = MyStringVar()
        self._customChrGoalsEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Goals'),
            textvariable=self._customChrGoals,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customChrGoalsEntry.pack(anchor='w')
        inputWidgets.append(self._customChrGoalsEntry)

        self._narrativeTimeFrame = FoldingFrame(self._elementInfoWindow, _('Narrative time'), self._toggle_narrative_time_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._referenceDate = MyStringVar()
        self._referenceDateEntry = LabelEntry(
            self._narrativeTimeFrame,
            text=_('Reference date'),
            textvariable=self._referenceDate,
            command=self.apply_changes,
            lblWidth=20
            )
        self._referenceDateEntry.pack(anchor='w')
        inputWidgets.append(self._referenceDateEntry)

        localeDateFrame = ttk.Frame(self._narrativeTimeFrame)
        localeDateFrame.pack(fill='x')
        ttk.Label(localeDateFrame, width=20).pack(side='left')
        self._referenceWeekDay = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._referenceWeekDay).pack(side='left')
        self._localeDate = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._localeDate).pack(anchor='w')

        self._datesToDaysButton = ttk.Button(self._narrativeTimeFrame, text=_('Convert dates to days'), command=self._dates_to_days)
        self._datesToDaysButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._datesToDaysButton)

        self._daysToDatesButton = ttk.Button(self._narrativeTimeFrame, text=_('Convert days to dates'), command=self._days_to_dates)
        self._daysToDatesButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._daysToDatesButton)

        self._progressFrame = FoldingFrame(self._elementInfoWindow, _('Writing progress'), self._toggle_progress_frame)

        self._saveWordCount = tk.BooleanVar()
        self._saveWordCountEntry = ttk.Checkbutton(
            self._progressFrame,
            text=_('Log writing progress'),
            variable=self._saveWordCount,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._saveWordCountEntry.pack(anchor='w')
        inputWidgets.append(self._saveWordCountEntry)

        ttk.Separator(self._progressFrame, orient='horizontal').pack(fill='x')

        self._wordTarget = tk.IntVar()
        self._wordTargetEntry = LabelEntry(
            self._progressFrame,
            text=_('Words to write'),
            textvariable=self._wordTarget,
            command=self.apply_changes,
            lblWidth=20
            )
        self._wordTargetEntry.pack(anchor='w')
        inputWidgets.append(self._wordTargetEntry)

        self._wordCountStart = tk.IntVar()
        self._wordCountStartEntry = LabelEntry(
            self._progressFrame,
            text=_('Starting count'),
            textvariable=self._wordCountStart,
            command=self.apply_changes,
            lblWidth=20
            )
        self._wordCountStartEntry.pack(anchor='w')
        inputWidgets.append(self._wordCountStartEntry)

        self._setInitialWcButton = ttk.Button(self._progressFrame, text=_('Set actual wordcount as start'), command=self._set_initial_wc)
        self._setInitialWcButton.pack(pady=2)
        inputWidgets.append(self._setInitialWcButton)

        self._wordsWritten = MyStringVar()
        self._wordTarget.trace_add('write', self._update_words_written)
        self._wordCountStart.trace_add('write', self._update_words_written)
        LabelDisp(self._progressFrame, text=_('Words written'),
                  textvariable=self._wordsWritten, lblWidth=20).pack(anchor='w')

        ttk.Separator(self._progressFrame, orient='horizontal').pack(fill='x')

        self._totalUsed = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Used'), textvariable=self._totalUsed, lblWidth=20).pack(anchor='w')
        self._totalOutline = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Outline'), textvariable=self._totalOutline, lblWidth=20).pack(anchor='w')
        self._totalDraft = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Draft'), textvariable=self._totalDraft, lblWidth=20).pack(anchor='w')
        self._total1stEdit = MyStringVar()
        LabelDisp(self._progressFrame, text=_('1st Edit'), textvariable=self._total1stEdit, lblWidth=20).pack(anchor='w')
        self._total2ndEdit = MyStringVar()
        LabelDisp(self._progressFrame, text=_('2nd Edit'), textvariable=self._total2ndEdit, lblWidth=20).pack(anchor='w')
        self._totalDone = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Done'), textvariable=self._totalDone, lblWidth=20).pack(anchor='w')
        self._totalUnused = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Unused'), textvariable=self._totalUnused, lblWidth=20).pack(anchor='w')
        self._totalWords = MyStringVar()
        LabelDisp(self._progressFrame, text=_('All'), textvariable=self._totalWords, lblWidth=20).pack(anchor='w')

        self._phase = MyStringVar()
        self._phaseCombobox = LabelCombo(self._progressFrame, lblWidth=20, text=_('Work phase'), textvariable=self._phase, values=[])
        self._phaseCombobox.pack(anchor='w')
        inputWidgets.append(self._phaseCombobox)
        self._phaseCombobox.bind('<Return>', self.apply_changes)

        self._coverFile = None

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pr_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        authorName = self._authorName.get()
        if authorName:
            authorName = authorName.strip()
        self._element.authorName = authorName

        self._element.languageCode = self._languageCode.get()
        self._element.countryCode = self._countryCode.get()

        self._element.renumberChapters = self._renumberChapters.get()
        self._element.renumberParts = self._renumberParts.get()
        self._element.renumberWithinParts = self._renumberWithinParts.get()
        self._element.romanChapterNumbers = self._romanChapterNumbers.get()
        self._element.romanPartNumbers = self._romanPartNumbers.get()
        self._element.saveWordCount = self._saveWordCount.get()

        self._element.chapterHeadingPrefix = self._chapterHeadingPrefix.get()
        self._element.chapterHeadingSuffix = self._chapterHeadingSuffix.get()
        self._element.partHeadingPrefix = self._partHeadingPrefix.get()
        self._element.partHeadingSuffix = self._partHeadingSuffix.get()
        self._element.customPlotProgress = self._customPlotProgress.get()
        self._element.customCharacterization = self._customCharacterization.get()
        self._element.customWorldBuilding = self._customWorldBuilding.get()
        self._element.customGoal = self._customGoal.get()
        self._element.customConflict = self._customConflict.get()
        self._element.customOutcome = self._customOutcome.get()
        self._element.customChrBio = self._customChrBio.get()
        self._element.customChrGoals = self._customChrGoals.get()

        refDateStr = self._referenceDate.get()
        if not refDateStr:
            self._element.referenceDate = None
            self._referenceWeekDay.set('')
            self._localeDate.set('')
        elif refDateStr != self._element.referenceDate:
            try:
                date.fromisoformat(refDateStr)
            except ValueError:
                self._referenceDate.set(self._element.referenceDate)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{refDateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.referenceDate = refDateStr
                if self._element.referenceWeekDay is not None:
                    self._referenceWeekDay.set(WEEKDAYS[self._element.referenceWeekDay])
                else:
                    self._referenceWeekDay.set('')
                    self._localeDate.set('')

        try:
            entry = self._wordTarget.get()
            if self._element.wordTarget or entry:
                if self._element.wordTarget != entry:
                    self._element.wordTarget = entry
        except:
            pass
        try:
            entry = self._wordCountStart.get()
            if self._element.wordCountStart or entry:
                if self._element.wordCountStart != entry:
                    self._element.wordCountStart = entry
        except:
            pass

        if not self._phaseCombobox.current():
            entry = None
        else:
            entry = self._phaseCombobox.current()
        self._element.workPhase = entry

    def set_data(self, elementId):
        self._element = self._mdl.novel
        super().set_data(elementId)

        self._authorName.set(self._element.authorName)

        if prefs['show_language_settings']:
            self._languageFrame.show()
        else:
            self._languageFrame.hide()

        self._languageCode.set(self._element.languageCode)

        self._countryCode.set(self._element.countryCode)

        if prefs['show_auto_numbering']:
            self._numberingFrame.show()
        else:
            self._numberingFrame.hide()

        if self._element.renumberChapters:
            self._renumberChapters.set(True)
        else:
            self._renumberChapters.set(False)

        self._chapterHeadingPrefix.set(self._element.chapterHeadingPrefix)

        self._chapterHeadingSuffix = MyStringVar(value=self._element.chapterHeadingSuffix)

        if self._element.romanChapterNumbers:
            self._romanChapterNumbers.set(True)
        else:
            self._romanChapterNumbers.set(False)

        if self._element.renumberWithinParts:
            self._renumberWithinParts.set(True)
        else:
            self._renumberWithinParts.set(False)

        if self._element.renumberParts:
            self._renumberParts.set(True)
        else:
            self._renumberParts.set(False)

        self._partHeadingPrefix.set(self._element.partHeadingPrefix)

        self._partHeadingSuffix.set(self._element.partHeadingSuffix)

        if self._element.romanPartNumbers:
            self._romanPartNumbers.set(True)
        else:
            self._romanPartNumbers.set(False)

        if prefs['show_renamings']:
            self._renamingsFrame.show()
        else:
            self._renamingsFrame.hide()

        self._customPlotProgress.set(self._element.customPlotProgress)
        self._customCharacterization.set(self._element.customCharacterization)
        self._customWorldBuilding.set(self._element.customWorldBuilding)
        self._customGoal.set(self._element.customGoal)
        self._customConflict.set(self._element.customConflict)
        self._customOutcome.set(self._element.customOutcome)
        self._customChrBio.set(self._element.customChrBio)
        self._customChrGoals.set(self._element.customChrGoals)

        if prefs['show_narrative_time']:
            self._narrativeTimeFrame.show()
        else:
            self._narrativeTimeFrame.hide()

        if self._element.referenceDate and self._element.referenceWeekDay is not None:
            self._referenceWeekDay.set(
                WEEKDAYS[self._element.referenceWeekDay]
                )
            self._localeDate.set(
                datestr(self._element.referenceDate)
                )
        else:
            self._referenceWeekDay.set('')
            self._localeDate.set('')
        self._referenceDate.set(self._element.referenceDate)

        if prefs['show_writing_progress']:
            self._progressFrame.show()
        else:
            self._progressFrame.hide()

        if self._element.saveWordCount:
            self._saveWordCount.set(True)
        else:
            self._saveWordCount.set(False)

        if self._element.wordTarget is not None:
            self._wordTarget.set(self._element.wordTarget)
        else:
            self._wordTarget.set(0)

        if self._element.wordCountStart is not None:
            self._wordCountStart.set(self._element.wordCountStart)
        else:
            self._wordCountStart.set(0)

        normalWordsTotal, allWordsTotal = self._mdl.prjFile.count_words()
        self._totalWords.set(allWordsTotal)
        self._totalUsed.set(normalWordsTotal)
        self._totalUnused.set(allWordsTotal - normalWordsTotal)
        statusCounts = self._mdl.get_status_counts()
        self._totalOutline.set(statusCounts[1])
        self._totalDraft.set(statusCounts[2])
        self._total1stEdit.set(statusCounts[3])
        self._total2ndEdit.set(statusCounts[4])
        self._totalDone.set(statusCounts[5])

        phases = [_('Undefined'), _('Outline'), _('Draft'), _('1st Edit'), _('2nd Edit'), _('Done')]
        self._phaseCombobox.configure(values=phases)
        try:
            workPhase = int(self._element.workPhase)
        except:
            workPhase = 0
        self._phase.set(value=phases[workPhase])

    def show(self):
        try:
            coverFile = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}.png'
            if self._coverFile != coverFile:
                self._coverFile = coverFile
                coverPic = tk.PhotoImage(file=coverFile)
                self._cover.configure(image=coverPic)
                self._cover.image = coverPic
        except:
            self._cover.configure(image=None)
            self._cover.image = None
        super().show()

    def _set_initial_wc(self):
        self._wordCountStart.set(self._mdl.wordCount)

    def _create_cover_window(self):
        self._cover = tk.Label(self._propertiesFrame)
        self._cover.pack()

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_cover_window()

    def _toggle_language_frame(self, event=None):
        if prefs['show_language_settings']:
            self._languageFrame.hide()
            prefs['show_language_settings'] = False
        else:
            self._languageFrame.show()
            prefs['show_language_settings'] = True

    def _dates_to_days(self):
        buttonText = self._datesToDaysButton['text']
        self._datesToDaysButton['text'] = _('Please wait ...')
        if self._mdl.novel.referenceDate:
            if self._ui.ask_yes_no(_('Convert all section dates to days relative to the reference date?')):
                self.doNotUpdate = True
                for scId in self._mdl.novel.sections:
                    self._mdl.novel.sections[scId].date_to_day(self._mdl.novel.referenceDate)
                self.doNotUpdate = False
        else:
            self._show_missing_reference_date_message()
        self._datesToDaysButton['text'] = buttonText

    def _days_to_dates(self):
        buttonText = self._daysToDatesButton['text']
        self._daysToDatesButton['text'] = _('Please wait ...')
        if self._mdl.novel.referenceDate:
            if self._ui.ask_yes_no(_('Convert all section days to dates using the reference date?')):
                self.doNotUpdate = True
                for scId in self._mdl.novel.sections:
                    self._mdl.novel.sections[scId].day_to_date(self._mdl.novel.referenceDate)
                self.doNotUpdate = False
        else:
            self._show_missing_reference_date_message()
        self._daysToDatesButton['text'] = buttonText

    def _toggle_numbering_frame(self, event=None):
        if prefs['show_auto_numbering']:
            self._numberingFrame.hide()
            prefs['show_auto_numbering'] = False
        else:
            self._numberingFrame.show()
            prefs['show_auto_numbering'] = True

    def _toggle_narrative_time_frame(self, event=None):
        if prefs['show_narrative_time']:
            self._narrativeTimeFrame.hide()
            prefs['show_narrative_time'] = False
        else:
            self._narrativeTimeFrame.show()
            prefs['show_narrative_time'] = True

    def _toggle_progress_frame(self, event=None):
        if prefs['show_writing_progress']:
            self._progressFrame.hide()
            prefs['show_writing_progress'] = False
        else:
            self._progressFrame.show()
            prefs['show_writing_progress'] = True

    def _toggle_renamings_frame(self, event=None):
        if prefs['show_renamings']:
            self._renamingsFrame.hide()
            prefs['show_renamings'] = False
        else:
            self._renamingsFrame.show()
            prefs['show_renamings'] = True

    def _update_words_written(self, n, m, x):
        try:
            ww = self._mdl.wordCount - self._wordCountStart.get()
            wt = self._wordTarget.get()
            try:
                wp = f'({round(100*ww/wt)}%)'
            except ZeroDivisionError:
                wp = ''
            self._wordsWritten.set(f'{ww} {wp}')
        except:
            pass



class ProjectNoteView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_pn_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.projectNotes[elementId]
        super().set_data(elementId)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_button_bar()


class StageView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_st_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()
from tkinter import ttk



class TurningPointView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._lastSelected = ''
        self._treeSelectBinding = None
        self._uiEscBinding = None

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._sectionFrame = ttk.Frame(self._elementInfoWindow)
        self._sectionFrame.pack(anchor='w', fill='x')
        ttk.Label(self._sectionFrame, text=f"{_('Section')}:").pack(anchor='w')
        self.sectionAssocTitle = tk.Label(self._sectionFrame, anchor='w', bg='white')
        self.sectionAssocTitle.pack(anchor='w', pady=2, fill='x')

        self._assignSectionButton = ttk.Button(self._sectionFrame, text=_('Assign section'), command=self._pick_section)
        self._assignSectionButton.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._assignSectionButton)

        self._clearAssignmentButton = ttk.Button(self._sectionFrame, text=_('Clear assignment'), command=self._clear_assignment)
        self._clearAssignmentButton.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._clearAssignmentButton)

        ttk.Button(self._sectionFrame, text=_('Go to section'), command=self._select_assigned_section).pack(side='left', fill='x', expand=True)

        for widget in inputWidgets:
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pp_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.plotPoints[elementId]
        super().set_data(elementId)

        try:
            sectionTitle = self._mdl.novel.sections[self._element.sectionAssoc].title
        except:
            sectionTitle = ''
        self.sectionAssocTitle['text'] = sectionTitle

    def _assign_section(self, event=None):
        nodeId = self._ui.tv.tree.selection()[0]
        if nodeId.startswith(SECTION_PREFIX):
            if self._mdl.novel.sections[nodeId].scType == 0:
                self._clear_assignment()
                plId = self._ui.tv.tree.parent(self._elementId)
                arcSections = self._mdl.novel.plotLines[plId].sections
                if arcSections is None:
                    arcSections = [nodeId]
                elif not nodeId in arcSections:
                    arcSections.append(nodeId)
                self._mdl.novel.plotLines[plId].sections = arcSections
                self._mdl.novel.sections[nodeId].scPlotPoints[self._elementId] = plId
                if not plId in self._mdl.novel.sections[nodeId].scPlotLines:
                    self._mdl.novel.sections[nodeId].scPlotLines.append(plId)
                self._element.sectionAssoc = nodeId

    def _clear_assignment(self):
        scId = self._element.sectionAssoc
        if scId is not None:
            del(self._mdl.novel.sections[scId].scPlotPoints[self._elementId])
            self._element.sectionAssoc = None

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _select_assigned_section(self):
        if self._element.sectionAssoc is not None:
            targetNode = self._element.sectionAssoc
            self._ui.tv.see_node(targetNode)
            self._ui.tv.tree.selection_set(targetNode)

    def _pick_section(self):
        self._start_picking_mode(command=self._assign_section)
        self._ui.tv.see_node(CH_ROOT)



class PropertiesViewer(ttk.Frame):

    def __init__(self, parent, model, view, controller, **kw):
        super().__init__(parent, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._noView = NoView(self, self._mdl, self._ui, self._ctrl)
        self._projectView = ProjectView(self, self._mdl, self._ui, self._ctrl)
        self._chapterView = ChapterView(self, self._mdl, self._ui, self._ctrl)
        self._stageView = StageView(self, self._mdl, self._ui, self._ctrl)
        self._sectionView = FullSectionView(self, self._mdl, self._ui, self._ctrl)
        self._characterView = CharacterView(self, self._mdl, self._ui, self._ctrl)
        self._locationView = LocationView(self, self._mdl, self._ui, self._ctrl)
        self._itemView = ItemView(self, self._mdl, self._ui, self._ctrl)
        self._arcView = PlotLineView(self, self._mdl, self._ui, self._ctrl)
        self._plotPointView = TurningPointView(self, self._mdl, self._ui, self._ctrl)
        self._projectnoteView = ProjectNoteView(self, self._mdl, self._ui, self._ctrl)
        self._elementView = self._noView
        self._elementView.set_data(None)
        self._elementView.doNotUpdate = False
        self._allViews = [
            self._projectView,
            self._chapterView,
            self._stageView,
            self._sectionView,
            self._characterView,
            self._locationView,
            self._itemView,
            self._arcView,
            self._plotPointView,
            self._projectnoteView,
            ]

    def apply_changes(self, event=None):
        if not self._ctrl.isLocked:
            self._elementView.doNotUpdate = True
            self._elementView.apply_changes()
            self._elementView.doNotUpdate = False

    def focus_title(self):
        self._elementView.focus_title()

    def lock(self):
        for view in self._allViews:
            view.lock()

    def show_properties(self, nodeId):
        if self._mdl is None:
            self._view_nothing()
        elif nodeId.startswith(SECTION_PREFIX):
            self._view_section(nodeId)
        elif nodeId == self._mdl.trashBin:
            self._view_nothing()
        elif nodeId.startswith(CHAPTER_PREFIX):
            self._view_chapter(nodeId)
        elif nodeId.startswith(CH_ROOT):
            self._view_project()
        elif nodeId.startswith(CHARACTER_PREFIX):
            self._view_character(nodeId)
        elif nodeId.startswith(LOCATION_PREFIX):
            self._view_location(nodeId)
        elif nodeId.startswith(ITEM_PREFIX):
            self._view_item(nodeId)
        elif nodeId.startswith(PLOT_LINE_PREFIX):
            self._view_arc(nodeId)
        elif nodeId.startswith(PLOT_POINT_PREFIX):
            self._view_plot_point(nodeId)
        elif nodeId.startswith(PRJ_NOTE_PREFIX):
            self._view_projectnote(nodeId)
        else:
            self._view_nothing()
        self._elementView.doNotUpdate = False

    def unlock(self):
        for view in self._allViews:
            view.unlock()

    def refresh(self):
        if not self._elementView.doNotUpdate:
            try:
                self.show_properties(self._elementView._elementId)
            except:
                pass

    def _set_data(self, elemId):
        if self._ctrl.isLocked:
            self._elementView.unlock()
            self._elementView.set_data(elemId)
            self._elementView.lock()
        else:
            self._elementView.set_data(elemId)

    def _view_arc(self, plId):
        if not self._elementView is self._arcView:
            self._elementView.hide()
            self._elementView = self._arcView
            self._elementView.show()
        self._set_data(plId)

    def _view_chapter(self, chId):
        if not self._elementView is self._chapterView:
            self._elementView.hide()
            self._elementView = self._chapterView
            self._elementView.show()
        self._set_data(chId)

    def _view_character(self, crId):
        if not self._elementView is self._characterView:
            self._elementView.hide()
            self._elementView = self._characterView
            self._elementView.show()
        self._set_data(crId)

    def _view_item(self, itId):
        if not self._elementView is self._itemView:
            self._elementView.hide()
            self._elementView = self._itemView
            self._elementView.show()
        self._set_data(itId)

    def _view_location(self, lcId):
        if not self._elementView is self._locationView:
            self._elementView.hide()
            self._elementView = self._locationView
            self._elementView.show()
        self._set_data(lcId)

    def _view_nothing(self):
        if not self._elementView is self._noView:
            self._elementView.hide()
            self._elementView = self._noView
            self._elementView.show()

    def _view_project(self):
        if not self._elementView is self._projectView:
            self._elementView.hide()
            self._elementView = self._projectView
            self._elementView.show()
        self._set_data(CH_ROOT)

    def _view_projectnote(self, pnId):
        if not self._elementView is self._projectnoteView:
            self._elementView.hide()
            self._elementView = self._projectnoteView
            self._elementView.show()
        self._set_data(pnId)

    def _view_section(self, scId):
        if self._mdl.novel.sections[scId].scType > 1:
            if not self._elementView is self._stageView:
                self._elementView.hide()
                self._elementView = self._stageView
                self._elementView.show()
        else:
            if not self._elementView is self._sectionView:
                self._elementView.hide()
                self._elementView = self._sectionView
                self._elementView.show()
        self._set_data(scId)

    def _view_plot_point(self, ppId):
        if not self._elementView is self._plotPointView:
            self._elementView.hide()
            self._elementView = self._plotPointView
            self._elementView.show()
        self._set_data(ppId)

from tkinter import ttk



class Toolbar:

    def __init__(self, view, controller):
        self._ctrl = controller
        self._ui = view

        self.buttonBar = tk.Frame(self._ui.mainWindow)

        self._goBackButton = ttk.Button(
            self.buttonBar,
            text=_('Back'),
            image=self._ui.icons.goBackIcon,
            command=self._ui.tv.go_back
            )
        self._goBackButton.pack(side='left')
        self._goBackButton.image = self._ui.icons.goBackIcon

        self._goForwardButton = ttk.Button(
            self.buttonBar,
            text=_('Forward'),
            image=self._ui.icons.goForwardIcon,
            command=self._ui.tv.go_forward
            )
        self._goForwardButton.pack(side='left')
        self._goForwardButton.image = self._ui.icons.goForwardIcon

        tk.Frame(self.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._viewBookButton = ttk.Button(
            self.buttonBar,
            text=_('Book'),
            image=self._ui.icons.viewBookIcon,
            command=lambda: self._ui.tv.show_branch(CH_ROOT)
            )
        self._viewBookButton.pack(side='left')
        self._viewBookButton.image = self._ui.icons.viewBookIcon

        self._viewCharactersButton = ttk.Button(
            self.buttonBar,
            text=_('Characters'),
            image=self._ui.icons.viewCharactersIcon,
            command=lambda: self._ui.tv.show_branch(CR_ROOT)
            )
        self._viewCharactersButton.pack(side='left')
        self._viewCharactersButton.image = self._ui.icons.viewCharactersIcon

        self._viewLocationsButton = ttk.Button(
            self.buttonBar,
            text=_('Locations'),
            image=self._ui.icons.viewLocationsIcon,
            command=lambda: self._ui.tv.show_branch(LC_ROOT)
            )
        self._viewLocationsButton.pack(side='left')
        self._viewLocationsButton.image = self._ui.icons.viewLocationsIcon

        self._viewItemsButton = ttk.Button(
            self.buttonBar,
            text=_('Items'),
            image=self._ui.icons.viewItemsIcon,
            command=lambda: self._ui.tv.show_branch(IT_ROOT)
            )
        self._viewItemsButton.pack(side='left')
        self._viewItemsButton.image = self._ui.icons.viewItemsIcon

        self._viewPlotLinesButton = ttk.Button(
            self.buttonBar,
            text=_('Plot lines'),
            image=self._ui.icons.viewPlotLinesIcon,
            command=lambda: self._ui.tv.show_branch(PL_ROOT)
            )
        self._viewPlotLinesButton.pack(side='left')
        self._viewPlotLinesButton.image = self._ui.icons.viewPlotLinesIcon

        self._viewProjectnotesButton = ttk.Button(
            self.buttonBar,
            text=_('Project notes'),
            image=self._ui.icons.viewProjectnotesIcon,
            command=lambda: self._ui.tv.show_branch(PN_ROOT)
            )
        self._viewProjectnotesButton.pack(side='left')
        self._viewProjectnotesButton.image = self._ui.icons.viewProjectnotesIcon

        tk.Frame(self.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._saveButton = ttk.Button(
            self.buttonBar,
            text=_('Save'),
            image=self._ui.icons.saveIcon,
            command=self._ctrl.save_project
            )
        self._saveButton.pack(side='left')
        self._saveButton.image = self._ui.icons.saveIcon

        self._lockButton = ttk.Button(
            self.buttonBar,
            text=_('Lock/unlock'),
            image=self._ui.icons.lockIcon,
            command=self._ctrl.toggle_lock
            )
        self._lockButton.pack(side='left')
        self._lockButton.image = self._ui.icons.lockIcon

        self._updateButton = ttk.Button(
            self.buttonBar,
            text=_('Update from manuscript'),
            image=self._ui.icons.updateFromManuscriptIcon,
            command=lambda: self._ctrl.update_from_odt(suffix=MANUSCRIPT_SUFFIX)
            )
        self._updateButton.pack(side='left')
        self._updateButton.image = self._ui.icons.updateFromManuscriptIcon

        self._manuscriptButton = ttk.Button(
            self.buttonBar,
            text=_('Export Manuscript'),
            image=self._ui.icons.manuscriptIcon,
            command=lambda:self._ctrl.export_document(MANUSCRIPT_SUFFIX, ask=False)
            )
        self._manuscriptButton.pack(side='left')
        self._manuscriptButton.image = self._ui.icons.manuscriptIcon

        tk.Frame(self.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._addElementButton = ttk.Button(
            self.buttonBar,
            text=_('Add'),
            image=self._ui.icons.addIcon,
            command=self._ctrl.add_element
            )
        self._addElementButton.pack(side='left')
        self._addElementButton.image = self._ui.icons.addIcon

        self._addChildButton = ttk.Button(
            self.buttonBar,
            text=_('Add child'),
            image=self._ui.icons.addChildIcon,
            command=self._ctrl.add_child
            )
        self._addChildButton.pack(side='left')
        self._addChildButton.image = self._ui.icons.addChildIcon

        self._addParentButton = ttk.Button(
            self.buttonBar,
            text=_('Add parent'),
            image=self._ui.icons.addParentIcon,
            command=self._ctrl.add_parent
            )
        self._addParentButton.pack(side='left')
        self._addParentButton.image = self._ui.icons.addParentIcon

        self._deleteElementButton = ttk.Button(
            self.buttonBar,
            text=_('Delete'),
            image=self._ui.icons.removeIcon,
            command=self._ctrl.delete_elements
            )
        self._deleteElementButton.pack(side='left')
        self._deleteElementButton.image = self._ui.icons.removeIcon


        self._propertiesButton = ttk.Button(
            self.buttonBar,
            text=_('Toggle Properties'),
            image=self._ui.icons.propertiesIcon,
            command=self._ui.toggle_properties_view
            )
        self._propertiesButton.pack(side='right')
        self._propertiesButton.image = self._ui.icons.propertiesIcon

        self._viewerButton = ttk.Button(
            self.buttonBar,
            text=_('Toggle Text viewer'),
            image=self._ui.icons.viewerIcon,
            command=self._ui.toggle_contents_view
            )
        self._viewerButton.pack(side='right')
        self._viewerButton.image = self._ui.icons.viewerIcon

        self.buttonBar.pack(expand=False, before=self._ui.appWindow, fill='both')
        self._set_hovertips()

    def disable_menu(self):
        self._addChildButton.config(state='disabled')
        self._addElementButton.config(state='disabled')
        self._addParentButton.config(state='disabled')
        self._goBackButton.config(state='disabled')
        self._goForwardButton.config(state='disabled')
        self._lockButton.config(state='disabled')
        self._manuscriptButton.config(state='disabled')
        self._deleteElementButton.config(state='disabled')
        self._saveButton.config(state='disabled')
        self._updateButton.config(state='disabled')
        self._viewBookButton.config(state='disabled')
        self._viewCharactersButton.config(state='disabled')
        self._viewItemsButton.config(state='disabled')
        self._viewLocationsButton.config(state='disabled')
        self._viewPlotLinesButton.config(state='disabled')
        self._viewProjectnotesButton.config(state='disabled')

    def enable_menu(self):
        self._addChildButton.config(state='normal')
        self._addElementButton.config(state='normal')
        self._addParentButton.config(state='normal')
        self._goBackButton.config(state='normal')
        self._goForwardButton.config(state='normal')
        self._lockButton.config(state='normal')
        self._manuscriptButton.config(state='normal')
        self._deleteElementButton.config(state='normal')
        self._saveButton.config(state='normal')
        self._updateButton.config(state='normal')
        self._viewBookButton.config(state='normal')
        self._viewCharactersButton.config(state='normal')
        self._viewItemsButton.config(state='normal')
        self._viewLocationsButton.config(state='normal')
        self._viewPlotLinesButton.config(state='normal')
        self._viewProjectnotesButton.config(state='normal')

    def lock(self):
        self._manuscriptButton.config(state='disabled')
        self._addElementButton.config(state='disabled')
        self._addChildButton.config(state='disabled')
        self._addParentButton.config(state='disabled')
        self._deleteElementButton.config(state='disabled')

    def unlock(self):
        self._manuscriptButton.config(state='normal')
        self._addElementButton.config(state='normal')
        self._addChildButton.config(state='normal')
        self._addParentButton.config(state='normal')
        self._deleteElementButton.config(state='normal')

    def _set_hovertips(self):
        if not prefs['enable_hovertips']:
            return

        try:
            from idlelib.tooltip import Hovertip
        except ModuleNotFoundError:
            return

        Hovertip(self._addChildButton, f"{self._addChildButton['text']} ({KEYS.ADD_CHILD[1]})")
        Hovertip(self._addElementButton, f"{self._addElementButton['text']} ({KEYS.ADD_ELEMENT[1]})")
        Hovertip(self._addParentButton, f"{self._addParentButton['text']} ({KEYS.ADD_PARENT[1]})")
        Hovertip(self._goBackButton, self._goBackButton['text'])
        Hovertip(self._goForwardButton, self._goForwardButton['text'])
        Hovertip(self._lockButton, self._lockButton['text'])
        Hovertip(self._manuscriptButton, self._manuscriptButton['text'])
        Hovertip(self._propertiesButton, f"{self._propertiesButton['text']} ({KEYS.TOGGLE_PROPERTIES[1]})")
        Hovertip(self._saveButton, f"{self._saveButton['text']} ({KEYS.SAVE_PROJECT[1]})")
        Hovertip(self._deleteElementButton, f"{self._deleteElementButton['text']} ({KEYS.DELETE[1]})")
        Hovertip(self._updateButton, self._updateButton['text'])
        Hovertip(self._viewBookButton, self._viewBookButton['text'])
        Hovertip(self._viewCharactersButton, self._viewCharactersButton['text'])
        Hovertip(self._viewItemsButton, self._viewItemsButton['text'])
        Hovertip(self._viewLocationsButton, self._viewLocationsButton['text'])
        Hovertip(self._viewPlotLinesButton, self._viewPlotLinesButton['text'])
        Hovertip(self._viewProjectnotesButton, self._viewProjectnotesButton['text'])
        Hovertip(self._viewerButton, f"{self._viewerButton['text']} ({KEYS.TOGGLE_VIEWER[1]})")

from tkinter import ttk



class HistoryList:

    def __init__(self):
        self._historyList = []
        self._pointer = None
        self._lock = False

    def append_node(self, node):
        if not self._lock:
            try:
                del self._historyList[self._pointer + 1:]
            except:
                pass
            if self._pointer is None or self._historyList[self._pointer] != node:
                self._historyList.append(node)
                self._pointer = len(self._historyList) - 1
        self._lock = False

    def go_back(self):
        if self._pointer is None:
            return None

        if self._pointer > 0:
            self._pointer -= 1
        return self._historyList[self._pointer]

    def go_forward(self):
        if self._pointer is None:
            return None

        if self._pointer + 1 < len(self._historyList):
            self._pointer += 1
        return self._historyList[self._pointer]

    def lock(self):
        self._lock = True

    def reset(self):
        self._historyList = []
        self._pointer = None
        self._lock = False



class ContextMenu(tk.Menu):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.bind('<FocusOut>', self._close)

    def _close(self, event):
        self.unpost()
import tkinter.font as tkFont


class TreeViewer(ttk.Frame):
    COLORING_MODES = [_('None'), _('Status'), _('Work phase')]

    _COLUMNS = dict(
        wc=(_('Words'), 'wc_width'),
        vp=(_('Viewpoint'), 'vp_width'),
        st=(_('Status'), 'status_width'),
        nt=(_('N'), 'nt_width'),
        dt=(_('Date'), 'date_width'),
        tm=(_('Time'), 'time_width'),
        dr=(_('Duration'), 'duration_width'),
        tg=(_('Tags'), 'tags_width'),
        po=(_('Position'), 'ps_width'),
        ac=(_('Plot lines'), 'arcs_width'),
        sc=(_('Scene'), 'scene_width'),
        tp=(_('Plot points'), 'points_width'),
        )

    _ROOT_TITLES = {
        CH_ROOT: _('Book'),
        CR_ROOT: _('Characters'),
        LC_ROOT: _('Locations'),
        IT_ROOT: _('Items'),
        PL_ROOT: _('Plot lines'),
        PN_ROOT: _('Project notes'),
        }

    _SCENE = [
        '-',
        _('A'),
        _('R'),
        'x',
        ]

    _NOTE_INDICATOR = _('N')

    def __init__(self, parent, model, view, controller, kwargs, **kw):
        super().__init__(parent, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._wordsTotal = None
        self.skipUpdate = False

        self.tree = NvTreeview(self)
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.tree.xview)
        scrollY = ttk.Scrollbar(self.tree, orient='vertical', command=self.tree.yview)
        self.tree.configure(xscrollcommand=scrollX.set)
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollX.pack(side='bottom', fill='x')
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)

        self.configure_columns()

        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('root', font=('', fontSize, 'bold'))
        self.tree.tag_configure('chapter', foreground=kwargs['color_chapter'])
        self.tree.tag_configure('arc', font=('', fontSize, 'bold'), foreground=kwargs['color_arc'])
        self.tree.tag_configure('plot_point', foreground=kwargs['color_arc'])
        self.tree.tag_configure('unused', foreground=kwargs['color_unused'])
        self.tree.tag_configure('stage1', font=('', fontSize, 'bold'), foreground=kwargs['color_stage'])
        self.tree.tag_configure('stage2', foreground=kwargs['color_stage'])
        self.tree.tag_configure('part', font=('', fontSize, 'bold'))
        self.tree.tag_configure('major', foreground=kwargs['color_major'])
        self.tree.tag_configure('minor', foreground=kwargs['color_minor'])
        self.tree.tag_configure('status1', foreground=kwargs['color_outline'])
        self.tree.tag_configure('status2', foreground=kwargs['color_draft'])
        self.tree.tag_configure('status3', foreground=kwargs['color_1st_edit'])
        self.tree.tag_configure('status4', foreground=kwargs['color_2nd_edit'])
        self.tree.tag_configure('status5', foreground=kwargs['color_done'])
        self.tree.tag_configure('On_schedule', foreground=kwargs['color_on_schedule'])
        self.tree.tag_configure('Behind_schedule', foreground=kwargs['color_behind_schedule'])
        self.tree.tag_configure('Before_schedule', foreground=kwargs['color_before_schedule'])

        self._history = HistoryList()

        try:
            self.coloringMode = int(prefs['coloring_mode'])
        except:
            self.coloringMode = 0
        if self.coloringMode > len(self.COLORING_MODES):
            self.coloringMode = 0

        self._build_menus()

        self._bind_events(**kwargs)

    def close_children(self, parent):
        self.tree.item(parent, open=False)
        self._update_node_values(parent, collect=True)
        for child in self.tree.get_children(parent):
            self.close_children(child)

    def configure_columns(self):
        self._colPos = {}
        self.columns = []
        titles = []
        srtColumns = string_to_list(prefs['column_order'])

        for coId in self._COLUMNS:
            if not coId in srtColumns:
                srtColumns.append(coId)
        i = 0
        for coId in srtColumns:
            try:
                title, width = self._COLUMNS[coId]
            except:
                continue
            self._colPos[coId] = i
            i += 1
            self.columns.append((coId, title, width))
            titles.append(title)
        self.tree.configure(columns=tuple(titles))
        for column in self.columns:
            self.tree.heading(column[1], text=column[1], anchor='w')
            self.tree.column(column[1], width=int(prefs[column[2]]), minwidth=3, stretch=False)
        self.tree.column('#0', width=int(prefs['title_width']), stretch=False)

    def go_back(self, event=None):
        self._browse_tree(self._history.go_back())

    def go_forward(self, event=None):
        self._browse_tree(self._history.go_forward())

    def see_node(self, node):
        try:
            self.tree.see(node)
            parent = self.tree.parent(node)
            self._update_node_values(parent, collect=False)
        except:
            pass

    def go_to_node(self, node):
        try:
            self.tree.focus_set()
            self.tree.selection_set(node)
            self.see_node(node)
            self.tree.focus(node)
        except:
            pass

    def next_node(self, thisNode):

        def search_tree(parent, result, flag):
            for child in self.tree.get_children(parent):
                if result:
                    break
                if child.startswith(prefix):
                    if prefix == CHAPTER_PREFIX:
                        if self._mdl.novel.chapters[child].chLevel != self._mdl.novel.chapters[thisNode].chLevel:
                            continue

                    elif prefix == SECTION_PREFIX:
                        if self._mdl.novel.sections[thisNode].scType > 1:
                            if self._mdl.novel.sections[child].scType != self._mdl.novel.sections[thisNode].scType:
                                continue

                        elif self._mdl.novel.sections[thisNode].scType < 2:
                            if self._mdl.novel.sections[child].scType > 1:
                                continue

                    if flag:
                        result = child
                        break

                    elif child == thisNode:
                        flag = True
                else:
                    result, flag = search_tree(child, result, flag)
            return result, flag

        prefix = thisNode[:2]
        root = self.tree.parent(thisNode)
        while not root.startswith(ROOT_PREFIX):
            root = self.tree.parent(root)
        nextNode, __ = search_tree(root, None, False)
        return nextNode

    def on_quit(self):
        prefs['title_width'] = self.tree.column('#0', 'width')
        for i, column in enumerate(self.columns):
            prefs[column[2]] = self.tree.column(i, 'width')

        prefs['coloring_mode'] = self.coloringMode

    def open_children(self, parent):
        self.tree.item(parent, open=True)
        self._update_node_values(parent, collect=False)
        for child in self.tree.get_children(parent):
            self.open_children(child)

    def prev_node(self, thisNode):

        def search_tree(parent, result, prevNode):
            for child in self.tree.get_children(parent):
                if result:
                    break

                if child.startswith(prefix):
                    if prefix == CHAPTER_PREFIX:
                        if self._mdl.novel.chapters[child].chLevel != self._mdl.novel.chapters[thisNode].chLevel:
                            continue

                    elif prefix == SECTION_PREFIX:
                        if self._mdl.novel.sections[thisNode].scType > 1:
                            if self._mdl.novel.sections[child].scType != self._mdl.novel.sections[thisNode].scType:
                                continue

                        elif self._mdl.novel.sections[thisNode].scType < 2:
                            if self._mdl.novel.sections[child].scType > 1:
                                continue

                    if child == thisNode:
                        result = prevNode
                        break
                    else:
                        prevNode = child
                else:
                    result, prevNode = search_tree(child, result, prevNode)
            return result, prevNode

        prefix = thisNode[:2]
        root = self.tree.parent(thisNode)
        while not root.startswith(ROOT_PREFIX):
            root = self.tree.parent(root)
        prevNode, __ = search_tree(root, None, None)
        return prevNode

    def reset_view(self):
        self._history.reset()
        for rootElement in self.tree.get_children(''):
            self.tree.item(rootElement, text='')
        self.tree.configure({'selectmode': 'none'})
        self._ctrl.reset_tree()

    def show_branch(self, node):
        self.go_to_node(node)
        self.open_children(node)
        return 'break'

    def show_chapter_level(self, event=None):

        def show_chapters(parent):
            if parent.startswith(CHAPTER_PREFIX):
                self.tree.item(parent, open=False)
                self._update_node_values(parent, collect=True)
            else:
                self.tree.item(parent, open=True)
                for child in self.tree.get_children(parent):
                    show_chapters(child)

        show_chapters(CH_ROOT)
        return 'break'

    def refresh(self, event=None):

        def update_branch(node, scnPos=0):
            for elemId in self.tree.get_children(node):
                if elemId.startswith(SECTION_PREFIX):
                    title, nodeValues, nodeTags = self._get_section_row_data(elemId, position=scnPos)
                    if self._mdl.novel.sections[elemId].scType == 0:
                        scnPos += self._mdl.novel.sections[elemId].wordCount
                elif elemId.startswith(CHARACTER_PREFIX):
                    title, nodeValues, nodeTags = self._get_character_row_data(elemId)
                elif elemId.startswith(LOCATION_PREFIX):
                    title, nodeValues, nodeTags = self._get_location_row_data(elemId)
                elif elemId.startswith(ITEM_PREFIX):
                    title, nodeValues, nodeTags = self._get_item_row_data(elemId)
                elif elemId.startswith(CHAPTER_PREFIX):
                    chpPos = scnPos
                    scnPos = update_branch(elemId, scnPos)
                    isCollapsed = not self.tree.item(elemId, 'open')
                    title, nodeValues, nodeTags = self._get_chapter_row_data(elemId, position=chpPos, collect=isCollapsed)
                elif elemId.startswith(PLOT_LINE_PREFIX):
                    update_branch(elemId, scnPos)
                    isCollapsed = not self.tree.item(elemId, 'open')
                    title, nodeValues, nodeTags = self._get_plot_line_row_data(elemId, collect=isCollapsed)
                elif elemId.startswith(PLOT_POINT_PREFIX):
                    title, nodeValues, nodeTags = self._get_plot_point_row_data(elemId)
                elif elemId.startswith(PRJ_NOTE_PREFIX):
                    title, nodeValues, nodeTags = self._get_prj_note_row_data(elemId)
                else:
                    title = self._ROOT_TITLES[elemId]
                    nodeValues = []
                    nodeTags = 'root'
                    update_branch(elemId, scnPos)
                self.tree.item(elemId, text=title, values=nodeValues, tags=nodeTags)
            return scnPos

        if self.skipUpdate:
            self.skipUpdate = False
        elif self._mdl.prjFile is not None:
            self._wordsTotal = self._mdl.get_counts()[0]
            update_branch('')
            self.tree.configure(selectmode='extended')

    def _bind_events(self, **kwargs):
        self.tree.bind('<<TreeviewSelect>>', self._on_select_node)
        self.tree.bind('<<TreeviewOpen>>', self._on_open_branch)
        self.tree.bind('<<TreeviewClose>>', self._on_close_branch)
        self.tree.bind(KEYS.DELETE[0], self._ctrl.delete_elements)
        self.tree.bind(MOUSE.RIGHT_CLICK, self._on_open_context_menu)
        self.tree.bind(MOUSE.MOVE_NODE, self._on_move_node)

    def _browse_tree(self, node):
        if node and self.tree.exists(node):
            if self.tree.selection()[0] != node:
                self._history.lock()
                self.go_to_node(node)
        else:
            self._history.reset()
            self._history.append_node(self.tree.selection()[0])

    def _build_menus(self):


        self.selectTypeMenu = tk.Menu(self.tree, tearoff=0)
        self.selectTypeMenu.add_command(label=_('Normal'), command=lambda:self._ctrl.set_type(0))
        self.selectTypeMenu.add_command(label=_('Unused'), command=lambda:self._ctrl.set_type(1))

        self.selectLevelMenu = tk.Menu(self.tree, tearoff=0)
        self.selectLevelMenu.add_command(label=_('1st Level'), command=lambda:self._ctrl.set_level(1))
        self.selectLevelMenu.add_command(label=_('2nd Level'), command=lambda:self._ctrl.set_level(2))

        self.scStatusMenu = tk.Menu(self.tree, tearoff=0)
        self.scStatusMenu.add_command(label=_('Outline'), command=lambda:self._ctrl.set_completion_status(1))
        self.scStatusMenu.add_command(label=_('Draft'), command=lambda:self._ctrl.set_completion_status(2))
        self.scStatusMenu.add_command(label=_('1st Edit'), command=lambda:self._ctrl.set_completion_status(3))
        self.scStatusMenu.add_command(label=_('2nd Edit'), command=lambda:self._ctrl.set_completion_status(4))
        self.scStatusMenu.add_command(label=_('Done'), command=lambda:self._ctrl.set_completion_status(5))

        self.crStatusMenu = tk.Menu(self.tree, tearoff=0)
        self.crStatusMenu.add_command(label=_('Major Character'), command=lambda:self._ctrl.set_character_status(True))
        self.crStatusMenu.add_command(label=_('Minor Character'), command=lambda:self._ctrl.set_character_status(False))


        self._nvCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._nvCtxtMenu.add_command(label=_('Add Section'), command=self._ctrl.add_section)
        self._nvCtxtMenu.add_command(label=_('Add Chapter'), command=self._ctrl.add_chapter)
        self._nvCtxtMenu.add_command(label=_('Add Part'), command=self._ctrl.add_part)
        self._nvCtxtMenu.add_command(label=_('Insert Stage'), command=self._ctrl.add_stage)
        self._nvCtxtMenu.add_cascade(label=_('Change Level'), menu=self.selectLevelMenu)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_cascade(label=_('Set Type'), menu=self.selectTypeMenu)
        self._nvCtxtMenu.add_cascade(label=_('Set Status'), menu=self.scStatusMenu)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Join with previous'), command=self._ctrl.join_sections)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Chapter level'), command=self.show_chapter_level)
        self._nvCtxtMenu.add_command(label=_('Expand'), command=lambda: self.open_children(self.tree.selection()[0]))
        self._nvCtxtMenu.add_command(label=_('Collapse'), command=lambda: self.close_children(self.tree.selection()[0]))
        self._nvCtxtMenu.add_command(label=_('Expand all'), command=lambda: self.open_children(''))
        self._nvCtxtMenu.add_command(label=_('Collapse all'), command=lambda: self.close_children(''))

        self._wrCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._wrCtxtMenu.add_command(label=_('Add'), command=self._ctrl.add_element)
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_command(label=_('Export manuscript filtered by viewpoint'), command=self._export_manuscript)
        self._wrCtxtMenu.add_command(label=_('Export synopsis filtered by viewpoint'), command=self._export_synopsis)
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_cascade(label=_('Set Status'), menu=self.crStatusMenu)

        self._plCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._plCtxtMenu.add_command(label=_('Add Plot line'), command=self._ctrl.add_plot_line)
        self._plCtxtMenu.add_command(label=_('Add Plot point'), command=self._ctrl.add_plot_point)
        self._plCtxtMenu.add_separator()
        self._plCtxtMenu.add_command(label=_('Export manuscript filtered by plot line'), command=self._export_manuscript)
        self._plCtxtMenu.add_command(label=_('Export synopsis filtered by plot line'), command=self._export_synopsis)
        self._plCtxtMenu.add_separator()
        self._plCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)

        self._pnCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._pnCtxtMenu.add_command(label=_('Add Project note'), command=self._ctrl.add_project_note)
        self._pnCtxtMenu.add_separator()
        self._pnCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)

    def _collect_ch_note_indicators(self, chId):
        if self._mdl.novel.chapters[chId].notes:
            return self._NOTE_INDICATOR

        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType != 1:
                    if self._mdl.novel.sections[scId].notes:
                        return self._NOTE_INDICATOR

        return ''

    def _collect_pl_note_indicators(self, plId):
        if self._mdl.novel.plotLines[plId].notes:
            return self._NOTE_INDICATOR

        for ppId in self.tree.get_children(plId):
            if self._mdl.novel.plotPoints[ppId].notes:
                return self._NOTE_INDICATOR

        return ''

    def _collect_plot_lines(self, chId):
        chPlotlineShortNames = []
        chPlotPointTitles = []
        chPlotlines = {}
        for plId in self._mdl.novel.plotLines:
            chPlotlines[plId] = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    scPlotlines = self._mdl.novel.sections[scId].scPlotLines
                    for plId in scPlotlines:
                        shortName = self._mdl.novel.plotLines[plId].shortName
                        if not shortName in chPlotlineShortNames:
                            chPlotlineShortNames.append(shortName)
                    for ppId in self._mdl.novel.sections[scId].scPlotPoints:
                        chPlotlines[plId].append(ppId)
            if len(chPlotlineShortNames) == 1:
                for plId in chPlotlines:
                    for ppId in chPlotlines[plId]:
                        chPlotPointTitles.append(self._mdl.novel.plotPoints[ppId].title)
            else:
                for plId in chPlotlines:
                    for ppId in chPlotlines[plId]:
                        chPlotPointTitles.append(f'{self._mdl.novel.plotLines[plId].shortName}: {self._mdl.novel.plotPoints[ppId].title}')
        return list_to_string(chPlotlineShortNames), list_to_string(chPlotPointTitles)

    def _collect_tags(self, chId):
        chapterTags = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    if self._mdl.novel.sections[scId].tags:
                        for tag in self._mdl.novel.sections[scId].tags:
                            if not tag in chapterTags:
                                chapterTags.append(tag)
        return list_to_string(chapterTags)

    def _collect_viewpoints(self, chId):
        chapterViewpoints = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    try:
                        crId = self._mdl.novel.sections[scId].characters[0]
                        viewpoint = self._mdl.novel.characters[crId].title
                        if not viewpoint in chapterViewpoints:
                            chapterViewpoints.append(viewpoint)
                    except:
                        pass
        return list_to_string(chapterViewpoints)

    def _count_words(self, chId):
        chapterWordCount = 0
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    chapterWordCount += self._mdl.novel.sections[scId].wordCount
        return chapterWordCount

    def _date_is_valid(self, section):
        if section.date is None:
            return False

        if section.date == section.NULL_DATE:
            return False

        return True

    def _export_manuscript(self, event=None):
        self._ctrl.export_document(MANUSCRIPT_SUFFIX, filter=self.tree.selection()[0], ask=False)

    def _export_synopsis(self, event=None):
        self._ctrl.export_document(SECTIONS_SUFFIX, filter=self.tree.selection()[0], ask=False)

    def _get_chapter_row_data(self, chId, position=None, collect=False):
        nodeValues = [''] * len(self.columns)
        nodeTags = []
        if self._mdl.novel.chapters[chId].chType != 0:
            nodeTags.append('unused')
            if self._mdl.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')
        else:
            nodeTags.append('chapter')
            try:
                positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
            except:
                positionStr = ''
            wordCount = self._count_words(chId)
            if self._mdl.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')

                srtChapters = self.tree.get_children(CH_ROOT)
                i = srtChapters.index(chId) + 1
                while i < len(srtChapters):
                    c = srtChapters[i]
                    if self._mdl.novel.chapters[c].chLevel == 1:
                        break
                    i += 1
                    wordCount += self._count_words(c)
            nodeValues[self._colPos['wc']] = wordCount
            nodeValues[self._colPos['po']] = positionStr
            if collect:
                nodeValues[self._colPos['vp']] = self._collect_viewpoints(chId)
        if collect:
            nodeValues[self._colPos['tg']] = self._collect_tags(chId)
            nodeValues[self._colPos['ac']], nodeValues[self._colPos['tp']] = self._collect_plot_lines(chId)
            nodeValues[self._colPos['nt']] = self._collect_ch_note_indicators(chId)
        else:
            nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.chapters[chId])
        return to_string(self._mdl.novel.chapters[chId].title), nodeValues, tuple(nodeTags)

    def _get_character_row_data(self, crId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.characters[crId])

        wordCount = 0
        for scId in self._mdl.novel.sections:
            if self._mdl.novel.sections[scId].scType == 0:
                if self._mdl.novel.sections[scId].characters:
                    if self._mdl.novel.sections[scId].characters[0] == crId:
                        wordCount += self._mdl.novel.sections[scId].wordCount
        if wordCount > 0:
            nodeValues[self._colPos['wc']] = wordCount

            try:
                percentageStr = f'{round(100 * wordCount / self._wordsTotal, 1)}%'
            except:
                percentageStr = ''
            nodeValues[self._colPos['vp']] = percentageStr

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.characters[crId].tags)
        except:
            pass

        nodeTags = []
        if self._mdl.novel.characters[crId].isMajor:
            nodeTags.append('major')
        else:
            nodeTags.append('minor')
        return to_string(self._mdl.novel.characters[crId].title), nodeValues, tuple(nodeTags)

    def _get_date_or_day(self, scId):
        if self._date_is_valid(self._mdl.novel.sections[scId]):
            return get_section_date_str(self._mdl.novel.sections[scId])

        if self._mdl.novel.sections[scId].day is not None:
            return f'{_("Day")} {self._mdl.novel.sections[scId].day}'

        return ''

        title = self._mdl.novel.sections[scId].title
        if not title:
            title = _('Unnamed')

    def _get_item_row_data(self, itId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.items[itId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.items[itId].tags)
        except:
            pass
        return to_string(self._mdl.novel.items[itId].title), nodeValues, ()

    def _get_location_row_data(self, lcId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.locations[lcId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.locations[lcId].tags)
        except:
            pass
        return to_string(self._mdl.novel.locations[lcId].title), nodeValues, ()

    def _get_notes_indicator(self, element):
        if element.notes:
            return self._NOTE_INDICATOR

        return ''

    def _get_plot_line_row_data(self, plId, collect=False):
        fullName = to_string(self._mdl.novel.plotLines[plId].title)
        title = f'({self._mdl.novel.plotLines[plId].shortName}) {fullName}'
        nodeValues = [''] * len(self.columns)
        if collect:
            nodeValues[self._colPos['nt']] = self._collect_pl_note_indicators(plId)
        else:
            nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.plotLines[plId])
        return title, nodeValues, ('arc')

    def _get_plot_point_row_data(self, ppId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.plotPoints[ppId])

        scId = self._mdl.novel.plotPoints[ppId].sectionAssoc
        if scId:
            sectionTitle = self._mdl.novel.sections[scId].title
            if sectionTitle is not None:
                nodeValues[self._colPos['tp']] = sectionTitle
        return to_string(self._mdl.novel.plotPoints[ppId].title), nodeValues, ('plot_point')

    def _get_prj_note_row_data(self, pnId):
        nodeValues = [''] * len(self.columns)
        return to_string(self._mdl.novel.projectNotes[pnId].title), nodeValues, ()

    def _get_section_row_data(self, scId, position=None):

        if self._mdl.novel.sections[scId].time is not None:
            dispTime = self._mdl.novel.sections[scId].time.rsplit(':', 1)[0]
        else:
            dispTime = ''

        if self._mdl.novel.sections[scId].lastsDays and self._mdl.novel.sections[scId].lastsDays != '0':
            days = f'{self._mdl.novel.sections[scId].lastsDays}d '
        else:
            days = ''
        if self._mdl.novel.sections[scId].lastsHours and self._mdl.novel.sections[scId].lastsHours != '0':
            hours = f'{self._mdl.novel.sections[scId].lastsHours}h '
        else:
            hours = ''
        if self._mdl.novel.sections[scId].lastsMinutes and self._mdl.novel.sections[scId].lastsMinutes != '0':
            minutes = f'{self._mdl.novel.sections[scId].lastsMinutes}min'
        else:
            minutes = ''

        nodeValues = [''] * len(self.columns)
        nodeTags = []
        if self._mdl.novel.sections[scId].scType > 1:
            stageLevel = self._mdl.novel.sections[scId].scType - 1
            nodeTags.append(f'stage{stageLevel}')
        else:
            positionStr = ''
            if self._mdl.novel.sections[scId].scType == 1:
                nodeTags.append('unused')
            else:
                if self.coloringMode == 1:
                    nodeTags.append(f'status{self._mdl.novel.sections[scId].status}')
                elif self.coloringMode == 2 and self._mdl.novel.workPhase:
                    if self._mdl.novel.sections[scId].status == self._mdl.novel.workPhase:
                        nodeTags.append('On_schedule')
                    elif self._mdl.novel.sections[scId].status < self._mdl.novel.workPhase:
                        nodeTags.append('Behind_schedule')
                    else:
                        nodeTags.append('Before_schedule')
                try:
                    positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
                except:
                    pass
            nodeValues[self._colPos['po']] = positionStr
            nodeValues[self._colPos['wc']] = self._mdl.novel.sections[scId].wordCount
            nodeValues[self._colPos['st']] = self._mdl.novel.sections[scId].STATUS[self._mdl.novel.sections[scId].status]
            try:
                nodeValues[self._colPos['vp']] = self._mdl.novel.characters[self._mdl.novel.sections[scId].characters[0]].title
            except:
                nodeValues[self._colPos['vp']] = _('N/A')

            nodeValues[self._colPos['sc']] = self._SCENE[self._mdl.novel.sections[scId].scene]

            nodeValues[self._colPos['dt']] = self._get_date_or_day(scId)
            nodeValues[self._colPos['tm']] = dispTime
            nodeValues[self._colPos['dr']] = f'{days}{hours}{minutes}'

            scPlotlineShortNames = []
            scPlotPointTitles = []
            scPlotlines = self._mdl.novel.sections[scId].scPlotLines
            for plId in scPlotlines:
                shortName = self._mdl.novel.plotLines[plId].shortName
                if not shortName in scPlotlineShortNames:
                    scPlotlineShortNames.append(shortName)
            for ppId in self._mdl.novel.sections[scId].scPlotPoints:
                if len(scPlotlineShortNames) == 1:
                    scPlotPointTitles.append(self._mdl.novel.plotPoints[ppId].title)
                else:
                    plId = self._mdl.novel.sections[scId].scPlotPoints[ppId]
                    scPlotPointTitles.append(f'{self._mdl.novel.plotLines[plId].shortName}: {self._mdl.novel.plotPoints[ppId].title}')
            nodeValues[self._colPos['ac']] = list_to_string(scPlotlineShortNames)
            nodeValues[self._colPos['tp']] = list_to_string(scPlotPointTitles)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.sections[scId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.sections[scId].tags)
        except:
            pass
        return to_string(self._mdl.novel.sections[scId].title), nodeValues, tuple(nodeTags)

    def _on_close_branch(self, event):
        self._update_node_values(self.tree.selection()[0], collect=True)

    def _on_move_node(self, event):
        self._ctrl.move_node(
            self.tree.selection()[0],
            self.tree.identify_row(event.y)
            )

    def _on_open_branch(self, event):
        self._update_node_values(self.tree.selection()[0], collect=False)

    def _on_open_context_menu(self, event):
        if self._mdl is None:
            return

        row = self.tree.identify_row(event.y)
        if row:
            self.go_to_node(row)
            if row.startswith(ROOT_PREFIX):
                prefix = row
            else:
                prefix = row[:2]
            if prefix in (CH_ROOT, CHAPTER_PREFIX, SECTION_PREFIX):
                if self._ctrl.isLocked:
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Section'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                elif prefix.startswith(CH_ROOT):
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Section'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                else:
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Section'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Change Level'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='normal')
                    if prefix.startswith(CHAPTER_PREFIX):
                        self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                        if row == self._mdl.trashBin:
                            self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Section'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Part'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='disabled')
                    if prefix.startswith(SECTION_PREFIX):
                        if self._mdl.novel.sections[row].scType < 2:
                            self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                        else:
                            self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                try:
                    self._nvCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._nvCtxtMenu.grab_release()
            elif prefix in (CR_ROOT, CHARACTER_PREFIX, LC_ROOT, LOCATION_PREFIX, IT_ROOT, ITEM_PREFIX):
                if self._ctrl.isLocked:
                    self._wrCtxtMenu.entryconfig(_('Add'), state='disabled')
                    self._wrCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._wrCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                    self._wrCtxtMenu.entryconfig(_('Export manuscript filtered by viewpoint'), state='disabled')
                    self._wrCtxtMenu.entryconfig(_('Export synopsis filtered by viewpoint'), state='disabled')
                else:
                    self._wrCtxtMenu.entryconfig(_('Add'), state='normal')
                    if prefix.startswith('wr'):
                        self._wrCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    else:
                        self._wrCtxtMenu.entryconfig(_('Delete'), state='normal')
                    if prefix.startswith(CHARACTER_PREFIX) or  row.endswith(CHARACTER_PREFIX):
                        self._wrCtxtMenu.entryconfig(_('Set Status'), state='normal')
                        self._wrCtxtMenu.entryconfig(_('Export manuscript filtered by viewpoint'), state='normal')
                        self._wrCtxtMenu.entryconfig(_('Export synopsis filtered by viewpoint'), state='normal')
                    else:
                        self._wrCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                        self._wrCtxtMenu.entryconfig(_('Export manuscript filtered by viewpoint'), state='disabled')
                        self._wrCtxtMenu.entryconfig(_('Export synopsis filtered by viewpoint'), state='disabled')
                try:
                    self._wrCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._wrCtxtMenu.grab_release()
            elif prefix in (PL_ROOT, PLOT_LINE_PREFIX, PLOT_POINT_PREFIX):
                if self._ctrl.isLocked:
                    self._plCtxtMenu.entryconfig(_('Add Plot line'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Add Plot point'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Export manuscript filtered by plot line'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Export synopsis filtered by plot line'), state='disabled')
                elif prefix.startswith(PL_ROOT):
                    self._plCtxtMenu.entryconfig(_('Add Plot line'), state='normal')
                    self._plCtxtMenu.entryconfig(_('Add Plot point'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Export manuscript filtered by plot line'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Export synopsis filtered by plot line'), state='disabled')
                else:
                    self._plCtxtMenu.entryconfig(_('Add Plot line'), state='normal')
                    self._plCtxtMenu.entryconfig(_('Add Plot point'), state='normal')
                    self._plCtxtMenu.entryconfig(_('Delete'), state='normal')
                    if prefix == PLOT_LINE_PREFIX:
                        self._plCtxtMenu.entryconfig(_('Export manuscript filtered by plot line'), state='normal')
                        self._plCtxtMenu.entryconfig(_('Export synopsis filtered by plot line'), state='normal')
                    else:
                        self._plCtxtMenu.entryconfig(_('Export manuscript filtered by plot line'), state='disabled')
                        self._plCtxtMenu.entryconfig(_('Export synopsis filtered by plot line'), state='disabled')
                try:
                    self._plCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._plCtxtMenu.grab_release()
            elif prefix in (PN_ROOT, PRJ_NOTE_PREFIX):
                if self._ctrl.isLocked:
                    self._pnCtxtMenu.entryconfig(_('Add Project note'), state='disabled')
                    self._pnCtxtMenu.entryconfig(_('Delete'), state='disabled')
                elif prefix.startswith(PN_ROOT):
                    self._pnCtxtMenu.entryconfig(_('Add Project note'), state='normal')
                    self._pnCtxtMenu.entryconfig(_('Delete'), state='normal')
                try:
                    self._pnCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._pnCtxtMenu.grab_release()

    def _on_select_node(self, event):
        try:
            nodeId = self.tree.selection()[0]
        except IndexError:
            return

        self._history.append_node(nodeId)
        self._ui.on_change_selection(nodeId)

    def _update_node_values(self, nodeId, collect=False):
        if nodeId.startswith(CHAPTER_PREFIX):
            positionStr = self.tree.item(nodeId)['values'][self._colPos['po']]
            __, nodeValues, __ = self._get_chapter_row_data(nodeId, position=None, collect=collect)
            nodeValues[self._colPos['po']] = positionStr
            self.tree.item(nodeId, values=nodeValues)
            return

        if nodeId.startswith(PLOT_LINE_PREFIX):
            __, nodeValues, __ = self._get_plot_line_row_data(nodeId, collect=collect)
            self.tree.item(nodeId, values=nodeValues)
            return



class NvView:
    _MIN_WINDOW_WIDTH = 400
    _MIN_WINDOW_HEIGHT = 200

    _MAX_NR_NEW_SECTIONS = 20
    _INI_NR_NEW_SECTIONS = 1

    def __init__(self, model, controller, title):
        self._mdl = model
        self._ctrl = controller
        self._mdl.register_client(self)
        self.views = []

        self.title = title
        self._statusText = ''
        self.root = tk.Tk()
        self.root.protocol("WM_DELETE_WINDOW", self._ctrl.on_quit)
        self.root.title(title)
        if prefs.get('root_geometry', None):
            self.root.geometry(prefs['root_geometry'])
        set_icon(self.root, icon='nLogo32')
        self.root.minsize(self._MIN_WINDOW_WIDTH, self._MIN_WINDOW_HEIGHT)

        self.mainMenu = tk.Menu(self.root)
        self.root.config(menu=self.mainMenu)

        self.mainWindow = tk.Frame()
        self.mainWindow.pack(expand=True, fill='both')

        self.statusBar = tk.Label(self.root, text='', anchor='w', padx=5, pady=2)
        self.statusBar.pack(expand=False, fill='both')
        self.statusBar.bind(MOUSE.LEFT_CLICK, self.restore_status)
        self.infoWhatText = ''
        self.infoHowText = ''

        self.pathBar = tk.Label(self.root, text='', anchor='w', padx=5, pady=3)
        self.pathBar.pack(expand=False, fill='both')

        self.guiStyle = ttk.Style()

        self.icons = Icons()


        self.appWindow = ttk.Frame(self.mainWindow)
        self.appWindow.pack(expand=True, fill='both')

        self.leftFrame = ttk.Frame(self.appWindow)
        self.leftFrame.pack(side='left', expand=True, fill='both')

        self.tv = TreeViewer(self.leftFrame, self._mdl, self, self._ctrl, prefs)
        self.register_view(self.tv)
        self.tv.pack(expand=True, fill='both')

        self.middleFrame = ttk.Frame(self.appWindow, width=prefs['middle_frame_width'])
        self.middleFrame.pack_propagate(0)

        self.contentsView = ContentsViewer(self.middleFrame, self._mdl, self, self._ctrl)
        self.register_view(self.contentsView)
        if prefs['show_contents']:
            self.middleFrame.pack(side='left', expand=False, fill='both')

        self.rightFrame = ttk.Frame(self.appWindow, width=prefs['right_frame_width'])
        self.rightFrame.pack_propagate(0)
        if prefs['show_properties']:
            self.rightFrame.pack(expand=True, fill='both')

        self.propertiesView = PropertiesViewer(self.rightFrame, self._mdl, self, self._ctrl)
        self.propertiesView.pack(expand=True, fill='both')
        self._propWinDetached = False
        if prefs['detach_prop_win']:
            self.detach_properties_frame()
        self.register_view(self.propertiesView)

        self._build_menu()

        self.toolbar = Toolbar(self, self._ctrl)
        self.register_view(self.toolbar)

        self._bind_events()

    def ask_yes_no(self, text, title=None):
        if title is None:
            title = self.title
        return messagebox.askyesno(title, text)

    def detach_properties_frame(self, event=None):
        self.propertiesView.apply_changes()
        if self._propWinDetached:
            return

        if self.rightFrame.winfo_manager():
            self.rightFrame.pack_forget()
        self._propertiesWindow = tk.Toplevel()
        self._propertiesWindow.geometry(prefs['prop_win_geometry'])
        set_icon(self._propertiesWindow, icon='pLogo32', default=False)

        self.propertiesView.pack_forget()
        self.unregister_view(self.propertiesView)
        self.propertiesView = PropertiesViewer(self._propertiesWindow, self._mdl, self, self._ctrl)
        self.register_view(self.propertiesView)
        self.propertiesView.pack(expand=True, fill='both')

        self._propertiesWindow.protocol("WM_DELETE_WINDOW", self.dock_properties_frame)
        prefs['detach_prop_win'] = True
        self._propWinDetached = True
        try:
            self.propertiesView.show_properties(self.tv.tree.selection()[0])
        except IndexError:
            pass
        return 'break'

    def disable_menu(self):
        self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.mainMenu.entryconfig(_('Part'), state='disabled')
        self.mainMenu.entryconfig(_('Chapter'), state='disabled')
        self.mainMenu.entryconfig(_('Section'), state='disabled')
        self.mainMenu.entryconfig(_('Characters'), state='disabled')
        self.mainMenu.entryconfig(_('Locations'), state='disabled')
        self.mainMenu.entryconfig(_('Items'), state='disabled')
        self.mainMenu.entryconfig(_('Plot'), state='disabled')
        self.mainMenu.entryconfig(_('Project notes'), state='disabled')
        self.mainMenu.entryconfig(_('Export'), state='disabled')
        self.mainMenu.entryconfig(_('Import'), state='disabled')
        self.fileMenu.entryconfig(_('Reload'), state='disabled')
        self.fileMenu.entryconfig(_('Restore backup'), state='disabled')
        self.fileMenu.entryconfig(_('Refresh Tree'), state='disabled')
        self.fileMenu.entryconfig(_('Lock'), state='disabled')
        self.fileMenu.entryconfig(_('Unlock'), state='disabled')
        self.fileMenu.entryconfig(_('Open Project folder'), state='disabled')
        self.fileMenu.entryconfig(_('Copy style sheet'), state='disabled')
        self.fileMenu.entryconfig(_('Save'), state='disabled')
        self.fileMenu.entryconfig(_('Save as...'), state='disabled')
        self.fileMenu.entryconfig(_('Discard manuscript'), state='disabled')
        self.viewMenu.entryconfig(_('Chapter level'), state='disabled')
        self.viewMenu.entryconfig(_('Expand selected'), state='disabled')
        self.viewMenu.entryconfig(_('Collapse selected'), state='disabled')
        self.viewMenu.entryconfig(_('Expand all'), state='disabled')
        self.viewMenu.entryconfig(_('Collapse all'), state='disabled')
        self.viewMenu.entryconfig(_('Show Book'), state='disabled')
        self.viewMenu.entryconfig(_('Show Characters'), state='disabled')
        self.viewMenu.entryconfig(_('Show Locations'), state='disabled')
        self.viewMenu.entryconfig(_('Show Items'), state='disabled')
        self.viewMenu.entryconfig(_('Show Plot lines'), state='disabled')
        self.viewMenu.entryconfig(_('Show Project notes'), state='disabled')
        for view in self.views:
            try:
                view.disable_menu()
            except AttributeError:
                pass

    def dock_properties_frame(self, event=None):
        self.propertiesView.apply_changes()
        if not self._propWinDetached:
            return

        if not self.rightFrame.winfo_manager():
            self.rightFrame.pack(side='left', expand=False, fill='both')

        prefs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()

        self._propertiesWindow.destroy()
        self.unregister_view(self.propertiesView)
        self.propertiesView = PropertiesViewer(self.rightFrame, self._mdl, self, self._ctrl)
        self.register_view(self.propertiesView)
        self.propertiesView.pack(expand=True, fill='both')
        self.root.lift()

        prefs['show_properties'] = True
        prefs['detach_prop_win'] = False
        self._propWinDetached = False
        try:
            self.propertiesView.show_properties(self.tv.tree.selection()[0])
        except IndexError:
            pass
        return 'break'

    def enable_menu(self):
        self.fileMenu.entryconfig(_('Close'), state='normal')
        self.mainMenu.entryconfig(_('Part'), state='normal')
        self.mainMenu.entryconfig(_('Chapter'), state='normal')
        self.mainMenu.entryconfig(_('Section'), state='normal')
        self.mainMenu.entryconfig(_('Characters'), state='normal')
        self.mainMenu.entryconfig(_('Locations'), state='normal')
        self.mainMenu.entryconfig(_('Items'), state='normal')
        self.mainMenu.entryconfig(_('Plot'), state='normal')
        self.mainMenu.entryconfig(_('Project notes'), state='normal')
        self.mainMenu.entryconfig(_('Export'), state='normal')
        self.mainMenu.entryconfig(_('Import'), state='normal')
        self.fileMenu.entryconfig(_('Reload'), state='normal')
        self.fileMenu.entryconfig(_('Restore backup'), state='normal')
        self.fileMenu.entryconfig(_('Refresh Tree'), state='normal')
        self.fileMenu.entryconfig(_('Lock'), state='normal')
        self.fileMenu.entryconfig(_('Open Project folder'), state='normal')
        self.fileMenu.entryconfig(_('Copy style sheet'), state='normal')
        self.fileMenu.entryconfig(_('Save'), state='normal')
        self.fileMenu.entryconfig(_('Save as...'), state='normal')
        self.fileMenu.entryconfig(_('Discard manuscript'), state='normal')
        self.viewMenu.entryconfig(_('Chapter level'), state='normal')
        self.viewMenu.entryconfig(_('Expand selected'), state='normal')
        self.viewMenu.entryconfig(_('Collapse selected'), state='normal')
        self.viewMenu.entryconfig(_('Expand all'), state='normal')
        self.viewMenu.entryconfig(_('Collapse all'), state='normal')
        self.viewMenu.entryconfig(_('Show Book'), state='normal')
        self.viewMenu.entryconfig(_('Show Characters'), state='normal')
        self.viewMenu.entryconfig(_('Show Locations'), state='normal')
        self.viewMenu.entryconfig(_('Show Items'), state='normal')
        self.viewMenu.entryconfig(_('Show Plot lines'), state='normal')
        self.viewMenu.entryconfig(_('Show Project notes'), state='normal')
        for view in self.views:
            try:
                view.enable_menu()
            except AttributeError:
                pass

    def lock(self):
        self.pathBar.config(bg=prefs['color_locked_bg'])
        self.pathBar.config(fg=prefs['color_locked_fg'])
        self.fileMenu.entryconfig(_('Save'), state='disabled')
        self.fileMenu.entryconfig(_('Lock'), state='disabled')
        self.fileMenu.entryconfig(_('Unlock'), state='normal')
        self.mainMenu.entryconfig(_('Part'), state='disabled')
        self.mainMenu.entryconfig(_('Chapter'), state='disabled')
        self.mainMenu.entryconfig(_('Section'), state='disabled')
        self.mainMenu.entryconfig(_('Characters'), state='disabled')
        self.mainMenu.entryconfig(_('Locations'), state='disabled')
        self.mainMenu.entryconfig(_('Items'), state='disabled')
        self.mainMenu.entryconfig(_('Plot'), state='disabled')
        self.mainMenu.entryconfig(_('Project notes'), state='disabled')
        self.mainMenu.entryconfig(_('Export'), state='disabled')
        for view in self.views:
            try:
                view.lock()
            except AttributeError:
                pass

    def on_change_selection(self, nodeId):
        self.propertiesView.show_properties(nodeId)
        self.contentsView.see(nodeId)

    def on_quit(self):

        prefs['show_markup'] = self.contentsView.showMarkup.get()

        if self._propWinDetached:
            prefs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()
        self.tv.on_quit()
        prefs['root_geometry'] = self.root.winfo_geometry()
        self.root.quit()

    def refresh(self):
        if self._mdl.isModified:
            self.pathBar.config(bg=prefs['color_modified_bg'])
            self.pathBar.config(fg=prefs['color_modified_fg'])
        else:
            self.pathBar.config(bg=self.root.cget('background'))
            self.pathBar.config(fg='black')
        for view in self.views:
            try:
                view.refresh()
            except AttributeError:
                pass
        self.set_title()

    def register_view(self, view):
        if not view in self.views:
            self.views.append(view)

    def restore_status(self, event=None):
        self.show_status(self._statusText)

    def set_info(self, message):
        pass

    def set_status(self, message, colors=None):
        if message is not None:
            try:
                self.statusBar.config(bg=colors[0])
                self.statusBar.config(fg=colors[1])
                self.infoHowText = message
            except:
                if message.startswith('!'):
                    self.statusBar.config(bg='red')
                    self.statusBar.config(fg='white')
                    self.infoHowText = message.lstrip('!').strip()
                else:
                    self.statusBar.config(bg='green')
                    self.statusBar.config(fg='white')
                    self.infoHowText = message
            self.statusBar.config(text=self.infoHowText)

    def set_title(self):
        if self._mdl.novel is None:
            return

        if self._mdl.novel.title:
            titleView = self._mdl.novel.title
        else:
            titleView = _('Untitled project')
        if self._mdl.novel.authorName:
            authorView = self._mdl.novel.authorName
        else:
            authorView = _('Unknown author')
        self.root.title(f'{titleView} {_("by")} {authorView} - {self.title}')

    def show_error(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showerror(title, message)

    def show_info(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showinfo(title, message)

    def show_warning(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showwarning(title, message)

    def show_path(self, message):
        self.pathBar.config(text=message)

    def show_status(self, message=''):
        self._statusText = message
        self.statusBar.config(bg=self.root.cget('background'))
        self.statusBar.config(fg='black')
        self.statusBar.config(text=message)

    def start(self):
        self.root.mainloop()

    def toggle_contents_view(self, event=None):
        if self.middleFrame.winfo_manager():
            self.middleFrame.pack_forget()
            prefs['show_contents'] = False
        else:
            self.middleFrame.pack(after=self.leftFrame, side='left', expand=False, fill='both')
            prefs['show_contents'] = True
        return 'break'

    def toggle_properties_view(self, event=None):
        if self.rightFrame.winfo_manager():
            self.propertiesView.apply_changes()
            self.rightFrame.pack_forget()
            prefs['show_properties'] = False
        elif not self._propWinDetached:
            self.rightFrame.pack(side='left', expand=False, fill='both')
            prefs['show_properties'] = True
        return 'break'

    def toggle_properties_window(self, event=None):
        if self._propWinDetached:
            self.dock_properties_frame()
        else:
            self.detach_properties_frame()
        return 'break'

    def unlock(self):
        self.pathBar.config(bg=self.root.cget('background'))
        self.pathBar.config(fg='black')
        self.fileMenu.entryconfig(_('Save'), state='normal')
        self.fileMenu.entryconfig(_('Lock'), state='normal')
        self.fileMenu.entryconfig(_('Unlock'), state='disabled')
        self.mainMenu.entryconfig(_('Part'), state='normal')
        self.mainMenu.entryconfig(_('Chapter'), state='normal')
        self.mainMenu.entryconfig(_('Section'), state='normal')
        self.mainMenu.entryconfig(_('Characters'), state='normal')
        self.mainMenu.entryconfig(_('Locations'), state='normal')
        self.mainMenu.entryconfig(_('Items'), state='normal')
        self.mainMenu.entryconfig(_('Plot'), state='normal')
        self.mainMenu.entryconfig(_('Project notes'), state='normal')
        self.mainMenu.entryconfig(_('Export'), state='normal')
        for view in self.views:
            try:
                view.unlock()
            except AttributeError:
                pass

    def unregister_view(self, view):
        try:
            self.views.remove(view)
        except:
            pass

    def _add_multiple_sections(self):
        n = askinteger(
            title=_('New'),
            prompt=_('How many sections to add?'),
            initialvalue=self._INI_NR_NEW_SECTIONS,
            minvalue=0,
            maxvalue=self._MAX_NR_NEW_SECTIONS
            )
        if n is not None:
            for __ in range(n):
                self._ctrl.add_section()

    def _bind_events(self):
        self.root.bind(KEYS.RESTORE_STATUS[0], self.restore_status)
        self.root.bind(KEYS.OPEN_PROJECT[0], self._ctrl.open_project)

        self.root.bind(KEYS.LOCK_PROJECT[0], self._ctrl.lock)
        self.root.bind(KEYS.UNLOCK_PROJECT[0], self._ctrl.unlock)
        self.root.bind(KEYS.RELOAD_PROJECT[0], self._ctrl.reload_project)
        self.root.bind(KEYS.RESTORE_BACKUP[0], self._ctrl.restore_backup)
        self.root.bind(KEYS.FOLDER[0], self._ctrl.open_project_folder)
        self.root.bind(KEYS.REFRESH_TREE[0], self._ctrl.refresh_views)
        self.root.bind(KEYS.SAVE_PROJECT[0], self._ctrl.save_project)
        self.root.bind(KEYS.SAVE_AS[0], self._ctrl.save_as)
        self.root.bind(KEYS.CHAPTER_LEVEL[0], self.tv.show_chapter_level)
        self.root.bind(KEYS.TOGGLE_VIEWER[0], self.toggle_contents_view)
        self.root.bind(KEYS.TOGGLE_PROPERTIES[0], self.toggle_properties_view)
        self.root.bind(KEYS.DETACH_PROPERTIES[0], self.toggle_properties_window)
        self.root.bind(KEYS.ADD_ELEMENT[0], self._ctrl.add_element)
        self.root.bind(KEYS.ADD_CHILD[0], self._ctrl.add_child)
        self.root.bind(KEYS.ADD_PARENT[0], self._ctrl.add_parent)
        if PLATFORM == 'win':
            self.root.bind(MOUSE.BACK_CLICK, self.tv.go_back)
            self.root.bind(MOUSE.FORWARD_CLICK, self.tv.go_forward)
        else:
            self.root.bind(KEYS.QUIT_PROGRAM[0], self._ctrl.on_quit)
        self.root.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _build_menu(self):

        self.newMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.newMenu.add_command(label=_('Empty project'), command=self._ctrl.new_project)
        self.newMenu.add_command(label=_('Create from ODT...'), command=self._ctrl.import_odf)

        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_cascade(label=_('New'), menu=self.newMenu)
        self.fileMenu.add_command(label=_('Open...'), accelerator=KEYS.OPEN_PROJECT[1], command=self._ctrl.open_project)
        self.fileMenu.add_command(label=_('Reload'), accelerator=KEYS.RELOAD_PROJECT[1], command=self._ctrl.reload_project)
        self.fileMenu.add_command(label=_('Restore backup'), accelerator=KEYS.RESTORE_BACKUP[1], command=self._ctrl.restore_backup)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Refresh Tree'), accelerator=KEYS.REFRESH_TREE[1], command=self._ctrl.refresh_views)
        self.fileMenu.add_command(label=_('Lock'), accelerator=KEYS.LOCK_PROJECT[1], command=self._ctrl.lock)
        self.fileMenu.add_command(label=_('Unlock'), accelerator=KEYS.UNLOCK_PROJECT[1], command=self._ctrl.unlock)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Open Project folder'), accelerator=KEYS.FOLDER[1], command=self._ctrl.open_project_folder)
        self.fileMenu.add_command(label=_('Copy style sheet'), command=self._ctrl.copy_css)
        self.fileMenu.add_command(label=_('Discard manuscript'), command=self._ctrl.discard_manuscript)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Save'), accelerator=KEYS.SAVE_PROJECT[1], command=self._ctrl.save_project)
        self.fileMenu.add_command(label=_('Save as...'), accelerator=KEYS.SAVE_AS[1], command=self._ctrl.save_as)
        self.fileMenu.add_command(label=_('Close'), command=self._ctrl.close_project)
        if PLATFORM == 'win':
            self.fileMenu.add_command(label=_('Exit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self._ctrl.on_quit)
        else:
            self.fileMenu.add_command(label=_('Quit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self._ctrl.on_quit)

        self.viewMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('View'), menu=self.viewMenu)
        self.viewMenu.add_command(label=_('Chapter level'), accelerator=KEYS.CHAPTER_LEVEL[1], command=self.tv.show_chapter_level)
        self.viewMenu.add_command(label=_('Expand selected'), command=lambda: self.tv.open_children(self.tv.tree.selection()[0]))
        self.viewMenu.add_command(label=_('Collapse selected'), command=lambda: self.tv.close_children(self.tv.tree.selection()[0]))
        self.viewMenu.add_command(label=_('Expand all'), command=lambda: self.tv.open_children(''))
        self.viewMenu.add_command(label=_('Collapse all'), command=lambda: self.tv.close_children(''))
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Show Book'), command=lambda: self.tv.show_branch(CH_ROOT))
        self.viewMenu.add_command(label=_('Show Characters'), command=lambda: self.tv.show_branch(CR_ROOT))
        self.viewMenu.add_command(label=_('Show Locations'), command=lambda: self.tv.show_branch(LC_ROOT))
        self.viewMenu.add_command(label=_('Show Items'), command=lambda: self.tv.show_branch(IT_ROOT))
        self.viewMenu.add_command(label=_('Show Plot lines'), command=lambda: self.tv.show_branch(PL_ROOT))
        self.viewMenu.add_command(label=_('Show Project notes'), command=lambda: self.tv.show_branch(PN_ROOT))
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Toggle Text viewer'), accelerator=KEYS.TOGGLE_VIEWER[1], command=self.toggle_contents_view)
        self.viewMenu.add_command(label=_('Toggle Properties'), accelerator=KEYS.TOGGLE_PROPERTIES[1], command=self.toggle_properties_view)
        self.viewMenu.add_command(label=_('Detach/Dock Properties'), accelerator=KEYS.DETACH_PROPERTIES[1], command=self.toggle_properties_window)
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Options'), command=self._view_options)

        self.partMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Part'), menu=self.partMenu)
        self.partMenu.add_command(label=_('Add'), command=self._ctrl.add_part)
        self.partMenu.add_separator()
        self.partMenu.add_command(label=_('Export part descriptions for editing'), command=lambda: self._ctrl.export_document(PARTS_SUFFIX))

        self.chapterMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Chapter'), menu=self.chapterMenu)
        self.chapterMenu.add_command(label=_('Add'), command=self._ctrl.add_chapter)
        self.chapterMenu.add_separator()
        self.chapterMenu.add_cascade(label=_('Set Type'), menu=self.tv.selectTypeMenu)
        self.chapterMenu.add_cascade(label=_('Change Level'), menu=self.tv.selectLevelMenu)
        self.chapterMenu.add_separator()
        self.chapterMenu.add_command(label=_('Export chapter descriptions for editing'), command=lambda: self._ctrl.export_document(CHAPTERS_SUFFIX))

        self.sectionMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Section'), menu=self.sectionMenu)
        self.sectionMenu.add_command(label=_('Add'), command=self._ctrl.add_section)
        self.sectionMenu.add_command(label=_('Add multiple sections'), command=self._add_multiple_sections)
        self.sectionMenu.add_separator()
        self.sectionMenu.add_cascade(label=_('Set Type'), menu=self.tv.selectTypeMenu)
        self.sectionMenu.add_cascade(label=_('Set Status'), menu=self.tv.scStatusMenu)
        self.sectionMenu.add_separator()
        self.sectionMenu.add_command(label=_('Export section descriptions for editing'), command=lambda: self._ctrl.export_document(SECTIONS_SUFFIX))
        self.sectionMenu.add_command(label=_('Section list (export only)'), command=lambda: self._ctrl.export_document(SECTIONLIST_SUFFIX))

        self.characterMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Characters'), menu=self.characterMenu)
        self.characterMenu.add_command(label=_('Add'), command=self._ctrl.add_character)
        self.characterMenu.add_separator()
        self.characterMenu.add_cascade(label=_('Set Status'), menu=self.tv.crStatusMenu)
        self.characterMenu.add_separator()
        self.characterMenu.add_command(label=_('Import'), command=lambda: self._ctrl.import_world_elements(CHARACTER_PREFIX))
        self.characterMenu.add_separator()
        self.characterMenu.add_command(label=_('Export character descriptions for editing'), command=lambda: self._ctrl.export_document(CHARACTERS_SUFFIX))
        self.characterMenu.add_command(label=_('Export character list (spreadsheet)'), command=lambda: self._ctrl.export_document(CHARLIST_SUFFIX))
        self.characterMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report(CHARACTER_REPORT_SUFFIX))

        self.locationMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Locations'), menu=self.locationMenu)
        self.locationMenu.add_command(label=_('Add'), command=self._ctrl.add_location)
        self.locationMenu.add_separator()
        self.locationMenu.add_command(label=_('Import'), command=lambda: self._ctrl.import_world_elements(LOCATION_PREFIX))
        self.locationMenu.add_separator()
        self.locationMenu.add_command(label=_('Export location descriptions for editing'), command=lambda: self._ctrl.export_document(LOCATIONS_SUFFIX))
        self.locationMenu.add_command(label=_('Export location list (spreadsheet)'), command=lambda: self._ctrl.export_document(LOCLIST_SUFFIX))
        self.locationMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report(LOCATION_REPORT_SUFFIX))

        self.itemMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Items'), menu=self.itemMenu)
        self.itemMenu.add_command(label=_('Add'), command=self._ctrl.add_item)
        self.itemMenu.add_separator()
        self.itemMenu.add_command(label=_('Import'), command=lambda: self._ctrl.import_world_elements(ITEM_PREFIX))
        self.itemMenu.add_separator()
        self.itemMenu.add_command(label=_('Export item descriptions for editing'), command=lambda: self._ctrl.export_document(ITEMS_SUFFIX))
        self.itemMenu.add_command(label=_('Export item list (spreadsheet)'), command=lambda: self._ctrl.export_document(ITEMLIST_SUFFIX))
        self.itemMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report(ITEM_REPORT_SUFFIX))

        self.plotMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Plot'), menu=self.plotMenu)
        self.plotMenu.add_command(label=_('Add Plot line'), command=self._ctrl.add_plot_line)
        self.plotMenu.add_command(label=_('Add Plot point'), command=self._ctrl.add_plot_point)
        self.plotMenu.add_separator()
        self.plotMenu.add_command(label=_('Insert Stage'), command=self._ctrl.add_stage)
        self.plotMenu.add_cascade(label=_('Change Level'), menu=self.tv.selectLevelMenu)
        self.plotMenu.add_separator()
        self.plotMenu.add_command(label=_('Export plot grid for editing'), command=lambda:self._ctrl.export_document(GRID_SUFFIX))
        self.plotMenu.add_command(label=_('Export story structure description for editing'), command=lambda:self._ctrl.export_document(STAGES_SUFFIX))
        self.plotMenu.add_command(label=_('Export plot line descriptions for editing'), command=lambda: self._ctrl.export_document(PLOTLINES_SUFFIX, lock=False))
        self.plotMenu.add_separator()
        self.plotMenu.add_command(label=_('Export plot list (spreadsheet)'), command=lambda: self._ctrl.export_document(PLOTLIST_SUFFIX, lock=False))
        self.plotMenu.add_command(label=_('Show Plot list'), command=lambda: self._ctrl.show_report(PLOTLIST_SUFFIX))

        self.prjNoteMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Project notes'), menu=self.prjNoteMenu)
        self.prjNoteMenu.add_command(label=_('Add'), command=self._ctrl.add_project_note)
        self.prjNoteMenu.add_separator()
        self.prjNoteMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report('_projectnote_report'))

        self.exportMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Export'), menu=self.exportMenu)
        self.exportMenu.add_command(label=_('Manuscript for editing'), command=lambda:self._ctrl.export_document(MANUSCRIPT_SUFFIX))
        self.exportMenu.add_command(label=_('Manuscript for third-party word processing'), command=lambda: self._ctrl.export_document(PROOF_SUFFIX))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Manuscript for printing (export only)'), command=lambda: self._ctrl.export_document('', lock=False))
        self.exportMenu.add_command(label=_('Brief synopsis (export only)'), command=lambda: self._ctrl.export_document(BRF_SYNOPSIS_SUFFIX, lock=False))
        self.exportMenu.add_command(label=_('Cross references (export only)'), command=lambda: self._ctrl.export_document(XREF_SUFFIX, lock=False))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Characters/locations/items data files'), command=lambda: self._ctrl.export_document(DATA_SUFFIX, lock=False, show=False))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Options'), command=self._export_options)

        self.mainMenu.add_command(label=_('Import'), command=self._ctrl.update_project)

        self.toolsMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Tools'), menu=self.toolsMenu)
        self.toolsMenu.add_command(label=_('Plugin Manager'), command=self._ctrl.manage_plugins)
        self.toolsMenu.add_command(label=_('Open installation folder'), command=self._ctrl.open_installationFolder)
        self.toolsMenu.add_separator()

        self.helpMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator=KEYS.OPEN_HELP[1], command=self._open_help)
        self.helpMenu.add_command(label=f"novelibre {_('Home page')}", command=lambda: webbrowser.open(HOME_URL))

    def _export_options(self, event=None):
        offset = 300
        __, x, y = self.root.geometry().split('+')
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        ExportOptionsWindow(windowGeometry, self)
        return 'break'

    def _open_help(self, event=None):
        open_help('')

    def _view_options(self, event=None):
        offset = 300
        __, x, y = self.root.geometry().split('+')
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        ViewOptionsWindow(windowGeometry, self)
        return 'break'

from datetime import datetime
from tkinter import ttk





class Ui:

    def __init__(self, title):
        self.infoWhatText = ''
        self.infoHowText = ''

    def ask_yes_no(self, text):
        return True

    def set_status(self, message):
        if message.startswith('!'):
            message = f'FAIL: {message.split("!", maxsplit=1)[1].strip()}'
            sys.stderr.write(message)
        self.infoHowText = message

    def set_info(self, message):
        self.infoWhatText = message

    def show_warning(self, message):
        pass

    def start(self):
        pass



class Converter:

    def __init__(self):
        self.ui = Ui('')
        self.newFile = None

    def export_from_novx(self, source, target):
        self.ui.set_info(
            _('Input: {0} "{1}"\nOutput: {2} "{3}"').format(source.DESCRIPTION, norm_path(source.filePath), target.DESCRIPTION, norm_path(target.filePath)))
        message = ''
        try:
            self.check(source, target)
            source.novel = Novel(tree=NvTree())
            source.read()
            target.novel = source.novel
            target.write()
        except Error as ex:
            message = f'!{str(ex)}'
            self.newFile = None
        else:
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self.newFile = target.filePath
        finally:
            self.ui.set_status(message)

    def create_novx(self, source, target):
        self.ui.set_info(
            _('Create a novelibre project file from {0}\nNew project: "{1}"').format(source.DESCRIPTION, norm_path(target.filePath)))
        if os.path.isfile(target.filePath):
            self.ui.set_status(f'!{_("File already exists")}: "{norm_path(target.filePath)}".')
        else:
            message = ''
            try:
                self.check(source, target)
                source.novel = Novel(tree=NvTree())
                source.novel.check_locale()
                source.read()
                target.novel = source.novel
                target.write()
            except Error as ex:
                message = f'!{str(ex)}'
                self.newFile = None
            else:
                message = f'{_("File written")}: "{norm_path(target.filePath)}".'
                self.newFile = target.filePath
            finally:
                self.ui.set_status(message)

    def import_to_novx(self, source, target):
        self.ui.set_info(
            _('Input: {0} "{1}"\nOutput: {2} "{3}"').format(source.DESCRIPTION, norm_path(source.filePath), target.DESCRIPTION, norm_path(target.filePath)))
        self.newFile = None
        message = ''
        try:
            self.check(source, target)
            target.novel = Novel(tree=NvTree())
            target.read()
            source.novel = target.novel
            source.read()
            target.novel = source.novel
            target.write()
        except Error as ex:
            message = f'!{str(ex)}'
        else:
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self.newFile = target.filePath
            if source.sectionsSplit:
                os.replace(source.filePath, f'{source.filePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
        finally:
            self.ui.set_status(f'{message}')

    def _confirm_overwrite(self, filePath):
        return self.ui.ask_yes_no(_('Overwrite existing file "{}"?').format(norm_path(filePath)))

    def _open_newFile(self):
        open_document(self.newFile)
        sys.exit(0)

    def check(self, source, target):
        if source.filePath is None:
            raise Error(f'{_("File type is not supported")}.')

        if not os.path.isfile(source.filePath):
            raise Error(f'{_("File not found")}: "{norm_path(source.filePath)}".')

        if source.is_locked():
            raise Error(f'{_("Please close the document first")}".')

        if target.is_locked():
            raise Error(f'{_("Please close the document first")}.')

        if target.filePath is None:
            raise Error(f'{_("File type is not supported")}.')

        if os.path.isfile(target.filePath) and not self._confirm_overwrite(target.filePath):
            raise Error(f'{_("Action canceled by user")}.')




class ExportSourceFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        __, fileExtension = os.path.splitext(sourcePath)
        for fileClass in self._fileClasses:
            if fileClass.EXTENSION == fileExtension:
                sourceFile = fileClass(sourcePath, **kwargs)
                return sourceFile, None

        raise Error(f'{_("File type is not supported")}: "{norm_path(sourcePath)}".')


class ConverterFf(Converter):
    EXPORT_SOURCE_CLASSES = []
    EXPORT_TARGET_CLASSES = []
    IMPORT_SOURCE_CLASSES = []
    IMPORT_TARGET_CLASSES = []

    def __init__(self):
        super().__init__()
        self.exportSourceFactory = ExportSourceFactory(self.EXPORT_SOURCE_CLASSES)
        self.exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)
        self.importSourceFactory = ImportSourceFactory(self.IMPORT_SOURCE_CLASSES)
        self.importTargetFactory = ImportTargetFactory(self.IMPORT_TARGET_CLASSES)
        self.newProjectFactory = None

    def run(self, sourcePath, **kwargs):
        self.newFile = None
        if not os.path.isfile(sourcePath):
            self.ui.set_status(f'!{_("File not found")}: "{norm_path(sourcePath)}".')
            return

        try:
            source, __ = self.exportSourceFactory.make_file_objects(sourcePath, **kwargs)
        except Error:
            try:
                source, __ = self.importSourceFactory.make_file_objects(sourcePath, **kwargs)
            except Error:
                try:
                    source, target = self.newProjectFactory.make_file_objects(sourcePath, **kwargs)
                except Error as ex:
                    self.ui.set_status(f'!{str(ex)}')
                else:
                    self.create_novx(source, target)
            else:
                kwargs['suffix'] = source.SUFFIX
                try:
                    __, target = self.importTargetFactory.make_file_objects(sourcePath, **kwargs)
                except Error as ex:
                    self.ui.set_status(f'!{str(ex)}')
                else:
                    self.import_to_novx(source, target)
        else:
            try:
                __, target = self.exportTargetFactory.make_file_objects(sourcePath, **kwargs)
            except Error as ex:
                self.ui.set_status(f'!{str(ex)}')
            else:
                self.export_from_novx(source, target)


class NovxConverter(ConverterFf):
    EXPORT_SOURCE_CLASSES = [NovxFile]
    EXPORT_TARGET_CLASSES = [
        OdsWCharList,
        OdsWGrid,
        OdsWItemList,
        OdsWLocList,
        OdsWPlotList,
        OdsWSectionList,
        OdtWBriefSynopsis,
        OdtWChapterDesc,
        OdtWCharacters,
        OdtWExport,
        OdtWItems,
        OdtWLocations,
        OdtWManuscript,
        OdtWPartDesc,
        OdtWPlotlines,
        OdtWProof,
        OdtWSectionDesc,
        OdtWStages,
        OdtWXref,
    ]
    IMPORT_SOURCE_CLASSES = [
        OdsRCharList,
        OdsRGrid,
        OdsRItemList,
        OdsRLocList,
        OdtRChapterDesc,
        OdtRCharacters,
        OdtRItems,
        OdtRLocations,
        OdtRManuscript,
        OdtRPartDesc,
        OdtRPlotlines,
        OdtRProof,
        OdtRSectionDesc,
        OdtRStages,
    ]
    IMPORT_TARGET_CLASSES = [NovxFile]
    CREATE_SOURCE_CLASSES = []

    def __init__(self):
        super().__init__()
        self.newProjectFactory = NewProjectFactory(self.CREATE_SOURCE_CLASSES)


class PrjUpdater(tk.Toplevel):

    def __init__(self, model, view, controller, size, **kw):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        if self._mdl.prjFile.filePath is None:
            return

        super().__init__(**kw)
        self.title(f'{_("Exported documents")} - novelibre 4.11.11')
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(fill='both', expand=True)

        columns = 'Document', 'Date'
        self._documentCollection = ttk.Treeview(window, columns=columns, show='headings', selectmode='browse')
        self._documentCollection.pack(fill='both', expand=True)
        self._documentCollection.bind('<<TreeviewSelect>>', self._on_select_document)
        self._documentCollection.tag_configure('newer', foreground='green')
        self._documentCollection.tag_configure('locked', foreground='red')

        self._documentCollection.column('Document', width=300, minwidth=250, stretch=True)
        self._documentCollection.heading('Document', text=_('Document'), anchor='w')
        self._documentCollection.column('Date', minwidth=120, stretch=False)
        self._documentCollection.heading('Date', text=_('Date'), anchor='w')

        IMPORT_MODES = [
            _("Discard documents only when sections are split"),
            _("Always discard documents after import"),
            _("Import documents even if locked; do not discard")
            ]
        try:
            importMode = int(prefs['import_mode'])
        except:
            importMode = 0
        if importMode >= len(IMPORT_MODES):
            importMode = 0

        self._importMode = tk.IntVar(window, value=importMode)
        for i, buttonLabel in enumerate(IMPORT_MODES):
            ttk.Radiobutton(
                window,
                text=buttonLabel,
                variable=self._importMode,
                value=i,
                command=self._on_select_document
                ).pack(padx=5, pady=1, anchor='w')
        self._importMode.trace('w', self._save_options)

        self._importButton = ttk.Button(window, text=_('Import'), command=self._import_document, state='disabled')
        self._importButton.pack(padx=5, pady=5, side='left')

        self._deleteButton = ttk.Button(window, text=_('Discard'), command=self._delete_document, state='disabled')
        self._deleteButton.pack(padx=5, pady=5, side='left')

        self._refreshButton = ttk.Button(window, text=_('Refresh view'), command=self.list_documents)
        self._refreshButton.pack(padx=5, pady=5, side='left')

        ttk.Button(window, text=_('Close'), command=self.destroy).pack(padx=5, pady=5, side='right')

        ttk.Button(
            window,
            text=_('Online help'),
            command=self._open_help
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)
        self._documentCollection.bind('<Double-1>', self._import_document)
        self._documentCollection.bind('<Return>', self._import_document)

        self._docTypes = {}
        for docClass in NovxConverter.IMPORT_SOURCE_CLASSES:
            self._docTypes[f'{docClass.SUFFIX}{docClass.EXTENSION}'] = docClass.DESCRIPTION

        self.list_documents()

    def list_documents(self):
        prjDir, prjFile = os.path.split(self._mdl.prjFile.filePath)
        prjName, __ = os.path.splitext(prjFile)
        self._prjDocuments = {}
        for file in os.listdir(prjDir):
            for docType in self._docTypes:
                if file == f'{prjName}{docType}':
                    self._prjDocuments[f'{prjDir}/{file}'] = self._docTypes[docType]
        self._reset_tree()
        for filePath in self._prjDocuments:
            timestamp = os.path.getmtime(filePath)
            nodeTags = []
            try:
                documentType = self._prjDocuments[filePath]
            except:
                documentType = _('No document type')
            try:
                documentDate = datetime.fromtimestamp(timestamp).strftime('%c')
            except:
                documentDate = _('unknown')
            columns = [documentType, documentDate]
            if odf_is_locked(filePath):
                nodeTags.append('locked')
            elif timestamp > self._mdl.prjFile.timestamp:
                nodeTags.append('newer')
            self._documentCollection.insert('', 'end', filePath, values=columns, tags=tuple(nodeTags))

    def _delete_document(self, event=None):
        filePath = self._documentCollection.selection()[0]
        if filePath and self._ui.ask_yes_no(f'{_("Delete file")} "{filePath}"?'):
            try:
                os.remove(filePath)
                self._documentCollection.delete(filePath)
            except Exception as ex:
                self._ui.set_status(f'!{str(ex)}')

    def _on_select_document(self, event=None):
        try:
            filePath = self._documentCollection.selection()[0]
        except IndexError:
            delButtonState = 'disabled'
            impButtonState = 'disabled'
        else:
            if odf_is_locked(filePath):
                delButtonState = 'disabled'
                if self._importMode.get() != 2:
                    impButtonState = 'disabled'
                else:
                    impButtonState = 'normal'
            else:
                delButtonState = 'normal'
                impButtonState = 'normal'
        self._deleteButton.configure(state=delButtonState)
        self._importButton.configure(state=impButtonState)

    def _import_document(self, event=None):
        try:
            filePath = self._documentCollection.selection()[0]
        except IndexError:
            pass
        else:
            self._ctrl.import_odf(sourcePath=filePath)
        importButtonState = 'disabled'
        self._importButton.configure(state=importButtonState)
        self.list_documents()

    def _open_help(self, event=None):
        open_help(f'import_menu.html')

    def _update_project(self, event=None):
        pass

    def _reset_tree(self):
        for child in self._documentCollection.get_children(''):
            self._documentCollection.delete(child)

    def _save_options(self, event=None, *args):
        prefs['import_mode'] = str(self._importMode.get())


PLUGIN_PATH = f'{sys.path[0]}/plugin'


class NvController:

    def __init__(self, title, tempDir):
        self.tempDir = tempDir
        self._internalLockFlag = False

        self._mdl = NvModel()
        self._mdl.register_client(self)

        self.launchers = {}

        self.linkProcessor = LinkProcessor(self._mdl)

        self._fileTypes = [(NvWorkFile.DESCRIPTION, NvWorkFile.EXTENSION)]
        self.importFiletypes = [(_('ODF Text document'), '.odt'), (_('ODF Spreadsheet document'), '.ods')]

        self._ui = NvView(self._mdl, self, title)

        self._mdl.tree = self._ui.tv.tree

        self.plugins = PluginCollection(self._mdl, self._ui, self)

        self.plugins.load_plugins(PLUGIN_PATH)
        self.disable_menu()

        self._ui.tv.reset_view()

    @property
    def isLocked(self):
        return self._internalLockFlag

    @isLocked.setter
    def isLocked(self, setFlag):
        raise NotImplementedError

    def add_chapter(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_chapter(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_character(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_character(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_child(self, event=None):
        if self._mdl.prjFile is None:
            return

        if self.check_lock():
            return

        try:
            selection = self._ui.tv.tree.selection()[0]
        except:
            return

        if selection == CH_ROOT:
            self.add_chapter(targetNode=selection)
            return

        if selection.startswith(CHAPTER_PREFIX):
            self.add_section(targetNode=selection)
            return

        if selection.startswith(PLOT_LINE_PREFIX):
            self.add_plot_point(targetNode=selection)
            return

        if selection == CR_ROOT:
            self.add_character(targetNode=selection)
            return

        if selection == LC_ROOT:
            self.add_location(targetNode=selection)
            return

        if selection == IT_ROOT:
            self.add_item(targetNode=selection)
            return

        if selection == PL_ROOT:
            self.add_plot_line(targetNode=selection)
            return

        if selection == PN_ROOT:
            self.add_project_note(targetNode=selection)

    def add_element(self, event=None):
        if self._mdl.prjFile is None:
            return

        if self.check_lock():
            return

        try:
            selection = self._ui.tv.tree.selection()[0]
        except:
            return

        if selection.startswith(SECTION_PREFIX):
            if self._mdl.novel.sections[selection].scType < 2:
                self.add_section(targetNode=selection)
                return

            self.add_stage(targetNode=selection)
            return

        if CHAPTER_PREFIX in selection:
            self.add_chapter(targetNode=selection)
            return

        if CHARACTER_PREFIX in selection:
            self.add_character(targetNode=selection)
            return

        if LOCATION_PREFIX in selection:
            self.add_location(targetNode=selection)
            return

        if ITEM_PREFIX in selection:
            self.add_item(targetNode=selection)
            return

        if PLOT_LINE_PREFIX in selection:
            self.add_plot_line(targetNode=selection)
            return

        if PRJ_NOTE_PREFIX in selection:
            self.add_project_note(targetNode=selection)
            return

        if selection.startswith(PLOT_POINT_PREFIX):
            self.add_plot_point(targetNode=selection)

    def add_item(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_item(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_location(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_location(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_parent(self, event=None):
        if self._mdl.prjFile is None:
            return

        if self.check_lock():
            return

        try:
            selection = self._ui.tv.tree.selection()[0]
        except:
            return

        if selection.startswith(SECTION_PREFIX):
            self.add_chapter(targetNode=selection)
        elif selection.startswith(PLOT_POINT_PREFIX):
            self.add_plot_line(targetNode=selection)

    def add_part(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_part(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_plot_line(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_plot_line(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_plot_point(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_plot_point(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_project_note(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_project_note(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_section(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_section(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_stage(self, **kwargs):
        if self.check_lock():
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_stage(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def check_lock(self):
        if self.isLocked:
            if self._ui.ask_yes_no(_('The project is locked.\nUnlock?'), title=_('Can not do')):
                self.unlock()
                return False
            else:
                return True
        else:
            return False

    def close_project(self, event=None, doNotSave=False):
        self._ui.propertiesView.apply_changes()
        self.plugins.on_close()
        if self._mdl.isModified and not doNotSave:
            if self._ui.ask_yes_no(_('Save changes?')):
                if not self.save_project():
                    self._ui.show_error(_('Cannot save the project'), _('Critical Error'))

        self._ui.propertiesView._view_nothing()
        self._mdl.close_project()
        self._ui.tv.reset_view()
        self._ui.contentsView.reset_view()
        self._internalLockFlag = False
        self._ui.unlock()
        self._ui.root.title(self._ui.title)
        self.show_status('')
        self._ui.show_path('')
        self.disable_menu()
        return 'break'

    def copy_css(self, event=None):
        try:
            projectDir, __ = os.path.split(self._mdl.prjFile.filePath)
            copy2(f'{os.path.dirname(sys.argv[0])}/css/novx.css', projectDir)
            message = _('Style sheet copied into the project folder.')
        except Exception as ex:
            message = f'!{str(ex)}'
        self._ui.set_status(message)

    def delete_elements(self, event=None, elements=None):
        if self.check_lock():
            return

        if elements is None:
            try:
                elements = self._ui.tv.tree.selection()
            except:
                return

        for  elemId in elements:
            if elemId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[elemId].scType < 2:
                    candidate = f'{_("Section")} "{self._mdl.novel.sections[elemId].title}"'
                else:
                    candidate = f'{_("Stage")} "{self._mdl.novel.sections[elemId].title}"'
            elif elemId.startswith(CHAPTER_PREFIX):
                candidate = f'{_("Chapter")} "{self._mdl.novel.chapters[elemId].title}"'
            elif elemId.startswith(CHARACTER_PREFIX):
                candidate = f'{_("Character")} "{self._mdl.novel.characters[elemId].title}"'
            elif elemId.startswith(LOCATION_PREFIX):
                candidate = f'{_("Location")} "{self._mdl.novel.locations[elemId].title}"'
            elif elemId.startswith(ITEM_PREFIX):
                candidate = f'{_("Item")} "{self._mdl.novel.items[elemId].title}"'
            elif elemId.startswith(PLOT_LINE_PREFIX):
                candidate = f'{_("Plot line")} "{self._mdl.novel.plotLines[elemId].title}"'
            elif elemId.startswith(PLOT_POINT_PREFIX):
                candidate = f'{_("Plot point")} "{self._mdl.novel.plotPoints[elemId].title}"'
            elif elemId.startswith(PRJ_NOTE_PREFIX):
                candidate = f'{_("Project note")} "{self._mdl.novel.projectNotes[elemId].title}"'
            else:
                return

            if not self._ui.ask_yes_no(_('Delete {}?').format(candidate)):
                return

            if self._ui.tv.tree.prev(elemId):
                self._view_new_element(self._ui.tv.tree.prev(elemId))
            else:
                self._view_new_element(self._ui.tv.tree.parent(elemId))
            self._mdl.delete_element(elemId)

    def disable_menu(self):
        self._ui.disable_menu()
        self.plugins.disable_menu()

    def discard_manuscript(self):
        fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        manuscriptPath = f'{fileName}{MANUSCRIPT_SUFFIX}.odt'
        if os.path.isfile(manuscriptPath):
            prjPath, manuscriptName = os.path.split(manuscriptPath)
            if os.path.isfile(f'{prjPath}/.~lock.{manuscriptName}#'):
                self._ui.set_status(f"!{_('Please close the manuscript first')}.")
            elif self._ui.ask_yes_no(f"{_('Discard manuscript')}?", self._mdl.novel.title):
                os.replace(manuscriptPath, f'{fileName}{MANUSCRIPT_SUFFIX}.odt.bak')
                self._ui.set_status(f"{_('Manuscript discarded')}.")

    def enable_menu(self):
        self._ui.enable_menu()
        self.plugins.enable_menu()

    def export_document(self, suffix, **kwargs):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.prjFile.filePath is not None or self.save_project():
            if self._mdl.isModified:
                if self._ui.ask_yes_no(_('Save changes?')):
                    self.save_project()
                else:
                    return

            exporter = NvDocExporter(self._ui)
            try:
                self._ui.set_status(exporter.run(self._mdl.prjFile, suffix, **kwargs))
            except Error as ex:
                self._ui.set_status(f'!{str(ex)}')
            else:
                if kwargs.get('lock', True) and prefs['lock_on_export']:
                    self.lock()

    def get_preferences(self):
        return prefs

    def get_view(self):
        return self._ui

    def import_world_elements(self, prefix):
        self._ui.restore_status()
        fileTypes = [(_('XML data file'), '.xml')]
        filePath = filedialog.askopenfilename(filetypes=fileTypes)
        if filePath:
            NvDataImporter(self._mdl, self._ui, self, filePath, prefix)

    def import_odf(self, event=None, sourcePath=None, defaultExtension='.odt'):
        if sourcePath is None:
            if prefs['last_open']:
                startDir, __ = os.path.split(prefs['last_open'])
            else:
                startDir = '.'
            sourcePath = filedialog.askopenfilename(
                filetypes=self.importFiletypes,
                defaultextension=defaultExtension,
                initialdir=startDir,
                )
            if not sourcePath:
                return 'break'

        if self._mdl.prjFile is not None:
            self.show_status()
            self.refresh_views()
            self.unlock()
            if self._mdl.isModified:
                if self._ui.ask_yes_no(_('Save changes?')):
                    self.save_project()
        importer = NvDocImporter(self._ui)
        try:
            message = importer.run(sourcePath, nv_service=self._mdl.nvService)
        except Error as ex:
            self._ui.set_status(f'!{str(ex)}')
            return 'break'

        if importer.newFile:
            self.open_project(filePath=importer.newFile)
            if os.path.isfile(sourcePath) and prefs['import_mode'] == '1':
                os.replace(sourcePath, f'{sourcePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
            self._ui.set_status(message)
        return 'break'

    def join_sections(self, event=None, scId0=None, scId1=None):
        if self.check_lock():
            return

        if scId0 is None or scId1 is None:
            try:
                scId1 = self._ui.tv.tree.selection()[0]
            except:
                return

            if not scId1.startswith(SECTION_PREFIX):
                return

            scId0 = self._ui.tv.prev_node(scId1)
            if not scId0:
                self._ui.show_error(_('There is no previous section'), title=_('Cannot join sections'))
                return

        if self._ui.ask_yes_no(f'{_("Join with previous")}?'):
            try:
                self._mdl.join_sections(scId0, scId1)
            except Error as ex:
                self._ui.show_error(str(ex), title=_('Cannot join sections'))
                return

            self._view_new_element(scId0)

    def lock(self, event=None):
        if self._mdl.isModified and not self._internalLockFlag:
            if self._ui.ask_yes_no(_('Save and lock?')):
                self.save_project()
            else:
                return False

        if self._mdl.prjFile.filePath is not None:
            self._internalLockFlag = True
            self._ui.lock()
            self.plugins.lock()
            self._mdl.prjFile.lock()
            return True
        else:
            return False

    def manage_plugins(self, event=None):
        offset = 300
        __, x, y = self._ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        PluginManager(windowGeometry, self._ui, self)
        return 'break'

    def move_node(self, node, targetNode):
        if not self.isLocked:
            if (node.startswith(SECTION_PREFIX) and targetNode.startswith(CHAPTER_PREFIX)
                ) or (node.startswith(PLOT_POINT_PREFIX) and targetNode.startswith(PLOT_LINE_PREFIX)):
                self._ui.tv.open_children(targetNode)
            self._ui.tv.skipUpdate = True
            self._mdl.move_node(node, targetNode)

    def new_project(self, event=None):
        if self._mdl.prjFile is not None:
            self.close_project()
        self._mdl.new_project(self._ui.tv.tree)
        self._ui.show_path(_('Unnamed'))
        self.enable_menu()
        self.show_status()
        self._ui.tv.go_to_node(CH_ROOT)
        self.refresh_views()
        self.save_project()
        return 'break'

    def on_quit(self, event=None):
        try:
            if self._mdl.prjFile is not None:
                self.close_project()
            self.plugins.on_quit()
            self._ui.on_quit()
        except Exception as ex:
            self._ui.show_error(str(ex), title='ERROR: Unhandled exception on exit')
            self._ui.root.quit()
        return 'break'

    def open_installationFolder(self, event=None):
        installDir = os.path.dirname(sys.argv[0])
        try:
            os.startfile(norm_path(installDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(installDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(installDir))
                except:
                    pass
        return 'break'

    def open_link(self, element, linkIndex):
        linkPath = list(element.links)[linkIndex]
        fullPath = element.links[linkPath]
        try:
            self.linkProcessor.open_link(linkPath, self.launchers)
        except:

            if fullPath is not None:
                newPath = self.linkProcessor.shorten_path(fullPath)
            else:
                newPath = ''
            try:
                self.linkProcessor.open_link(newPath, self.launchers)
            except Exception as ex:

                self._ui.show_error(
                    str(ex),
                    title=_('Cannot open link')
                    )
            else:
                links = element.links
                del links[linkPath]
                links[newPath] = fullPath
                element.links = links
                self._ui.set_status(_('Broken link fixed'))
        else:
            pathOk = self.linkProcessor.expand_path(linkPath)
            if fullPath != pathOk:
                links = element.links
                links[linkPath] = pathOk
                element.links = links
                self._ui.set_status(_('Broken link fixed'))

    def open_project(self, event=None, filePath='', doNotSave=False):
        self._ui.restore_status()
        filePath = self.select_project(filePath)
        if not filePath:
            return False

        prefs['last_open'] = filePath

        if self._mdl.prjFile is not None:
            self.close_project(doNotSave=doNotSave)
        try:
            self._mdl.open_project(filePath)
        except Error as ex:
            self.close_project(doNotSave=doNotSave)
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)}')
        self.enable_menu()

        self.refresh_views()
        self._ui.show_path(_('{0} (last saved on {1})').format(norm_path(self._mdl.prjFile.filePath), self._mdl.prjFile.fileDate))
        self.show_status()
        self._ui.contentsView.view_text()
        if self._mdl.prjFile.has_lockfile():
            self.lock()
        self._ui.tv.show_branch(CH_ROOT)
        return True

    def open_project_folder(self, event=None):
        if not self.save_project():
            if not self._mdl:
                return

            if not self._mdl.prjFile:
                return

            if self._mdl.prjFile.filePath is None:
                return

        projectDir, __ = os.path.split(self._mdl.prjFile.filePath)
        try:
            os.startfile(norm_path(projectDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(projectDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(projectDir))
                except:
                    pass
        return 'break'

    def refresh(self):
        self.show_status()

    def refresh_views(self, event=None):
        self._ui.propertiesView.apply_changes()
        self._mdl.renumber_chapters()
        self._mdl.prjFile.adjust_section_types()
        self._mdl.novel.update_plot_lines()
        self._ui.refresh()
        return 'break'

    def reload_project(self, event=None):
        if self._mdl.prjFile is None:
            return 'break'

        if self._mdl.isModified and not self._ui.ask_yes_no(_('Discard changes and reload the project?')):
            return 'break'

        if self._mdl.prjFile.has_changed_on_disk() and not self._ui.ask_yes_no(_('File has changed on disk. Reload anyway?')):
            return 'break'

        if self.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True):
            self._ui.set_status(_('Project successfully restored from disk.'))
        return 'break'

    def reset_tree(self, event=None):
        self._mdl.reset_tree()

    def restore_backup(self, event=None):
        if self._mdl.prjFile is None:
            return 'break'

        latestBackup = f'{self._mdl.prjFile.filePath}.bak'
        if not os.path.isfile(latestBackup):
            self._ui.set_status(f'!{_("No backup available")}')
            return 'break'

        if self._mdl.isModified:
            if not self._ui.ask_yes_no(_('Discard changes and restore the latest backup?')):
                return 'break'

        elif not self._ui.ask_yes_no(_('Restore the latest backup?')):
            return 'break'

        try:
            os.replace(latestBackup, self._mdl.prjFile.filePath)
        except Exception as ex:
            self._ui.set_status(str(ex))
        else:
            if self.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True):
                self._ui.set_status(_('Latest backup successfully restored.'))
        return 'break'

    def save_as(self, event=None):
        if self._mdl.prjFile is None:
            return False

        if prefs['last_open']:
            startDir, __ = os.path.split(prefs['last_open'])
        else:
            startDir = '.'
        fileName = filedialog.asksaveasfilename(
            filetypes=self._fileTypes,
            defaultextension=self._fileTypes[0][1],
            initialdir=startDir,
            )
        if fileName:
            if self._mdl.prjFile is not None:
                self._ui.propertiesView.apply_changes()
                try:
                    self._mdl.save_project(fileName)
                except Error as ex:
                    self._ui.set_status(f'!{str(ex)}')
                else:
                    self.unlock()
                    self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)} ({_("last saved on")} {self._mdl.prjFile.fileDate})')
                    self._ui.restore_status()
                    prefs['last_open'] = self._mdl.prjFile.filePath
                    return True

        return False

    def save_project(self, event=None):
        if self._mdl.prjFile is None:
            return False

        if self.check_lock():
            self._ui.set_status(f'!{_("Cannot save: The project is locked")}.')
            return False

        if self._mdl.prjFile.filePath is None:
            return self.save_as()

        if self._mdl.prjFile.has_changed_on_disk() and not self._ui.ask_yes_no(_('File has changed on disk. Save anyway?')):
            return False

        self._ui.propertiesView.apply_changes()
        try:
            self._mdl.save_project()
        except Error as ex:
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)} ({_("last saved on")} {self._mdl.prjFile.fileDate})')
        self._ui.restore_status()
        prefs['last_open'] = self._mdl.prjFile.filePath
        return True

    def select_project(self, fileName):
        initDir = os.path.dirname(prefs.get('last_open', ''))
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileName = filedialog.askopenfilename(
                filetypes=self._fileTypes,
                defaultextension=NvWorkFile.EXTENSION,
                initialdir=initDir
                )
        if not fileName:
            return ''

        return fileName

    def set_character_status(self, isMajor, elemIds=None):
        if self.check_lock():
            return

        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._ui.tv.open_children(CR_ROOT)
        self._mdl.set_character_status(isMajor, elemIds)

    def set_level(self, newLevel, elemIds=None):
        if self.check_lock():
            return

        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._mdl.set_level(newLevel, elemIds)

    def set_completion_status(self, newStatus, elemIds=None):
        if self.check_lock():
            return

        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._ui.tv.open_children(elemIds[0])
        self._mdl.set_completion_status(newStatus, elemIds)

    def set_type(self, newType, elemIds=None):
        if self.check_lock():
            return

        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._ui.tv.open_children(elemIds[0])
        self._mdl.set_type(newType, elemIds)

    def show_report(self, suffix):
        if self._mdl.prjFile.filePath is None:
            return False

        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        reporter = NvHtmlReporter()
        try:
            reporter.run(self._mdl.prjFile, suffix, tempdir=self.tempDir)
        except Error as ex:
            self._ui.set_status(f'!{str(ex)}')

    def show_status(self, message=None):
        if self._mdl.novel is not None and not message:
            wordCount, sectionCount, chapterCount, partCount = self._mdl.get_counts()
            message = _('{0} parts, {1} chapters, {2} sections, {3} words').format(partCount, chapterCount, sectionCount, wordCount)
            self.wordCount = wordCount
        self._ui.show_status(message)

    def toggle_lock(self, event=None):
        if self.isLocked:
            self.unlock()
        else:
            self.lock()
        return 'break'

    def unlock(self, event=None):
        self._internalLockFlag = False
        self._ui.unlock()
        self.plugins.unlock()
        self._mdl.prjFile.unlock()
        if self._mdl.prjFile.has_changed_on_disk():
            if self._ui.ask_yes_no(_('File has changed on disk. Reload?')):
                self.open_project(filePath=self._mdl.prjFile.filePath)
        return 'break'

    def update_from_odt(self, suffix='', event=None):
        fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        self.import_odf(sourcePath=f'{fileName}{suffix}.odt')
        return 'break'

    def update_project(self, event=None):
        offset = 300
        __, x, y = self._ui.root.geometry().split('+')
        PrjUpdater(self._mdl, self._ui, self, f'+{int(x)+offset}+{int(y)+offset}')
        return 'break'

    def _view_new_element(self, newNode):
        if newNode:
            self._ui.tv.go_to_node(newNode)
            self._ui.propertiesView.show_properties(newNode)
            self._ui.propertiesView.focus_title()
        else:
            self._ui.set_status(f'!{_("Cannot create the element at this position")}.')


SETTINGS = dict(
    arcs_width=55,
    color_1st_edit='DarkGoldenrod4',
    color_2nd_edit='DarkGoldenrod3',
    color_arc='maroon',
    color_before_schedule='lime green',
    color_behind_schedule='magenta',
    color_chapter='green',
    color_done='DarkGoldenrod2',
    color_draft='black',
    color_locked_bg='dim gray',
    color_locked_fg='light gray',
    color_major='navy',
    color_minor='cornflower blue',
    color_modified_bg='goldenrod1',
    color_modified_fg='maroon',
    color_notes_bg='lemon chiffon',
    color_notes_fg='black',
    color_on_schedule='black',
    color_outline='dark orchid',
    color_stage='red',
    color_text_bg='white',
    color_text_fg='black',
    color_unused='gray',
    coloring_mode='',
    column_order='wc;vp;sy;st;nt;dt;tm;dr;tg;po;ac;pt;ar',
    date_width=70,
    duration_width=55,
    gco_height=4,
    gui_theme='',
    import_mode='0',
    index_card_height=13,
    last_open='',
    middle_frame_width=400,
    nt_width=20,
    points_width=300,
    prop_win_geometry='299x716+260+260',
    ps_width=50,
    right_frame_width=350,
    root_geometry='1200x800',
    scene_width=40,
    status_width=100,
    tags_width=100,
    time_width=40,
    title_width=400,
    vp_width=100,
    wc_width=50,
    )
OPTIONS = dict(
    ask_doc_open=True,
    detach_prop_win=False,
    enable_hovertips=True,
    large_icons=False,
    localize_date=True,
    lock_on_export=False,
    show_auto_numbering=False,
    show_ch_links=False,
    show_contents=True,
    show_cr_bio=True,
    show_cr_goals=True,
    show_cr_links=False,
    show_date_time=False,
    show_it_links=False,
    show_language_settings=False,
    show_lc_links=False,
    show_markup=False,
    show_narrative_time=False,
    show_pl_links=False,
    show_plot=False,
    show_pn_links=False,
    show_pp_links=False,
    show_pr_links=False,
    show_properties=True,
    show_relationships=False,
    show_renamings=False,
    show_sc_links=False,
    show_scene=False,
    show_st_links=False,
    show_writing_progress=False,
)


def main():
    try:
        homeDir = str(Path.home()).replace('\\', '/')
        installDir = f'{homeDir}/.novx'
    except:
        installDir = '.'
    os.makedirs(installDir, exist_ok=True)
    configDir = f'{installDir}/config'
    os.makedirs(configDir, exist_ok=True)
    tempDir = f'{installDir}/temp'
    os.makedirs(tempDir, exist_ok=True)

    iniFile = f'{configDir}/novx.ini'
    configuration = Configuration(SETTINGS, OPTIONS)
    configuration.read(iniFile)
    prefs.update(configuration.settings)
    prefs.update(configuration.options)

    app = NvController('novelibre 4.11.11', tempDir)
    ui = app.get_view()

    launcherConfig = NvConfiguration()
    launcherConfig.read(f'{configDir}/launchers.ini')
    app.launchers = launcherConfig.settings

    try:
        sourcePath = sys.argv[1]
    except:
        sourcePath = ''
    if not sourcePath or not os.path.isfile(sourcePath):
        sourcePath = prefs['last_open']
    if sourcePath and os.path.isfile(sourcePath):
        app.open_project(filePath=sourcePath)

    ui.start()

    for keyword in prefs:
        if keyword in configuration.options:
            configuration.options[keyword] = prefs[keyword]
        elif keyword in configuration.settings:
            configuration.settings[keyword] = prefs[keyword]
    configuration.write(iniFile)

    for file in os.scandir(tempDir):
        try:
            os.remove(file)
        except:
            pass


if __name__ == '__main__':
    main()
