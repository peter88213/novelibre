#!/usr/bin/python3
"""A novel organizer for writers. 

Version 5.60.0
Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/novelibre
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify \
it under the terms of the GNU General Public License as published by \
the Free Software Foundation, either version 3 of the License, or \
(at your option) any later version.

This program is distributed in the hope that it will be useful, \
but WITHOUT ANY WARRANTY; without even the implied warranty of \
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the \
GNU General Public License for more details.
"""
import os
import sys

from configparser import ConfigParser

from abc import ABC, abstractmethod


class ConfigurationBase(ABC):

    def __init__(self, settings=None, options=None, filePath=None):
        self.settings = None
        self.options = None
        self.filePath = filePath
        self.strLabel = 'SETTINGS'
        self.boolLabel = 'OPTIONS'
        self.set(
            settings=settings,
            options=options,
        )

    @abstractmethod
    def read(self):
        pass

    def set(self, settings=None, options=None):
        self.settings = (settings or {}).copy()
        self.options = (options or {}).copy()

    @abstractmethod
    def write(self):
        pass



class Configuration(ConfigurationBase):

    def read(self, filePath=None):
        self.filePath = self.filePath or filePath

        config = ConfigParser()
        config.read(self.filePath, encoding='utf-8')
        if self.strLabel in config:
            section = config[self.strLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if self.boolLabel in config:
            section = config[self.boolLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, filePath=None):
        self.filePath = self.filePath or filePath

        config = ConfigParser()
        if self.settings:
            config.add_section(self.strLabel)
            for settingId in self.settings:
                config.set(
                    self.strLabel,
                    settingId,
                    str(self.settings[settingId]),
                )
        if self.options:
            config.add_section(self.boolLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self.boolLabel, settingId, 'Yes')
                else:
                    config.set(self.boolLabel, settingId, 'No')
        with open(self.filePath, 'w', encoding='utf-8') as f:
            config.write(f)
from configparser import ConfigParser



class JustSettings(Configuration):

    def read(self):
        config = ConfigParser()
        config.read(self.filePath, encoding='utf-8')
        if config.has_section(self.strLabel):
            section = config[self.strLabel]
            for setting in section:
                self.settings[setting] = section[setting]


import webbrowser


import gettext
import locale

try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class NvHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/'

    @classmethod
    def open_help_page(cls, page):
        webbrowser.open(f'{cls.HELP_URL}{page}')

from tkinter import filedialog
from tkinter import ttk



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import platform



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'Alt-{_("Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'Alt-{_("Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'Alt-{_("Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'Alt-{_("Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    CHOOSE_COLOR = '<Button-1>'
    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<B1-Motion>'
    RESET_COLOR = '<Shift-Button-1>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Option-n>', 'Cmd-Option-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Option-N>', 'Cmd-Option-Shift-N')
    BACK = ('<Option-Left>', f'Option-{_("Left")}')
    CHAPTER_LEVEL = ('<Command-Option-c>', 'Cmd-Option-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Option-d>', 'Cmd-Option-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    FORWARD = ('<Option-Right>', f'Option-{_("Right")}')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    NEXT = ('<Option-Down>', f'Option-{_("Down")}')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    PREVIOUS = ('<Option-Up>', f'Option-{_("Up")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Option-t>', 'Cmd-Option-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')



class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from tkinter import ttk


class LabelDisp(ttk.Frame):

    def __init__(self, parent, text, textvariable, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._leftLabel = ttk.Label(
            self,
            text=text,
            anchor='w',
            width=lblWidth,
        )
        self._leftLabel.pack(side='left')
        self._rightLabel = ttk.Label(
            self,
            textvariable=textvariable,
            anchor='w',
        )
        self._rightLabel.pack(side='left', fill='x', expand=True)

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None):
        if text is not None:
            self._leftLabel['text'] = text
from abc import abstractmethod

import tkinter as tk


class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()




ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHAPTER_BOARD_SUFFFIX = '_sectioncards'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_REPORT_SUFFIX = '_grid_report'
GRID_SUFFIX = '_grid_tmp'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOT_LINE_BOARD_SUFFIX = '_plotcards'
PROJECTNOTES_REPORT_SUFFIX = '_projectnotes_report'
PROJECTNOTES_SUFFIX = '_projectnotes_tmp'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
STORY_STRUCT_BOARD_SUFFIX = '_stagecards'
TIMETABLE_SUFFIX = '_tt_tmp'
VIEWPOINT_BOARD_SUFFFIX = '_viewpoint_board'
XREF_SUFFIX = '_xref'

MAJOR_MARKER = _('Major Character')

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        return divider.join(elements)

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr



def open_document(document):
    if PLATFORM == 'win':
        os.startfile(norm_path(document))
        return

    if PLATFORM == 'ix':
        os.system('xdg-open "%s"' % norm_path(document))
        return

    if PLATFORM == 'mac':
        os.system('open "%s"' % norm_path(document))
from pathlib import Path

prefs = {}
launchers = {}

HOME_URL = 'https://github.com/peter88213/novelibre/'
NEWS_URL = 'https://github.com/peter88213/novelibre/discussions/1?sort=new'

HOME_DIR = str(Path.home()).replace('\\', '/')
INSTALL_DIR = f'{HOME_DIR}/.novx'
PROGRAM_DIR = os.path.dirname(sys.argv[0])
if not PROGRAM_DIR:
    PROGRAM_DIR = '.'
USER_STYLES_DIR = f'{INSTALL_DIR}/styles'
USER_STYLES_XML = f'{USER_STYLES_DIR}/styles.xml'

NOT_ASSIGNED = ''


def to_string(text):
    return str(text or '')



class BackupOptionsDialog(ModalDialog, SubController):
    LABEL_WIDTH = 20

    def __init__(self, view, **kw):
        super().__init__(view, **kw)
        self._ui = view
        self._ui.restore_status()

        self.title(_('Backup options'))
        self.iconphoto(False, view.icons.settingsIcon)
        window = ttk.Frame(self)
        window.pack(
            fill='both',
            padx=50,
            pady=5
        )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')

        self._backupDirVar = tk.StringVar(
            frame1,
            value=prefs['backup_dir']
        )
        self.backupDirDisplay = LabelDisp(
            frame1,
            f"{_('Backup directory')}:",
            self._backupDirVar,
            lblWidth=self.LABEL_WIDTH,
            )

        ttk.Button(
            frame1,
            text=_('Change backup directory'),
            command=self._set_backup_dir,
        ).pack(anchor='w', fill='x')

        ttk.Button(
            frame1,
            text=_('Open backup directory'),
            command=self._open_backup_dir,
        ).pack(anchor='w', fill='x')

        self._enableBackupVar = tk.BooleanVar(
            frame1,
            value=prefs['enable_backup']
        )
        ttk.Checkbutton(
            frame1,
            text=_('Create backup copies'),
            variable=self._enableBackupVar,
            command=self._change_enable_backup,
        ).pack(padx=5, pady=5, anchor='w')
        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_enable_backup(self, *args):
        prefs['enable_backup'] = self._enableBackupVar.get()
        if not prefs['enable_backup']:
            return

        if not os.path.isdir(prefs['backup_dir']):
            self._set_backup_dir()

    def _open_backup_dir(self):
        self._ui.restore_status()
        if not os.path.isdir(prefs['backup_dir']):
            self._ui.set_status(
                (
                    f'#{_("Backup directory not found")}. '
                    f'{_("Please check the setting")}.'
                )
            )
            return

        try:
            open_document(prefs['backup_dir'])
        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')

    def _open_help(self, event=None):
        NvHelp.open_help_page(
            f'tools_menu.html#{_("backup-options")}')

    def _set_backup_dir(self):
        self._ui.restore_status()
        if os.path.isdir(prefs['backup_dir']):
            initDir = prefs['backup_dir']
        else:
            initDir = HOME_DIR
        backupDir = filedialog.askdirectory(initialdir=initDir)
        if not backupDir:
            self._ui.set_status(
                f'#{_("Action canceled by user")}.')
            return

        prefs['backup_dir'] = backupDir
        self._backupDirVar.set(norm_path(backupDir))
from tkinter import ttk



class ExportOptionsDialog(ModalDialog, SubController):

    def __init__(self, view, controller, **kw):
        super().__init__(view, **kw)
        self._ctrl = controller

        self.title(_('"Export" options'))
        self.iconphoto(False, view.icons.settingsIcon)
        window = ttk.Frame(self)
        window.pack(
            fill='both',
            pady=5
        )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', padx=50)

        self._askDocOpenVar = tk.BooleanVar(
            frame1,
            value=prefs['ask_doc_open'],
        )
        ttk.Checkbutton(
            frame1,
            text=_('Ask before opening exported documents'),
            variable=self._askDocOpenVar,
            command=self._change_ask_doc_open,
        ).pack(padx=5, pady=5, anchor='w')

        self._lockOnExportVar = tk.BooleanVar(
            frame1,
            value=prefs['lock_on_export'],
        )
        ttk.Checkbutton(
            frame1,
            text=_('Lock the project after document export for editing'),
            variable=self._lockOnExportVar,
            command=self._change_lock_on_export,
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(window, orient='horizontal').pack(fill='x')

        frame2 = ttk.Frame(window)
        frame2.pack(fill='both', padx=50)

        ttk.Button(
            frame2,
            text=_('Select document template'),
            command=self._ctrl.fileManager.set_user_styles,
        ).pack(padx=5, pady=5, anchor='w', fill='x')

        ttk.Button(
            frame2,
            text=_('Restore default styles'),
            command=self._ctrl.fileManager.restore_default_styles,
        ).pack(padx=5, pady=5, anchor='w', fill='x')

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_ask_doc_open(self, *args):
        prefs['ask_doc_open'] = self._askDocOpenVar.get()

    def _change_lock_on_export(self, *args):
        prefs['lock_on_export'] = self._lockOnExportVar.get()

    def _open_help(self, event=None):
        NvHelp.open_help_page(f'export_menu.html#{_("options").lower()}')

from tkinter import ttk



class PluginManagerDialog(ModalDialog, SubController):
    MIN_HEIGHT = 450

    def __init__(self, view, controller, **kw):
        super().__init__(view, **kw)
        self.minsize(1, self.MIN_HEIGHT)
        self._ui = view
        self._ctrl = controller

        self.title(f'{_("Installed plugins")} - novelibre 5.60.0')
        self.iconphoto(False, view.icons.pluginsIcon)

        columns = (
            'Plugin',
            'Version',
            'novelibre API',
            'Description',
        )
        self._pluginTree = ttk.Treeview(
            self,
            columns=columns,
            show='headings',
            selectmode='browse',
        )


        self._pluginTree.pack(fill='both', expand=True)
        self._pluginTree.bind('<<TreeviewSelect>>', self._on_select_plugin)
        self._pluginTree.tag_configure('rejected', foreground='red')
        self._pluginTree.tag_configure('inactive', foreground='gray')

        self._pluginTree.column(
            'Plugin',
            width=150,
            minwidth=120,
            stretch=False,
        )
        self._pluginTree.heading(
            'Plugin',
            text=_('Plugin'),
            anchor='w',
        )
        self._pluginTree.column(
            'Version',
            width=100,
            minwidth=100,
            stretch=False,
        )
        self._pluginTree.heading(
            'Version',
            text=_('Version'),
            anchor='w',
        )
        self._pluginTree.column(
            'novelibre API',
            width=100,
            minwidth=100,
            stretch=False,
        )
        self._pluginTree.heading(
            'novelibre API',
            text=_('novelibre API'),
            anchor='w',
        )
        self._pluginTree.column(
            'Description',
            width=400,
            stretch=True,
        )
        self._pluginTree.heading(
            'Description',
            text=_('Description'),
            anchor='w',
        )

        for pluginName in self._ctrl.plugins:
            nodeTags = []
            try:
                version = self._ctrl.plugins[pluginName].VERSION
            except AttributeError:
                version = _('unknown')
            try:
                description = self._ctrl.plugins[pluginName].DESCRIPTION
            except AttributeError:
                description = _('No description')
            try:
                apiRequired = self._ctrl.plugins[pluginName].API_VERSION
            except AttributeError:
                try:
                    apiRequired = self._ctrl.plugins[pluginName].NOVELTREE_API
                except AttributeError:
                    apiRequired = _('unknown')
            columns = [
                pluginName,
                version,
                apiRequired,
                description,
            ]
            if self._ctrl.plugins[pluginName].isRejected:
                nodeTags.append('rejected')
            elif not self._ctrl.plugins[pluginName].isActive:
                nodeTags.append('inactive')
            self._pluginTree.insert(
                '',
                'end',
                pluginName,
                values=columns,
                tags=tuple(nodeTags),
            )

        self._footer = ttk.Frame(self)
        self._footer.pack(fill='both', expand=False)

        self._homeButton = ttk.Button(
            self._footer,
            text=_('Home page'),
            command=self._open_homepage,
            state='disabled'
        )
        self._homeButton.pack(padx=5, pady=5, side='left')

        self._deleteButton = ttk.Button(
            self._footer,
            text=_('Uninstall'),
            command=self._uninstall_plugin,
            state='disabled'
        )
        self._deleteButton.pack(padx=5, pady=5, side='left')

        ttk.Button(
            self._footer,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self._footer,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _uninstall_plugin(self, event=None):
        pluginName = self._pluginTree.selection()[0]
        if not pluginName:
            return

        if not pluginName in self._ctrl.plugins:
            return

        if not self._ctrl.plugins[pluginName].filePath:
            return

        if not self._ui.ask_yes_no(
            message=_('Delete file?'),
            detail=self._ctrl.plugins[pluginName].filePath,
            title=_('Plugin Manager'),
            parent=self
        ):
            return

        if self._ctrl.plugins.uninstall_plugin(pluginName):
            self._deleteButton.configure(state='disabled')
            if self._ctrl.plugins[pluginName].isActive:
                self._ui.show_info(
                    message=_("Uninstalled {}").format(pluginName),
                    detail=(
                        f"{_('The plugin remains active until next start')}."
                    ),
                    title=_('Plugin Manager'),
                    parent=self
                )
            else:
                self._pluginTree.delete(pluginName)

    def _on_select_plugin(self, event):
        try:
            pluginName = self._pluginTree.selection()[0]
        except IndexError:
            return

        homeButtonState = 'disabled'
        deleteButtonState = 'disabled'
        if pluginName:
            try:
                if self._ctrl.plugins[pluginName].URL:
                    homeButtonState = 'normal'
            except:
                pass
            try:
                if self._ctrl.plugins[pluginName].filePath:
                    deleteButtonState = 'normal'
            except:
                pass
        self._homeButton.configure(state=homeButtonState)
        self._deleteButton.configure(state=deleteButtonState)

    def _open_help(self, event=None):
        NvHelp.open_help_page(f'tools_menu.html#{_("plugin-manager")}')

    def _open_homepage(self, event=None):
        pluginName = self._pluginTree.selection()[0]
        if pluginName:
            try:
                url = self._ctrl.plugins[pluginName].URL
                if url:
                    webbrowser.open(url)
            except:
                pass

from datetime import datetime
from tkinter import ttk


from datetime import date



class BasicElement:

    def __init__(
        self,
        on_element_change=None,
        title=None,
        desc=None,
        links=None,
        fields=None,
        color=None,
    ):
        self.on_element_change = on_element_change or self.do_nothing
        self._title = title
        self._desc = desc
        self._color = color
        self._links = links or {}
        self._fields = fields or {}

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._title != newVal:
            self._title = newVal
            self.on_element_change()

    @property
    def desc(self):
        return self._desc

    @desc.setter
    def desc(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._desc != newVal:
            self._desc = newVal
            self.on_element_change()

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._color != newVal:
            self._color = newVal
            self.on_element_change()

    @property
    def links(self):
        try:
            return self._links.copy()
        except AttributeError:
            return None

    @links.setter
    def links(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) is str
        if self._links != newVal:
            self._links = newVal
            self.on_element_change()

    @property
    def fields(self):
        return self._fields.copy()

    @fields.setter
    def fields(self, newVal):
        if self._fields != newVal:
            self._fields = newVal
            self.on_element_change()

    def do_nothing(self):
        pass




class BasicElementNotes(BasicElement):

    def __init__(
        self,
        notes=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._notes = notes

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()



class Chapter(BasicElementNotes):

    def __init__(
        self,
        chLevel=None,
        chType=None,
        noNumber=None,
        isTrash=None,
        hasEpigraph=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._chLevel = chLevel
        self._chType = chType
        self._noNumber = noNumber
        self._isTrash = isTrash
        self._hasEpigraph = hasEpigraph

    @property
    def chLevel(self):
        return self._chLevel

    @chLevel.setter
    def chLevel(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._chLevel != newVal:
            self._chLevel = newVal
            self.on_element_change()

    @property
    def chType(self):
        return self._chType

    @chType.setter
    def chType(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._chType != newVal:
            self._chType = newVal
            self.on_element_change()

    @property
    def noNumber(self):
        return self._noNumber

    @noNumber.setter
    def noNumber(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._noNumber != newVal:
            self._noNumber = newVal
            self.on_element_change()

    @property
    def isTrash(self):
        return self._isTrash

    @isTrash.setter
    def isTrash(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._isTrash != newVal:
            self._isTrash = newVal
            self.on_element_change()

    @property
    def hasEpigraph(self):
        return self._hasEpigraph

    @hasEpigraph.setter
    def hasEpigraph(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._hasEpigraph != newVal:
            self._hasEpigraph = newVal
            self.on_element_change()



class BasicElementTags(BasicElementNotes):

    def __init__(
        self,
        tags=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._tags = tags or []

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) is str
        if self._tags != newVal:
            self._tags = newVal
            self.on_element_change()



class WorldElement(BasicElementTags):

    def __init__(
        self,
        aka=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._aka = aka

    @property
    def aka(self):
        return self._aka

    @aka.setter
    def aka(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._aka != newVal:
            self._aka = newVal
            self.on_element_change()



class Character(WorldElement):

    def __init__(
        self,
        bio=None,
        goals=None,
        fullName=None,
        isMajor=None,
        birthDate=None,
        deathDate=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._bio = bio
        self._goals = goals
        self._fullName = fullName
        self._isMajor = isMajor
        self._birthDate = birthDate
        self._deathDate = deathDate

    @property
    def bio(self):
        return self._bio

    @bio.setter
    def bio(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._bio != newVal:
            self._bio = newVal
            self.on_element_change()

    @property
    def goals(self):
        return self._goals

    @goals.setter
    def goals(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._goals != newVal:
            self._goals = newVal
            self.on_element_change()

    @property
    def fullName(self):
        return self._fullName

    @fullName.setter
    def fullName(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._fullName != newVal:
            self._fullName = newVal
            self.on_element_change()

    @property
    def isMajor(self):
        return self._isMajor

    @isMajor.setter
    def isMajor(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._isMajor != newVal:
            self._isMajor = newVal
            self.on_element_change()

    @property
    def birthDate(self):
        return self._birthDate

    @birthDate.setter
    def birthDate(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._birthDate != newVal:
            self._birthDate = newVal
            self.on_element_change()

    @property
    def deathDate(self):
        return self._deathDate

    @deathDate.setter
    def deathDate(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._deathDate != newVal:
            self._deathDate = newVal
            self.on_element_change()



class PlotLine(BasicElementNotes):

    def __init__(
        self,
        shortName=None,
        sections=None,
        **kwargs
    ):
        super().__init__(**kwargs)

        self._shortName = shortName
        self._sections = sections or []

    @property
    def shortName(self):
        return self._shortName

    @shortName.setter
    def shortName(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._shortName != newVal:
            self._shortName = newVal
            self.on_element_change()

    @property
    def sections(self):
        try:
            return self._sections[:]
        except TypeError:
            return None

    @sections.setter
    def sections(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) is str
        if self._sections != newVal:
            self._sections = newVal
            self.on_element_change()



class PlotPoint(BasicElementNotes):

    def __init__(
        self,
        sectionAssoc=None,
        **kwargs
    ):
        super().__init__(**kwargs)

        self._sectionAssoc = sectionAssoc

    @property
    def sectionAssoc(self):
        return self._sectionAssoc

    @sectionAssoc.setter
    def sectionAssoc(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._sectionAssoc != newVal:
            self._sectionAssoc = newVal
            self.on_element_change()


from calendar import isleap, day_name, month_name
from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta



class PyCalendar:

    DATE_FORMAT = _("YYYY-MM-DD")
    TIME_FORMAT = _("hh:mm")
    WEEKDAYS = day_name
    MONTHS = month_name
    min = date.min.isoformat()
    max = date.max.isoformat()

    @classmethod
    def age(cls, nowIso, birthDateIso, deathDateIso):
        now = datetime.fromisoformat(nowIso)
        if deathDateIso:
            deathDate = datetime.fromisoformat(deathDateIso)
            if now > deathDate:
                yearsDead = cls._difference_in_years(deathDate, now)
                daysDead = cls._difference_in_days(deathDate, now)
                if birthDateIso:
                    birthDate = datetime.fromisoformat(birthDateIso)
                    yearsOld = cls._difference_in_years(birthDate, deathDate)
                else:
                    yearsOld = None
                return yearsOld, yearsDead, None, daysDead

        if birthDateIso:
            birthDate = datetime.fromisoformat(birthDateIso)
            yearsOld = cls._difference_in_years(birthDate, now)
            daysOld = cls._difference_in_days(birthDate, now)
        return yearsOld, None, daysOld, None

    @classmethod
    def dt_disp(cls, day, dateStr, timeIso):
        dt = []
        if day:
            dt.append(f'{_("Day")} {day}')
        if dateStr:
            dt.append(dateStr)
        if timeIso:
            dt.append(cls.time_disp(timeIso))
        return ' '.join(dt)

    @classmethod
    def duration(cls, startDateIso, startTimeIso, endDateIso, endTimeIso):
        StartDateTime = datetime.fromisoformat(
            f'{startDateIso}T{startTimeIso}'
        )
        endDateTime = datetime.fromisoformat(f'{endDateIso}T{endTimeIso}')
        durationTimedelta = endDateTime - StartDateTime
        lastsHours = durationTimedelta.seconds // 3600
        lastsMinutes = (durationTimedelta.seconds % 3600) // 60
        if durationTimedelta.days:
            daysStr = str(durationTimedelta.days)
        else:
            daysStr = None
        if lastsHours:
            hoursStr = str(lastsHours)
        else:
            hoursStr = None
        if lastsMinutes:
            minutesStr = str(lastsMinutes)
        else:
            minutesStr = None
        return daysStr, hoursStr, minutesStr

    @classmethod
    def duration_disp(cls, lastsDays, lastsHours, lastsMinutes):
        duration = []
        if lastsDays and lastsDays != '0':
            duration.append(f"{lastsDays}{_('d')}")
        if lastsHours and lastsHours != '0':
            duration.append(f"{lastsHours}{_('h')}")
        if lastsMinutes and lastsMinutes != '0':
            duration.append(f"{lastsMinutes}{_('min')}")
        return ' '.join(duration)

    @classmethod
    def get_duration_str(cls, section):
        return cls.duration_disp(
            section.lastsDays,
            section.lastsHours,
            section.lastsMinutes
        )

    @classmethod
    def get_end_date_time(cls, section):
        sectionStart = datetime.fromisoformat(
            f'{section.date} {section.time}'
        )
        sectionEnd = sectionStart + cls._get_duration(section)
        return sectionEnd.isoformat().split('T')

    @classmethod
    def get_end_day_time(cls, section):
        if section.day:
            dayInt = int(section.day)
        else:
            dayInt = 0
        virtualStartDate = (date.min + timedelta(days=dayInt)).isoformat()
        virtualSectionStart = datetime.fromisoformat(
            f'{virtualStartDate} {section.time}'
        )
        virtualSectionEnd = virtualSectionStart + cls._get_duration(section)
        virtualEndDate, endTime = virtualSectionEnd.isoformat().split('T')
        endDay = str((date.fromisoformat(virtualEndDate) - date.min).days)
        return (endDay, endTime)

    @classmethod
    def get_end_time(cls, section):
        virtualSectionStart = datetime.fromisoformat(
            f'{cls.min} {section.time}'
        )
        virtualSectionEnd = virtualSectionStart + cls._get_duration(section)
        return virtualSectionEnd.isoformat().split('T')[1]

    @classmethod
    def get_locale_date(cls, isoDate, localize):
        if localize:
            try:
                localeDateStr = cls.locale_date(isoDate)
            except:
                localeDateStr = ''
            return localeDateStr

        else:
            return isoDate

    @classmethod
    def get_timestamp(cls, section, refIso):
        if not section.time and not section.date and not section.day:
            return

        timeStr = section.time
        if not timeStr:
            timeStr = '00:00'
        if section.date:
            try:
                sectionStart = datetime.fromisoformat(
                    f'{section.date} {timeStr}'
                )
            except:
                return
        else:
            try:
                if section.day:
                    dayInt = int(section.day)
                else:
                    dayInt = 0
                startDate = (
                    date.fromisoformat(refIso) + timedelta(days=dayInt)
                ).isoformat()
                sectionStart = datetime.fromisoformat(f'{startDate} {timeStr}')
            except:
                return

        return int((sectionStart - datetime.min).total_seconds())

    @classmethod
    def h_m_s_str(cls, timeIso):
        return timeIso.split(':')

    @classmethod
    def locale_date(cls, dateIso):
        return date.fromisoformat(dateIso).strftime('%x')

    @classmethod
    def specific_date(cls, dayStr, refIso):
        refDate = date.fromisoformat(refIso)
        return date.isoformat(refDate + timedelta(days=int(dayStr)))

    @classmethod
    def time_disp(cls, timeIso):
        h, m, __ = cls.verified_time(timeIso).split(':')
        return f'{h}:{m}'

    @classmethod
    def unspecific_date(cls, dateIso, refIso):
        refDate = date.fromisoformat(refIso)
        return str((date.fromisoformat(dateIso) - refDate).days)

    @classmethod
    def verified_date(cls, dateIso):
        if dateIso is not None:
            date.fromisoformat(dateIso)
        return dateIso

    @classmethod
    def verified_time(cls, timeIso):
        if  timeIso is not None:
            time.fromisoformat(timeIso)
            while timeIso.count(':') < 2:
                timeIso = f'{timeIso}:00'
        return timeIso

    @classmethod
    def weekday(cls, dateIso):
        return date.fromisoformat(dateIso).weekday()

    @classmethod
    def weekday_str(cls, timestamp):
        return (datetime.min + timedelta(seconds=timestamp)).strftime('%A')

    @classmethod
    def y_m_d_str(cls, dateIso):
        return dateIso.split('-')

    @classmethod
    def _difference_in_years(cls, startDate, endDate):
        diffyears = endDate.year - startDate.year
        difference = endDate - startDate.replace(endDate.year)
        days_in_year = isleap(endDate.year) and 366 or 365
        years = diffyears + (
            difference.days + difference.seconds / 86400.0
            ) / days_in_year
        return int(years)

    @classmethod
    def _difference_in_days(cls, startDate, endDate):
        return (endDate - startDate).days

    @classmethod
    def _get_duration(cls, section):
        if section.lastsDays:
            lastsDays = int(section.lastsDays)
        else:
            lastsDays = 0
        if section.lastsHours:
            lastsSeconds = int(section.lastsHours) * 3600
        else:
            lastsSeconds = 0
        if section.lastsMinutes:
            lastsSeconds += int(section.lastsMinutes) * 60
        return timedelta(days=lastsDays, seconds=lastsSeconds)

import re


class WordCounter:

    IGNORE_PATTERN = re.compile(
        r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>'
    )

    SEPARATOR_PATTERN = re.compile(r'—|–|\<\/p\>')

    def get_word_count(self, text):
        text = text.replace('\n', '')
        text = self.SEPARATOR_PATTERN.sub(' ', text)
        text = self.IGNORE_PATTERN.sub('', text)
        return len(text.split())


class Section(BasicElementTags):

    NULL_DATE = '0001-01-01'
    NULL_TIME = '00:00:00'

    wordCounter = WordCounter()

    def __init__(
        self,
        scType=None,
        scene=None,
        status=None,
        appendToPrev=None,
        viewpoint=None,
        goal=None,
        conflict=None,
        outcome=None,
        plotlineNotes=None,
        scDate=None,
        scTime=None,
        day=None,
        lastsMinutes=None,
        lastsHours=None,
        lastsDays=None,
        characters=None,
        locations=None,
        items=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._sectionContent = None
        self.wordCount = 0
        self._hasComment = False

        self._scType = scType
        self._scene = scene
        self._status = status
        self._appendToPrev = appendToPrev
        self._goal = goal
        self._conflict = conflict
        self._outcome = outcome
        self._plotlineNotes = plotlineNotes or {}
        try:
            self._weekDay = PyCalendar.weekday(scDate)
            self._localeDate = PyCalendar.locale_date(scDate)
            self._date = scDate
        except:
            self._weekDay = None
            self._localeDate = None
            self._date = None
        self._time = scTime
        self._day = day
        self._lastsMinutes = lastsMinutes
        self._lastsHours = lastsHours
        self._lastsDays = lastsDays
        self._viewpoint = viewpoint
        self._characters = characters or []
        self._locations = locations or []
        self._items = items or []

        self.scPlotLines = []
        self.scPlotPoints = {}

    @property
    def sectionContent(self):
        return self._sectionContent

    @sectionContent.setter
    def sectionContent(self, text):
        if text is not None:
            assert type(text) is str
        if self._sectionContent != text:
            self._sectionContent = text
            if text is not None:
                self.wordCount = self.wordCounter.get_word_count(text)
                self._hasComment = '<comment>' in self._sectionContent
            else:
                self.wordCount = 0
                self._hasComment = False
            self.on_element_change()

    @property
    def hasComment(self):
        return self._hasComment

    @property
    def scType(self):
        return self._scType

    @scType.setter
    def scType(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._scType != newVal:
            self._scType = newVal
            self.on_element_change()

    @property
    def scene(self):
        return self._scene

    @scene.setter
    def scene(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._scene != newVal:
            self._scene = newVal
            self.on_element_change()

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._status != newVal:
            self._status = newVal
            self.on_element_change()

    @property
    def appendToPrev(self):
        return self._appendToPrev

    @appendToPrev.setter
    def appendToPrev(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._appendToPrev != newVal:
            self._appendToPrev = newVal
            self.on_element_change()

    @property
    def goal(self):
        return self._goal

    @goal.setter
    def goal(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._goal != newVal:
            self._goal = newVal
            self.on_element_change()

    @property
    def conflict(self):
        return self._conflict

    @conflict.setter
    def conflict(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._conflict != newVal:
            self._conflict = newVal
            self.on_element_change()

    @property
    def outcome(self):
        return self._outcome

    @outcome.setter
    def outcome(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._outcome != newVal:
            self._outcome = newVal
            self.on_element_change()

    @property
    def plotlineNotes(self):
        try:
            return dict(self._plotlineNotes)
        except TypeError:
            return None

    @plotlineNotes.setter
    def plotlineNotes(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) is str
        if self._plotlineNotes != newVal:
            self._plotlineNotes = newVal
            self.on_element_change()

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._date != newVal:
            if not newVal:
                self._date = None
                self._weekDay = None
                self._localeDate = None
                self.on_element_change()
                return

            try:
                self._weekDay = PyCalendar.weekday(newVal)
            except:
                return

            try:
                self._localeDate = PyCalendar.locale_date(newVal)
            except:
                self._localeDate = newVal
            self._date = newVal
            self.on_element_change()

    @property
    def weekDay(self):
        return self._weekDay

    @property
    def localeDate(self):
        return self._localeDate

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._time != newVal:
            self._time = newVal
            self.on_element_change()

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._day != newVal:
            self._day = newVal
            self.on_element_change()

    @property
    def lastsMinutes(self):
        return self._lastsMinutes

    @lastsMinutes.setter
    def lastsMinutes(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._lastsMinutes != newVal:
            self._lastsMinutes = newVal
            self.on_element_change()

    @property
    def lastsHours(self):
        return self._lastsHours

    @lastsHours.setter
    def lastsHours(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._lastsHours != newVal:
            self._lastsHours = newVal
            self.on_element_change()

    @property
    def lastsDays(self):
        return self._lastsDays

    @lastsDays.setter
    def lastsDays(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._lastsDays != newVal:
            self._lastsDays = newVal
            self.on_element_change()

    @property
    def viewpoint(self):
        return self._viewpoint

    @viewpoint.setter
    def viewpoint(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._viewpoint != newVal:
            self._viewpoint = newVal
            self.on_element_change()

    @property
    def characters(self):
        try:
            return self._characters[:]
        except TypeError:
            return None

    @characters.setter
    def characters(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) is str
        if self._characters != newVal:
            self._characters = newVal
            self.on_element_change()

    @property
    def locations(self):
        try:
            return self._locations[:]
        except TypeError:
            return None

    @locations.setter
    def locations(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) is str
        if self._locations != newVal:
            self._locations = newVal
            self.on_element_change()

    @property
    def items(self):
        try:
            return self._items[:]
        except TypeError:
            return None

    @items.setter
    def items(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) is str
        if self._items != newVal:
            self._items = newVal
            self.on_element_change()

    def day_to_date(self, referenceDate):
        if self._date:
            return True

        try:
            self.date = PyCalendar.specific_date(self._day, referenceDate)
            self._day = None
            return True

        except:
            self.date = None
            return False

    def date_to_day(self, referenceDate):
        if self._day:
            return True

        try:
            self._day = PyCalendar.unspecific_date(self._date, referenceDate)
            self.date = None
            return True

        except:
            self._day = None
            return False

    def get_end_date_time(self):
        endDate = None
        endTime = None
        endDay = None
        if self.time:
            if self.date:
                try:
                    endDate, endTime = PyCalendar.get_end_date_time(self)
                except:
                    pass
            elif self.day:
                try:
                    endDay, endTime = PyCalendar.get_end_day_time(self)
                except:
                    pass
            else:
                endTime = PyCalendar.get_end_time(self)
        return endDate, endTime, endDay

from abc import ABC
from urllib.parse import quote



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.projectStructureModified = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        filePath = filePath.replace('\\', '/')
        suffix = self.SUFFIX or ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(
                tail.replace(f'{suffix}{self.EXTENSION}', '')
            )

    def is_locked(self):
        return False

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError

import xml.etree.ElementTree as ET


class BasicElementNovx:

    def import_data(self, element, xmlElement):
        element.title = self._get_element_text(xmlElement, 'Title')
        element.desc = self._xml_element_to_text(xmlElement.find('Desc'))
        element.color = xmlElement.get('color', None)
        element.links = self._get_link_dict(xmlElement)
        element.fields = self._get_fields(xmlElement)

    def export_data(self, element, xmlElement):
        if element.title:
            ET.SubElement(xmlElement, 'Title').text = element.title
        if element.desc:
            xmlElement.append(self._text_to_xml_element('Desc', element.desc))
        if element.color:
            xmlElement.set('color', element.color)
        for path in element.links:
            xmlLink = ET.SubElement(xmlElement, 'Link')
            ET.SubElement(xmlLink, 'Path').text = path
            if element.links[path]:
                ET.SubElement(xmlLink, 'FullPath').text = element.links[path]
        for tag in element.fields:
            xmlField = ET.SubElement(xmlElement, 'Field')
            xmlField.set('tag', tag)
            xmlField.text = element.fields[tag]

    def _get_element_text(self, xmlElement, tag, default=None):
        if xmlElement.find(tag) is not None:
            return xmlElement.find(tag).text
        else:
            return default

    def _get_fields(self, xmlElement):
        fields = {}
        for xmlField in xmlElement.iterfind('Field'):
            tag = xmlField.get('tag', None)
            if tag is not None:
                fields[tag] = xmlField.text
        return fields

    def _get_link_dict(self, xmlElement):
        links = {}
        for xmlLink in xmlElement.iterfind('Link'):
            xmlPath = xmlLink.find('Path')
            if xmlPath is not None:
                path = xmlPath.text
                xmlFullPath = xmlLink.find('FullPath')
                if xmlFullPath is not None:
                    fullPath = xmlFullPath.text
                else:
                    fullPath = None
            else:
                path = xmlLink.attrib.get('path', None)
                fullPath = xmlLink.attrib.get('fullPath', None)
            if path:
                links[path] = fullPath
        return links

    def _text_to_xml_element(self, tag, text):
        xmlElement = ET.Element(tag)
        if text:
            for line in text.split('\n'):
                ET.SubElement(xmlElement, 'p').text = line
        return xmlElement

    def _xml_element_to_text(self, xmlElement):
        lines = []
        if xmlElement is not None:
            for paragraph in xmlElement.iterfind('p'):
                lines.append(''.join(t for t in paragraph.itertext()))
        return '\n'.join(lines)




class BasicElementNotesNovx(BasicElementNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        element.notes = self._xml_element_to_text(xmlElement.find('Notes'))

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.notes:
            xmlElement.append(self._text_to_xml_element('Notes', element.notes))



class ChapterNovx(BasicElementNotesNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        typeStr = xmlElement.get('type', '0')
        if typeStr in ('0', '1'):
            element.chType = int(typeStr)
        else:
            element.chType = 1
        chLevel = xmlElement.get('level', '2')
        if chLevel in ('1', '2'):
            element.chLevel = int(chLevel)
        else:
            element.chLevel = 2
        element.isTrash = xmlElement.get('isTrash', None) == '1'
        element.noNumber = xmlElement.get('noNumber', None) == '1'
        element.hasEpigraph = xmlElement.get('hasEpigraph', None) == '1'

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.chType:
            xmlElement.set('type', str(element.chType))
        if element.chLevel == 1:
            xmlElement.set('level', '1')
        if element.isTrash:
            xmlElement.set('isTrash', '1')
        if element.noNumber:
            xmlElement.set('noNumber', '1')
        if element.hasEpigraph:
            xmlElement.set('hasEpigraph', '1')


class BasicElementTagsNovx(BasicElementNotesNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        tags = string_to_list(self._get_element_text(xmlElement, 'Tags'))
        strippedTags = []
        for tag in tags:
            strippedTags.append(tag.strip())
        element.tags = strippedTags

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        tagStr = list_to_string(element.tags)
        if tagStr:
            ET.SubElement(xmlElement, 'Tags').text = tagStr



class WorldElementNovx(BasicElementTagsNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        element.aka = self._get_element_text(xmlElement, 'Aka')

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.aka:
            ET.SubElement(xmlElement, 'Aka').text = element.aka



class CharacterNovx(WorldElementNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        element.isMajor = xmlElement.get('major', None) == '1'
        element.fullName = self._get_element_text(xmlElement, 'FullName')
        element.bio = self._xml_element_to_text(xmlElement.find('Bio'))
        element.goals = self._xml_element_to_text(xmlElement.find('Goals'))
        element.birthDate = PyCalendar.verified_date(
            self._get_element_text(xmlElement, 'BirthDate')
        )
        element.deathDate = PyCalendar.verified_date(
            self._get_element_text(xmlElement, 'DeathDate')
        )

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.isMajor:
            xmlElement.set('major', '1')
        if element.fullName:
            ET.SubElement(xmlElement, 'FullName').text = element.fullName
        if element.bio:
            xmlElement.append(self._text_to_xml_element('Bio', element.bio))
        if element.goals:
            xmlElement.append(self._text_to_xml_element('Goals', element.goals))
        if element.birthDate:
            ET.SubElement(xmlElement, 'BirthDate').text = element.birthDate
        if element.deathDate:
            ET.SubElement(xmlElement, 'DeathDate').text = element.deathDate



class NovelNovx(BasicElementNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        element.renumberChapters = xmlElement.get(
            'renumberChapters', None) == '1'
        element.renumberParts = xmlElement.get(
            'renumberParts', None) == '1'
        element.renumberWithinParts = xmlElement.get(
            'renumberWithinParts', None) == '1'
        element.romanChapterNumbers = xmlElement.get(
            'romanChapterNumbers', None) == '1'
        element.romanPartNumbers = xmlElement.get(
            'romanPartNumbers', None) == '1'
        element.saveWordCount = xmlElement.get(
            'saveWordCount', None) == '1'
        workPhase = xmlElement.get('workPhase', None)
        if workPhase in ('1', '2', '3', '4', '5'):
            element.workPhase = int(workPhase)
        else:
            element.workPhase = None

        element.authorName = self._get_element_text(xmlElement, 'Author')

        element.chapterHeadingPrefix = self._get_element_text(
            xmlElement,
            'ChapterHeadingPrefix'
        )
        element.chapterHeadingSuffix = self._get_element_text(
            xmlElement,
            'ChapterHeadingSuffix'
        )

        element.partHeadingPrefix = self._get_element_text(
            xmlElement,
            'PartHeadingPrefix'
        )
        element.partHeadingSuffix = self._get_element_text(
            xmlElement,
            'PartHeadingSuffix'
        )

        element.noSceneField1 = self._get_element_text(
            xmlElement,
            'CustomPlotProgress',
            default=element.noSceneField1,
        )
        element.noSceneField2 = self._get_element_text(
            xmlElement,
            'CustomCharacterization',
            default=element.noSceneField2,
        )
        element.noSceneField3 = self._get_element_text(
            xmlElement,
            'CustomWorldBuilding',
            default=element.noSceneField3,
        )

        element.otherSceneField1 = self._get_element_text(
            xmlElement,
            'CustomGoal',
            default=element.otherSceneField1,
        )
        element.otherSceneField2 = self._get_element_text(
            xmlElement,
            'CustomConflict',
            default=element.otherSceneField2,
        )
        element.otherSceneField3 = self._get_element_text(
            xmlElement,
            'CustomOutcome',
            default=element.otherSceneField3,
        )

        element.crField1 = self._get_element_text(
            xmlElement,
            'CustomChrBio',
            default=element.crField1,
        )
        element.crField2 = self._get_element_text(
            xmlElement,
            'CustomChrGoals',
            default=element.crField2,
        )

        if xmlElement.find('WordCountStart') is not None:
            element.wordCountStart = int(
                xmlElement.find('WordCountStart').text
            )
        else:
            element.wordCountStart = 0
        if xmlElement.find('WordTarget') is not None:
            element.wordTarget = int(
                xmlElement.find('WordTarget').text
            )

        element.referenceDate = PyCalendar.verified_date(
            self._get_element_text(xmlElement, 'ReferenceDate')
        )

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.renumberChapters:
            xmlElement.set('renumberChapters', '1')
        if element.renumberParts:
            xmlElement.set('renumberParts', '1')
        if element.renumberWithinParts:
            xmlElement.set('renumberWithinParts', '1')
        if element.romanChapterNumbers:
            xmlElement.set('romanChapterNumbers', '1')
        if element.romanPartNumbers:
            xmlElement.set('romanPartNumbers', '1')
        if element.saveWordCount:
            xmlElement.set('saveWordCount', '1')
        if element.workPhase is not None:
            xmlElement.set('workPhase', str(element.workPhase))

        if element.authorName:
            ET.SubElement(
                xmlElement,
                'Author',
            ).text = element.authorName

        if element.chapterHeadingPrefix:
            ET.SubElement(
                xmlElement,
                'ChapterHeadingPrefix',
            ).text = element.chapterHeadingPrefix
        if element.chapterHeadingSuffix:
            ET.SubElement(
                xmlElement,
                'ChapterHeadingSuffix',
            ).text = element.chapterHeadingSuffix

        if element.partHeadingPrefix:
            ET.SubElement(
                xmlElement,
                'PartHeadingPrefix',
            ).text = element.partHeadingPrefix
        if element.partHeadingSuffix:
            ET.SubElement(
                xmlElement,
                'PartHeadingSuffix',
            ).text = element.partHeadingSuffix

        if element.noSceneField1:
            ET.SubElement(
                xmlElement,
                'CustomPlotProgress',
            ).text = element.noSceneField1
        if element.noSceneField2:
            ET.SubElement(
                xmlElement,
                'CustomCharacterization',
            ).text = element.noSceneField2
        if element.noSceneField3:
            ET.SubElement(
                xmlElement,
                'CustomWorldBuilding',
            ).text = element.noSceneField3

        if element.otherSceneField1:
            ET.SubElement(
                xmlElement,
                'CustomGoal',
            ).text = element.otherSceneField1
        if element.otherSceneField2:
            ET.SubElement(
                xmlElement,
                'CustomConflict',
            ).text = element.otherSceneField2
        if element.otherSceneField3:
            ET.SubElement(
                xmlElement,
                'CustomOutcome',
            ).text = element.otherSceneField3

        if element.crField1:
            ET.SubElement(
                xmlElement,
                'CustomChrBio',
            ).text = element.crField1
        if element.crField2:
            ET.SubElement(
                xmlElement,
                'CustomChrGoals',
            ).text = element.crField2

        if element.wordCountStart:
            ET.SubElement(
                xmlElement,
                'WordCountStart',
            ).text = str(element.wordCountStart)
        if element.wordTarget:
            ET.SubElement(
                xmlElement,
                'WordTarget',
            ).text = str(element.wordTarget)

        if element.referenceDate:
            ET.SubElement(
                xmlElement,
                'ReferenceDate',
            ).text = element.referenceDate



def new_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'



class NovxOpener:

    @classmethod
    def get_xml_root(cls, filePath, majorVersion, minorVersion):
        try:
            xmlTree = ET.parse(filePath)
        except Exception as ex:
            normPath = norm_path(filePath)
            raise RuntimeError(
                f'{_("Cannot process file")}: "{normPath}" - {str(ex)}'
            )

        xmlRoot = xmlTree.getroot()
        if xmlRoot.tag != 'novx':
            msg = _("No valid xml root element found in file")
            raise RuntimeError(f'{msg}: "{norm_path(filePath)}".')

        fileMajorVersion, fileMinorVersion = cls._get_file_version(
            xmlRoot,
            filePath,
        )
        fileMajorVersion, fileMinorVersion = cls._upgrade_file_version(
            xmlRoot,
            fileMajorVersion,
            fileMinorVersion,
        )
        cls._check_version(
            fileMajorVersion,
            fileMinorVersion,
            filePath,
            majorVersion,
            minorVersion,
        )
        return xmlRoot

    @classmethod
    def _check_version(
            cls,
            fileMajorVersion,
            fileMinorVersion,
            filePath,
            majorVersion,
            minorVersion,
    ):
        if fileMajorVersion > majorVersion:
            msg = _('The project "{}" was created with a newer novelibre version.')
            raise RuntimeError(msg.format(norm_path(filePath)))

        if fileMajorVersion < majorVersion:
            msg = _('The project "{}" was created with an outdated novelibre version.')
            raise RuntimeError(msg.format(norm_path(filePath)))

        if fileMinorVersion > minorVersion:
            msg = _('The project "{}" was created with a newer novelibre version.')
            raise RuntimeError(msg.format(norm_path(filePath)))

    @classmethod
    def _upgrade_file_version(
            cls,
            xmlRoot,
            fileMajorVersion,
            fileMinorVersion,
    ):
        if fileMajorVersion == 1 and fileMinorVersion < 7:
            cls._upgrade_to_1_7(xmlRoot)
            fileMinorVersion = 7
        if fileMajorVersion == 1 and fileMinorVersion < 8:
            cls._upgrade_to_1_8(xmlRoot)
            fileMinorVersion = 8
        return fileMajorVersion, fileMinorVersion

    @classmethod
    def _get_file_version(cls, xmlRoot, filePath):
        try:
            (
                fileMajorVersionStr,
                fileMinorVersionStr
            ) = xmlRoot.attrib['version'].split('.')
            fileMajorVersion = int(fileMajorVersionStr)
            fileMinorVersion = int(fileMinorVersionStr)
        except (KeyError, ValueError):
            msg = _("No valid version found in file")
            raise RuntimeError(msg.format(norm_path(filePath)))

        return fileMajorVersion, fileMinorVersion

    @classmethod
    def _upgrade_to_1_7(cls, xmlRoot):
        for xmlSection in xmlRoot.iter('SECTION'):
            xmlCharacters = xmlSection.find('Characters')
            if xmlCharacters is not None:
                crIds = xmlCharacters.get('ids', None)
                if crIds is not None:
                    crId = crIds.split(' ')[0]
                    ET.SubElement(
                        xmlSection,
                        'Viewpoint',
                        attrib={'id':crId},
                    )

    @classmethod
    def _upgrade_to_1_8(cls, xmlRoot):
        allSections = []

        for xmlSection in xmlRoot.iter(tag='SECTION'):
            allSections.append(xmlSection.attrib['id'])

        xmlChapters = xmlRoot.find('CHAPTERS')
        if xmlChapters is None:
            return

        for xmlChapter in xmlChapters.iterfind('CHAPTER'):
            xmlEpigraph = xmlChapter.find('Epigraph')
            xmlEpigraphSrc = xmlChapter.find('EpigraphSrc')
            if xmlEpigraph is not None:
                xmlChapter.remove(xmlEpigraph)

                xmlChapter.set('hasEpigraph', '1')

                xmlNewSection = ET.Element('SECTION')

                newId = new_id(allSections, SECTION_PREFIX)
                allSections.append(newId)
                xmlNewSection.set('id', newId)

                ET.SubElement(xmlNewSection, 'Title').text = _('Epigraph')

                xmlNewSection.append(xmlEpigraph)
                xmlEpigraph.tag = 'Content'

                if xmlEpigraphSrc is not None:
                    xmlChapter.remove(xmlEpigraphSrc)
                    xmlNewSection.append(
                        ET.fromstring(
                           f'<Desc><p>{xmlEpigraphSrc.text}</p></Desc>'
                        )
                    )

                xmlChapter.insert(0, xmlNewSection)



class PlotLineNovx(BasicElementNotesNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        element.shortName = self._get_element_text(xmlElement, 'ShortName')
        plSections = []
        xmlSections = xmlElement.find('Sections')
        if xmlSections is not None:
            scIds = xmlSections.get('ids', None)
            if scIds is not None:
                for scId in string_to_list(scIds, divider=' '):
                    plSections.append(scId)
        element.sections = plSections

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.shortName:
            ET.SubElement(xmlElement, 'ShortName').text = element.shortName
        if element.sections:
            attrib = {'ids':' '.join(element.sections)}
            ET.SubElement(xmlElement, 'Sections', attrib=attrib)


class PlotPointNovx(BasicElementNotesNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)
        xmlSectionAssoc = xmlElement.find('Section')
        if xmlSectionAssoc is not None:
            element.sectionAssoc = xmlSectionAssoc.get('id', None)

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.sectionAssoc:
            ET.SubElement(
                xmlElement,
                'Section',
                attrib={'id': element.sectionAssoc},
            )



class SectionNovx(BasicElementTagsNovx):

    def import_data(self, element, xmlElement):
        super().import_data(element, xmlElement)

        typeStr = xmlElement.get('type', '0')
        if typeStr in ('0', '1', '2', '3'):
            element.scType = int(typeStr)
        else:
            element.scType = 1
        status = xmlElement.get('status', '1')
        if status in ('1', '2', '3', '4', '5'):
            element.status = int(status)
        else:
            element.status = 1
        scene = xmlElement.get('scene', '0')
        if scene in ('0', '1', '2', '3'):
            element.scene = int(scene)
        else:
            element.scene = 0

        if not element.scene:
            sceneKind = xmlElement.get('pacing', None)
            if sceneKind in ('1', '2'):
                element.scene = int(sceneKind) + 1

        element.appendToPrev = xmlElement.get('append', None) == '1'

        xmlViewpoint = xmlElement.find('Viewpoint')
        if xmlViewpoint is not None:
            element.viewpoint = xmlViewpoint.get('id', None)

        element.goal = self._xml_element_to_text(xmlElement.find('Goal'))
        element.conflict = self._xml_element_to_text(xmlElement.find('Conflict'))
        element.outcome = self._xml_element_to_text(xmlElement.find('Outcome'))

        xmlPlotlineNotes = xmlElement.find('PlotNotes')
        if xmlPlotlineNotes is None:
            xmlPlotlineNotes = xmlElement
        plotlineNotes = {}
        for xmlPlotlineNote in xmlPlotlineNotes.iterfind('PlotlineNotes'):
            plId = xmlPlotlineNote.get('id', None)
            plotlineNotes[plId] = self._xml_element_to_text(xmlPlotlineNote)
        element.plotlineNotes = plotlineNotes

        if xmlElement.find('Date') is not None:
            element.date = PyCalendar.verified_date(xmlElement.find('Date').text)
        elif xmlElement.find('Day') is not None:
            element.day = verified_int_string(xmlElement.find('Day').text)

        if xmlElement.find('Time') is not None:
            element.time = PyCalendar.verified_time(xmlElement.find('Time').text)

        element.lastsDays = verified_int_string(
            self._get_element_text(xmlElement, 'LastsDays')
        )
        element.lastsHours = verified_int_string(
            self._get_element_text(xmlElement, 'LastsHours')
        )
        element.lastsMinutes = verified_int_string(
            self._get_element_text(xmlElement, 'LastsMinutes')
        )

        def get_references(tag):
            scReferences = []
            xmlReferences = xmlElement.find(tag)
            if xmlReferences is not None:
                refIds = xmlReferences.get('ids', None)
                if refIds is not None:
                    for refId in string_to_list(refIds, divider=' '):
                        scReferences.append(refId)
            return scReferences

        element.characters = get_references('Characters')
        element.locations = get_references('Locations')
        element.items = get_references('Items')

        xmlContent = xmlElement.find('Content')
        if xmlContent is not None:
            xmlStr = ET.tostring(
                xmlContent,
                encoding='utf-8',
                short_empty_elements=False
                ).decode('utf-8')
            xmlStr = xmlStr.replace('<Content>', '').replace('</Content>', '')

            lines = xmlStr.split('\n')
            newlines = []
            for line in lines:
                newlines.append(line.strip())
            xmlStr = ''.join(newlines)
            if xmlStr:
                element.sectionContent = xmlStr
            else:
                element.sectionContent = '<p></p>'
        elif element.scType < 2:
            element.sectionContent = '<p></p>'

    def export_data(self, element, xmlElement):
        super().export_data(element, xmlElement)
        if element.scType:
            xmlElement.set('type', str(element.scType))
        if element.status > 1:
            xmlElement.set('status', str(element.status))
        if element.scene > 0:
            xmlElement.set('scene', str(element.scene))
        if element.appendToPrev:
            xmlElement.set('append', '1')

        if element.viewpoint:
            ET.SubElement(
                xmlElement,
                'Viewpoint',
                attrib={'id':element.viewpoint},
            )

        if element.goal:
            xmlElement.append(
                self._text_to_xml_element('Goal', element.goal)
            )
        if element.conflict:
            xmlElement.append(
                self._text_to_xml_element('Conflict', element.conflict)
            )
        if element.outcome:
            xmlElement.append(
                self._text_to_xml_element('Outcome', element.outcome)
            )

        if element.plotlineNotes:
            for plId in element.plotlineNotes:
                if not plId in element.scPlotLines:
                    continue

                if not element.plotlineNotes[plId]:
                    continue

                xmlPlotlineNotes = self._text_to_xml_element(
                    'PlotlineNotes', element.plotlineNotes[plId]
                )
                xmlPlotlineNotes.set('id', plId)
                xmlElement.append(xmlPlotlineNotes)

        if element.date:
            ET.SubElement(xmlElement, 'Date').text = element.date
        elif element.day:
            ET.SubElement(xmlElement, 'Day').text = element.day
        if element.time:
            ET.SubElement(xmlElement, 'Time').text = element.time

        if element.lastsDays and element.lastsDays != '0':
            ET.SubElement(xmlElement, 'LastsDays').text = element.lastsDays
        if element.lastsHours and element.lastsHours != '0':
            ET.SubElement(xmlElement, 'LastsHours').text = element.lastsHours
        if element.lastsMinutes and element.lastsMinutes != '0':
            ET.SubElement(xmlElement, 'LastsMinutes').text = element.lastsMinutes

        if element.characters:
            ET.SubElement(
                xmlElement,
                'Characters',
                attrib={'ids':' '.join(element.characters)},
            )

        if element.locations:
            ET.SubElement(
                xmlElement,
                'Locations',
                attrib={'ids':' '.join(element.locations)},
            )

        if element.items:
            ET.SubElement(
                xmlElement,
                'Items',
                attrib={'ids':' '.join(element.items)},
            )

        sectionContent = element.sectionContent
        if sectionContent:
            if not sectionContent in ('<p></p>', '<p />'):
                xmlElement.append(
                    ET.fromstring(f'<Content>{sectionContent}</Content>')
                )


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



def indent(elem, level=0):
    PARAGRAPH_LEVEL = 5

    i = f'\n{level * "  "}'
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        if level < PARAGRAPH_LEVEL:
            for elem in elem:
                indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


class NovxFile(File):
    DESCRIPTION = _('novelibre project')
    EXTENSION = '.novx'

    MAJOR_VERSION = 1
    MINOR_VERSION = 10

    XML_HEADER = (
        f'<?xml version="1.0" encoding="utf-8"?>\n'
        f'<!DOCTYPE novx SYSTEM "novx_{MAJOR_VERSION}_{MINOR_VERSION}.dtd">\n'
        '<?xml-stylesheet href="novx.css" type="text/css"?>\n'
    )

    fileOpener = NovxOpener

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.xmlTree = None

        self.wcLog = {}

        self.wcLogUpdate = {}

        self.timestamp = None

        self.basicElementCnv = BasicElementNovx()
        self.chapterCnv = ChapterNovx()
        self.characterCnv = CharacterNovx()
        self.novelCnv = NovelNovx()
        self.plotLineCnv = PlotLineNovx()
        self.plotPointCnv = PlotPointNovx()
        self.sectionCnv = SectionNovx()
        self.worldElementCnv = WorldElementNovx()

    def adjust_section_types(self):
        partType = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chLevel == 1:
                partType = self.novel.chapters[chId].chType
            elif partType != 0 and not self.novel.chapters[chId].isTrash:
                self.novel.chapters[chId].chType = partType
            for scId in self.novel.tree.get_children(chId):
                if (self.novel.sections[scId].scType
                        < self.novel.chapters[chId].chType
                ):
                    self.novel.sections[scId].scType = (
                        self.novel.chapters[chId].chType
                    )

    def count_words(self):
        count = 0
        totalCount = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if not self.novel.chapters[chId].isTrash:
                for scId in self.novel.tree.get_children(chId):
                    if self.novel.sections[scId].scType < 2:
                        totalCount += self.novel.sections[scId].wordCount
                        if self.novel.sections[scId].scType == 0:
                            count += self.novel.sections[scId].wordCount
        return count, totalCount

    def read(self):

        xmlRoot = self.fileOpener.get_xml_root(
            self.filePath,
            self.MAJOR_VERSION,
            self.MINOR_VERSION,
        )
        try:
            locale = (
                xmlRoot.attrib['{http://www.w3.org/XML/1998/namespace}lang']
            )
        except KeyError:
            pass
        else:
            codes = locale.split('-')
            self.novel.languageCode = codes[0]
            try:
                self.novel.countryCode = codes[1]
            except IndexError:
                self.novel.countryCode = None
        self.novel.tree.reset()
        try:
            self._read_project_data(xmlRoot)
            self._read_locations(xmlRoot)
            self._read_items(xmlRoot)
            self._read_characters(xmlRoot)
            self._read_chapters_and_sections(xmlRoot)
            self._read_plot_lines_and_points(xmlRoot)
            self._read_project_notes(xmlRoot)
            self.adjust_section_types()
            self._read_word_count_log(xmlRoot)
        except Exception as ex:
            raise RuntimeError(f"{_('Corrupt project data')} ({str(ex)})")
        self._get_timestamp()
        self._keep_word_count()

    def write(self):
        self._update_word_count_log()
        self.adjust_section_types()
        self.novel.get_languages()

        if self.novel.countryCode:
            countryCode = f'-{self.novel.countryCode}'
        else:
            countryCode = ''
        attrib = {
            'version': f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}',
            'xml:lang': f'{self.novel.languageCode}{countryCode}',
        }
        xmlRoot = ET.Element('novx', attrib=attrib)
        self._build_project(xmlRoot)
        self._build_chapters_and_sections(xmlRoot)
        self._build_characters(xmlRoot)
        self._build_locations(xmlRoot)
        self._build_items(xmlRoot)
        self._build_plot_lines_and_points(xmlRoot)
        self._build_project_notes(xmlRoot)
        self._build_word_count_log(xmlRoot)

        indent(xmlRoot)

        self.xmlTree = ET.ElementTree(xmlRoot)
        self._write_element_tree(self)
        self._postprocess_xml_file(self.filePath)
        self._get_timestamp()

    def _build_project(self, root):
        xmlProject = ET.SubElement(root, 'PROJECT')
        self.novelCnv.export_data(self.novel, xmlProject)

    def _build_chapters_and_sections(self, root):
        xmlChapters = ET.SubElement(root, 'CHAPTERS')
        for chId in self.novel.tree.get_children(CH_ROOT):
            xmlChapter = ET.SubElement(
                xmlChapters, 'CHAPTER', attrib={'id': chId})
            self.chapterCnv.export_data(self.novel.chapters[chId], xmlChapter)
            for scId in self.novel.tree.get_children(chId):
                self.sectionCnv.export_data(
                    self.novel.sections[scId],
                    ET.SubElement(
                        xmlChapter,
                        'SECTION',
                        attrib={'id': scId},
                    )
                )

    def _build_characters(self, root):
        xmlCharacters = ET.SubElement(root, 'CHARACTERS')
        for crId in self.novel.tree.get_children(CR_ROOT):
            self.characterCnv.export_data(
                self.novel.characters[crId],
                ET.SubElement(
                    xmlCharacters,
                    'CHARACTER',
                    attrib={'id': crId},
                )
            )

    def _build_locations(self, root):
        xmlLocations = ET.SubElement(root, 'LOCATIONS')
        for lcId in self.novel.tree.get_children(LC_ROOT):
            self.worldElementCnv.export_data(
                self.novel.locations[lcId],
                ET.SubElement(
                    xmlLocations,
                    'LOCATION',
                    attrib={'id': lcId},
                )
            )

    def _build_items(self, root):
        xmlItems = ET.SubElement(root, 'ITEMS')
        for itId in self.novel.tree.get_children(IT_ROOT):
            self.worldElementCnv.export_data(
                self.novel.items[itId],
                ET.SubElement(
                    xmlItems,
                    'ITEM',
                    attrib={'id': itId},
                )
            )

    def _build_plot_lines_and_points(self, root):
        xmlPlotLines = ET.SubElement(root, 'ARCS')
        for plId in self.novel.tree.get_children(PL_ROOT):
            xmlPlotLine = ET.SubElement(
                xmlPlotLines,
                'ARC',
                attrib={'id': plId},
            )
            self.plotLineCnv.export_data(self.novel.plotLines[plId], xmlPlotLine)
            for ppId in self.novel.tree.get_children(plId):
                self.plotPointCnv.export_data(
                    self.novel.plotPoints[ppId],
                    ET.SubElement(
                        xmlPlotLine,
                        'POINT',
                        attrib={'id': ppId},
                    )
                )

    def _build_project_notes(self, root):
        xmlProjectNotes = ET.SubElement(root, 'PROJECTNOTES')
        for pnId in self.novel.tree.get_children(PN_ROOT):
            self.basicElementCnv.export_data(
                self.novel.projectNotes[pnId],
                ET.SubElement(
                    xmlProjectNotes,
                    'PROJECTNOTE',
                    attrib={'id': pnId},
                )
            )

    def _build_word_count_log(self, root):
        if not self.wcLog:
            return

        xmlWcLog = ET.SubElement(root, 'PROGRESS')
        wcLastCount = None
        wcLastTotalCount = None
        for wc in self.wcLog:
            wcCount, wcTotalCount = self.wcLog[wc]
            if self.novel.saveWordCount:
                if (
                    wcCount == wcLastCount
                    and wcTotalCount == wcLastTotalCount
                ):
                    continue

                wcLastCount = wcCount
                wcLastTotalCount = wcTotalCount
            xmlWc = ET.SubElement(xmlWcLog, 'WC')
            ET.SubElement(xmlWc, 'Date').text = wc
            ET.SubElement(xmlWc, 'Count').text = str(wcCount)
            ET.SubElement(xmlWc, 'WithUnused').text = str(wcTotalCount)

    def _check_id(self, elemId, elemPrefix):
        if not elemId.startswith(elemPrefix):
            raise RuntimeError(f"bad ID: '{elemId}'")

    def _get_timestamp(self):
        try:
            self.timestamp = os.path.getmtime(self.filePath)
        except Exception:
            self.timestamp = None

    def _keep_word_count(self):

        if not self.wcLog:
            return

        actualCount, actualTotalCount = self.count_words()
        latestDate = list(self.wcLog)[-1]
        latestCount = self.wcLog[latestDate][0]
        latestTotalCount = self.wcLog[latestDate][1]
        if (
            actualCount != latestCount
            or actualTotalCount != latestTotalCount
        ):
            try:
                fileDateIso = date.fromtimestamp(self.timestamp).isoformat()
            except Exception:
                fileDateIso = date.today().isoformat()
            self.wcLogUpdate[fileDateIso] = [actualCount, actualTotalCount]

    def _postprocess_xml_file(self, filePath):

        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
            text = strip_illegal_characters(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except Exception as ex:
            msg = _("Cannot write file")
            msg = f'{msg}: "{norm_path(filePath)}"'
            msg = f'{msg} - {str(ex)}'
            raise RuntimeError(msg)

    def _read_chapters_and_sections(self, root):
        xmlChapters = root.find('CHAPTERS')
        if xmlChapters is None:
            return

        for xmlChapter in xmlChapters.iterfind('CHAPTER'):
            chId = xmlChapter.attrib['id']
            self._check_id(chId, CHAPTER_PREFIX)
            self.novel.chapters[chId] = Chapter()
            self.chapterCnv.import_data(self.novel.chapters[chId], xmlChapter)
            self.novel.tree.append(CH_ROOT, chId)

            for xmlSection in xmlChapter.iterfind('SECTION'):
                scId = xmlSection.attrib['id']
                self._check_id(scId, SECTION_PREFIX)
                self._read_section(xmlSection, scId)
                self.novel.tree.append(chId, scId)

    def _read_characters(self, root):
        xmlCharacters = root.find('CHARACTERS')
        if xmlCharacters is None:
            return

        for xmlCharacter in xmlCharacters.iterfind('CHARACTER'):
            crId = xmlCharacter.attrib['id']
            self._check_id(crId, CHARACTER_PREFIX)
            self.novel.characters[crId] = Character()
            self.characterCnv.import_data(
                self.novel.characters[crId],
                xmlCharacter
            )
            self.novel.tree.append(CR_ROOT, crId)

    def _read_items(self, root):
        xmlItems = root.find('ITEMS')
        if xmlItems is None:
            return

        for xmlItem in xmlItems.iterfind('ITEM'):
            itId = xmlItem.attrib['id']
            self._check_id(itId, ITEM_PREFIX)
            self.novel.items[itId] = WorldElement()
            self.worldElementCnv.import_data(self.novel.items[itId], xmlItem)
            self.novel.tree.append(IT_ROOT, itId)

    def _read_locations(self, root):
        xmlLocations = root.find('LOCATIONS')
        if xmlLocations is None:
            return

        for xmlLocation in xmlLocations.iterfind('LOCATION'):
            lcId = xmlLocation.attrib['id']
            self._check_id(lcId, LOCATION_PREFIX)
            self.novel.locations[lcId] = WorldElement()
            self.worldElementCnv.import_data(
                self.novel.locations[lcId],
                xmlLocation
            )
            self.novel.tree.append(LC_ROOT, lcId)

    def _read_plot_lines_and_points(self, root):
        xmlPlotLines = root.find('ARCS')
        if xmlPlotLines is None:
            return

        for xmlPlotLine in xmlPlotLines.iterfind('ARC'):
            plId = xmlPlotLine.attrib['id']
            self._check_id(plId, PLOT_LINE_PREFIX)
            self.novel.plotLines[plId] = PlotLine()
            self.plotLineCnv.import_data(self.novel.plotLines[plId], xmlPlotLine)
            self.novel.tree.append(PL_ROOT, plId)

            self.novel.plotLines[plId].sections = intersection(
                self.novel.plotLines[plId].sections, self.novel.sections)

            for scId in self.novel.plotLines[plId].sections:
                self.novel.sections[scId].scPlotLines.append(plId)

            for xmlPlotPoint in xmlPlotLine.iterfind('POINT'):
                ppId = xmlPlotPoint.attrib['id']
                self._check_id(ppId, PLOT_POINT_PREFIX)
                self._read_plot_point(xmlPlotPoint, ppId, plId)
                self.novel.tree.append(plId, ppId)

    def _read_plot_point(self, xmlPlotPoint, ppId, plId):
        self.novel.plotPoints[ppId] = PlotPoint()
        self.plotPointCnv.import_data(self.novel.plotPoints[ppId], xmlPlotPoint)

        scId = self.novel.plotPoints[ppId].sectionAssoc
        if scId in self.novel.sections:
            self.novel.sections[scId].scPlotPoints[ppId] = plId
        else:
            self.novel.plotPoints[ppId].sectionAssoc = None

    def _read_project_data(self, root):
        xmlProject = root.find('PROJECT')
        if xmlProject is None:
            return

        self.novelCnv.import_data(self.novel, xmlProject)

    def _read_project_notes(self, root):
        xmlProjectNotes = root.find('PROJECTNOTES')
        if xmlProjectNotes is None:
            return

        for xmlProjectNote in xmlProjectNotes.iterfind('PROJECTNOTE'):
            pnId = xmlProjectNote.attrib['id']
            self._check_id(pnId, PRJ_NOTE_PREFIX)
            self.novel.projectNotes[pnId] = BasicElement()
            self.basicElementCnv.import_data(
                self.novel.projectNotes[pnId],
                xmlProjectNote
            )
            self.novel.tree.append(PN_ROOT, pnId)

    def _read_section(self, xmlSection, scId):
        self.novel.sections[scId] = Section()
        self.sectionCnv.import_data(self.novel.sections[scId], xmlSection)

        self.novel.sections[scId].characters = intersection(
            self.novel.sections[scId].characters, self.novel.characters)
        self.novel.sections[scId].locations = intersection(
            self.novel.sections[scId].locations, self.novel.locations)
        self.novel.sections[scId].items = intersection(
            self.novel.sections[scId].items, self.novel.items)

    def _read_word_count_log(self, xmlRoot):

        def verified_date(dateStr):
            if dateStr is not None:
                date.fromisoformat(dateStr)
            return dateStr

        xmlWclog = xmlRoot.find('PROGRESS')
        if xmlWclog is None:
            return

        for xmlWc in xmlWclog.iterfind('WC'):
            try:
                wcDate = verified_date(xmlWc.find('Date').text)
                self.wcLog[wcDate] = [
                    int(xmlWc.find('Count').text),
                    int(xmlWc.find('WithUnused').text)
                ]
            except:
                pass

    def _update_word_count_log(self):

        if self.novel.saveWordCount:
            newCount, newTotalCount = self.count_words()
            todayIso = date.today().isoformat()
            self.wcLogUpdate[todayIso] = [newCount, newTotalCount]
            for wcDate in self.wcLogUpdate:
                self.wcLog[wcDate] = self.wcLogUpdate[wcDate]
        self.wcLogUpdate.clear()

    def _write_element_tree(self, xmlProject):

        backedUp = False
        if os.path.isfile(xmlProject.filePath):
            try:
                os.replace(xmlProject.filePath, f'{xmlProject.filePath}.bak')
            except Exception as ex:
                raise RuntimeError(str(ex))
            else:
                backedUp = True
        try:
            xmlProject.xmlTree.write(
                xmlProject.filePath, xml_declaration=False, encoding='utf-8')
        except Exception as ex:
            if backedUp:
                os.replace(f'{xmlProject.filePath}.bak', xmlProject.filePath)
            msg = _("Cannot write file")
            msg = f'{msg}: "{norm_path(xmlProject.filePath)}"'
            msg = f'{msg} - {str(ex)}'
            raise RuntimeError(msg)


class DataWriter(NovxFile):
    DESCRIPTION = _('novelibre XML data files')
    EXTENSION = '.xml'
    SUFFIX = DATA_SUFFIX

    XML_HEADER = '<?xml version="1.0" encoding="utf-8"?>\n'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        path, __ = os.path.splitext(filePath)
        self._dataFiles = dict(
            CHARACTERS=f'{path}_Characters.xml',
            LOCATIONS=f'{path}_Locations.xml',
            ITEMS=f'{path}_Items.xml',
            ARCS=f'{path}_Plotlines.xml',
        )

    def _postprocess_xml_file(self, filePath):
        for xmlBranch in self._dataFiles:
            super()._postprocess_xml_file(self._dataFiles[xmlBranch])

    def _write_element_tree(self, xmlProject):
        for xmlBranch in self._dataFiles:
            elementSubtree = xmlProject.xmlTree.find(xmlBranch)
            elementTree = ET.ElementTree(elementSubtree)
            try:
                elementTree.write(
                    self._dataFiles[xmlBranch],
                    xml_declaration=False,
                    encoding='utf-8',
                )
            except(PermissionError):
                raise RuntimeError(
                    f'{_("File is write protected")}: '
                    f'"{norm_path(self._dataFiles[xmlBranch])}".'
                )

from abc import ABC, abstractmethod

from string import Template



class Filter:

    def accept(self, source, eId):
        return True

    def get_message(self, source):
        return ''


class FileExport(File):
    SUFFIX = ''
    _DIVIDER = ', '
    _appendedSectionTemplate = ''
    _assocSectionTemplate = ''
    _chapterEndTemplate = ''
    _chapterTemplate = ''
    _characterHeadingTemplate = ''
    _characterTemplate = ''
    _epigraphTemplate = ''
    _fileFooter = ''
    _fileHeader = ''
    _firstSectionTemplate = ''
    _itemHeadingTemplate = ''
    _itemTemplate = ''
    _locationHeadingTemplate = ''
    _locationTemplate = ''
    _partTemplate = ''
    _partEndTemplate = ''
    _plotLineHeadingTemplate = ''
    _plotLineTemplate = ''
    _plotPointTemplate = ''
    _projectNoteTemplate = ''
    _sectionDivider = ''
    _sectionTemplate = ''
    _stage1Template = ''
    _stage2Template = ''
    _unusedChapterEndTemplate = ''
    _unusedChapterTemplate = ''
    _unusedSectionTemplate = ''
    localizeDate = False

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self.sectionFilter = Filter()
        self.chapterFilter = Filter()
        self.characterFilter = Filter()
        self.locationFilter = Filter()
        self.itemFilter = Filter()
        self.arcFilter = Filter()
        self.turningPointFilter = Filter()

    def write(self):
        text = self._get_text()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise RuntimeError(
                    f'{_("Cannot overwrite file")}: '
                    f'"{norm_path(self.filePath)}".'
                )
            else:
                backedUp = True
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise RuntimeError(
                f'{_("Cannot write file")}: '
                f'"{norm_path(self.filePath)}".'
            )

    def _convert_from_novx(self, text, **kwargs):
        return(text or '')

    def _get_chapterMapping(self, chId, chapterNumber):
        if chapterNumber == 0:
            chapterNumber = ''

        chapterMapping = dict(
            ID=chId,
            ChapterNumber=chapterNumber,
            Title=self._convert_from_novx(
                self.novel.chapters[chId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.chapters[chId].desc
            ),
            Notes=self._convert_from_novx(
                self.novel.chapters[chId].notes
            ),
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True
            ),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
            ManuscriptSuffix=MANUSCRIPT_SUFFIX,
        )
        return chapterMapping

    def _get_chapters(self):
        lines = []
        partNumber = 0
        chapterNumber = 0
        sectionNumber = 0
        wordsTotal = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            dispNumber = 0
            if not self.chapterFilter.accept(self, chId):
                continue

            template = None
            if self.novel.chapters[chId].chType == 1:
                if self._unusedChapterTemplate:
                    template = Template(self._unusedChapterTemplate)
            elif (
                self.novel.chapters[chId].chLevel == 1
                and self._partTemplate
            ):
                template = Template(self._partTemplate)
                partNumber += 1
                dispNumber = partNumber
            elif (
                self.novel.chapters[chId].chLevel == 2
                and self._chapterTemplate
            ):
                template = Template(self._chapterTemplate)
                chapterNumber += 1
                dispNumber = chapterNumber
            if template is not None:
                lines.append(
                    template.safe_substitute(
                        self._get_chapterMapping(chId, dispNumber)
                    )
                )

            (
                sectionLines,
                sectionNumber,
                wordsTotal,
            ) = self._get_sections(
                chId,
                sectionNumber,
                wordsTotal,
                self.novel.chapters[chId].hasEpigraph,
            )
            lines.extend(sectionLines)

            template = None
            if self.novel.chapters[chId].chType == 1:
                if self._unusedChapterEndTemplate:
                    template = Template(self._unusedChapterEndTemplate)
            elif (
                self.novel.chapters[chId].chLevel == 1
                and self._partEndTemplate
            ):
                template = Template(self._partEndTemplate)
            elif (
                self.novel.chapters[chId].chLevel == 2
                and self._chapterEndTemplate
            ):
                template = Template(self._chapterEndTemplate)
            if template is not None:
                lines.append(
                    template.safe_substitute(
                        self._get_chapterMapping(chId, dispNumber)
                    )
                )
        return lines

    def _get_characterMapping(self, crId):
        if self.novel.characters[crId].tags is not None:
            tags = list_to_string(
                self.novel.characters[crId].tags,
                divider=self._DIVIDER
            )
        else:
            tags = ''
        if self.novel.characters[crId].isMajor:
            characterStatus = MAJOR_MARKER
        else:
            characterStatus = MINOR_MARKER
        birthDateStr = self.novel.characters[crId].birthDate
        if birthDateStr is None:
            birthDateStr = ''
        deathDateStr = self.novel.characters[crId].deathDate
        if deathDateStr is None:
            deathDateStr = ''

        (
            __, __, __, __, __, __,
            crField1,
            crField2,
        ) = self._get_field_names()

        characterMapping = dict(
            ID=crId,
            Title=self._convert_from_novx(
                self.novel.characters[crId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.characters[crId].desc,
            ),
            Tags=self._convert_from_novx(tags),
            AKA=self._convert_from_novx(
                self.novel.characters[crId].aka,
                quick=True,
            ),
            Notes=self._convert_from_novx(
                self.novel.characters[crId].notes,
            ),
            Bio=self._convert_from_novx(
                self.novel.characters[crId].bio,
            ),
            Goals=self._convert_from_novx(
                self.novel.characters[crId].goals,
            ),
            FullName=self._convert_from_novx(
                self.novel.characters[crId].fullName,
                quick=True,
            ),
            Status=characterStatus,
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
            CharactersSuffix=CHARACTERS_SUFFIX,
            BirthDate=birthDateStr,
            DeathDate=deathDateStr,
            CharacterField1=crField1,
            CharacterField2=crField2,

            CustomChrBio=crField1,
            CustomChrGoals=crField2,
        )
        return characterMapping

    def _get_characters(self):
        if self._characterHeadingTemplate:
            lines = [self._characterHeadingTemplate]
        else:
            lines = []
        template = Template(self._characterTemplate)
        for crId in self.novel.tree.get_children(CR_ROOT):
            if self.characterFilter.accept(self, crId):
                lines.append(
                    template.safe_substitute(
                        self._get_characterMapping(crId)
                    )
                )
        return lines

    def _get_field_names(self):
        if self.novel.noSceneField1:
            noSceneField1 = self.novel.noSceneField1
        else:
            noSceneField1 = f"{_('Field')} 1"
        if self.novel.noSceneField2:
            noSceneField2 = self.novel.noSceneField2
        else:
            noSceneField2 = f"{_('Field')} 2"
        if self.novel.noSceneField3:
            noSceneField3 = self.novel.noSceneField3
        else:
            noSceneField3 = f"{_('Field')} 3"
        if self.novel.otherSceneField1:
            otherSceneField1 = self.novel.otherSceneField1
        else:
            otherSceneField1 = f"{_('Field')} 1"
        if self.novel.otherSceneField2:
            otherSceneField2 = self.novel.otherSceneField2
        else:
            otherSceneField2 = f"{_('Field')} 2"
        if self.novel.otherSceneField3:
            otherSceneField3 = self.novel.otherSceneField3
        else:
            otherSceneField3 = f"{_('Field')} 3"
        if self.novel.crField1:
            crField1 = self.novel.crField1
        else:
            crField1 = f"{_('Field')} 1"
        if self.novel.crField2:
            crField2 = self.novel.crField2
        else:
            crField2 = f"{_('Field')} 2"
        return (
            noSceneField1,
            noSceneField2,
            noSceneField3,
            otherSceneField1,
            otherSceneField2,
            otherSceneField3,
            crField1,
            crField2,
        )

    def _get_fileFooter(self):
        lines = []
        template = Template(self._fileFooter)
        lines.append(template.safe_substitute(self._get_fileFooterMapping()))
        return lines

    def _get_fileFooterMapping(self):
        return []

    def _get_fileHeader(self):
        lines = []
        template = Template(self._fileHeader)
        lines.append(template.safe_substitute(self._get_fileHeaderMapping()))
        return lines

    def _get_fileHeaderMapping(self):
        filterMessages = []
        expFilters = [
            self.chapterFilter,
            self.sectionFilter,
            self.characterFilter,
            self.locationFilter,
            self.itemFilter,
            self.arcFilter,
            self.turningPointFilter,
        ]
        for expFilter in expFilters:
            message = expFilter.get_message(self)
            if message:
                filterMessages.append(message)
            if filterMessages:
                filters = self._convert_from_novx('\n'.join(filterMessages))
            else:
                filters = ''
            (
                noSceneField1,
                noSceneField2,
                noSceneField3,
                otherSceneField1,
                otherSceneField2,
                otherSceneField3,
                crField1,
                crField2,
            ) = self._get_field_names()

        fileHeaderMapping = dict(
            Title=self._convert_from_novx(
                self.novel.title,
                quick=True,
            ),
            Filters=filters,
            Desc=self._convert_from_novx(self.novel.desc),
            AuthorName=self._convert_from_novx(
                self.novel.authorName,
                quick=True,
            ),
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,

            NotASceneField1=noSceneField1,
            NotASceneField2=noSceneField2,
            NotASceneField3=noSceneField3,
            OtherSceneField1=otherSceneField1,
            OtherSceneField2=otherSceneField2,
            OtherSceneField3=otherSceneField3,
            CharacterField1=crField1,
            CharacterField2=crField2,

            CustomPlotProgress=noSceneField1,
            CustomCharacterization=noSceneField2,
            CustomWorldBuilding=noSceneField3,
            CustomGoal=otherSceneField1,
            CustomConflict=otherSceneField2,
            CustomOutcome=otherSceneField3,
            CustomChrBio=crField1,
            CustomChrGoals=crField2
        )
        return fileHeaderMapping

    def _get_itemMapping(self, itId):
        if self.novel.items[itId].tags is not None:
            tags = list_to_string(
                self.novel.items[itId].tags,
                divider=self._DIVIDER
            )
        else:
            tags = ''

        itemMapping = dict(
            ID=itId,
            Title=self._convert_from_novx(
                self.novel.items[itId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.items[itId].desc,
            ),
            Notes=self._convert_from_novx(
                self.novel.items[itId].notes,
            ),
            Tags=self._convert_from_novx(
                tags,
                quick=True,
            ),
            AKA=self._convert_from_novx(
                self.novel.items[itId].aka,
                quick=True,
            ),
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
            ItemsSuffix=ITEMS_SUFFIX,
        )
        return itemMapping

    def _get_items(self):
        if self._itemHeadingTemplate:
            lines = [self._itemHeadingTemplate]
        else:
            lines = []
        template = Template(self._itemTemplate)
        for itId in self.novel.tree.get_children(IT_ROOT):
            if self.itemFilter.accept(self, itId):
                lines.append(
                    template.safe_substitute(
                        self._get_itemMapping(itId)
                    )
                )
        return lines

    def _get_locationMapping(self, lcId):
        if self.novel.locations[lcId].tags is not None:
            tags = list_to_string(
                self.novel.locations[lcId].tags,
                divider=self._DIVIDER
            )
        else:
            tags = ''

        locationMapping = dict(
            ID=lcId,
            Title=self._convert_from_novx(
                self.novel.locations[lcId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.locations[lcId].desc,
            ),
            Notes=self._convert_from_novx(
                self.novel.locations[lcId].notes
            ),
            Tags=self._convert_from_novx(
                tags,
                quick=True,
            ),
            AKA=self._convert_from_novx(
                self.novel.locations[lcId].aka,
                quick=True,
            ),
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
            LocationsSuffix=LOCATIONS_SUFFIX,
        )
        return locationMapping

    def _get_locations(self):
        if self._locationHeadingTemplate:
            lines = [self._locationHeadingTemplate]
        else:
            lines = []
        template = Template(self._locationTemplate)
        for lcId in self.novel.tree.get_children(LC_ROOT):
            if self.locationFilter.accept(self, lcId):
                lines.append(
                    template.safe_substitute(
                        self._get_locationMapping(lcId)
                    )
                )
        return lines

    def _get_plotLineMapping(self, plId):
        plotlineMapping = dict(
            ID=plId,
            Title=self._convert_from_novx(
                self.novel.plotLines[plId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.plotLines[plId].desc,
            ),
            Notes=self._convert_from_novx(
                self.novel.plotLines[plId].notes,
            ),
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        return plotlineMapping

    def _get_plotlines(self):
        if self._plotLineHeadingTemplate:
            lines = [self._plotLineHeadingTemplate]
        else:
            lines = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            if self.arcFilter.accept(self, plId):
                if self._plotLineTemplate:
                    template = Template(self._plotLineTemplate)
                    lines.append(
                        template.safe_substitute(
                            self._get_plotLineMapping(plId)
                        )
                    )

            for ppId in self.novel.tree.get_children(plId):
                if self._plotPointTemplate:
                    template = Template(self._plotPointTemplate)
                    plotPointMapping = self._get_plotPointMapping(ppId)
                    lines.append(
                        template.safe_substitute(
                            plotPointMapping
                        )
                    )
        return lines

    def _get_plotPointMapping(self, ppId):
        plotPointMapping = dict(
            ID=ppId,
            Title=self._convert_from_novx(
                self.novel.plotPoints[ppId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.plotPoints[ppId].desc,
            ),
            Notes=self._convert_from_novx(
                self.novel.plotPoints[ppId].notes,
            ),
            Section='',
            scID='',
            SectionTitle='',
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        scId = self.novel.plotPoints[ppId].sectionAssoc
        if scId:
            template = Template(self._assocSectionTemplate)
            plotPointMapping['Section'] = template.safe_substitute(
                self._get_sectionAssocMapping(scId)
            )
        return plotPointMapping

    def _get_sectionAssocMapping(self, scId):
        sectionAssocMapping = dict(
            SectionTitle=self.novel.sections[scId].title,
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            scID=scId,
            ManuscriptSuffix=MANUSCRIPT_SUFFIX,
            SectionsSuffix=SECTIONS_SUFFIX,
        )
        return sectionAssocMapping

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter=False,
            isEpigraph=False,
        ):

        if sectionNumber == 0:
            sectionNumber = ''
        if self.novel.sections[scId].tags is not None:
            tags = list_to_string(
                self.novel.sections[scId].tags, divider=self._DIVIDER
            )
        else:
            tags = ''

        if self.novel.sections[scId].viewpoint:
            viewpointChar = self.novel.characters[
                self.novel.sections[scId].viewpoint].title
        else:
            viewpointChar = ''

        if self.novel.sections[scId].characters is not None:
            sChList = []
            for crId in self.novel.sections[scId].characters:
                sChList.append(self.novel.characters[crId].title)
            sectionChars = list_to_string(sChList, divider=self._DIVIDER)

        else:
            sectionChars = ''
            viewpointChar = ''

        if self.novel.sections[scId].locations is not None:
            sLcList = []
            for lcId in self.novel.sections[scId].locations:
                sLcList.append(self.novel.locations[lcId].title)
            sectionLocs = list_to_string(sLcList, divider=self._DIVIDER)
        else:
            sectionLocs = ''

        if self.novel.sections[scId].items is not None:
            sItList = []
            for itId in self.novel.sections[scId].items:
                sItList.append(self.novel.items[itId].title)
            sectionItems = list_to_string(sItList, divider=self._DIVIDER)
        else:
            sectionItems = ''

        if (
            self.novel.sections[scId].date is not None
            and self.novel.sections[scId].date != Section.NULL_DATE
        ):
            scDay = ''
            dateStr = self.novel.sections[scId].date
            cmbDateStr = self.novel.sections[scId].localeDate
            yearStr, monthStr, dayStr = PyCalendar.y_m_d_str(dateStr)
            dtMonth = PyCalendar.MONTHS[int(monthStr)]
            dtWeekday = PyCalendar.WEEKDAYS[self.novel.sections[scId].weekDay]
        else:
            dateStr = ''
            yearStr = ''
            monthStr = ''
            dayStr = ''
            dtMonth = ''
            dtWeekday = ''
            if self.novel.sections[scId].day is not None:
                scDay = self.novel.sections[scId].day
                cmbDateStr = f'{_("Day")} {self.novel.sections[scId].day}'
            else:
                scDay = ''
                cmbDateStr = ''

        if self.novel.sections[scId].time is not None:
            scTime = PyCalendar.time_disp(self.novel.sections[scId].time)
            h, m, s = PyCalendar.h_m_s_str(self.novel.sections[scId].time)
            odsTime = f'PT{h}H{m}M{s}S'
        else:
            scTime = ''
            odsTime = ''

        if (
            self.novel.sections[scId].lastsDays is not None
            and self.novel.sections[scId].lastsDays != '0'
        ):
            lastsDays = self.novel.sections[scId].lastsDays
            days = f'{self.novel.sections[scId].lastsDays}d '
        else:
            lastsDays = ''
            days = ''

        if (
            self.novel.sections[scId].lastsHours is not None
            and self.novel.sections[scId].lastsHours != '0'
        ):
            lastsHours = self.novel.sections[scId].lastsHours
            hours = f'{self.novel.sections[scId].lastsHours}h '
        else:
            lastsHours = ''
            hours = ''

        if (
            self.novel.sections[scId].lastsMinutes is not None
            and self.novel.sections[scId].lastsMinutes != '0'
        ):
            lastsMinutes = self.novel.sections[scId].lastsMinutes
            minutes = f'{self.novel.sections[scId].lastsMinutes}min'
        else:
            lastsMinutes = ''
            minutes = ''

        duration = f'{days}{hours}{minutes}'
        (
            noSceneField1,
            noSceneField2,
            noSceneField3,
            otherSceneField1,
            otherSceneField2,
            otherSceneField3,
            __, __,
        ) = self._get_field_names()
        sectionMapping = dict(
            ID=scId,
            SectionNumber=sectionNumber,
            Title=self._convert_from_novx(
                self.novel.sections[scId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.sections[scId].desc,
                isEpigraph=isEpigraph,
                append=self.novel.sections[scId].appendToPrev,
            ),
            WordCount=str(self.novel.sections[scId].wordCount),
            WordsTotal=wordsTotal,
            Status=int(self.novel.sections[scId].status),
            SectionContent=self._convert_from_novx(
                self.novel.sections[scId].sectionContent,
                append=self.novel.sections[scId].appendToPrev,
                firstInChapter=firstInChapter,
                isEpigraph=isEpigraph,
                xml=True,
            ),
            Date=dateStr,
            Time=scTime,
            OdsTime=odsTime,
            Day=scDay,
            ScDate=cmbDateStr,
            DateYear=yearStr,
            DateMonth=monthStr,
            DateDay=dayStr,
            DateWeekday=dtWeekday,
            MonthName=dtMonth,
            LastsDays=lastsDays,
            LastsHours=lastsHours,
            LastsMinutes=lastsMinutes,
            Duration=duration,
            Scene=SCENE[self.novel.sections[scId].scene],
            Goal=self._convert_from_novx(
                self.novel.sections[scId].goal,
            ),
            Conflict=self._convert_from_novx(
                self.novel.sections[scId].conflict,
            ),
            Outcome=self._convert_from_novx(
                self.novel.sections[scId].outcome,
            ),
            Tags=self._convert_from_novx(tags, quick=True),
            Characters=sectionChars,
            Viewpoint=viewpointChar,
            Locations=sectionLocs,
            Items=sectionItems,
            Notes=self._convert_from_novx(self.novel.sections[scId].notes),
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
            ManuscriptSuffix=MANUSCRIPT_SUFFIX,
            SectionsSuffix=SECTIONS_SUFFIX,

            NotASceneField1=noSceneField1,
            NotASceneField2=noSceneField2,
            NotASceneField3=noSceneField3,
            OtherSceneField1=otherSceneField1,
            OtherSceneField2=otherSceneField2,
            OtherSceneField3=otherSceneField3,

            CustomPlotProgress=noSceneField1,
            CustomCharacterization=noSceneField2,
            CustomWorldBuilding=noSceneField3,
            CustomGoal=otherSceneField1,
            CustomConflict=otherSceneField2,
            CustomOutcome=otherSceneField3,
        )
        return sectionMapping

    def _get_sections(
            self,
            chId,
            sectionNumber,
            wordsTotal,
            isEpigraph,
    ):
        lines = []
        firstSectionInChapter = True
        for scId in self.novel.tree.get_children(chId):
            template = None
            dispNumber = 0
            if not self.sectionFilter.accept(self, scId):
                continue

            sectionContent = self.novel.sections[scId].sectionContent
            if sectionContent is None:
                sectionContent = ''

            if self.novel.sections[scId].scType == 2:
                if self._stage1Template:
                    template = Template(self._stage1Template)
                else:
                    continue

            elif self.novel.sections[scId].scType == 3:
                if self._stage2Template:
                    template = Template(self._stage2Template)
                else:
                    continue

            elif (
                self.novel.sections[scId].scType == 1
                or self.novel.chapters[chId].chType == 1
            ):
                isEpigraph = False
                if self._unusedSectionTemplate:
                    template = Template(self._unusedSectionTemplate)
                else:
                    continue

            elif isEpigraph and not self._epigraphTemplate:
                isEpigraph = False
                continue

            else:
                sectionNumber += 1
                dispNumber = sectionNumber
                wordsTotal += self.novel.sections[scId].wordCount
                template = Template(self._sectionTemplate)
                if isEpigraph:
                    template = Template(self._epigraphTemplate)
                elif firstSectionInChapter:
                    if self._firstSectionTemplate:
                        template = Template(self._firstSectionTemplate)
                elif self.novel.sections[scId].appendToPrev:
                    if self._appendedSectionTemplate:
                        template = Template(self._appendedSectionTemplate)

            if not (
                isEpigraph
                or firstSectionInChapter
                or self.novel.sections[scId].appendToPrev
                or self.novel.sections[scId].scType > 1
            ):
                lines.append(self._sectionDivider)

            tempEpigraph = False
            tempFirstSection = firstSectionInChapter
            if template is not None:
                if self.novel.sections[scId].scType == 0:
                    if isEpigraph:
                        tempEpigraph = True
                        tempFirstSection = False
                lines.append(
                    template.safe_substitute(
                        self._get_sectionMapping(
                            scId, dispNumber,
                            wordsTotal,
                            firstInChapter=tempFirstSection,
                            isEpigraph=tempEpigraph,
                        )
                    )
                )
            if self.novel.sections[scId].scType < 2:
                isEpigraph = False
            if self.novel.sections[scId].scType == 0 and tempFirstSection:
                firstSectionInChapter = False

        return lines, sectionNumber, wordsTotal

    def _get_prjNoteMapping(self, pnId):
        noteMapping = dict(
            ID=pnId,
            Title=self._convert_from_novx(
                self.novel.projectNotes[pnId].title,
                quick=True,
            ),
            Desc=self._convert_from_novx(
                self.novel.projectNotes[pnId].desc,
            ),
            ProjectName=self._convert_from_novx(
                self.projectName,
                quick=True,
            ),
            ProjectPath=self.projectPath,
        )
        return noteMapping

    def _get_projectNotes(self):
        lines = []
        template = Template(self._projectNoteTemplate)
        for pnId in self.novel.tree.get_children(PN_ROOT):
            pnMap = self._get_prjNoteMapping(pnId)
            lines.append(template.safe_substitute(pnMap))
        return lines

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_plotlines())
        lines.extend(self._get_projectNotes())
        lines.extend(self._get_fileFooter())
        return ''.join(lines)

from abc import ABC



def odf_is_locked(filePath):
    prjPath, fileName = os.path.split(filePath)
    return os.path.isfile(f'{prjPath}/.~lock.{fileName}#')



class OdfReader(File, ABC):

    def is_locked(self):
        return odf_is_locked(self.filePath)


class DurationParser:

    def __init__(self):
        self.hPattern = re.compile(r'(\d+) *h')
        self.dPattern = re.compile(r'(\d+) *d')
        self.mPattern = re.compile(r'(\d+) *min')

    def get_duration(self, durationStr):
        hours = 0
        try:
            minutes = int(self.mPattern.search(durationStr).group(1))
            hours, minutes = divmod(minutes, 60)
        except AttributeError:
            minutes = 0
        days = 0
        try:
            hours += int(self.hPattern.search(durationStr).group(1))
            days, hours = divmod(hours, 24)
        except AttributeError:
            pass
        try:
            days += int(self.dPattern.search(durationStr).group(1))
        except AttributeError:
            pass
        return days, hours, minutes

import zipfile

from datetime import datetime
from shutil import rmtree
from string import Template
import tempfile
from xml import sax



class OdfFile(FileExport):
    _ODF_COMPONENTS = []
    _MIMETYPE = ''
    _MANIFEST_XML = ''
    _STYLES_XML = ''
    _META_XML = ''

    NAMESPACES = dict(
        office='urn:oasis:names:tc:opendocument:xmlns:office:1.0',
        style='urn:oasis:names:tc:opendocument:xmlns:style:1.0',
        text='urn:oasis:names:tc:opendocument:xmlns:text:1.0',
        table='urn:oasis:names:tc:opendocument:xmlns:table:1.0',
        draw='urn:oasis:names:tc:opendocument:xmlns:drawing:1.0',
        fo='urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0',
        xlink='http://www.w3.org/1999/xlink',
        dc='http://purl.org/dc/elements/1.1/',
        meta='urn:oasis:names:tc:opendocument:xmlns:meta:1.0',
        number='urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0',
        svg='urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0',
        chart='urn:oasis:names:tc:opendocument:xmlns:chart:1.0',
        dr3d='urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0',
        math='http://www.w3.org/1998/Math/MathML',
        form='urn:oasis:names:tc:opendocument:xmlns:form:1.0',
        script='urn:oasis:names:tc:opendocument:xmlns:script:1.0',
        ooo='http://openoffice.org/2004/office',
        ooow='http://openoffice.org/2004/writer',
        oooc='http://openoffice.org/2004/calc',
        dom='http://www.w3.org/2001/xml-events',
        rpt='http://openoffice.org/2005/report',
        of='urn:oasis:names:tc:opendocument:xmlns:of:1.2',
        xhtml='http://www.w3.org/1999/xhtml',
        grddl='http://www.w3.org/2003/g/data-view#',
        tableooo='http://openoffice.org/2009/table',
        loext=(
            'urn:org:documentfoundation:names:experimental:'
            'office:xmlns:loext:1.0'
        ),
    )

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._tempDir = tempfile.mkdtemp(suffix='.tmp', prefix='odf_')
        self._originalPath = self._filePath

    def __del__(self):
        self._tear_down()

    def is_locked(self):
        return odf_is_locked(self.filePath)

    def write_content_xml(self):
        super().write()

    def write(self):

        self._set_up()

        self._originalPath = self._filePath
        self._filePath = f'{self._tempDir}/content.xml'
        self.write_content_xml()
        self._filePath = self._originalPath

        workdir = os.getcwd()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise RuntimeError(
                    f'{_("Cannot overwrite file")}: '
                    f'"{norm_path(self.filePath)}".'
                )
            else:
                backedUp = True
        try:
            with zipfile.ZipFile(self.filePath, 'w') as odfTarget:
                os.chdir(self._tempDir)
                for file in self._ODF_COMPONENTS:
                    odfTarget.write(file, compress_type=zipfile.ZIP_DEFLATED)
        except:
            os.chdir(workdir)
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise RuntimeError(
                f'{_("Cannot create file")}: '
                f'"{norm_path(self.filePath)}".'
            )

        os.chdir(workdir)
        self._tear_down()
        return f'{_("File written")}: "{norm_path(self.filePath)}".'

    def _escape(self, text):
        try:
            return sax.saxutils.escape(text)

        except AttributeError:
            return text

    def _get_styles_xml_str(self):
        self.novel.check_locale()
        localeMapping = dict(
            Language=self.novel.languageCode,
            Country=self.novel.countryCode or 'none',
        )
        template = Template(self._STYLES_XML)
        stylesXmlStr = template.safe_substitute(localeMapping)
        return stylesXmlStr

    def _set_up(self):

        try:
            self._tear_down()
            os.mkdir(self._tempDir)
            os.mkdir(f'{self._tempDir}/META-INF')
        except:
            raise RuntimeError(
                f'{_("Cannot create directory")}: '
                f'"{norm_path(self._tempDir)}".'
            )
        try:
            with open(
                f'{self._tempDir}/mimetype',
                'w',
                encoding='utf-8'
            ) as f:
                f.write(self._MIMETYPE)
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "mimetype"')

        try:
            with open(
                f'{self._tempDir}/META-INF/manifest.xml',
                'w',
                encoding='utf-8'
            ) as f:
                f.write(self._MANIFEST_XML)
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "manifest.xml"')

        stylesXmlStr = self._get_styles_xml_str()
        try:
            with open(
                f'{self._tempDir}/styles.xml',
                'w',
                encoding='utf-8'
            ) as f:
                f.write(stylesXmlStr)
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "styles.xml"')

        metaMapping = dict(
            Author=self._escape(self.novel.authorName),
            Title=self._escape(self.novel.title),
            Summary=self._escape(self.novel.desc),
            Datetime=datetime.today().replace(microsecond=0).isoformat(),
        )
        template = Template(self._META_XML)
        stylesXmlStr = template.safe_substitute(metaMapping)
        try:
            with open(
                f'{self._tempDir}/meta.xml',
                'w',
                encoding='utf-8'
            ) as f:
                f.write(stylesXmlStr)
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "meta.xml".')

    def _tear_down(self):
        try:
            rmtree(self._tempDir)
        except:
            pass



class OdsParser:

    def get_rows(self, filePath, cellsPerRow):
        root = ET.fromstring(self._unzip_ods_file(filePath))

        body = root.find('office:body', OdfFile.NAMESPACES)
        spreadsheet = body.find('office:spreadsheet', OdfFile.NAMESPACES)
        table = spreadsheet.find('table:table', OdfFile.NAMESPACES)
        rows = []
        for row in table.iterfind('table:table-row', OdfFile.NAMESPACES):
            cells = []
            i = 0
            for cell in row.iterfind('table:table-cell', OdfFile.NAMESPACES):
                content = ''
                odfDate = cell.get(
                    f'{{{OdfFile.NAMESPACES["office"]}}}date-value'
                )
                odfTime = cell.get(
                    f'{{{OdfFile.NAMESPACES["office"]}}}time-value'
                )
                if odfDate:
                    cells.append(odfDate)
                elif odfTime:
                    t = re.search(r'PT(..)H(..)M(..)S', odfTime)
                    cells.append(f'{t.group(1)}:{t.group(2)}:{t.group(3)}')
                elif cell.find('text:p', OdfFile.NAMESPACES) is not None:
                    lines = []
                    for paragraph in cell.iterfind(
                        'text:p',
                        OdfFile.NAMESPACES
                    ):
                        lines.append(''.join(t for t in paragraph.itertext()))
                    content = '\n'.join(lines)
                    cells.append(content)
                else:
                    cells.append(content)

                i += 1
                if i >= cellsPerRow:
                    break

                attribute = cell.get(
                    f'{{{OdfFile.NAMESPACES["table"]}}}'
                    'number-columns-repeated'
                )
                if attribute:
                    repeat = int(attribute) - 1
                    for __ in range(repeat):
                        if i >= cellsPerRow:
                            break

                        cells.append(content)
                        i += 1
            if cells:
                rows.append(cells)
        return rows

    def _unzip_ods_file(self, filePath):
        try:
            with zipfile.ZipFile(filePath, 'r') as odfFile:
                content = odfFile.read('content.xml')
            return content

        except:
            raise RuntimeError(
                f'{_("Cannot read file")}: "{norm_path(filePath)}".'
            )



class OdsReader(OdfReader, ABC):
    EXTENSION = '.ods'
    _SEPARATOR = ','
    _columnTitles = []
    _idPrefix = '??',

    _DIVIDER = FileExport._DIVIDER

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._columnDict = None
        self._rows = None
        self.parser = OdsParser()

    def add_new_element(self, prevId, row):
        return ''

    @abstractmethod
    def read(self):
        self._columnDict = {}
        cellsPerRow = len(self._columnTitles)
        self._rows = self.parser.get_rows(self.filePath, cellsPerRow)
        for title in self._rows[0]:
            self._columnDict[title] = {}
        elemId = None
        for row in self._rows:
            if not row[0]:
                elemId = self.add_new_element(elemId, row)
            else:
                elemId = row[0]
            if elemId and elemId[:2] in self._idPrefix:
                for i, col in enumerate(self._columnDict):
                    self._columnDict[col][elemId] = row[i]
            else:
                elemId = None

    def _read_basic_element(self, element, elemId):

        try:
            title = self._columnDict['Name'][elemId]
        except:
            pass
        else:
            element.title = title.rstrip()

        try:
            title = self._columnDict['Title'][elemId]
        except:
            pass
        else:
            element.title = title.rstrip()

        try:
            desc = self._columnDict['Description'][elemId]
        except:
            pass
        else:
            element.desc = desc.rstrip()

    def _read_basic_element_notes(self, element, elemId):
        self._read_basic_element(element, elemId)

        try:
            notes = self._columnDict['Notes'][elemId]
        except:
            pass
        else:
            element.notes = notes.rstrip()

    def _read_basic_element_tags(self, element, elemId):
        self._read_basic_element_notes(element, elemId)

        try:
            tags = self._columnDict['Tags'][elemId]
        except:
            pass
        else:
            if tags:
                element.tags = string_to_list(
                    tags,
                    divider=self._DIVIDER,
                )

    def _read_chapters(self):
        for chId in self.novel.chapters:
            self._read_basic_element_notes(self.novel.chapters[chId], chId)

    def _read_characters(self):
        for crId in self.novel.characters:
            self._read_world_element(self.novel.characters[crId], crId)

            try:
                fullName = self._columnDict['Full name'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].fullName = fullName.rstrip()

            try:
                bio = self._columnDict['Bio'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].bio = bio.rstrip()

            try:
                goals = self._columnDict['Goals'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].goals = goals.rstrip()

            try:
                birthDate = self._columnDict['Birth date'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].birthDate = birthDate.rstrip()

            try:
                deathDate = self._columnDict['Death date'][crId]
            except:
                pass
            else:
                self.novel.characters[crId].deathDate = deathDate.rstrip()

            try:
                importance = self._columnDict['Importance'][crId]
            except:
                pass
            else:
                if MAJOR_MARKER in importance:
                    self.novel.characters[crId].isMajor = True
                elif MINOR_MARKER in importance:
                    self.novel.characters[crId].isMajor = False

    def _read_items(self):
        for itId in self.novel.items:
            self._read_world_element(self.novel.items[itId], itId)

    def _read_locations(self):
        for lcId in self.novel.locations:
            self._read_world_element(self.novel.locations[lcId], lcId)

    def _read_plotlines(self):
        for plId in self.novel.plotLines:
            self._read_basic_element_notes(self.novel.plotLines[plId], plId)

    def _read_plot_points(self):
        for ppId in self.novel.plotPoints:
            self._read_basic_element_notes(self.novel.plotPoints[ppId], ppId)

    def _read_project_notes(self):
        for pnId in self.novel.projectNotes:
            self._read_basic_element(self.novel.projectNotes[pnId], pnId)

    def _read_sections(self):
        durationParser = DurationParser()
        for scId in self.novel.sections:
            self._read_basic_element_tags(self.novel.sections[scId], scId)

            for plId in self.novel.plotLines:
                try:
                    odsPlotLineNotes = self._columnDict[plId][scId]
                except:
                    continue

                plotlineNotes = self.novel.sections[scId].plotlineNotes
                if not plotlineNotes:
                    plotlineNotes = {}
                plotlineNotes[plId] = odsPlotLineNotes.strip()
                self.novel.sections[scId].plotlineNotes = plotlineNotes
                if (
                    plotlineNotes[plId]
                    and not plId in self.novel.sections[scId].scPlotLines
                ):
                    scPlotLines = self.novel.sections[scId].scPlotLines
                    scPlotLines.append(plId)
                    self.novel.sections[scId].scPlotLines = scPlotLines
                    plSections = self.novel.plotLines[plId].sections
                    plSections.append(scId)
                    self.novel.plotLines[plId].sections = plSections

            try:
                scDate = self._columnDict['Date'][scId]
                self.novel.sections[scId].date = PyCalendar.verified_date(
                    scDate)
            except:
                pass

            try:
                scTime = self._columnDict['Time'][scId]
                self.novel.sections[scId].time = PyCalendar.verified_time(
                    scTime)
            except:
                pass

            try:
                day = self._columnDict['Day'][scId]
                int(day)
            except:
                pass
            else:
                self.novel.sections[scId].day = day.strip()

            try:
                durationStr = self._columnDict['Duration'][scId]
                d, h, m = durationParser.get_duration(durationStr)
            except:
                pass
            else:
                self.novel.sections[scId].lastsDays = str(d)
                self.novel.sections[scId].lastsHours = str(h)
                self.novel.sections[scId].lastsMinutes = str(m)

            try:
                viewpoint = self._columnDict['Viewpoint'][scId]
            except:
                pass
            else:
                viewpoint = viewpoint.strip()

                vpId = None
                for crId in self.novel.characters:
                    if self.novel.characters[crId].title == viewpoint:
                        vpId = crId
                        break

                self.novel.sections[scId].viewpoint = vpId

            try:
                ar = self._columnDict['Scene'][scId] or '-'
            except:
                ar = '-'
            self.novel.sections[scId].scene = SCENE.index(ar)

            try:
                goal = self._columnDict['Goal'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].goal = goal.strip()

            try:
                conflict = self._columnDict['Conflict'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].conflict = conflict.strip()

            try:
                outcome = self._columnDict['Outcome'][scId]
            except:
                pass
            else:
                self.novel.sections[scId].outcome = outcome.strip()

    def _read_world_element(self, element, elemId):
        self._read_basic_element_tags(element, elemId)

        try:
            aka = self._columnDict['Aka'][elemId]
        except:
            pass
        else:
            element.aka = aka.rstrip()



class OdsRChapterList(OdsReader):

    DESCRIPTION = _('Chapter table')
    SUFFIX = CHAPTERLIST_SUFFIX
    _columnTitles = [
        'ID',
        'Chapter',
        'Title',
        'Description',
        'Notes',
    ]
    _idPrefix = CHAPTER_PREFIX,

    def add_new_element(self, prevId, row, level=2):
        if not row[2]:
            return ''

        newId = new_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[newId] = Chapter(
            chLevel=level,
            chType=0,
            noNumber=False,
            isTrash=False,
            hasEpigraph=False,
        )
        if prevId:
            index = self.novel.tree.get_children(CH_ROOT).index(prevId) + 1
        else:
            index = 0
        self.novel.tree.insert(CH_ROOT, index, newId)
        self.projectStructureModified = True
        return newId

    def read(self):
        super().read()
        self._read_chapters()



class OdsRCharList(OdsReader):
    DESCRIPTION = _('Character table')
    SUFFIX = CHARLIST_SUFFIX
    _columnTitles = [
        'ID',
        'Name',
        'Full name',
        'Aka',
        'Description',
        'Bio',
        'Goals',
        'Importance',
        'Tags',
        'Notes',
    ]
    _idPrefix = CHARACTER_PREFIX,

    def add_new_element(self, prevId, row):
        if not row[1]:
            return ''

        newId = new_id(self.novel.characters, prefix=CHARACTER_PREFIX)
        self.novel.characters[newId] = Character()
        if prevId is not None:
            index = self.novel.tree.get_children(CR_ROOT).index(prevId) + 1
        else:
            index = 0
        self.novel.tree.insert(CR_ROOT, index, newId)
        self.projectStructureModified = True
        return newId

    def read(self):
        super().read()
        self._read_characters()



class OdsRGrid(OdsReader):
    DESCRIPTION = _('Plot grid')
    SUFFIX = GRID_SUFFIX
    COLUMN_TITLES = [
        'ID',
        'Section',
        'Date',
        'Time',
        'Day',
        'Duration',
        'Title',
        'Description',
        'Viewpoint',
        'Tags',
        'Scene',
        'Goal',
        'Conflict',
        'Outcome',
        'Notes',
    ]
    _idPrefix = SECTION_PREFIX,

    def add_new_element(self, prevId, row):
        if not row[6]:
            return ''

        newId = new_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[newId] = Section(
            scType=0,
            status=1,
            appendToPrev=False,
        )
        if prevId:
            chId = self.novel.tree.parent(prevId)
            index = self.novel.tree.get_children(chId).index(prevId) + 1
        else:
            chId = self.novel.tree.get_children(CH_ROOT)[0]
            index = 0
        self.novel.tree.insert(chId, index, newId)
        self.projectStructureModified = True
        return newId

    def read(self):
        self._columnTitles = self.COLUMN_TITLES[:]
        for plId in self.novel.plotLines:
            self._columnTitles.append(plId)
        super().read()
        self._read_sections()

        for i, column in enumerate(self._rows[0]):
            if column.startswith(PLOT_LINE_PREFIX):
                self.novel.plotLines[column].title = self._rows[1][i]



class OdsRItemList(OdsReader):
    DESCRIPTION = _('Item table')
    SUFFIX = ITEMLIST_SUFFIX
    _columnTitles = [
        'ID',
        'Name',
        'Description',
        'Aka',
        'Tags',
        'Notes',
    ]
    _idPrefix = ITEM_PREFIX,

    def add_new_element(self, prevId, row):
        if not row[1]:
            return ''

        newId = new_id(self.novel.items, prefix=ITEM_PREFIX)
        self.novel.items[newId] = WorldElement()
        if prevId is not None:
            index = self.novel.tree.get_children(IT_ROOT).index(prevId) + 1
        else:
            index = 0
        self.novel.tree.insert(IT_ROOT, index, newId)
        self.projectStructureModified = True
        return newId

    def read(self):
        super().read()
        self._read_items()



class OdsRLocList(OdsReader):
    DESCRIPTION = _('Location table')
    SUFFIX = LOCLIST_SUFFIX
    _columnTitles = [
        'ID',
        'Name',
        'Description',
        'Aka',
        'Tags',
        'Notes',
    ]
    _idPrefix = LOCATION_PREFIX,

    def add_new_element(self, prevId, row):
        if not row[1]:
            return ''

        newId = new_id(self.novel.locations, prefix=LOCATION_PREFIX)
        self.novel.locations[newId] = WorldElement()
        if prevId is not None:
            index = self.novel.tree.get_children(LC_ROOT).index(prevId) + 1
        else:
            index = 0
        self.novel.tree.insert(LC_ROOT, index, newId)
        self.projectStructureModified = True
        return newId

    def read(self):
        super().read()
        self._read_locations()



class OdsRMetadataText(OdsReader):
    DESCRIPTION = _('Metadata text')
    SUFFIX = METADATA_TEXT_SUFFIX
    COLUMN_TITLES = [
        'ID',
        'Title',
        'Full name',
        'Aka',
        'Description',
        'Bio',
        'Goals',
        'Notes',
        'Tags',
        'Goal',
        'Conflict',
        'Outcome',
    ]
    _idPrefix = (
        CHARACTER_PREFIX,
        CHAPTER_PREFIX,
        ITEM_PREFIX,
        LOCATION_PREFIX,
        SECTION_PREFIX,
        PLOT_LINE_PREFIX,
        PLOT_POINT_PREFIX,
        PRJ_NOTE_PREFIX,
        ROOT_PREFIX,
    )

    def read(self):
        self._columnTitles = self.COLUMN_TITLES[:]
        for plId in self.novel.plotLines:
            self._columnTitles.append(plId)
        super().read()
        self._read_basic_element(self.novel, ROOT_PREFIX)
        self._read_chapters()
        self._read_characters()
        self._read_items()
        self._read_locations()
        self._read_sections()
        self._read_plotlines()
        self._read_plot_points()
        self._read_project_notes()



class OdsRPartList(OdsRChapterList):

    DESCRIPTION = _('Part table')
    SUFFIX = PARTLIST_SUFFIX

    def add_new_element(self, prevId, row):
        return super().add_new_element(prevId, row, level=1)
from string import Template
from xml import sax



class OdsWriter(OdfFile):
    EXTENSION = '.ods'
    _ODF_COMPONENTS = [
        'META-INF',
        'content.xml',
        'meta.xml',
        'mimetype',
        'styles.xml',
        'META-INF/manifest.xml'
    ]


    _CONTENT_XML_HEADER = (
        '<?xml version="1.0" encoding="UTF-8"?>\n\n'
        '<office:document-content '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
        'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
        'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
        'xmlns:fo="urn:oasis:names:tc:opendocument:'
        'xmlns:xsl-fo-compatible:1.0" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" '
        'xmlns:presentation="urn:oasis:names:tc:opendocument:'
        'xmlns:presentation:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:'
        'xmlns:svg-compatible:1.0" '
        'xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" '
        'xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" '
        'xmlns:math="http://www.w3.org/1998/Math/MathML" '
        'xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" '
        'xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:ooow="http://openoffice.org/2004/writer" '
        'xmlns:oooc="http://openoffice.org/2004/calc" '
        'xmlns:dom="http://www.w3.org/2001/xml-events" '
        'xmlns:xforms="http://www.w3.org/2002/xforms" '
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        'xmlns:rpt="http://openoffice.org/2005/report" '
        'xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" '
        'xmlns:xhtml="http://www.w3.org/1999/xhtml" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'xmlns:tableooo="http://openoffice.org/2009/table" '
        'xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:'
        'xmlns:field:1.0" office:version="1.2">\n'
        ' <office:scripts/>\n'
        ' <office:font-face-decls>\n'
        '  <style:font-face style:name="Calibri" '
        'svg:font-family="&apos;Calibri&apos;" '
        'style:font-adornments="Standard" '
        'style:font-family-generic="swiss" style:font-pitch="variable"/>\n'
        ' </office:font-face-decls>\n'
        ' <office:automatic-styles>\n'
        '  <style:style style:name="co1" style:family="table-column">\n'
        '   <style:table-column-properties '
        'fo:break-before="auto" style:column-width="2.000cm"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="co2" style:family="table-column">\n'
        '   <style:table-column-properties '
        'fo:break-before="auto" style:column-width="3.000cm"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="co3" style:family="table-column">\n'
        '   <style:table-column-properties '
        'fo:break-before="auto" style:column-width="4.000cm"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="co4" style:family="table-column">\n'
        '   <style:table-column-properties '
        'fo:break-before="auto" style:column-width="8.000cm"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="ro1" style:family="table-row">\n'
        '   <style:table-row-properties style:row-height="1.157cm" '
        'fo:break-before="auto" style:use-optimal-row-height="true"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="ro2" style:family="table-row">\n'
        '   <style:table-row-properties style:row-height="2.053cm" '
        'fo:break-before="auto" style:use-optimal-row-height="true"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="ta1" style:family="table" '
        'style:master-page-name="Default">\n'
        '   <style:table-properties table:display="true" '
        'style:writing-mode="lr-tb"/>\n'
        '  </style:style>\n'
        '  <number:date-style style:name="N36" '
        'number:automatic-order="true">\n'
        '   <number:day number:style="long"/>\n'
        '   <number:text>.</number:text>\n'
        '   <number:month number:style="long"/>\n'
        '   <number:text>.</number:text>\n'
        '   <number:year number:style="long"/>\n'
        '  </number:date-style>\n'
        '  <number:time-style style:name="N40">\n'
        '   <number:hours number:style="long"/>\n'
        '   <number:text>:</number:text>\n'
        '   <number:minutes number:style="long"/>\n'
        '  </number:time-style>\n'
        '  <style:style style:name="ce1" style:family="table-cell" '
        'style:parent-style-name="Heading" style:data-style-name="N36"/>\n'
        '  <style:style style:name="ce2" style:family="table-cell" '
        'style:parent-style-name="Default" style:data-style-name="N36"/>\n'
        '  <style:style style:name="ce3" style:family="table-cell" '
        'style:parent-style-name="Heading" style:data-style-name="N40"/>\n'
        '  <style:style style:name="ce4" style:family="table-cell" '
        'style:parent-style-name="Default" style:data-style-name="N40"/>\n'
        '$Styles </office:automatic-styles>\n'
        ' <office:body>\n'
        '  <office:spreadsheet>\n'
        '   <table:table table:name="'
    )
    _CONTENT_XML_FOOTER = (
        '   </table:table>\n'
        '  </office:spreadsheet>\n'
        ' </office:body>\n'
        '</office:document-content>\n'
    )
    _META_XML = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<office:document-meta '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'office:version="1.2">\n'
        '  <office:meta>\n'
        '    <meta:generator>novxlib</meta:generator>\n'
        '    <dc:title>$Title</dc:title>\n'
        '    <dc:description>$Summary</dc:description>\n'
        '    <dc:subject></dc:subject>\n'
        '    <meta:keyword></meta:keyword>\n'
        '    <meta:initial-creator>$Author</meta:initial-creator>\n'
        '    <dc:creator></dc:creator>\n'
        '    <meta:creation-date>${Datetime}Z</meta:creation-date>\n'
        '    <dc:date></dc:date>\n'
        '  </office:meta>\n'
        '</office:document-meta>\n'
    )
    _MANIFEST_XML = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<manifest:manifest xmlns:manifest='
        '"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" '
        'manifest:version="1.2">\n'
        ' <manifest:file-entry manifest:media-type='
        '"application/vnd.oasis.opendocument.spreadsheet" '
        'manifest:version="1.2" manifest:full-path="/"/>\n'
        ' <manifest:file-entry manifest:media-type="text/xml" '
        'manifest:full-path="content.xml"/>\n'
        ' <manifest:file-entry manifest:media-type="text/xml" '
        'manifest:full-path="styles.xml"/>\n'
        ' <manifest:file-entry manifest:media-type="text/xml" '
        'manifest:full-path="meta.xml"/>\n'
        ' <manifest:file-entry manifest:media-type="text/xml" '
        'manifest:full-path="settings.xml"/>\n'
        '</manifest:manifest>\n'
    )
    _STYLES_XML = (
        '<?xml version="1.0" encoding="UTF-8"?>\n\n'
        '<office:document-styles '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
        'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
        'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
        'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:'
        'xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" '
        'xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:'
        'presentation:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:'
        'svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:'
        'xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:'
        'xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" '
        'xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" '
        'xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:ooow="http://openoffice.org/2004/writer" '
        'xmlns:oooc="http://openoffice.org/2004/calc" '
        'xmlns:dom="http://www.w3.org/2001/xml-events" '
        'xmlns:rpt="http://openoffice.org/2005/report" '
        'xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" '
        'xmlns:xhtml="http://www.w3.org/1999/xhtml" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'xmlns:tableooo="http://openoffice.org/2009/table" '
        'office:version="1.2">\n'
        ' <office:font-face-decls>\n'
        '  <style:font-face style:name="Calibri" '
        'svg:font-family="&apos;Calibri&apos;" '
        'style:font-adornments="Standard" '
        'style:font-family-generic="swiss" style:font-pitch="variable"/>\n'
        ' </office:font-face-decls>\n'
        ' <office:styles>\n'
        '  <style:default-style style:family="table-cell">\n'
        '   <style:paragraph-properties style:tab-stop-distance="1.25cm"/>\n'
        '   <style:text-properties style:font-name="Arial" '
        'fo:language="$Language" fo:country="$Country" '
        'style:font-name-asian="Arial Unicode MS" style:language-asian="zh" '
        'style:country-asian="CN" style:font-name-complex="Tahoma" '
        'style:language-complex="hi" style:country-complex="IN"/>\n'
        '  </style:default-style>\n'
        '  <number:number-style style:name="N0">\n'
        '   <number:number number:min-integer-digits="1"/>\n'
        '  </number:number-style>\n'
        '  <style:style style:name="Default" style:family="table-cell">\n'
        '   <style:table-cell-properties style:text-align-source="fix" '
        'style:repeat-content="false" fo:background-color="transparent" '
        'fo:wrap-option="wrap" fo:padding="0.136cm" '
        'style:vertical-align="top"/>\n'
        '   <style:paragraph-properties fo:text-align="start"/>\n'
        '   <style:text-properties style:font-name="Calibri" '
        'fo:font-size="10.5pt" style:font-name-asian="Microsoft YaHei" '
        'style:font-name-complex="Lucida Sans"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Result" style:family="table-cell" '
        'style:parent-style-name="Default">\n'
        '   <style:text-properties fo:font-style="italic" '
        'style:text-underline-style="solid" '
        'style:text-underline-width="auto" '
        'style:text-underline-color="font-color" fo:font-weight="bold"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Result2" style:family="table-cell" '
        'style:parent-style-name="Result"/>\n'
        '  <style:style style:name="Heading" style:family="table-cell" '
        'style:parent-style-name="Default">\n'
        '   <style:table-cell-properties fo:background-color="#f0f0f0" '
        'style:text-align-source="fix" style:repeat-content="false"/>\n'
        '   <style:paragraph-properties fo:text-align="start"/>\n'
        '   <style:text-properties fo:font-weight="bold"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading1" '
        'style:family="table-cell" style:parent-style-name="Heading">\n'
        '   <style:table-cell-properties style:rotation-angle="90"/>\n'
        '  </style:style>\n'
        ' </office:styles>\n'
        ' <office:automatic-styles>\n'
        '  <style:page-layout style:name="Mpm1">\n'
        '   <style:page-layout-properties style:writing-mode="lr-tb"/>\n'
        '   <style:header-style>\n'
        '    <style:header-footer-properties fo:min-height="0.751cm" '
        'fo:margin-left="0cm" fo:margin-right="0cm" '
        'fo:margin-bottom="0.25cm"/>\n'
        '   </style:header-style>\n'
        '   <style:footer-style>\n'
        '    <style:header-footer-properties fo:min-height="0.751cm" '
        'fo:margin-left="0cm" fo:margin-right="0cm" '
        'fo:margin-top="0.25cm"/>\n'
        '   </style:footer-style>\n'
        '  </style:page-layout>\n'
        '  <style:page-layout style:name="Mpm2">\n'
        '   <style:page-layout-properties style:writing-mode="lr-tb"/>\n'
        '   <style:header-style>\n'
        '    <style:header-footer-properties fo:min-height="0.751cm" '
        'fo:margin-left="0cm" fo:margin-right="0cm" '
        'fo:margin-bottom="0.25cm" '
        'fo:border="0.088cm solid #000000" fo:padding="0.018cm" '
        'fo:background-color="#c0c0c0">\n'
        '     <style:background-image/>\n'
        '    </style:header-footer-properties>\n'
        '   </style:header-style>\n'
        '   <style:footer-style>\n'
        '    <style:header-footer-properties fo:min-height="0.751cm" '
        'fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.25cm" '
        'fo:border="0.088cm solid #000000" fo:padding="0.018cm" '
        'fo:background-color="#c0c0c0">\n'
        '     <style:background-image/>\n'
        '    </style:header-footer-properties>\n'
        '   </style:footer-style>\n'
        '  </style:page-layout>\n'
        ' </office:automatic-styles>\n'
        ' <office:master-styles>\n'
        '  <style:master-page style:name="Default" '
        'style:page-layout-name="Mpm1">\n'
        '   <style:header>\n'
        '    <text:p><text:sheet-name>???</text:sheet-name></text:p>\n'
        '   </style:header>\n'
        '   <style:header-left style:display="false"/>\n'
        '   <style:footer>\n'
        '    <text:p>Seite <text:page-number>1</text:page-number></text:p>\n'
        '   </style:footer>\n'
        '   <style:footer-left style:display="false"/>\n'
        '  </style:master-page>\n'
        '  <style:master-page style:name="Report" '
        'style:page-layout-name="Mpm2">\n'
        '   <style:header>\n'
        '    <style:region-left>\n'
        '     <text:p><text:sheet-name>???</text:sheet-name> '
        '(<text:title>???</text:title>)</text:p>\n'
        '    </style:region-left>\n'
        '    <style:region-right>\n'
        '     <text:p><text:date style:data-style-name="N2" '
        'text:date-value="2021-03-15">15.03.2021</text:date>, '
        '<text:time>15:34:40</text:time></text:p>\n'
        '    </style:region-right>\n'
        '   </style:header>\n'
        '   <style:header-left style:display="false"/>\n'
        '   <style:footer>\n'
        '    <text:p>Seite <text:page-number>1</text:page-number> / '
        '<text:page-count>99</text:page-count></text:p>\n'
        '   </style:footer>\n'
        '   <style:footer-left style:display="false"/>\n'
        '  </style:master-page>\n'
        ' </office:master-styles>\n'
        '</office:document-styles>\n'
    )
    _MIMETYPE = 'application/vnd.oasis.opendocument.spreadsheet'

    def _convert_from_novx(self, text, isLink=False, **kwargs):
        if not text:
            return ''

        text = text.rstrip()
        entities = {"'": '&apos;'}
        entities['"'] = '&apos;' if isLink else '&quot;'
        text = sax.saxutils.escape(text, entities=entities)
        return text.replace('\n', '</text:p>\n<text:p>')

    def _get_extra_styles(self, elements):

        styleTemplate = (
            '  <style:style style:name="$Name" style:family="table-cell" '
            'style:parent-style-name="Default">\n'
            '   <style:table-cell-properties '
            'fo:border-bottom="none" '
            'fo:border-left="0.176cm solid $BgColor" '
            'fo:border-right="none" '
            'fo:border-top="none"/>\n'
            '  </style:style>'
        )

        mappings = {}
        xmlText = []
        for elemId in elements:
            mappings['Name'] = elemId
            mappings['BgColor'] = elements[elemId].color or '#ffffff'
            styleXml = Template(styleTemplate)
            xmlText.append(styleXml.substitute(mappings))
        return '\n'.join(xmlText)

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = ''
        return fileHeaderMapping


class OdsWChapterList(OdsWriter):

    DESCRIPTION = _('Chapter table')
    SUFFIX = CHAPTERLIST_SUFFIX

    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:number-columns-repeated="1019" '
        'table:default-cell-style-name="Default"/>\n'
        '     <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Chapter</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1019"/>\n'
        '    </table:table-row>\n'
        '     <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Chapter")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Title")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1019"/>\n'
        '    </table:table-row>\n'
    )
    _chapterTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'office:value-type="string">\n'
        '      <text:p>$ChapterNumber</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:number-columns-repeated="1019"/>\n'
        '    </table:table-row>\n'
    )
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = self._get_extra_styles(
            self.novel.chapters
        )
        return fileHeaderMapping
from string import Template



class OdsWCharList(OdsWriter):

    DESCRIPTION = _('Character table')
    SUFFIX = CHARLIST_SUFFIX

    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:number-columns-repeated="3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="ce2"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="ce2"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:number-columns-repeated="1014" '
        'table:default-cell-style-name="Default"/>\n'
        '     <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Name</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Full name</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Aka</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Bio</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Goals</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="ce1" '
        'office:value-type="string">\n'
        '      <text:p>Birth date</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="ce1" '
        'office:value-type="string">\n'
        '      <text:p>Death date</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Importance</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1014"/>\n'
        '    </table:table-row>\n'
        '     <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Name")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Full name")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Aka")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>$CharacterField1</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>$CharacterField2</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Birth date")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Death date")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Importance")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Tags")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1014"/>\n'
        '    </table:table-row>\n'
    )
    _characterTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$FullName</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$AKA</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Bio</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Goals</text:p>\n'
        '     </table:table-cell>\n'
        '$BirthDateCell\n'
        '$DeathDateCell\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Status</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:number-columns-repeated="1014"/>\n'
        '    </table:table-row>\n'
    )
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER
    _emptyDateCell = '     <table:table-cell table:style-name="ce2"/>'
    _validBirthDateCell = (
        '     <table:table-cell office:value-type="date" '
        'office:date-value="$BirthDate">\n'
        '      <text:p>$BirthDate</text:p>\n'
        '     </table:table-cell>\n'
     )
    _validDeathDateCell = (
        '     <table:table-cell office:value-type="date" '
        'office:date-value="$DeathDate">\n'
        '      <text:p>$DeathDate</text:p>\n'
        '     </table:table-cell>\n'
    )

    def _get_characterMapping(self, crId):
        characterMapping = super()._get_characterMapping(crId)

        if characterMapping['BirthDate']:
            characterMapping['BirthDateCell'] = Template(
                self._validBirthDateCell
            ).safe_substitute(characterMapping)
        else:
            characterMapping['BirthDateCell'] = self._emptyDateCell

        if characterMapping['DeathDate']:
            characterMapping['DeathDateCell'] = Template(
                self._validDeathDateCell
            ).safe_substitute(characterMapping)
        else:
            characterMapping['DeathDateCell'] = self._emptyDateCell

        return characterMapping

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = self._get_extra_styles(
            self.novel.characters
        )
        return fileHeaderMapping

from string import Template



class OdsWGrid(OdsWriter):

    DESCRIPTION = _('Plot grid')
    SUFFIX = GRID_SUFFIX



    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="ce2"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="ce4"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '$PlotlineColumns\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Section</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="ce1" office:value-type="string">\n'
        '      <text:p>Date</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="ce3" office:value-type="string">\n'
        '      <text:p>Time</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Day</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Duration</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Viewpoint</text:p>\n'
        '     </table:table-cell>\n'
        '$PlotlineIdCells\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Scene</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Goal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Conflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Outcome</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" table:number-columns-repeated="1003"/>\n'
        '    </table:table-row>\n'
        '    <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Section")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="ce1" office:value-type="string">\n'
        f'      <text:p>{_("Date")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="ce3" office:value-type="string">\n'
        f'      <text:p>{_("Time")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Day")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Duration")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Title")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Viewpoint")}</text:p>\n'
        '     </table:table-cell>\n'
        '$PlotlineTitleCells\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Tags")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>{_("Scene")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>$NotASceneField1 / '
        f'{_("Goal")} / {_("Reaction")} / $OtherSceneField1</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        f'      <text:p>$NotASceneField2 / '
        f'{_("Conflict")} / {_("Dilemma")} / $OtherSceneField2</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>$NotASceneField3 /'
        f'{_("Outcome")} / {_("Choice")} / $OtherSceneField3</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1003"/>\n'
        '    </table:table-row>\n'
    )
    _sectionTemplate = _epigraphTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'table:formula="of:=HYPERLINK(&quot;'
        'file:///$ProjectPath/$ProjectName$ManuscriptSuffix.odt'
        '#$ID%7Cregion&quot;;&quot;$SectionNumber&quot;)" '
        'office:value-type="string" office:string-value="$SectionNumber">\n'
        '      <text:p>$SectionNumber</text:p>\n'
        '     </table:table-cell>\n'
        '$DateCell'
        '$TimeCell'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Day</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Duration</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Viewpoint</text:p>\n'
        '     </table:table-cell>\n'
        '$PlotlineNoteCells\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Scene</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Goal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Conflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Outcome</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '    </table:table-row>\n'
    )
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER
    _emptyDateCell = '     <table:table-cell table:style-name="ce2"/>'
    _validDateCell = (
        '     <table:table-cell '
        'office:value-type="date" office:date-value="$Date">\n'
        '      <text:p>$Date</text:p>\n'
        '     </table:table-cell>\n'
    )
    _emptyTimeCell = '     <table:table-cell table:style-name="ce4"/>'
    _validTimeCell = (
        '     <table:table-cell office:value-type="time" '
        'office:time-value="$OdsTime">\n'
        '      <text:p>$Time</text:p>\n'
        '     </table:table-cell>\n'
    )
    _plotlineNoteCell = (
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$PlotlineNote</text:p>\n'
        '     </table:table-cell>\n'
    )
    _plotlineIdCell = (
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>$PlotlineId</text:p>\n'
        '     </table:table-cell>\n'
    )
    _plotlineTitleCell = (
        '     <table:table-cell $Link '
        'table:style-name="h$PlotlineId" office:value-type="string">\n'
        '      <text:p>$PlotlineTitle</text:p>\n'
        '     </table:table-cell>\n'
    )

    def _get_extra_h_styles(self, elements):

        DEFAULT_BG_COLOR = '#000000'

        styleTemplateHeading = (
            '  <style:style style:name="h$Name" style:family="table-cell" '
            'style:parent-style-name="Heading">\n'
            '   <style:table-cell-properties '
            'fo:border-bottom="none" '
            'fo:border-left="none" '
            'fo:border-right="none" '
            'fo:border-top="0.176cm solid $BgColor"/>\n'
            '  </style:style>'
        )

        mappings = {}
        xmlText = []
        for elemId in elements:
            bgColor = elements[elemId].color or DEFAULT_BG_COLOR
            mappings['Name'] = elemId
            mappings['BgColor'] = bgColor
            styleXml = Template(styleTemplateHeading)
            xmlText.append(styleXml.substitute(mappings))

        return '\n'.join(xmlText)

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()

        plotlineColumns = []
        plotlineIdCells = []
        plotlineTitleCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            link = self._convert_from_novx(
                self.novel.plotLines[plId].title,
                isLink=True,
            )
            plotlineColumns.append(
                '    <table:table-column table:style-name="co4" '
                f'table:default-cell-style-name="Default"/>'
            )
            mapping = dict(
                PlotlineId=plId,
                PlotlineTitle=self.novel.plotLines[plId].title,
                Link=(
                    'table:formula="of:=HYPERLINK(&quot;'
                    f'file:///{self.projectPath}/'
                    f'{self._convert_from_novx(self.projectName)}'
                    f'{PLOTLINES_SUFFIX}.odt#{plId}&quot;;&quot;'
                    f'{link}&quot;)"'
                ),
            )
            plotlineIdCells.append(
                Template(self._plotlineIdCell).safe_substitute(mapping)
            )
            plotlineTitleCells.append(
                Template(self._plotlineTitleCell).safe_substitute(mapping)
            )
        fileHeaderMapping['PlotlineColumns'] = '\n'.join(plotlineColumns)
        fileHeaderMapping['PlotlineIdCells'] = '\n'.join(plotlineIdCells)
        fileHeaderMapping['PlotlineTitleCells'] = '\n'.join(plotlineTitleCells)
        extraStyles = self._get_extra_styles(self.novel.sections)
        extraHeadingStyles = self._get_extra_h_styles(self.novel.plotLines)
        fileHeaderMapping['Styles'] = f'{extraStyles}{extraHeadingStyles}'

        return fileHeaderMapping

    def _get_sectionMapping(
        self,
        scId,
        sectionNumber,
        wordsTotal,
        firstInChapter=False,
        isEpigraph=False,
    ):
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter,
            isEpigraph,
        )

        if sectionMapping['Date']:
            sectionMapping['DateCell'] = Template(
                self._validDateCell
            ).safe_substitute(sectionMapping)
        else:
            sectionMapping['DateCell'] = self._emptyDateCell

        if sectionMapping['Time']:
            sectionMapping['TimeCell'] = Template(
                self._validTimeCell
            ).safe_substitute(sectionMapping)
        else:
            sectionMapping['TimeCell'] = self._emptyTimeCell

        plotlineCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            plotlineNotes = self.novel.sections[scId].plotlineNotes
            if plotlineNotes:
                plotlineNote = plotlineNotes.get(plId, '')
            else:
                plotlineNote = ''
            mapping = {
                'PlotlineNote':plotlineNote,
                'ID':plId,
            }
            plotlineCells.append(
                Template(self._plotlineNoteCell).safe_substitute(mapping)
            )
        sectionMapping['PlotlineNoteCells'] = '\n'.join(plotlineCells)

        return sectionMapping



class OdsWItemList(OdsWriter):

    DESCRIPTION = _('Item table')
    SUFFIX = ITEMLIST_SUFFIX

    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:number-columns-repeated="1013" '
        'table:default-cell-style-name="Default"/>\n'
        '     <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Name</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Aka</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1013"/>\n'
        '    </table:table-row>\n'
        '     <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Name")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Aka")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Tags")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1013"/>\n'
        '    </table:table-row>\n'
    )
    _itemTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$AKA</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:number-columns-repeated="1013"/>\n'
        '    </table:table-row>\n'
    )
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = self._get_extra_styles(
            self.novel.items
        )
        return fileHeaderMapping


class OdsWLocList(OdsWriter):
    DESCRIPTION = _('Location table')
    SUFFIX = LOCLIST_SUFFIX

    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:number-columns-repeated="1013" '
        'table:default-cell-style-name="Default"/>\n'
        '     <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Name</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Aka</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1013"/>\n'
        '    </table:table-row>\n'
        '     <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Name")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Aka")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Tags")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1013"/>\n'
        '    </table:table-row>\n'
    )
    _locationTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$AKA</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:number-columns-repeated="1013"/>\n'
        '    </table:table-row>\n'
    )
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = self._get_extra_styles(
            self.novel.locations
        )
        return fileHeaderMapping
from string import Template



class OdsWMetadataText(OdsWriter):

    DESCRIPTION = _('Metadata text')
    SUFFIX = METADATA_TEXT_SUFFIX



    _element_template = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$FullName</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$AKA</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Bio</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Goals</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Goal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Conflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Outcome</text:p>\n'
        '     </table:table-cell>\n'
        '$ArcNoteCells\n'
        '    </table:table-row>\n'
    )
    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:number-columns-repeated="3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '$ArcColumns\n'
        '    <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Full name</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Aka</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Bio</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Goals</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Goal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Conflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>Outcome</text:p>\n'
        '     </table:table-cell>\n'
        '$ArcIdCells\n'
        '     <table:table-cell '
        'table:style-name="Heading" table:number-columns-repeated="1003"/>\n'
        '    </table:table-row>\n'
        f'{_element_template}'
    )
    _characterTemplate = _element_template
    _chapterTemplate = _element_template
    _epigraphTemplate = _element_template
    _itemTemplate = _element_template
    _locationTemplate = _element_template
    _partTemplate = _element_template
    _plotLineTemplate = _element_template
    _plotPointTemplate = _element_template
    _projectNoteTemplate = _element_template
    _sectionTemplate = _element_template
    _stage1Template = _element_template
    _stage2Template = _element_template
    _unusedChapterTemplate = _element_template
    _unusedSectionTemplate = _element_template

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER
    _emptyDateCell = '     <table:table-cell table:style-name="ce2"/>'
    _validDateCell = (
        '     <table:table-cell '
        'office:value-type="date" office:date-value="$Date">\n'
        '      <text:p>$Date</text:p>\n'
        '     </table:table-cell>\n'
    )
    _emptyTimeCell = '     <table:table-cell table:style-name="ce4"/>'
    _validTimeCell = (
        '     <table:table-cell office:value-type="time" '
        'office:time-value="$OdsTime">\n'
        '      <text:p>$Time</text:p>\n'
        '     </table:table-cell>\n'
    )
    _arcNoteCell = (
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ArcNote</text:p>\n'
        '     </table:table-cell>\n'
    )
    _arcIdCell = (
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>$ArcId</text:p>\n'
        '     </table:table-cell>\n'
    )
    _arcTitleCell = (
        '     <table:table-cell $Link '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>$ArcTitle</text:p>\n'
        '     </table:table-cell>\n'
    )
    _MAPPING = {
        'FullName': '',
        'AKA': '',
        'Bio': '',
        'Goals': '',
        'Notes': '',
        'Tags': '',
        'Goal': '',
        'Conflict': '',
        'Outcome': '',
    }

    def _get_characterMapping(self, crId):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_characterMapping(crId)
        )
        return mapping

    def _get_chapterMapping(self, chId, chapterNumber):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_chapterMapping(chId, chapterNumber)
        )
        return mapping

    def _get_fileHeaderMapping(self):
        mapping = self._MAPPING.copy()
        mapping.update(super()._get_fileHeaderMapping())

        arcColumns = []
        arcIdCells = []
        arcTitleCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            link = self._convert_from_novx(
                self.novel.plotLines[plId].title,
                isLink=True,
            )
            arcColumns.append(
                '    <table:table-column table:style-name="co4" '
                'table:default-cell-style-name="Default"/>'
            )
            arcMapping = dict(
                ArcId=plId,
                ArcTitle=self.novel.plotLines[plId].title,
                Link=(
                    'table:formula="of:=HYPERLINK(&quot;'
                    f'file:///{self.projectPath}/'
                    f'{self._convert_from_novx(self.projectName)}'
                    f'{PLOTLINES_SUFFIX}.odt#{plId}&quot;;&quot;'
                    f'{link}&quot;)"'
                ),
            )
            arcIdCells.append(
                Template(self._arcIdCell
            ).safe_substitute(arcMapping))
            arcTitleCells.append(
                Template(
                    self._arcTitleCell
                ).safe_substitute(arcMapping))
        mapping['ArcColumns'] = '\n'.join(arcColumns)
        mapping['ArcIdCells'] = '\n'.join(arcIdCells)
        mapping['ArcTitleCells'] = '\n'.join(arcTitleCells)
        mapping['ID'] = ROOT_PREFIX
        return mapping

    def _get_itemMapping(self, itId):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_itemMapping(itId)
        )
        return mapping

    def _get_locationMapping(self, lcId):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_locationMapping(lcId)
        )
        return mapping

    def _get_plotLineMapping(self, plId):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_plotLineMapping(plId)
        )
        return mapping

    def _get_plotPointMapping(self, ppId):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_plotPointMapping(ppId)
        )
        return mapping

    def _get_prjNoteMapping(self, pnId):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_prjNoteMapping(pnId)
        )
        return mapping

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter=False,
            isEpigraph=False,
    ):
        mapping = self._MAPPING.copy()
        mapping.update(
            super()._get_sectionMapping(
                scId,
                sectionNumber,
                wordsTotal,
                firstInChapter,
                isEpigraph,
            )
        )

        arcNoteCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            plotlineNotes = self.novel.sections[scId].plotlineNotes
            if plotlineNotes:
                arcNote = plotlineNotes.get(plId, '')
            else:
                arcNote = ''
            arcMapping = {'ArcNote':arcNote}
            arcNoteCells.append(
                Template(
                    self._arcNoteCell
                ).safe_substitute(arcMapping))
        mapping['ArcNoteCells'] = '\n'.join(arcNoteCells)
        return mapping



class OdsWPartList(OdsWriter):

    DESCRIPTION = _('Part table')
    SUFFIX = PARTLIST_SUFFIX

    _fileHeader = (
        f'{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:number-columns-repeated="1019" '
        'table:default-cell-style-name="Default"/>\n'
        '     <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Chapter</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1019"/>\n'
        '    </table:table-row>\n'
        '     <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Part")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Title")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1019"/>\n'
        '    </table:table-row>\n'
    )
    _partTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'office:value-type="string">\n'
        '      <text:p>$ChapterNumber</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:number-columns-repeated="1020"/>\n'
        '    </table:table-row>\n'
    )
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = self._get_extra_styles(
            self.novel.chapters
        )
        return fileHeaderMapping
from string import Template



class HexColor:

    @classmethod
    def get_luminance(cls, hexColor):
        color = hexColor[1:]
        hexRed = int(color[0:2], base=16)
        hexGreen = int(color[2:4], base=16)
        hexBlue = int(color[4:6], base=16)
        return hexRed * 0.2126 + hexGreen * 0.7152 + hexBlue * 0.0722

    @classmethod
    def is_dark(cls, hexColor):
        if not hexColor.startswith('#'):
            return None

        return cls.get_luminance(hexColor) < 140



class OdsWPlotList(OdsWriter):

    DESCRIPTION = _('ODS Plot table')
    SUFFIX = PLOTLIST_SUFFIX

    def write_content_xml(self):
        fileHeader = Template(self._CONTENT_XML_HEADER).substitute(
            self._get_fileHeaderMapping()
        )
        odsText = [
            f'{fileHeader}{self.DESCRIPTION}" table:style-name="ta1" '
            'table:print="false">\n'
            '   <table:table-column table:style-name="co4" '
            'table:default-cell-style-name="Default"/>'
        ]

        srtPlotLines = self.novel.tree.get_children(PL_ROOT)

        for plId in srtPlotLines:
            odsText.append(
                '   <table:table-column table:style-name="co3" '
                'table:default-cell-style-name="Default"/>'
            )

        odsText.append('   <table:table-row table:style-name="ro2">')
        odsText.append(self._new_cell(''))
        for plId in srtPlotLines:
            odsText.append(
                self._new_cell(
                    self.novel.plotLines[plId].title,
                    attr=f'table:style-name="h{plId}"',
                    link=f'{PLOTLINES_SUFFIX}.odt#{plId}'
                )
            )
        odsText.append('    </table:table-row>')

        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    odsText.append(
                        '   <table:table-row table:style-name="ro2">'
                    )
                    odsText.append(
                        self._new_cell(
                            self.novel.sections[scId].title,
                            link=f'{MANUSCRIPT_SUFFIX}.odt#{scId}%7Cregion ',
                            attr=f'table:style-name="{scId}" '
                        )
                    )
                    for plId in srtPlotLines:
                        if scId in self.novel.plotLines[plId].sections:
                            plotPoints = []
                            for ppId in self.novel.tree.get_children(plId):
                                if (
                                    scId ==
                                    self.novel.plotPoints[ppId].sectionAssoc
                                ):
                                    plotPoints.append(
                                        self.novel.plotPoints[ppId].title
                                    )
                            odsText.append(
                                self._new_cell(
                                    list_to_string(
                                        plotPoints,
                                        divider=self._DIVIDER
                                    ),
                                    attr=f'table:style-name="{plId}" '
                                )
                            )
                        else:
                            odsText.append(self._new_cell(''))
                    odsText.append(f'    </table:table-row>')

        odsText.append(self._CONTENT_XML_FOOTER)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(odsText))

    def _get_extra_h_styles(self, elements):

        DEFAULT_BG_COLOR = '#dfdfdf'
        DEFAULT_FG_COLOR = BLACK = '#000000'
        WHITE = '#ffffff'

        styleTemplateHeading = (
            '  <style:style style:name="h$Name" style:family="table-cell" '
            'style:parent-style-name="Default">\n'
            '   <style:table-cell-properties '
            'fo:background-color="$BgColor"/>\n'
            '   <style:text-properties fo:color="$FgColor" '
            'fo:font-weight="bold" '
            'style:font-weight-asian="bold" '
            'style:font-weight-complex="bold"/>\n'
            '  </style:style>'
        )

        styleTemplate = (
            '  <style:style style:name="$Name" style:family="table-cell" '
            'style:parent-style-name="Default">\n'
            '   <style:table-cell-properties '
            'fo:background-color="$DefaultBgColor" '
            'fo:border-bottom="none" '
            'fo:border-left="0.176cm solid $BgColor" '
            'fo:border-right="none" '
            'fo:border-top="none"/>\n'
            '   <style:text-properties fo:color="$DefaultFgColor"/>\n'
            '  </style:style>'
        )

        mappings = {
            'DefaultBgColor': DEFAULT_BG_COLOR,
            'DefaultFgColor': DEFAULT_FG_COLOR,
        }
        xmlText = []
        for elemId in elements:
            elemColor = elements[elemId].color or BLACK
            if HexColor.is_dark(elemColor):
                fgColor = WHITE
            else:
                fgColor = BLACK
            bgColor = elemColor

            mappings['Name'] = elemId
            mappings['BgColor'] = bgColor
            mappings['FgColor'] = fgColor
            styleXml = Template(styleTemplateHeading)
            xmlText.append(styleXml.substitute(mappings))
            styleXml = Template(styleTemplate)
            xmlText.append(styleXml.substitute(mappings))

        return '\n'.join(xmlText)

    def _get_fileHeaderMapping(self):
        extraStyles = self._get_extra_styles(self.novel.sections)
        extraHeadingStyles = self._get_extra_h_styles(self.novel.plotLines)
        fileHeaderMapping = {'Styles': f'{extraStyles}{extraHeadingStyles}'}
        return fileHeaderMapping

    def _new_cell(self, text, attr='', link=''):
        if link:
            attr = (
                f'{attr} table:formula="of:=HYPERLINK(&quot;file:///'
                f'{self.projectPath}/'
                f'{self._convert_from_novx(self.projectName)}{link}&quot;'
                f';&quot;{self._convert_from_novx(text, isLink=True)}&quot;)"'
            )
            text = ''
        else:
            text = f'\n      <text:p>{self._convert_from_novx(text)}</text:p>'
        return (
            f'     <table:table-cell {attr} '
            f'office:value-type="string">{text}\n'
            '     </table:table-cell>'
        )



class OdsWSectionList(OdsWGrid):

    DESCRIPTION = _('Section table')
    SUFFIX = SECTIONLIST_SUFFIX



    _fileHeader = (
        f'{OdsWGrid._CONTENT_XML_HEADER}{DESCRIPTION}" '
        'table:style-name="ta1" table:print="false">\n'
        '    <table:table-column table:style-name="co1" '
        'table:visibility="collapse" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="ce2"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="ce4"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co4" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co2" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co1" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-column table:style-name="co3" '
        'table:default-cell-style-name="Default"/>\n'
        '    <table:table-row table:style-name="ro1" '
        'table:visibility="collapse">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Section</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Description</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Viewpoint</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="ce1" '
        'office:value-type="string">\n'
        '      <text:p>Date</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="ce3" '
        'office:value-type="string">\n'
        '      <text:p>Time</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Day</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Duration</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Section notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Scene</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Goal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Conflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Outcome</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Status</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Words total</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Word count</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Characters</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Locations</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>Items</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1003"/>\n'
        '    </table:table-row>\n'
        '    <table:table-row table:style-name="ro1">\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Section")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Title")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Description")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Viewpoint")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="ce1" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Date")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="ce3" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Time")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Day")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Duration")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Tags")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Section notes")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Scene")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>$NotASceneField1 / '
        f'{_("Goal")} / {_("Reaction")} / $OtherSceneField1</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        '      <text:p>$NotASceneField2 / '
        f'{_("Conflict")} / {_("Dilemma")} / $CustomConflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell '
        'table:style-name="Heading" office:value-type="string">\n'
        '      <text:p>$NotASceneField3 / '
        f'{_("Outcome")} / {_("Choice")} / $CustomOutcome</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Status")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Words total")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Section word count")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Characters")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Locations")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'office:value-type="string">\n'
        f'      <text:p>{_("Items")}</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="Heading" '
        'table:number-columns-repeated="1003"/>\n'
        '    </table:table-row>\n'
    )
    _sectionTemplate = (
        '   <table:table-row table:style-name="ro2">\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$ID</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell table:style-name="$ID" '
        'table:formula="of:=HYPERLINK(&quot;'
        'file:///$ProjectPath/$ProjectName$ManuscriptSuffix.odt'
        '#$ID%7Cregion&quot;;&quot;$SectionNumber&quot;)" '
        'office:value-type="string" office:string-value="$SectionNumber">\n'
        '      <text:p>$SectionNumber</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Title</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Desc</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Viewpoint</text:p>\n'
        '     </table:table-cell>\n'
        '$DateCell\n'
        '$TimeCell\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Day</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Duration</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Tags</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Notes</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Scene</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Goal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Conflict</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Outcome</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Status</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="float" '
        'office:value="$WordsTotal">\n'
        '      <text:p>$WordsTotal</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="float" '
        'office:value="$WordCount">\n'
        '      <text:p>$WordCount</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Characters</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell office:value-type="string">\n'
        '      <text:p>$Locations</text:p>\n'
        '     </table:table-cell>\n'
        '     <table:table-cell>\n'
        '      <text:p>$Items</text:p>\n'
        '     </table:table-cell>\n'
        '    </table:table-row>\n'
    )
    _epigraphTemplate = ''

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = OdsWriter._get_fileHeaderMapping(self)
        fileHeaderMapping['Styles'] = self._get_extra_styles(
            self.novel.sections
        )
        return fileHeaderMapping

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter=False,
            isEpigraph=False,
        ):
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter,
            isEpigraph,
        )
        sectionMapping['Status'] = STATUS[sectionMapping['Status']]
        return sectionMapping
from abc import ABC, abstractmethod



class Splitter(ABC):
    PART_SEPARATOR = '#'
    CHAPTER_SEPARATOR = '##'
    SECTION_SEPARATOR = '###'
    APPENDED_SECTION_SEPARATOR = '####'
    DESC_SEPARATOR = '|'
    _CLIP_TITLE = 20

    def create_chapter(
        self,
        novel,
        chapterId,
        title,
        desc,
        level,
    ):
        newChapter = Chapter()
        newChapter.title = title
        newChapter.desc = desc
        newChapter.chLevel = level
        newChapter.chType = 0
        novel.chapters[chapterId] = newChapter

    def create_section(
        self,
        novel,
        sectionId,
        parent,
        splitCount,
        title,
        appendToPrev,
    ):

        newSection = Section(appendToPrev=appendToPrev)
        if title:
            newSection.title = title
        elif parent.title:
            if len(parent.title) > self._CLIP_TITLE:
                title = f'{parent.title[:self._CLIP_TITLE]}...'
            else:
                title = parent.title
            newSection.title = f'{title} Split: {splitCount}'
        else:
            newSection.title = f'{_("New Section")} Split: {splitCount}'
        newSection.scType = parent.scType
        newSection.scene = parent.scene
        newSection.date = parent.date
        newSection.time = parent.time
        newSection.day = parent.day
        newSection.lastsDays = parent.lastsDays
        newSection.lastsHours = parent.lastsHours
        newSection.lastsMinutes = parent.lastsMinutes
        novel.sections[sectionId] = newSection

    def split_sections(self, novel):

        sectionsSplit = False
        chIndex = 0
        newLines = []
        for scanChId in novel.tree.get_children(CH_ROOT):
            scList = novel.tree.get_children(scanChId)
            novel.tree.delete_children(scanChId)
            chId = scanChId
            for scanScId in scList:
                scId = scanScId
                novel.tree.append(chId, scId)
                if not self._contains_heading(novel, scId):
                    continue

                lines = self._get_lines(novel, scanScId)
                newLines.clear()
                inSection = True
                sectionSplitCount = 0

                for line in lines:
                    plainLine = self._stripped_line(line)

                    if '#' in plainLine:
                        heading = plainLine.strip('# ').split(
                            self.DESC_SEPARATOR)
                        title = heading[0]
                        if len(heading) > 1:
                            desc = heading[1].strip()
                        else:
                            desc = ''

                    if plainLine.startswith(self.SECTION_SEPARATOR):
                        if inSection:
                            self._set_text(novel, scId, newLines)
                        newLines.clear()
                        sectionSplitCount += 1
                        newScId = new_id(
                            novel.sections,
                            prefix=SECTION_PREFIX,
                        )
                        self.create_section(
                            novel,
                            newScId,
                            novel.sections[scId],
                            sectionSplitCount,
                            title,
                            desc,
                            plainLine.startswith(
                                self.APPENDED_SECTION_SEPARATOR)
                        )
                        novel.tree.append(chId, newScId)
                        scId = newScId
                        sectionsSplit = True
                        inSection = True

                    elif plainLine.startswith(self.CHAPTER_SEPARATOR):
                        if inSection:
                            self._set_text(novel, scId, newLines)
                            newLines.clear()
                            inSection = False
                        newChId = new_id(
                            novel.chapters,
                            prefix=CHAPTER_PREFIX,
                        )
                        if not title:
                            title = _('New Chapter')
                        self.create_chapter(novel, newChId, title, desc, 2)
                        chIndex += 1
                        novel.tree.insert(CH_ROOT, chIndex, newChId)
                        chId = newChId
                        sectionsSplit = True

                    elif plainLine.startswith(self.PART_SEPARATOR):
                        if inSection:
                            self._set_text(novel, scId, newLines)
                            newLines.clear()
                            inSection = False
                        newChId = new_id(
                            novel.chapters,
                            prefix=CHAPTER_PREFIX,
                        )
                        if not title:
                            title = _('New Part')
                        self.create_chapter(novel, newChId, title, desc, 1)
                        chIndex += 1
                        novel.tree.insert(CH_ROOT, chIndex, newChId)
                        chId = newChId

                    elif not inSection:
                        newLines.append(line)
                        sectionSplitCount += 1
                        newScId = new_id(
                            novel.sections,
                            prefix=SECTION_PREFIX,
                        )
                        self.create_section(
                            novel,
                            newScId,
                            novel.sections[scId],
                            sectionSplitCount,
                            '',
                            '',
                            False,
                        )
                        novel.tree.append(chId, newScId)
                        scId = newScId
                        sectionsSplit = True
                        inSection = True

                    else:
                        newLines.append(line)

                if inSection:
                    self._set_text(novel, scId, newLines)
            chIndex += 1
        return sectionsSplit

    def _contains_heading(self, novel, scId):
        return True

    @abstractmethod
    def _get_lines(self, novel, scanScId):
        pass

    @abstractmethod
    def _set_text(self, novel, scId, newLines):
        pass

    def _stripped_line(self, line):
        return line


class ChapterSplitter(Splitter):

    def split_sections(self, novel):

        chaptersSplit = False
        chIndex = 0
        newLines = []
        for scanChId in novel.tree.get_children(CH_ROOT):
            chId = scanChId
            if self._contains_heading(novel, chId):
                lines = self._get_lines(novel, scanChId)
                newLines.clear()
                inChapter = True
                chapterSplitCount = 0

                for line in lines:
                    plainLine = self._stripped_line(line)

                    if '#' in plainLine:
                        title = plainLine.strip('# ')

                        if plainLine.startswith(self.CHAPTER_SEPARATOR):
                            level = 2
                        elif plainLine.startswith(self.PART_SEPARATOR):
                            level = 1

                        if inChapter:
                            self._set_text(novel, chId, newLines)

                        newLines.clear()
                        chapterSplitCount += 1
                        newChId = new_id(
                            novel.chapters,
                            prefix=CHAPTER_PREFIX,
                        )
                        self.create_chapter(
                            novel,
                            newChId,
                            title,
                            '',
                            level,
                        )
                        chIndex += 1
                        novel.tree.insert(CH_ROOT, chIndex, newChId)
                        chId = newChId
                        chaptersSplit = True
                        inChapter = True

                    else:
                        newLines.append(line)
                if inChapter:
                    self._set_text(novel, chId, newLines)
            chIndex += 1
        return chaptersSplit

    def _contains_heading(self, novel, chId):
        return (
            novel.chapters[chId].desc and
            '#' in novel.chapters[chId].desc
        )

    def _get_lines(self, novel, scanChId):
        return novel.chapters[scanChId].desc.split('\n')

    def _set_text(self, novel, chId, newLines):
        novel.chapters[chId].desc = '\n'.join(newLines)



class DescSplitter(Splitter):

    def create_section(
        self,
        novel,
        sectionId,
        parent,
        splitCount,
        title,
        desc,
        appendToPrev,
    ):
        super().create_section(
            novel,
            sectionId,
            parent,
            splitCount,
            title,
            appendToPrev,
        )
        novel.sections[sectionId].status = 0

    def _contains_heading(self, novel, scId):
        return (
            novel.sections[scId].desc and
            '#' in novel.sections[scId].desc
        )

    def _get_lines(self, novel, scanScId):
        return novel.sections[scanScId].desc.split('\n')

    def _set_text(self, novel, scId, newLines):
        novel.sections[scId].desc = '\n'.join(newLines)

from abc import ABC

from xml import sax



class OdtParser(sax.ContentHandler):

    def __init__(self, client):
        super().__init__()

        self._emTags = ['Emphasis']

        self._strongTags = ['Strong_20_Emphasis']

        self._normalTags = []

        self._blockquoteTags = ['Quotations']

        self._languageTags = {}

        self._headingTags = {}

        self._paraTags = []

        self._getData = False

        self._span = []

        self._paraSpan = []

        self._style = None

        self._novelLocale = None

        self._currentLocale = []

        self._client = client

    def feed_file(self, filePath):
        styles, meta, content = self._unzip_odt_file(filePath)
        self._read_styles_xml(styles, OdfFile.NAMESPACES)
        self._read_meta_xml(meta, OdfFile.NAMESPACES)
        sax.parseString(content, self)

    def characters(self, content):
        if self._getData:
            self._client.handle_data(sax.saxutils.escape(content))

    def endElement(self, name):
        if name in ('text:p', 'text:h'):
            if self._paraSpan:
                span = self._paraSpan.pop()
                if span is not None:
                    self._client.handle_endtag(span)
            self._getData = False
            self._client.handle_endtag(self._paraTags.pop())
            return

        if name == 'text:span':
            try:
                while self._span:
                    span = self._span.pop()
                    if span is not None:
                        self._client.handle_endtag(span)
                        if span == 'lang':
                            self._currentLocale.pop()
                return

            except:
                return

        if name == 'text:section':
            self._client.handle_endtag('div')
            return

        if name == 'office:annotation':
            self._client.handle_endtag('comment')
            self._getData = True
            return

        if name == 'dc:creator':
            self._client.handle_endtag('creator')
            self._getData = False
            return

        if name == 'dc:date':
            self._client.handle_endtag('date')
            self._getData = False
            return

        if name == 'text:note':
            self._client.handle_endtag('note')
            self._getData = True
            return

        if name == 'text:note-citation':
            self._client.handle_endtag('note-citation')
            self._getData = False
            return

        if name == 'text:list-item':
            self._client.handle_endtag('li')
            return

        if name == 'text:list':
            self._client.handle_endtag('ul')
            return

        if name == 'style:style':
            self._style = None

    def startElement(self, name, attrs):
        xmlAttributes = {}
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            xmlAttributes[attrKey] = attrValue
        style = xmlAttributes.get('text:style-name', '')

        if name in ('text:p', 'text:h'):
            self._getData = True
            self._currentLocale = [self._novelLocale]
            param = []
            if style in self._languageTags:
                self._currentLocale.append(self._languageTags[style])
                if self._currentLocale[-1] != self._novelLocale:
                    param.append(('xml:lang', self._currentLocale[-1]))
            if style in self._blockquoteTags:
                param.append(('style', 'quotations'))
                tag = 'p'
                self._paraTags.append(tag)
                self._client.handle_starttag(tag, param)
            elif style.startswith('Heading'):
                tag = f'h{style[-1]}'
                self._paraTags.append(tag)
                self._client.handle_starttag(tag, param)
            elif style in self._headingTags:
                tag = self._headingTags[style]
                self._paraTags.append(tag)
                self._client.handle_starttag(tag, param)
            else:
                if not param:
                    param = [()]
                tag = 'p'
                self._paraTags.append(tag)
                self._client.handle_starttag(tag, param)
            if style in self._emTags:
                self._paraSpan.append('em')
                self._client.handle_starttag('em', [()])
            elif style in self._strongTags:
                self._paraSpan.append('strong')
                self._client.handle_starttag('strong', [()])
            else:
                self._paraSpan.append(None)
            return

        if name == 'text:span':
            span = None
            if style in self._normalTags:
                while self._span:
                    span = self._span.pop()
                    if span is not None:
                        self._client.handle_endtag(span)
                        if span == 'lang':
                            self._currentLocale.pop()
                span = None
            elif style in self._emTags:
                span = 'em'
                self._client.handle_starttag('em', [()])
                self._span.append(span)
            elif style in self._strongTags:
                span = 'strong'
                self._client.handle_starttag('strong', [()])
                self._span.append(span)
            if style in self._languageTags:
                if (
                    not self._currentLocale or 
                    self._languageTags[style] != self._currentLocale[-1]
                ):
                    span = 'lang'
                    self._client.handle_starttag(
                        'lang',
                        [('lang', self._languageTags[style])]
                    )
                    self._currentLocale.append(self._languageTags[style])
                    self._span.append(span)
            return

        if name == 'text:section':
            self._client.handle_starttag(
                'div',
                [('id', xmlAttributes['text:name'])]
            )
            return

        if name == 'office:annotation':
            self._client.handle_starttag('comment', [()])
            self._getData = False
            return

        if name == 'dc:date':
            self._client.handle_starttag('date', [()])
            self._getData = True
            return

        if name == 'dc:creator':
            self._client.handle_starttag('creator', [()])
            self._getData = True
            return

        if name == 'text:note':
            self._client.handle_starttag(
                'note',
                [
                    (
                        'id',
                        xmlAttributes.get('text:id', '')
                    ),
                    (
                        'class',
                        xmlAttributes.get('text:note-class', '')
                    )
                ]
            )
            self._getData = False
            return

        if name == 'text:note-citation':
            self._client.handle_starttag('note-citation', [()])
            self._getData = True
            return

        if name == 'text:list-item':
            self._client.handle_starttag('li', [()])
            return

        if name == 'text:list':
            self._client.handle_starttag('ul', [()])
            return

        if name == 'style:style':
            self._style = xmlAttributes.get('style:name', None)
            styleName = xmlAttributes.get('style:parent-style-name', '')
            if styleName.startswith('Heading'):
                self._headingTags[self._style] = f'h{styleName[-1]}'
            elif styleName == 'Quotations':
                self._blockquoteTags.append(self._style)
            return

        if name == 'style:text-properties':

            if xmlAttributes.get('fo:font-style', None) == 'italic':
                self._emTags.append(self._style)

            if xmlAttributes.get('fo:font-weight', None) == 'bold':
                self._strongTags.append(self._style)

            if xmlAttributes.get('fo:font-style', None) == 'normal':
                self._normalTags.append(self._style)

            if xmlAttributes.get('fo:language', False):
                languageCode = xmlAttributes['fo:language']
                countryCode = xmlAttributes['fo:country']
                if countryCode and countryCode != 'none':
                    locale = f'{languageCode}-{countryCode}'
                else:
                    locale = languageCode
                self._languageTags[self._style] = locale
            return

        if name == 'text:s':
            self._client.handle_starttag('s', [()])

    def _read_meta_xml(self, meta, namespaces):
        if meta is None:
            return

        root = ET.fromstring(meta)
        meta = root.find('office:meta', namespaces)
        title = meta.find('dc:title', namespaces)
        if title is not None:
            if title.text:
                self._client.handle_starttag('title', [()])
                self._client.handle_data(title.text)
                self._client.handle_endtag('title')
        author = meta.find('meta:initial-creator', namespaces)
        if author is not None:
            if author.text:
                self._client.handle_starttag(
                    'meta',
                    [
                        ('', 'author'),
                        ('', author.text)
                    ]
                )
        desc = meta.find('dc:description', namespaces)
        if desc is not None:
            if desc.text:
                self._client.handle_starttag(
                    'meta',
                    [
                        ('', 'description'),
                        ('', desc.text),
                    ]
                )

    def _read_styles_xml(self, styles, namespaces):
        root = ET.fromstring(styles)
        styles = root.find('office:styles', namespaces)
        for defaultStyle in styles.iterfind(
            'style:default-style',
            namespaces,
        ):
            if defaultStyle.get(
                f'{{{namespaces["style"]}}}family'
            ) == 'paragraph':
                textProperties = defaultStyle.find(
                    'style:text-properties',
                    namespaces,
                )
                languageCode = textProperties.get(
                    f'{{{namespaces["fo"]}}}language'
                )
                countryCode = textProperties.get(
                    f'{{{namespaces["fo"]}}}country', ''
                )
                if countryCode and countryCode != 'none':
                    self._novelLocale = f'{languageCode}-{countryCode}'
                else:
                    self._novelLocale = languageCode
                self._client.handle_starttag(
                    'body',
                    [
                        ('language', languageCode),
                        ('country', countryCode),
                    ]
                )
                return

    def _unzip_odt_file(self, filePath):
        try:
            with zipfile.ZipFile(filePath, 'r') as odfFile:
                content = odfFile.read('content.xml')
                styles = odfFile.read('styles.xml')
                try:
                    meta = odfFile.read('meta.xml')
                except KeyError:
                    meta = None
                return styles, meta, content

        except:
            raise RuntimeError(
                f'{_("Cannot read file")}: "{norm_path(filePath)}".'
            )



class OdtReader(OdfReader, ABC):
    EXTENSION = '.odt'

    _SEPARATORS = {
        'h1': f'{Splitter.PART_SEPARATOR} ',
        'h2': f'{Splitter.CHAPTER_SEPARATOR} ',
        'h3': f'{Splitter.SECTION_SEPARATOR} ',
        'h4': f'{Splitter.APPENDED_SECTION_SEPARATOR} ',
    }
    splitter = None

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._lines = []
        self._scId = None
        self._chId = None
        self._plId = None
        self._ppId = None
        self._skip_data = False

    def handle_data(self, data):
        pass

    def handle_endtag(self, tag):
        pass

    def handle_starttag(self, tag, attrs):
        if tag == 'div':

            if attrs[0][0] == 'id':
                if attrs[0][1].startswith(SECTION_PREFIX):
                    self._scId = attrs[0][1]
                    return

                if attrs[0][1].startswith(CHAPTER_PREFIX):
                    self._chId = attrs[0][1]
                    return

                if attrs[0][1].startswith(PLOT_LINE_PREFIX):
                    self._plId = attrs[0][1]
                    return

                if attrs[0][1].startswith(PLOT_POINT_PREFIX):
                    self._ppId = attrs[0][1]
                    return

                if attrs[0][1].startswith(LOCATION_PREFIX):
                    self._lcId = attrs[0][1]
                    return

                if attrs[0][1].startswith(ITEM_PREFIX):
                    self._itId = attrs[0][1]
                    return

                if attrs[0][1].startswith(PRJ_NOTE_PREFIX):
                    self._pnId = attrs[0][1]
                    return

                return

        if tag == 's':
            self._lines.append(' ')

    def read(self):
        parser = OdtParser(self)
        try:
            parser.feed_file(self.filePath)
        except KeyError as ex:
            raise RuntimeError(
                f'{_("Unknown element in File")}: '
                f'{norm_path(self.filePath)} - {str(ex)}'
            )
        except Exception as ex:
            raise RuntimeError(
                f'{_("Cannot parse File")}: '
                f'{norm_path(self.filePath)} - {str(ex)}'
            )

    def _set_novel_language(self, attrs):
        for attr in attrs:
            if attr[0] == 'language':
                if attr[1]:
                    self.novel.languageCode = attr[1]
            elif attr[0] == 'country':
                if attr[1] and attr[1] != 'none':
                    self.novel.countryCode = attr[1]
                else:
                    self.novel.countryCode = None


class OdtRDesc(OdtReader):
    SPLITTER = DescSplitter

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.splitter = self.SPLITTER()

    def read(self):
        self.novel.languages = []
        super().read()

        self.projectStructureModified = self.splitter.split_sections(self.novel)



class OdtRChapterDesc(OdtRDesc):
    DESCRIPTION = _('Chapter descriptions')
    SUFFIX = CHAPTERS_SUFFIX

    SPLITTER = ChapterSplitter

    def handle_data(self, data):
        if self._chId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._chId is None:
            return

        if tag == 'div':
            self.novel.chapters[self._chId].desc = ''.join(
                self._lines).rstrip()
            self._lines.clear()
            self._chId = None
            return

        if tag == 'p':
            self._lines.append('\n')
            return

        if tag in self._SEPARATORS:
            self._lines.append('\n')
            return

    def handle_starttag(self, tag, attrs):
        super().handle_starttag(tag, attrs)

        if self._chId is None:
            if tag == 'body':
                self._set_novel_language(attrs)
        else:
            if tag in self._SEPARATORS:
                self._lines.append(self._SEPARATORS[tag])
                return




class OdtRCharacters(OdtReader):
    DESCRIPTION = _('Character descriptions')
    SUFFIX = CHARACTERS_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._crId = None
        self._section = None

    def handle_data(self, data):
        if self._section is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._crId is None:
            return

        if tag == 'div':

            if self._section == 'desc':
                self.novel.characters[self._crId].desc = ''.join(
                    self._lines).rstrip()
                self._lines.clear()
                self._section = None
                return

            if self._section == 'bio':
                self.novel.characters[self._crId].bio = ''.join(
                    self._lines).rstrip()
                self._lines.clear()
                self._section = None
                return

            if self._section == 'goals':
                self.novel.characters[self._crId].goals = ''.join(
                    self._lines).rstrip()
                self._lines.clear()
                self._section = None
                return

            if self._section == 'field2':
                self.novel.characters[self._crId].field2 = ''.join(
                    self._lines).rstrip()
                self._lines.clear()
                self._section = None
                return

            if self._section == 'notes':
                self.novel.characters[self._crId].notes = ''.join(
                    self._lines).rstrip()
                self._lines.clear()
                self._section = None
            return

        if tag == 'p':
            self._lines.append('\n')

    def handle_starttag(self, tag, attrs):
        if tag == 'div':
            if attrs[0][0] == 'id':

                if attrs[0][1].startswith('desc'):
                    self._crId = (
                        f"{CHARACTER_PREFIX}"
                        f"{re.search('[0-9]+', attrs[0][1]).group()}"
                    )
                    if not self._crId in self.novel.characters:
                        self.novel.tree.append(CR_ROOT, self._crId)
                        self.novel.characters[self._crId] = Character()
                    self._section = 'desc'
                    return

                if attrs[0][1].startswith('bio'):
                    self._section = 'bio'
                    return

                if attrs[0][1].startswith('goals'):
                    self._section = 'goals'
                    return

                if attrs[0][1].startswith('notes'):
                    self._section = 'notes'
            return

        if tag == 's':
            self._lines.append(' ')



class ContentSplitter(Splitter):

    def create_section(
        self,
        novel,
        sectionId,
        parent,
        splitCount,
        title,
        desc,
        appendToPrev,
    ):
        super().create_section(
            novel,
            sectionId,
            parent,
            splitCount,
            title,
            appendToPrev,
        )
        WARNING = '(!)'
        if desc:
            novel.sections[sectionId].desc = desc

        if parent.status > 2:
            parent.status = 2
        novel.sections[sectionId].status = parent.status

        if parent.desc and not parent.desc.startswith(WARNING):
            parent.desc = f'{WARNING}{parent.desc}'
        if parent.goal and not parent.goal.startswith(WARNING):
            parent.goal = f'{WARNING}{parent.goal}'
        if parent.conflict and not parent.conflict.startswith(WARNING):
            parent.conflict = f'{WARNING}{parent.conflict}'
        if parent.outcome and not parent.outcome.startswith(WARNING):
            parent.outcome = f'{WARNING}{parent.outcome}'

    def _contains_heading(self, novel, scId):
        return (
            novel.sections[scId].sectionContent and
            '#' in novel.sections[scId].sectionContent
        )

    def _get_lines(self, novel, scanScId):
        sectionContent = novel.sections[scanScId].sectionContent
        sectionContent = sectionContent.replace('</p>', '</p>\n')
        return sectionContent.split('\n')

    def _set_text(self, novel, scId, newLines):
        novel.sections[scId].sectionContent = ''.join(newLines)

    def _stripped_line(self, line):
        return re.sub(r'\<.*?\>', '', line)


class OdtRFormatted(OdtReader):
    SPLITTER = ContentSplitter

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.splitter = self.SPLITTER()

    def read(self):
        self.novel.languages = []
        super().read()

        self.projectStructureModified = self.splitter.split_sections(self.novel)

    def _remove_redundant_tags(self, text):
        for tag in(
            'em',
            'strong',
        ):
            text = text.replace(f'</{tag}><{tag}>', '')
        return text


class OdtRManuscript(OdtRFormatted):
    DESCRIPTION = _('Editable manuscript')
    SUFFIX = MANUSCRIPT_SUFFIX

    def handle_data(self, data):
        if self._scId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._scId is None:
            return

        if tag in (
            'p',
            'em',
            'strong',
            'comment',
            'creator',
            'date',
            'note',
            'note-citation',
            'ul',
            'li',
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            self._lines.append(f'</{tag}>')
            return

        if tag == 'lang':
            self._lines.append('</span>')
            return

        if tag == 'div':
            text = ''.join(self._lines)
            text = self._remove_redundant_tags(text)
            self.novel.sections[self._scId].sectionContent = text
            self._lines.clear()
            self._scId = None
            return

        if tag in self._SEPARATORS:
            self._lines.append('\n')
            return

    def handle_starttag(self, tag, attrs):
        super().handle_starttag(tag, attrs)

        if self._scId is None:
            if tag == 'body':
                self._set_novel_language(attrs)
            return

        if tag in (
            'p',
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            attributes = ''
            try:
                for att in attrs:
                    attributes = f'{attributes} {att[0]}="{att[1]}"'
                    if att[0] == 'lang':
                        if not att[1] in self.novel.languages:
                            self.novel.languages.append(att[1])
            except:
                pass
            self._lines.append(f'<{tag}{attributes}>')
            return

        if tag in(
            'em',
            'strong',
            'comment',
            'creator',
            'date',
            'note-citation',
            'ul',
            'li',
        ):
            self._lines.append(f'<{tag}>')
            return

        if tag == 'lang':
            if attrs[0][0] == 'lang':
                if not attrs[0][1] in self.novel.languages:
                    self.novel.languages.append(attrs[0][1])
                self._lines.append(f'<span xml:lang="{attrs[0][1]}">')
            return

        if tag in self._SEPARATORS:
            self._lines.append(self._SEPARATORS[tag])
            return

        if tag == 'note':
            attributes = ''
            for att in attrs:
                attributes = f'{attributes} {att[0]}="{att[1]}"'
            self._lines.append(f'<note {attributes}>')



class OdtRFull(OdtRManuscript):
    DESCRIPTION = _('Manuscript including unused text')
    SUFFIX = FULL_MANUSCRIPT_SUFFIX



class OdtRItems(OdtReader):
    DESCRIPTION = _('Item descriptions')
    SUFFIX = ITEMS_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._itId = None

    def handle_data(self, data):
        if self._itId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._itId is None:
            return

        if tag == 'div':
            self.novel.items[self._itId].desc = ''.join(self._lines).rstrip()
            self._lines.clear()
            self._itId = None
            return

        if tag == 'p':
            self._lines.append('\n')



class OdtRLocations(OdtReader):
    DESCRIPTION = _('Location descriptions')
    SUFFIX = LOCATIONS_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._lcId = None

    def handle_data(self, data):
        if self._lcId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._lcId is None:
            return

        if tag == 'div':
            self.novel.locations[self._lcId].desc = ''.join(
                self._lines).rstrip()
            self._lines.clear()
            self._lcId = None
            return

        if tag == 'p':
            self._lines.append('\n')



class OdtRPartDesc(OdtRChapterDesc):
    DESCRIPTION = _('Part descriptions')
    SUFFIX = PARTS_SUFFIX


class OdtRPlotlines(OdtReader):
    DESCRIPTION = _('Plot lines')
    SUFFIX = PLOTLINES_SUFFIX

    def handle_data(self, data):
        if self._plId is not None or self._ppId is not None:
            self._lines.append(data)

    def handle_endtag(self, tag):
        if self._plId is not None:
            if tag == 'div':
                text = ''.join(self._lines)
                self.novel.plotLines[self._plId].desc = text.rstrip()
                self._lines.clear()
                self._plId = None
                return

            if tag == 'p':
                self._lines.append('\n')
            return

        if self._ppId is not None:
            if tag == 'div':
                text = ''.join(self._lines)
                self.novel.plotPoints[self._ppId].desc = text.rstrip()
                self._lines.clear()
                self._ppId = None
                return

            if tag == 'p':
                self._lines.append('\n')



class OdtRProjectNotes(OdtReader):
    DESCRIPTION = _('Project notes')
    SUFFIX = PROJECTNOTES_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._pnId = None

    def handle_data(self, data):
        if self._pnId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._pnId is None:
            return

        if tag == 'div':
            self.novel.projectNotes[self._pnId].desc = ''.join(self._lines).rstrip()
            self._lines.clear()
            self._pnId = None
            return

        if tag == 'p':
            self._lines.append('\n')




class OdtRProof(OdtRFormatted):
    DESCRIPTION = _('Tagged manuscript for proofing')
    SUFFIX = PROOF_SUFFIX

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._content = False

    def handle_data(self, data):
        try:
            if f'[{SECTION_PREFIX}' in data:
                self._scId = (
                    f"{SECTION_PREFIX}"
                    f"{re.search('[0-9]+', data).group()}"
                )
                self._lines.clear()
                return

            if f'[/{SECTION_PREFIX}]' in data:
                if self._scId in self.novel.sections:
                    self._lines.pop()
                    text = ''.join(self._lines)
                    self.novel.sections[
                        self._scId
                    ].sectionContent = text.strip()
                    self._lines.clear()
                self._scId = None
                self._content = False
                return

            if self._scId is not None:
                self._lines.append(data)
        except:
            raise RuntimeError(f'{_("Corrupt marker")}: "{data}"')

    def handle_endtag(self, tag):
        if tag in (
            'p',
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            if self._content:
                self._lines.append(f'</{tag}>')
                return

            if self._scId:
                self._content = True
            return

        if tag in (
            'em',
            'strong',
            'comment',
            'creator',
            'date',
            'note',
            'note-citation',
            'ul',
            'li',
        ):
            self._lines.append(f'</{tag}>')
            return

        if tag == 'lang':
            self._lines.append('</span>')
            return

        if tag in self._SEPARATORS:
            self._lines.append('\n')
            return

    def handle_starttag(self, tag, attrs):
        if self._content:

            if tag in (
                'p',
                'h5',
                'h6',
                'h7',
                'h8',
                'h9',
            ):
                attributes = ''
                try:
                    for att in attrs:
                        attributes = f'{attributes} {att[0]}="{att[1]}"'
                        if att[0] == 'lang':
                            if not att[1] in self.novel.languages:
                                self.novel.languages.append(att[1])
                except:
                    pass
                self._lines.append(f'<{tag}{attributes}>')
                return

            if tag in(
                'em',
                'strong',
                'comment',
                'creator',
                'date',
                'note-citation',
                'ul',
                'li',
            ):
                self._lines.append(f'<{tag}>')
                return

            if tag == 'lang':
                if attrs[0][0] == 'lang':
                    if not attrs[0][1] in self.novel.languages:
                        self.novel.languages.append(attrs[0][1])
                    self._lines.append(f'<span xml:lang="{attrs[0][1]}">')
                return

            if tag in self._SEPARATORS:
                self._lines.append(self._SEPARATORS[tag])
                return

            if tag == 's':
                self._lines.append(' ')
                return

            if tag == 'note':
                attributes = ''
                for att in attrs:
                    attributes = f'{attributes} {att[0]}="{att[1]}"'
                self._lines.append(f'<note {attributes}>')
                return

        if tag == 'body':
            self._set_novel_language(attrs)



class OdtRSectionDesc(OdtRDesc):
    DESCRIPTION = _('Section descriptions')
    SUFFIX = SECTIONS_SUFFIX

    def handle_data(self, data):
        if self._scId is None:
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if self._scId is not None:
            if tag == 'div':
                text = ''.join(self._lines)
                self.novel.sections[self._scId].desc = text.rstrip()
                self._lines.clear()
                self._scId = None
                return

            if tag in self._SEPARATORS:
                self._lines.append('\n')
                return

            if tag == 'p':
                self._lines.append('\n')
            return

        if self._chId is not None:
            if tag == 'div':
                self._chId = None

    def handle_starttag(self, tag, attrs):
        super().handle_starttag(tag, attrs)

        if self._scId is None:
            if tag == 'body':
                self._set_novel_language(attrs)
        else:
            if tag in self._SEPARATORS:
                self._lines.append(self._SEPARATORS[tag])
                return



class StageSplitter(DescSplitter):

    def create_section(
        self,
        novel,
        sectionId,
        parent,
        splitCount,
        title,
        level,
    ):
        super().create_section(
            novel,
            sectionId,
            parent,
            splitCount,
            title,
            '',
            False,
        )
        novel.sections[sectionId].scType = level + 1

    def split_sections(self, novel):

        sectionsSplit = False
        chIndex = 0
        newLines = []
        for scanChId in novel.tree.get_children(CH_ROOT):
            scList = novel.tree.get_children(scanChId)
            novel.tree.delete_children(scanChId)
            chId = scanChId
            for scanScId in scList:
                scId = scanScId
                novel.tree.append(chId, scId)
                if not self._contains_heading(novel, scId):
                    continue

                lines = self._get_lines(novel, scanScId)
                newLines.clear()
                inSection = True
                sectionSplitCount = 0

                for line in lines:
                    plainLine = self._stripped_line(line)

                    if '#' in plainLine:
                        title = plainLine.strip('# ')

                        if plainLine.startswith(self.CHAPTER_SEPARATOR):
                            level = 2
                        elif plainLine.startswith(self.PART_SEPARATOR):
                            level = 1

                        if inSection:
                            self._set_text(novel, scId, newLines)
                        newLines.clear()
                        sectionSplitCount += 1
                        newScId = new_id(
                            novel.sections,
                            prefix=SECTION_PREFIX,
                        )
                        self.create_section(
                            novel,
                            newScId,
                            novel.sections[scId],
                            sectionSplitCount,
                            title,
                            level,
                        )
                        novel.tree.append(chId, newScId)
                        scId = newScId
                        sectionsSplit = True
                        inSection = True

                    else:
                        newLines.append(line)

                if inSection:
                    self._set_text(novel, scId, newLines)
            chIndex += 1
        return sectionsSplit


class OdtRStages(OdtRSectionDesc):
    DESCRIPTION = _('Story structure')
    SUFFIX = STAGES_SUFFIX

    SPLITTER = StageSplitter

from xml import sax
from xml.etree import ElementTree as ET

from xml import sax



class NovxToOdt(sax.ContentHandler):

    def __init__(self):
        super().__init__()
        self.odtLines = None
        self._languages = None
        self._indentParagraph = None
        self._note = None
        self._comment = None
        self._quotations = None
        self._firstParagraphInChapter = None
        self._spanLevel = None

    def feed(
        self,
        xmlString,
        languages,
        append,
        firstInChapter,
        isEpigraph,
    ):
        self._languages = languages
        self._firstParagraphInChapter = firstInChapter
        self._indentParagraph = append and not isEpigraph
        self._isEpigraph = isEpigraph
        self._quotations = False
        self._note = None
        self._spanLevel = 0
        self._comment = False
        self.odtLines = []
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):
        content = sax.saxutils.escape(content)
        self.odtLines.append(content)
        self._indentParagraph = not self._quotations

    def endElement(self, name):
        if name == 'p':
            while self._spanLevel > 0:
                self._spanLevel -= 1
                self.odtLines.append('</text:span>')
            self.odtLines.append('</text:p>')
            self._quotations = False
            return

        if name in ('em', 'strong', 'span'):
            self.odtLines.append('</text:span>')
            return

        if name == 'creator':
            self.odtLines.append('</dc:creator>')
            return

        if name == 'date':
            self.odtLines.append('</dc:date>')
            return

        if name == 'note-citation':
            self.odtLines.append(
                '</text:note-citation><text:note-body>'
            )
            return
        if name == 'comment':
            self.odtLines.append('</office:annotation>')
            self._comment = False
            return

        if name == 'note':
            self._note = None
            self.odtLines.append('</text:note-body></text:note>')

        if name in (
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            while self._spanLevel > 0:
                self._spanLevel -= 1
                self.odtLines.append('</text:span>')
            self.odtLines.append('</text:p>')
            self._indentParagraph = False
            return

        if name == 'li':
            self.odtLines.append('</text:list-item>')
            return

        if name == 'ul':
            self._list = False
            self._indentParagraph = False
            self.odtLines.append('</text:list>')
            return

    def startElement(self, name, attrs):
        xmlAttributes = {}
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            xmlAttributes[attrKey] = attrValue

        if name == 'p':
            if xmlAttributes.get('style', None) == 'quotations':
                self.odtLines.append(
                    '<text:p text:style-name="Quotations">'
                )
                self._quotations = True
            elif self._note:
                self.odtLines.append(
                    f'<text:p text:style-name="{self._note.title()}">'
                )
            elif self._comment:
                self.odtLines.append('<text:p>')
            elif self._firstParagraphInChapter:
                self.odtLines.append(
                    f'<text:p text:style-name="{_("Chapter_20_beginning")}">'
                )
            elif self._isEpigraph:
                self.odtLines.append(
                    f'<text:p text:style-name="{_("Epigraph")}">'
                )
            elif self._indentParagraph:
                self.odtLines.append(
                    '<text:p text:style-name="First_20_line_20_indent">'
                )
            else:
                self.odtLines.append(
                    '<text:p text:style-name="Text_20_body">'
                )
            if not self._isEpigraph:
                self._firstParagraphInChapter = False
                self._indentParagraph = False

            language = xmlAttributes.get('xml:lang', None)
            if language:
                i = self._languages.index(language) + 1
                self.odtLines.append(
                    f'<text:span text:style-name="T{i}">'
                )
                self._spanLevel += 1
            return

        if name == 'em':
            self.odtLines.append(
                '<text:span text:style-name="Emphasis">'
            )
            return

        if name == 'strong':
            self.odtLines.append(
                '<text:span text:style-name="Strong_20_Emphasis">'
            )
            return

        if name == 'span':
            language = xmlAttributes.get('xml:lang', None)
            if language:
                i = self._languages.index(language) + 1
                self.odtLines.append(
                    f'<text:span text:style-name="T{i}">'
                )
            return

        if name == 'comment':
            self._comment = True
            self.odtLines.append('<office:annotation>')
            return

        if name == 'note':
            self._note = xmlAttributes.get('class', 'footnote')
            self.odtLines.append(
                f'<text:note text:note-class="{self._note}">'
            )
            return

        if name == 'creator':
            self.odtLines.append('<dc:creator>')
            return

        if name == 'date':
            self.odtLines.append('<dc:date>')
            return

        if name == 'note-citation':
            self.odtLines.append('<text:note-citation>')
            return

        if name in (
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            level = name[-1]
            self.odtLines.append(
                f'<text:p text:style-name="Heading_20_{level}">'
            )
            language = xmlAttributes.get('xml:lang', None)
            if language:
                i = self._languages.index(language) + 1
                self.odtLines.append(
                    f'<text:span text:style-name="T{i}">'
                )
                self._spanLevel += 1
            return

        if name == 'ul':
            self._list = True
            self.odtLines.append('<text:list>')
            return

        if name == 'li':
            self.odtLines.append('<text:list-item>')


class OdtWriter(OdfFile):

    EXTENSION = '.odt'

    _ODF_COMPONENTS = [
        'manifest.rdf',
        'META-INF',
        'content.xml',
        'meta.xml',
        'mimetype',
        'styles.xml',
        'META-INF/manifest.xml',
    ]

    _CONTENT_XML_HEADER = (
        '<?xml version="1.0" encoding="UTF-8"?>\n\n'
        '<office:document-content '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
        'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
        'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
        'xmlns:fo="urn:oasis:names:tc:opendocument:'
        'xmlns:xsl-fo-compatible:1.0" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" '
        'xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" '
        'xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" '
        'xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" '
        'xmlns:math="http://www.w3.org/1998/Math/MathML" '
        'xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" '
        'xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:ooow="http://openoffice.org/2004/writer" '
        'xmlns:oooc="http://openoffice.org/2004/calc" '
        'xmlns:dom="http://www.w3.org/2001/xml-events" '
        'xmlns:xforms="http://www.w3.org/2002/xforms" '
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        'xmlns:rpt="http://openoffice.org/2005/report" '
        'xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" '
        'xmlns:xhtml="http://www.w3.org/1999/xhtml" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'xmlns:tableooo="http://openoffice.org/2009/table" '
        'xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:'
        'xmlns:field:1.0" office:version="1.2">\n'
        ' <office:scripts/>\n'
        ' <office:font-face-decls>\n'
        '  <style:font-face style:name="StarSymbol" '
        'svg:font-family="StarSymbol" style:font-charset="x-symbol"/>\n'
        '  <style:font-face style:name="Consolas" svg:font-family="Consolas" '
        'style:font-adornments="Standard" '
        'style:font-family-generic="modern" '
        'style:font-pitch="fixed"/>\n'
        '  <style:font-face style:name="Courier New" '
        'svg:font-family="&apos;Courier New&apos;" '
        'style:font-adornments="Standard" style:font-family-generic="modern" '
        'style:font-pitch="fixed"/>\n'
        ' </office:font-face-decls>\n'
        ' <office:automatic-styles/>\n'
        ' <office:body>\n'
        '  <office:text text:use-soft-page-breaks="true">\n\n'
    )
    _CONTENT_XML_FOOTER = (
        '  </office:text>\n'
        ' </office:body>\n'
        '</office:document-content>\n'
    )
    _META_XML = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:'
        'xmlns:office:1.0" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'office:version="1.2">\n'
        '  <office:meta>\n'
        '    <meta:generator>novelibre</meta:generator>\n'
        '    <dc:title>$Title</dc:title>\n'
        '    <dc:description>$Summary</dc:description>\n'
        '    <dc:subject></dc:subject>\n'
        '    <meta:keyword></meta:keyword>\n'
        '    <meta:initial-creator>$Author</meta:initial-creator>\n'
        '    <dc:creator></dc:creator>\n'
        '    <meta:creation-date>${Datetime}Z</meta:creation-date>\n'
        '    <dc:date></dc:date>\n'
        '  </office:meta>\n'
        '</office:document-meta>\n'
    )
    _MANIFEST_XML = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<manifest:manifest '
        'xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" '
        'manifest:version="1.2">\n'
        '  <manifest:file-entry '
        'manifest:media-type="application/vnd.oasis.opendocument.text" '
        'manifest:full-path="/" />\n'
        '  <manifest:file-entry '
        'manifest:media-type="application/xml" '
        'manifest:full-path="content.xml" manifest:version="1.2" />\n'
        '  <manifest:file-entry manifest:media-type="application/rdf+xml" '
        'manifest:full-path="manifest.rdf" manifest:version="1.2" />\n'
        '  <manifest:file-entry '
        'manifest:media-type="application/xml" manifest:full-path="styles.xml" '
        'manifest:version="1.2" />\n'
        '  <manifest:file-entry '
        'manifest:media-type="application/xml" manifest:full-path="meta.xml" '
        'manifest:version="1.2" />\n'
        '  <manifest:file-entry manifest:media-type="application/xml" '
        'manifest:full-path="settings.xml" manifest:version="1.2" />\n'
        '</manifest:manifest>\n'
    )
    _MANIFEST_RDF = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n'
        '  <rdf:Description rdf:about="styles.xml">\n'
        '    <rdf:type rdf:resource='
        '"http://docs.oasis-open.org/ns/office/1.2/meta/odf#StylesFile"/>\n'
        '  </rdf:Description>\n'
        '  <rdf:Description rdf:about="">\n'
        '    <ns0:hasPart xmlns:ns0='
        '"http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" '
        'rdf:resource="styles.xml"/>\n'
        '  </rdf:Description>\n'
        '  <rdf:Description rdf:about="content.xml">\n'
        '    <rdf:type rdf:resource='
        '"http://docs.oasis-open.org/ns/office/1.2/meta/odf#ContentFile"/>\n'
        '  </rdf:Description>\n'
        '  <rdf:Description rdf:about="">\n'
        '    <ns0:hasPart '
        'xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" '
        'rdf:resource="content.xml"/>\n'
        '  </rdf:Description>\n'
        '  <rdf:Description rdf:about="">\n'
        '    <rdf:type rdf:resource='
        '"http://docs.oasis-open.org/ns/office/1.2/meta/pkg#Document"/>\n'
        '  </rdf:Description>\n'
        '</rdf:RDF>\n'
    )
    _STYLES_XML = (
        '<?xml version="1.0" encoding="UTF-8"?>\n\n'
        '<office:document-styles '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
        'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
        'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
        'xmlns:fo="urn:oasis:names:tc:opendocument:'
        'xmlns:xsl-fo-compatible:1.0" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" '
        'xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" '
        'xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" '
        'xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" '
        'xmlns:math="http://www.w3.org/1998/Math/MathML" '
        'xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" '
        'xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:ooow="http://openoffice.org/2004/writer" '
        'xmlns:oooc="http://openoffice.org/2004/calc" '
        'xmlns:dom="http://www.w3.org/2001/xml-events" '
        'xmlns:rpt="http://openoffice.org/2005/report" '
        'xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" '
        'xmlns:xhtml="http://www.w3.org/1999/xhtml" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'xmlns:tableooo="http://openoffice.org/2009/table" '
        'xmlns:loext="urn:org:documentfoundation:names:experimental:'
        'office:xmlns:loext:1.0">\n'
        ' <office:font-face-decls>\n'
        '  <style:font-face style:name="StarSymbol" '
        'svg:font-family="StarSymbol" style:font-charset="x-symbol"/>\n'
        '  <style:font-face style:name="Calibri" '
        'svg:font-family="&apos;Calibri&apos;"/>\n'
        '  <style:font-face style:name="Courier New" '
        'svg:font-family="&apos;Courier New&apos;" '
        'style:font-adornments="Standard" style:font-family-generic="modern" '
        'style:font-pitch="fixed"/>\n'
        '  <style:font-face style:name="Consolas" '
        'svg:font-family="Consolas" style:font-adornments="Standard" '
        'style:font-family-generic="modern" style:font-pitch="fixed"/>\n'
        '  </office:font-face-decls>\n'
        ' <office:styles>\n'
        '  <style:default-style style:family="graphic">\n'
        '   <style:graphic-properties svg:stroke-color="#3465a4" '
        'draw:fill-color="#729fcf" fo:wrap-option="no-wrap" '
        'draw:shadow-offset-x="0.3cm" draw:shadow-offset-y="0.3cm" '
        'draw:start-line-spacing-horizontal="0.283cm" '
        'draw:start-line-spacing-vertical="0.283cm" '
        'draw:end-line-spacing-horizontal="0.283cm" '
        'draw:end-line-spacing-vertical="0.283cm" '
        'style:flow-with-text="true"/>\n'
        '   <style:paragraph-properties '
        'style:text-autospace="ideograph-alpha" style:line-break="strict" '
        'style:writing-mode="lr-tb" '
        'style:font-independent-line-spacing="false">\n'
        '    <style:tab-stops/>\n'
        '   </style:paragraph-properties>\n'
        '   <style:text-properties fo:color="#000000" '
        'fo:font-size="10pt" '
        'fo:language="$Language" fo:country="$Country" '
        'style:font-size-asian="10pt" style:language-asian="zxx" '
        'style:country-asian="none" style:font-size-complex="1pt" '
        'style:language-complex="zxx" style:country-complex="none"/>\n'
        '  </style:default-style>\n'
        '  <style:default-style style:family="paragraph">\n'
        '   <style:paragraph-properties '
        'fo:hyphenation-ladder-count="no-limit" '
        'style:text-autospace="ideograph-alpha" '
        'style:punctuation-wrap="hanging" style:line-break="strict" '
        'style:tab-stop-distance="1.251cm" style:writing-mode="lr-tb"/>\n'
        '   <style:text-properties fo:color="#000000" '
        'style:font-name="Calibri" fo:font-size="10.5pt" '
        'fo:language="$Language" fo:country="$Country" '
        'style:font-name-asian="Calibri" style:font-size-asian="10pt" '
        'style:language-asian="zxx" style:country-asian="none" '
        'style:font-name-complex="Segoe UI" style:font-size-complex="1pt" '
        'style:language-complex="zxx" style:country-complex="none" '
        'fo:hyphenate="false" fo:hyphenation-remain-char-count="2" '
        'fo:hyphenation-push-char-count="2"/>\n'
        '  </style:default-style>\n'
        '  <style:style style:name="Standard" style:family="paragraph" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties fo:line-height="0.73cm" '
        'style:page-number="auto"/>\n'
        '   <style:text-properties style:font-name="Courier New" '
        'fo:font-size="12pt" fo:font-weight="normal"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Text_20_body" '
        'style:display-name="Text body" style:family="paragraph" '
        'style:parent-style-name="Standard" '
        'style:next-style-name="First_20_line_20_indent" style:class="text" '
        'style:master-page-name="">\n'
        '   <style:paragraph-properties style:page-number="auto">\n'
        '    <style:tab-stops/>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="First_20_line_20_indent" '
        'style:display-name="First line indent" style:family="paragraph" '
        'style:parent-style-name="Text_20_body" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin="100%" fo:margin-left="0cm" fo:margin-right="0cm" '
        'fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0.499cm" '
        'style:auto-text-indent="false" style:page-number="auto"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Hanging_20_indent" '
        'style:display-name="Hanging indent" style:family="paragraph" '
        'style:parent-style-name="Text_20_body" style:class="text">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin="100%" fo:margin-left="1cm" fo:margin-right="0cm" '
        'fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="-0.499cm" '
        'style:auto-text-indent="false">\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="0cm"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="Text_20_body_20_indent" '
        'style:display-name="Text body indent" style:family="paragraph" '
        'style:parent-style-name="Text_20_body" style:class="text">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin="100%" fo:margin-left="0.499cm" fo:margin-right="0cm" '
        'fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0cm" '
        'style:auto-text-indent="false"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading" style:family="paragraph" '
        'style:parent-style-name="Standard" '
        'style:next-style-name="Text_20_body" style:class="text" '
        'style:master-page-name="">\n'
        '   <style:paragraph-properties fo:line-height="0.73cm" '
        'fo:text-align="center" style:justify-single-word="false" '
        'style:page-number="auto" fo:keep-with-next="always">\n'
        '    <style:tab-stops/>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading_20_1" '
        'style:display-name="Heading 1" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" '
        'style:default-outline-level="1" style:list-style-name="" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin-top="1.461cm" fo:margin-bottom="0.73cm" '
        'style:page-number="auto">\n'
        '    <style:tab-stops/>\n'
        '   </style:paragraph-properties>\n'
        '   <style:text-properties fo:text-transform="uppercase" '
        'fo:font-weight="bold"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading_20_2" '
        'style:display-name="Heading 2" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" '
        'style:default-outline-level="2" style:list-style-name="" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin-top="1.461cm" fo:margin-bottom="0.73cm" '
        'style:page-number="auto"/>\n'
        '   <style:text-properties fo:font-weight="bold"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading_20_3" '
        'style:display-name="Heading 3" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" '
        'style:default-outline-level="3" style:list-style-name="" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin-top="0.73cm" fo:margin-bottom="0.73cm" '
        'style:page-number="auto"/>\n'
        '   <style:text-properties fo:font-style="italic"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading_20_4" '
        'style:display-name="Heading 4" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" '
        'style:default-outline-level="" style:list-style-name="" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties fo:margin-top="0.73cm" '
        'fo:margin-bottom="0.73cm" style:page-number="auto"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading_20_5" '
        'style:display-name="Heading 5" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" '
        'style:default-outline-level="" style:list-style-name="" '
        'style:class="text" style:master-page-name="">\n'
        '   <style:paragraph-properties style:page-number="auto"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Heading_20_6" '
        'style:display-name="Heading 6" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" style:default-outline-level="" '
        'style:list-style-name="" style:class="text"/>\n'
        '  <style:style style:name="Heading_20_7" '
        'style:display-name="Heading 7" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" style:default-outline-level="" '
        'style:list-style-name="" style:class="text"/>\n'
        '  <style:style style:name="Heading_20_8" '
        'style:display-name="Heading 8" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" style:default-outline-level="" '
        'style:list-style-name="" style:class="text"/>\n'
        '  <style:style style:name="Heading_20_9" '
        'style:display-name="Heading 9" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" style:default-outline-level="" '
        'style:list-style-name="" style:class="text"/>\n'
        '  <style:style style:name="Heading_20_10" '
        'style:display-name="Heading 10" style:family="paragraph" '
        'style:parent-style-name="Heading" '
        'style:next-style-name="Text_20_body" '
        'style:default-outline-level="10" style:list-style-name="" '
        'style:class="text">\n'
        '   <style:text-properties fo:font-size="75%" fo:font-weight="bold"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Header" style:family="paragraph" '
        'style:parent-style-name="Standard" style:class="extra" '
        'style:master-page-name="">\n'
        '   <style:paragraph-properties fo:text-align="end" '
        'style:justify-single-word="false" style:page-number="auto" '
        'fo:padding="0.049cm" fo:border-left="none" fo:border-right="none" '
        'fo:border-top="none" fo:border-bottom="0.002cm solid #000000" '
        'style:shadow="none">\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="8.5cm" '
        'style:type="center"/>\n'
        '     <style:tab-stop style:position="17.002cm" '
        'style:type="right"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '   <style:text-properties fo:font-variant="normal" '
        'fo:text-transform="none" fo:font-style="italic"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Header_20_left" '
        'style:display-name="Header left" style:family="paragraph" '
        'style:parent-style-name="Standard" style:class="extra">\n'
        '   <style:paragraph-properties>\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="8.5cm" style:type="center"/>\n'
        '     <style:tab-stop style:position="17.002cm" '
        'style:type="right"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="Header_20_right" '
        'style:display-name="Header right" style:family="paragraph" '
        'style:parent-style-name="Standard" style:class="extra">\n'
        '   <style:paragraph-properties>\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="8.5cm" style:type="center"/>\n'
        '     <style:tab-stop style:position="17.002cm" '
        'style:type="right"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="Footer" style:family="paragraph" '
        'style:parent-style-name="Standard" style:class="extra" '
        'style:master-page-name="">\n'
        '   <style:paragraph-properties fo:text-align="center" '
        'style:justify-single-word="false" style:page-number="auto" '
        'text:number-lines="false" text:line-number="0">\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="8.5cm" style:type="center"/>\n'
        '     <style:tab-stop style:position="17.002cm" '
        'style:type="right"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '   <style:text-properties fo:font-size="11pt"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Footer_20_left" '
        'style:display-name="Footer left" style:family="paragraph" '
        'style:parent-style-name="Standard" style:class="extra">\n'
        '   <style:paragraph-properties>\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="8.5cm" style:type="center"/>\n'
        '     <style:tab-stop style:position="17.002cm" '
        'style:type="right"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="Footer_20_right" '
        'style:display-name="Footer right" style:family="paragraph" '
        'style:parent-style-name="Standard" style:class="extra">\n'
        '   <style:paragraph-properties>\n'
        '    <style:tab-stops>\n'
        '     <style:tab-stop style:position="8.5cm" style:type="center"/>\n'
        '     <style:tab-stop style:position="17.002cm" '
        'style:type="right"/>\n'
        '    </style:tab-stops>\n'
        '   </style:paragraph-properties>\n'
        '  </style:style>\n'
        '  <style:style style:name="Title" style:family="paragraph" '
        'style:parent-style-name="Standard" style:next-style-name="Subtitle" '
        'style:class="chapter" style:master-page-name="">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin="100%" fo:margin-left="0cm" '
        'fo:margin-right="0cm" fo:margin-top="0.000cm" '
        'fo:margin-bottom="0cm" fo:line-height="200%" '
        'fo:text-align="center" style:justify-single-word="false" '
        'fo:text-indent="0cm" style:auto-text-indent="false" '
        'style:page-number="auto" fo:background-color="transparent" '
        'fo:padding="0cm" fo:border="none" text:number-lines="false" '
        'text:line-number="0">\n'
        '    <style:tab-stops/>\n'
        '    <style:background-image/>\n'
        '   </style:paragraph-properties>\n'
        '   <style:text-properties fo:text-transform="uppercase" '
        'fo:font-weight="normal" style:letter-kerning="false"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Subtitle" style:family="paragraph" '
        'style:parent-style-name="Title" style:class="chapter" '
        'style:master-page-name="">\n'
        '   <style:paragraph-properties loext:contextual-spacing="false" '
        'fo:margin-top="0cm" fo:margin-bottom="0cm" '
        'style:page-number="auto"/>\n'
        '   <style:text-properties fo:font-variant="normal" '
        'fo:text-transform="none" fo:letter-spacing="normal" '
        'fo:font-style="italic" fo:font-weight="normal"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Quotations" style:family="paragraph" '
        'style:parent-style-name="Text_20_body" style:class="html">\n'
        '   <style:paragraph-properties fo:margin="100%" '
        'fo:margin-left="1cm" fo:margin-right="0cm" fo:margin-top="0cm" '
        'fo:margin-bottom="0cm" fo:text-indent="0cm" '
        'style:auto-text-indent="false"/>\n'
        '   <style:text-properties style:font-name="Consolas"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Emphasis" style:family="text">\n'
        '   <style:text-properties fo:font-style="italic" '
        'fo:background-color="transparent"/>\n'
        '  </style:style>\n'
        '  <style:style style:name="Strong_20_Emphasis" '
        'style:display-name="Strong Emphasis" style:family="text">\n'
        '   <style:text-properties fo:text-transform="uppercase"/>\n'
        '  </style:style>\n'
        ' </office:styles>\n'
        ' <office:automatic-styles>\n'
        '  <style:page-layout style:name="Mpm1">\n'
        '   <style:page-layout-properties fo:page-width="21.001cm" '
        'fo:page-height="29.7cm" style:num-format="1" '
        'style:paper-tray-name="[From printer settings]" '
        'style:print-orientation="portrait" fo:margin-top="3.2cm" '
        'fo:margin-bottom="2.499cm" fo:margin-left="2.701cm" '
        'fo:margin-right="3cm" style:writing-mode="lr-tb" '
        'style:layout-grid-color="#c0c0c0" style:layout-grid-lines="20" '
        'style:layout-grid-base-height="0.706cm" '
        'style:layout-grid-ruby-height="0.353cm" '
        'style:layout-grid-mode="none" style:layout-grid-ruby-below="false" '
        'style:layout-grid-print="false" style:layout-grid-display="false" '
        'style:footnote-max-height="0cm">\n'
        '    <style:columns fo:column-count="1" fo:column-gap="0cm"/>\n'
        '    <style:footnote-sep style:width="0.018cm" '
        'style:distance-before-sep="0.101cm" '
        'style:distance-after-sep="0.101cm" style:adjustment="left" '
        'style:rel-width="25%" style:color="#000000"/>\n'
        '   </style:page-layout-properties>\n'
        '   <style:header-style/>\n'
        '   <style:footer-style>\n'
        '    <style:header-footer-properties fo:min-height="1.699cm" '
        'fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="1.199cm" '
        'style:shadow="none" style:dynamic-spacing="false"/>\n'
        '   </style:footer-style>\n'
        '  </style:page-layout>\n'
        ' </office:automatic-styles>\n'
        ' <office:master-styles>\n'
        '  <style:master-page style:name="Standard" '
        'style:page-layout-name="Mpm1">\n'
        '   <style:footer>\n'
        '    <text:p text:style-name="Footer"><text:page-number '
        'text:select-page="current"/></text:p>\n'
        '   </style:footer>\n'
        '  </style:master-page>\n'
        ' </office:master-styles>\n'
        '</office:document-styles>\n'
    )
    _NOVELIBRE_STYLES = (
        f'  <style:style style:name="{_("Chapter_20_beginning")}" '
        f'style:display-name="{_("Chapter beginning")}" '
        'style:family="paragraph" style:parent-style-name="Text_20_body" '
        'style:next-style-name="First_20_line_20_indent" '
        'style:class="text">\n'
        '  </style:style>\n'
        f'  <style:style style:name="{_("Epigraph")}" '
        f'style:display-name="{_("Epigraph")}" '
        'style:family="paragraph" style:parent-style-name="Quotations" '
        f'style:next-style-name="{_("Epigraph source")}" style:class="text">\n'
        '  </style:style>\n'
        f'  <style:style style:name="{_("Epigraph_20_source")}" '
        f'style:display-name="{_("Epigraph source")}" '
        f'style:family="paragraph" style:parent-style-name="{_("Epigraph")}" '
        'style:next-style-name="Text_20_body" style:class="text">\n'
        '  <style:paragraph-properties fo:margin-top="0cm" '
        'fo:margin-bottom="1.46cm" fo:text-align="center"/>\n'
        '  <style:text-properties fo:language="zxx" fo:country="none" fo:font-style="italic"/>\n'
        '  </style:style>\n'
        f'  <style:style style:name="{_("Section_20_mark")}" '
        f'style:display-name="{_("Section mark")}" '
        'style:family="paragraph" style:parent-style-name="Standard" '
        'style:next-style-name="Text_20_body" style:class="text">\n'
        '   <style:text-properties fo:color="#008000" '
        'fo:font-size="10pt" fo:language="zxx" fo:country="none"/>\n'
        '  </style:style>\n'
        f'  <style:style style:name="{_("Heading_20_3_20_invisible")}" '
        f'style:display-name="{_("Heading 3 invisible")}" '
        'style:family="paragraph" '
        'style:parent-style-name="Heading_20_3" style:class="text">\n'
        '   <style:paragraph-properties fo:margin-top="0cm" '
        'fo:margin-bottom="0cm" fo:line-height="100%"/>\n'
        '   <style:text-properties text:display="none"/>\n'
        '  </style:style>'
    )
    _NOVELIBRE_STYLE_NAMES = (
        _('Chapter_20_beginning'),
        _('Epigraph'),
        _('Epigraph_20_source'),
        _('Section_20_mark'),
        _('Heading_20_3_20_invisible'),
    )

    _MIMETYPE = 'application/vnd.oasis.opendocument.text'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._contentParser = NovxToOdt()

        self.userStylesXml = None

    @classmethod
    def add_novelibre_styles(cls, stylesXmlStr):
        success = False
        lines = stylesXmlStr.split('\n')
        newlines = []
        for line in lines:
            if '</office:styles>' in line:
                newlines.append(cls._NOVELIBRE_STYLES)
                success = True
            newlines.append(line)
        if not success:
            raise ValueError('Invalid XML Styles data')

        return '\n'.join(newlines)

    @classmethod
    def remove_novelibre_styles(cls, stylesXmlStr):
        for prefix in cls.NAMESPACES:
            ET.register_namespace(prefix, cls.NAMESPACES[prefix])
        root = ET.fromstring(stylesXmlStr)
        officeStyles = root.find('office:styles', cls.NAMESPACES)
        stylesToDiscard = []
        for officeStyle in officeStyles.iterfind(
            'style:style', cls.NAMESPACES
        ):
            officeStyleName = (
                officeStyle.attrib[f"{{{cls.NAMESPACES['style']}}}name"]
            )
            if officeStyleName in cls._NOVELIBRE_STYLE_NAMES:
                stylesToDiscard.append(officeStyle)
        for officeStyle in stylesToDiscard:
            officeStyles.remove(officeStyle)
        stylesXmlStr = ET.tostring(
            root,
            encoding='utf-8',
            xml_declaration=True
        ).decode('utf-8')
        return stylesXmlStr

    def write(self):
        if self.novel.languages is None:
            self.novel.get_languages()
        return super().write()

    def _convert_from_novx(
        self,
        text,
        quick=False,
        append=False,
        firstInChapter=False,
        xml=False,
        linebreaks=False,
        isEpigraph=False,
    ):
        if not text and not linebreaks and not isEpigraph:
            return ''

        if quick:
            return sax.saxutils.escape(text)

        if xml:
            self._contentParser.feed(
                text,
                self.novel.languages,
                append,
                firstInChapter,
                isEpigraph,
            )
            return ''.join(self._contentParser.odtLines)

        lines = sax.saxutils.escape(text).split('\n')
        if linebreaks:
            text = '<text:line-break/>'.join(lines)
        else:
            text = (
                '</text:p><text:p text:style-name="Text_20_body">'
            ).join(lines)

        if isEpigraph:
            firstParagraphStyle = _('Epigraph_20_source')
        else:
            firstParagraphStyle = "Text_20_body"
        return (
            f'<text:p text:style-name="{firstParagraphStyle}">{text}</text:p>'
        )

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        filterMessage = fileHeaderMapping['Filters']
        if filterMessage:
            fileHeaderMapping['Filters'] = filterMessage.replace(
                'First_20_line_20_indent', 'Text_20_body'
            ).replace('<text:p', '\n<text:p')
        return fileHeaderMapping

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal=None,
            isEpigraph=None,
            **kwargs,
    ):
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            wordsTotal=wordsTotal,
            isEpigraph=isEpigraph,
            **kwargs
        )
        sectionMapping['sectionTitle'] = _('Section')
        return sectionMapping

    def _get_styles_xml_str(self):
        if self.userStylesXml:
            try:
                with open(self.userStylesXml, 'r', encoding='utf-8') as f:
                    stylesXmlStr = f.read()
                stylesXmlStr = self._set_document_language(stylesXmlStr)
                stylesXmlStr = self.add_novelibre_styles(stylesXmlStr)
                return stylesXmlStr

            except:
                pass
        stylesXmlStr = super()._get_styles_xml_str()
        stylesXmlStr = self.add_novelibre_styles(stylesXmlStr)
        return stylesXmlStr

    def _set_document_language(self, stylesXmlStr):
        stylesXmlStr = re.sub(
            r'fo\:language=\".+?\"',
            f'fo:language="{self.novel.languageCode}"',
            stylesXmlStr
        )
        if self.novel.countryCode:
            countryCode = self.novel.countryCode
        else:
            countryCode = 'none'
        stylesXmlStr = re.sub(
            r'fo\:country=\".+?\"',
            f'fo:country="{countryCode}"',
            stylesXmlStr
        )
        return stylesXmlStr

    def _set_up(self):

        super()._set_up()

        try:
            with open(
                f'{self._tempDir}/manifest.rdf',
                'w',
                encoding='utf-8'
            ) as f:
                f.write(self._MANIFEST_RDF)
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "manifest.rdf"')



class OdtWBriefSynopsis(OdtWriter):
    DESCRIPTION = _('Brief synopsis')
    SUFFIX = BRF_SYNOPSIS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '$Title</text:h>\n'
    )
    _chapterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '$Title</text:h>\n'
    )
    _sectionTemplate = (
        '<text:p text:style-name="Text_20_body">$Title</text:p>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWChapterDesc(OdtWriter):
    DESCRIPTION = _('Chapter descriptions')
    SUFFIX = CHAPTERS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '$Title</text:h>\n'
    )
    _chapterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '<text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#'
        '$Title|outline">$Title</text:a></text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWCharacters(OdtWriter):
    DESCRIPTION = _('Character descriptions')
    SUFFIX = CHARACTERS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _characterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '$Title$FullName$AKA</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '<text:h text:style-name="Heading_20_3" text:outline-level="3">'
        f'{_("Description")}</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="desc:$ID">\n'
        '$Desc\n'
        '</text:section>\n'
        '<text:h text:style-name="Heading_20_3" text:outline-level="3">'
        '$CharacterField1</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="bio:$ID">\n'
        '$Bio\n'
        '</text:section>\n'
        '<text:h text:style-name="Heading_20_3" text:outline-level="3">'
        '$CharacterField2</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="goals:$ID">\n'
        '$Goals\n'
        '</text:section>\n'
        '<text:h text:style-name="Heading_20_3" text:outline-level="3">'
        f'{_("Notes")}</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="notes:$ID">\n'
        '$Notes\n'
        '</text:section>\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_characterMapping(self, crId):
        characterMapping = OdtWriter._get_characterMapping(self, crId)
        if self.novel.characters[crId].aka:
            characterMapping['AKA'] = f' ("{self.novel.characters[crId].aka}")'
        if self.novel.characters[crId].fullName:
            characterMapping['FullName'
                             ] = f'/{self.novel.characters[crId].fullName}'

        return characterMapping
from string import Template



class OdtWFormatted(OdtWriter):
    _CONTENT_XML_HEADER = (
        '<?xml version="1.0" encoding="UTF-8"?>\n\n'
        '<office:document-content '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
        'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
        'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
        'xmlns:fo="urn:oasis:names:tc:opendocument:'
        'xmlns:xsl-fo-compatible:1.0" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
        'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" '
        'xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" '
        'xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" '
        'xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" '
        'xmlns:math="http://www.w3.org/1998/Math/MathML" '
        'xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" '
        'xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" '
        'xmlns:ooo="http://openoffice.org/2004/office" '
        'xmlns:ooow="http://openoffice.org/2004/writer" '
        'xmlns:oooc="http://openoffice.org/2004/calc" '
        'xmlns:dom="http://www.w3.org/2001/xml-events" '
        'xmlns:xforms="http://www.w3.org/2002/xforms" '
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        'xmlns:rpt="http://openoffice.org/2005/report'
        '" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" '
        'xmlns:xhtml="http://www.w3.org/1999/xhtml" '
        'xmlns:grddl="http://www.w3.org/2003/g/data-view#" '
        'xmlns:tableooo="http://openoffice.org/2009/table" '
        'xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:'
        'xmlns:field:1.0" office:version="1.2">\n'
        ' <office:scripts/>\n'
        ' <office:font-face-decls>\n'
        '  <style:font-face style:name="StarSymbol" '
        'svg:font-family="StarSymbol" style:font-charset="x-symbol"/>\n'
        '  <style:font-face style:name="Consolas" svg:font-family="Consolas" '
        'style:font-adornments="Standard" style:font-family-generic="modern" '
        'style:font-pitch="fixed"/>\n'
        '  <style:font-face style:name="Courier New" '
        'svg:font-family="&apos;Courier New&apos;'
        '" style:font-adornments="Standard" style:font-family-generic='
        '"modern" style:font-pitch="fixed"/>\n'
        ' </office:font-face-decls>\n'
        ' $automaticStyles\n'
        ' <office:body>\n'
        '  <office:text text:use-soft-page-breaks="true">\n\n'
    )

    def _get_fileHeaderMapping(self):
        styleMapping = {}
        if self.novel.languages:
            lines = ['<office:automatic-styles>']
            for i, language in enumerate(self.novel.languages, 1):
                try:
                    lngCode, ctrCode = language.split('-')
                except:
                    lngCode = 'zxx'
                    ctrCode = 'none'
                lines.append(
                    (
                        f'  <style:style style:name="T{i}" '
                        'style:family="text">\n'
                        f'   <style:text-properties '
                        f'fo:language="{lngCode}" fo:country="{ctrCode}" '
                        f'style:language-asian="{lngCode}" '
                        f'style:country-asian="{ctrCode}" '
                        f'style:language-complex="{lngCode}" '
                        f'style:country-complex="{ctrCode}"/>\n'
                        '  </style:style>'
                    )
                )
            lines.append(' </office:automatic-styles>')
            styleMapping['automaticStyles'] = '\n'.join(lines)
        else:
            styleMapping['automaticStyles'] = '<office:automatic-styles/>'
        template = Template(self._CONTENT_XML_HEADER)
        projectTemplateMapping = super()._get_fileHeaderMapping()
        projectTemplateMapping['ContentHeader'] = template.safe_substitute(
            styleMapping
        )
        return projectTemplateMapping

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.append(self._fileFooter)
        text = ''.join(lines)
        return text



class OdtWExport(OdtWFormatted):
    DESCRIPTION = _('manuscript')

    _fileHeader = (
        '$ContentHeader'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '$Title</text:h>\n'
    )
    _chapterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '$Title</text:h>\n'
    )
    _epigraphTemplate = '$SectionContent$Desc\n'
    _sectionTemplate = '$SectionContent\n'

    _sectionDivider = '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'
    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER



class OdtWManuscript(OdtWFormatted):
    DESCRIPTION = _('Editable manuscript')
    SUFFIX = MANUSCRIPT_SUFFIX

    _fileHeader = (
        '$ContentHeader'
        '<text:p text:style-name="Title">$Title</text:p>'
        '\n<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '$Title</text:h>\n'
    )
    _chapterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '$Title</text:h>\n'
    )
    _epigraphTemplate = (
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$SectionContent\n'
        '</text:section>\n'
        '$Desc\n'
    )
    _sectionTemplate = (
        f'<text:h text:style-name="{_("Heading_20_3_20_invisible")}" '
        'text:outline-level="3">$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$SectionContent\n'
        '</text:section>\n'
    )
    _sectionDivider = (
        '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'
    )
    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER



class OdtWFull(OdtWManuscript):
    DESCRIPTION = _('Manuscript including unused text')
    SUFFIX = FULL_MANUSCRIPT_SUFFIX

    _unusedChapterTemplate = OdtWManuscript._chapterTemplate
    _unusedSectionTemplate = OdtWManuscript._sectionTemplate


class OdtWItems(OdtWriter):
    DESCRIPTION = _('Item descriptions')
    SUFFIX = ITEMS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _itemTemplate = (
        '<text:h text:style-name="Heading_20_2" '
        'text:outline-level="2">$Title$AKA</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_itemMapping(self, itId):
        itemMapping = super()._get_itemMapping(itId)
        if self.novel.items[itId].aka:
            itemMapping['AKA'] = f' ("{self.novel.items[itId].aka}")'
        return itemMapping


class OdtWLocations(OdtWriter):
    DESCRIPTION = _('Location descriptions')
    SUFFIX = LOCATIONS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _locationTemplate = (
        '<text:h text:style-name="Heading_20_2" '
        'text:outline-level="2">$Title$AKA</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_locationMapping(self, lcId):
        locationMapping = super()._get_locationMapping(lcId)
        if self.novel.locations[lcId].aka:
            locationMapping['AKA'] = f' ("{self.novel.locations[lcId].aka}")'
        return locationMapping


class OdtWPartDesc(OdtWriter):
    DESCRIPTION = _('Part descriptions')
    SUFFIX = PARTS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '<text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt'
        '#$Title|outline">$Title</text:a></text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWPlotlines(OdtWriter):
    DESCRIPTION = _('Plot lines')
    SUFFIX = PLOTLINES_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>\n'
    )
    _plotLineHeadingTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        f'{_("Plot lines")}</text:h>\n'
    )
    _plotLineTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '<text:bookmark text:name="$ID"/>$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _plotPointTemplate = (
        '<text:h text:style-name="Heading_20_3" text:outline-level="3">'
        '<text:bookmark text:name="$ID"/>$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
        '$Section\n'
    )
    _assocSectionTemplate = (
        '\n<text:p text:style-name="Text_20_body" />\n'
        '<text:p text:style-name="Text_20_body">'
        f'{_("Section")}: <text:span text:style-name="Emphasis">'
        '$SectionTitle</text:span></text:p>\n'
        '<text:p text:style-name="Text_20_body">→ <text:a xlink:'
        'href="../$ProjectName$SectionsSuffix.odt#$scID%7Cregion">'
        f'{_("Description")}</text:a></text:p>\n'
        '<text:p text:style-name="Text_20_body">→ <text:a xlink:'
        'href="../$ProjectName$ManuscriptSuffix.odt#$scID%7Cregion">'
        f'{_("Manuscript")}</text:a></text:p>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER



class OdtWProjectNotes(OdtWriter):
    DESCRIPTION = _('Project notes')
    SUFFIX = PROJECTNOTES_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">'
        '$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>\n'
        f'<text:h text:style-name="Heading_20_1">{_("Project notes")}</text:h>\n'
    )
    _projectNoteTemplate = (
        '<text:h text:style-name="Heading_20_2" '
        'text:outline-level="2">$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER



class OdtWProof(OdtWFormatted):
    DESCRIPTION = _('Tagged manuscript for proofing')
    SUFFIX = PROOF_SUFFIX

    _fileHeader = (
        '$ContentHeader<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '$Title</text:h>\n'
    )
    _chapterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '$Title</text:h>\n'
    )
    _epigraphTemplate = (
        f'<text:p text:style-name="{_("Section_20_mark")}">[$ID]</text:p>\n'
        '$SectionContent\n'
        f'<text:p text:style-name="{_("Section_20_mark")}">'
        f'[/{SECTION_PREFIX}]</text:p>\n'
        '$Desc\n'
    )
    _sectionTemplate = (
        '<text:h text:style-name="Heading_20_3" text:outline-level="3">'
        '$Title</text:h>\n'
        f'<text:p text:style-name="{_("Section_20_mark")}">[$ID]</text:p>\n'
        '$SectionContent\n'
        f'<text:p text:style-name="{_("Section_20_mark")}">'
        f'[/{SECTION_PREFIX}]</text:p>\n'
    )
    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER

    def _convert_from_novx(
        self,
        text,
        quick=False,
        append=False,
        firstInChapter=False,
        xml=False,
        linebreaks=False,
        isEpigraph=False,
    ):
        return super()._convert_from_novx(
            text,
            quick=quick,
            append=append,
            firstInChapter=False,
            xml=xml,
            linebreaks=linebreaks,
            isEpigraph=isEpigraph,
        )


class OdtWSectionDesc(OdtWriter):
    DESCRIPTION = _('Section descriptions')
    SUFFIX = SECTIONS_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">'
        '$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>$Filters\n'
    )
    _partTemplate = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '$Title</text:h>\n'
    )
    _chapterTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '<text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt#'
        '$Title|outline">$Title</text:a></text:h>\n'
    )
    _sectionTemplate = (
        f'<text:h text:style-name="{_("Heading_20_3_20_invisible")}" '
        'text:outline-level="3">$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _sectionDivider = '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal,
            **kwargs
    ):
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            wordsTotal,
            **kwargs
        )
        sectionMapping['Manuscript'] = _('Manuscript')
        return sectionMapping


class OdtWStages(OdtWriter):
    DESCRIPTION = _('Story structure')
    SUFFIX = STAGES_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>\n\n'
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        f'{_("Story structure")}</text:h>\n'
    )
    _stage1Template = (
        '<text:h text:style-name="Heading_20_1" text:outline-level="1">'
        '<text:bookmark text:name="$ID"/>$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _stage2Template = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        '<text:bookmark text:name="$ID"/>$Title</text:h>\n'
        '<text:section text:style-name="Sect1" text:name="$ID">\n'
        '$Desc\n'
        '</text:section>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

from string import Template



LANGUAGE_TAG = re.compile(r'\<(p|span|h.) xml\:lang=\"(.*?)\".*?\>')


class Novel(BasicElement):

    def __init__(
        self,
        authorName=None,
        wordTarget=None,
        wordCountStart=None,
        languageCode=None,
        countryCode=None,
        renumberChapters=None,
        renumberParts=None,
        renumberWithinParts=None,
        romanChapterNumbers=None,
        romanPartNumbers=None,
        saveWordCount=None,
        workPhase=None,
        chapterHeadingPrefix=None,
        chapterHeadingSuffix=None,
        partHeadingPrefix=None,
        partHeadingSuffix=None,
        noSceneField1=None,
        noSceneField2=None,
        noSceneField3=None,
        otherSceneField1=None,
        otherSceneField2=None,
        otherSceneField3=None,
        crField1=None,
        crField2=None,
        referenceDate=None,
        tree=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self._authorName = authorName
        self._wordTarget = wordTarget
        self._wordCountStart = wordCountStart
        self._languageCode = languageCode
        self._countryCode = countryCode
        self._renumberChapters = renumberChapters
        self._renumberParts = renumberParts
        self._renumberWithinParts = renumberWithinParts
        self._romanChapterNumbers = romanChapterNumbers
        self._romanPartNumbers = romanPartNumbers
        self._saveWordCount = saveWordCount
        self._workPhase = workPhase
        self._chapterHeadingPrefix = chapterHeadingPrefix
        self._chapterHeadingSuffix = chapterHeadingSuffix
        self._partHeadingPrefix = partHeadingPrefix
        self._partHeadingSuffix = partHeadingSuffix
        self._noSceneField1 = noSceneField1
        self._noSceneField2 = noSceneField2
        self._noSceneField3 = noSceneField3
        self._otherSceneField1 = otherSceneField1
        self._otherSceneField2 = otherSceneField2
        self._otherSceneField3 = otherSceneField3
        self._crField1 = crField1
        self._crField2 = crField2

        self.chapters = {}
        self.sections = {}
        self.plotPoints = {}
        self.languages = None
        self.plotLines = {}
        self.locations = {}
        self.items = {}
        self.characters = {}
        self.projectNotes = {}
        try:
            self.referenceWeekDay = PyCalendar.weekday(referenceDate)
            self._referenceDate = referenceDate
        except:
            self.referenceWeekDay = None
            self._referenceDate = None
        self.tree = tree
        self.elementsByPrefix = {
            CHAPTER_PREFIX: self.chapters,
            CHARACTER_PREFIX: self.characters,
            ITEM_PREFIX: self.items,
            LOCATION_PREFIX: self.locations,
            PLOT_LINE_PREFIX: self.plotLines,
            PLOT_POINT_PREFIX: self.plotPoints,
            PRJ_NOTE_PREFIX: self.projectNotes,
            SECTION_PREFIX: self.sections,
        }

    @property
    def authorName(self):
        return self._authorName

    @authorName.setter
    def authorName(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._authorName != newVal:
            self._authorName = newVal
            self.on_element_change()

    @property
    def wordTarget(self):
        return self._wordTarget

    @wordTarget.setter
    def wordTarget(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._wordTarget != newVal:
            self._wordTarget = newVal
            self.on_element_change()

    @property
    def wordCountStart(self):
        return self._wordCountStart

    @wordCountStart.setter
    def wordCountStart(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._wordCountStart != newVal:
            self._wordCountStart = newVal
            self.on_element_change()

    @property
    def languageCode(self):
        return self._languageCode

    @languageCode.setter
    def languageCode(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._languageCode != newVal:
            self._languageCode = newVal
            self.on_element_change()

    @property
    def countryCode(self):
        return self._countryCode

    @countryCode.setter
    def countryCode(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._countryCode != newVal:
            self._countryCode = newVal
            self.on_element_change()

    @property
    def renumberChapters(self):
        return self._renumberChapters

    @renumberChapters.setter
    def renumberChapters(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._renumberChapters != newVal:
            self._renumberChapters = newVal
            self.on_element_change()

    @property
    def renumberParts(self):
        return self._renumberParts

    @renumberParts.setter
    def renumberParts(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._renumberParts != newVal:
            self._renumberParts = newVal
            self.on_element_change()

    @property
    def renumberWithinParts(self):
        return self._renumberWithinParts

    @renumberWithinParts.setter
    def renumberWithinParts(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._renumberWithinParts != newVal:
            self._renumberWithinParts = newVal
            self.on_element_change()

    @property
    def romanChapterNumbers(self):
        return self._romanChapterNumbers

    @romanChapterNumbers.setter
    def romanChapterNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._romanChapterNumbers != newVal:
            self._romanChapterNumbers = newVal
            self.on_element_change()

    @property
    def romanPartNumbers(self):
        return self._romanPartNumbers

    @romanPartNumbers.setter
    def romanPartNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._romanPartNumbers != newVal:
            self._romanPartNumbers = newVal
            self.on_element_change()

    @property
    def saveWordCount(self):
        return self._saveWordCount

    @saveWordCount.setter
    def saveWordCount(self, newVal):
        if newVal is not None:
            assert type(newVal) is bool
        if self._saveWordCount != newVal:
            self._saveWordCount = newVal
            self.on_element_change()

    @property
    def workPhase(self):
        return self._workPhase

    @workPhase.setter
    def workPhase(self, newVal):
        if newVal is not None:
            assert type(newVal) is int
        if self._workPhase != newVal:
            self._workPhase = newVal
            self.on_element_change()

    @property
    def chapterHeadingPrefix(self):
        return self._chapterHeadingPrefix

    @chapterHeadingPrefix.setter
    def chapterHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._chapterHeadingPrefix != newVal:
            self._chapterHeadingPrefix = newVal
            self.on_element_change()

    @property
    def chapterHeadingSuffix(self):
        return self._chapterHeadingSuffix

    @chapterHeadingSuffix.setter
    def chapterHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._chapterHeadingSuffix != newVal:
            self._chapterHeadingSuffix = newVal
            self.on_element_change()

    @property
    def partHeadingPrefix(self):
        return self._partHeadingPrefix

    @partHeadingPrefix.setter
    def partHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._partHeadingPrefix != newVal:
            self._partHeadingPrefix = newVal
            self.on_element_change()

    @property
    def partHeadingSuffix(self):
        return self._partHeadingSuffix

    @partHeadingSuffix.setter
    def partHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._partHeadingSuffix != newVal:
            self._partHeadingSuffix = newVal
            self.on_element_change()

    @property
    def noSceneField1(self):
        return self._noSceneField1

    @noSceneField1.setter
    def noSceneField1(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._noSceneField1 != newVal:
            self._noSceneField1 = newVal
            self.on_element_change()

    @property
    def noSceneField2(self):
        return self._noSceneField2

    @noSceneField2.setter
    def noSceneField2(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._noSceneField2 != newVal:
            self._noSceneField2 = newVal
            self.on_element_change()

    @property
    def noSceneField3(self):
        return self._noSceneField3

    @noSceneField3.setter
    def noSceneField3(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._noSceneField3 != newVal:
            self._noSceneField3 = newVal
            self.on_element_change()

    @property
    def otherSceneField1(self):
        return self._otherSceneField1

    @otherSceneField1.setter
    def otherSceneField1(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._otherSceneField1 != newVal:
            self._otherSceneField1 = newVal
            self.on_element_change()

    @property
    def otherSceneField2(self):
        return self._otherSceneField2

    @otherSceneField2.setter
    def otherSceneField2(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._otherSceneField2 != newVal:
            self._otherSceneField2 = newVal
            self.on_element_change()

    @property
    def otherSceneField3(self):
        return self._otherSceneField3

    @otherSceneField3.setter
    def otherSceneField3(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._otherSceneField3 != newVal:
            self._otherSceneField3 = newVal
            self.on_element_change()

    @property
    def crField1(self):
        return self._crField1

    @crField1.setter
    def crField1(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._crField1 != newVal:
            self._crField1 = newVal
            self.on_element_change()

    @property
    def crField2(self):
        return self._crField2

    @crField2.setter
    def crField2(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._crField2 != newVal:
            self._crField2 = newVal
            self.on_element_change()

    @property
    def referenceDate(self):
        return self._referenceDate

    @referenceDate.setter
    def referenceDate(self, newVal):
        if newVal is not None:
            assert type(newVal) is str
        if self._referenceDate != newVal:
            if not newVal:
                self._referenceDate = None
                self.referenceWeekDay = None
                self.on_element_change()
            else:
                try:
                    self.referenceWeekDay = PyCalendar.weekday(newVal)
                except:
                    pass
                else:
                    self._referenceDate = newVal
                    self.on_element_change()

    def check_locale(self):
        if not self._languageCode:
            try:
                sysLng, sysCtr = locale.getlocale()[0].split('_')
            except:
                sysLng, sysCtr = locale.getdefaultlocale()[0].split('_')
            self.languageCode = sysLng
            self.countryCode = sysCtr
            return

        if len(self._languageCode) != 2:
            self.languageCode = 'zxx'
            self.countryCode = None
            return

        if self._countryCode and len(self._countryCode) != 2:
            self.countryCode = None

    def get_languages(self):

        def languages(text):
            m = LANGUAGE_TAG.search(text)
            while m:
                text = text[m.span()[1]:]
                yield m.group(2)
                m = LANGUAGE_TAG.search(text)

        self.languages = []
        for scId in self.sections:
            text = self.sections[scId].sectionContent
            if text:
                for language in languages(text):
                    if not language in self.languages:
                        self.languages.append(language)

    def get_tags(self):
        tags = {}
        for elements in [
            self.sections,
            self.characters,
            self.locations,
            self.items,
        ]:
            for elemId in elements:
                for tag in elements[elemId].tags:
                    if not tag in tags:
                        tags[tag] = [elemId]
                    else:
                        tags[tag].append(elemId)
        return tags

    def update_plot_lines(self):
        for scId in self.sections:
            self.sections[scId].scPlotPoints = {}
            self.sections[scId].scPlotLines = []
            for plId in self.plotLines:
                if scId in self.plotLines[plId].sections:
                    self.sections[scId].scPlotLines.append(plId)
                    for ppId in self.tree.get_children(plId):
                        if self.plotPoints[ppId].sectionAssoc == scId:
                            self.sections[scId].scPlotPoints[ppId] = plId
                            break



class CrossReferences:

    def __init__(self):

        self.scnPerChr = {}
        self.scnPerLoc = {}
        self.scnPerItm = {}
        self.scnPerTag = {}
        self.chrPerTag = {}
        self.locPerTag = {}
        self.itmPerTag = {}
        self.chpPerScn = {}
        self.srtSections = None

    def generate_xref(self, novel: Novel):
        self.scnPerChr = {}
        self.scnPerLoc = {}
        self.scnPerItm = {}
        self.scnPerTag = {}
        self.chrPerTag = {}
        self.locPerTag = {}
        self.itmPerTag = {}
        self.chpPerScn = {}
        self.srtSections = []

        for crId in novel.tree.get_children(CR_ROOT):
            self.scnPerChr[crId] = []
            if novel.characters[crId].tags:
                for tag in novel.characters[crId].tags:
                    if not tag in self.chrPerTag:
                        self.chrPerTag[tag] = []
                    self.chrPerTag[tag].append(crId)

        for lcId in novel.tree.get_children(LC_ROOT):
            self.scnPerLoc[lcId] = []
            if novel.locations[lcId].tags:
                for tag in novel.locations[lcId].tags:
                    if not tag in self.locPerTag:
                        self.locPerTag[tag] = []
                    self.locPerTag[tag].append(lcId)

        for itId in novel.tree.get_children(IT_ROOT):
            self.scnPerItm[itId] = []
            if novel.items[itId].tags:
                for tag in novel.items[itId].tags:
                    if not tag in self.itmPerTag:
                        self.itmPerTag[tag] = []
                    self.itmPerTag[tag].append(itId)

        for chId in novel.tree.get_children(CH_ROOT):

            for scId in novel.tree.get_children(chId):
                self.srtSections.append(scId)
                self.chpPerScn[scId] = chId

                if novel.sections[scId].characters:
                    for crId in novel.sections[scId].characters:
                        self.scnPerChr[crId].append(scId)

                if novel.sections[scId].locations:
                    for lcId in novel.sections[scId].locations:
                        self.scnPerLoc[lcId].append(scId)

                if novel.sections[scId].items:
                    for itId in novel.sections[scId].items:
                        self.scnPerItm[itId].append(scId)

                if novel.sections[scId].tags:
                    for tag in novel.sections[scId].tags:
                        if not tag in self.scnPerTag:
                            self.scnPerTag[tag] = []
                        self.scnPerTag[tag].append(scId)


class OdtWXref(OdtWriter):
    DESCRIPTION = _('Cross reference')
    SUFFIX = XREF_SUFFIX

    _fileHeader = (
        f'{OdtWriter._CONTENT_XML_HEADER}'
        '<text:p text:style-name="Title">$Title</text:p>\n'
        '<text:p text:style-name="Subtitle">$AuthorName</text:p>\n'
    )
    _sectionTemplate = (
        '<text:p text:style-name="Text_20_body">\n'
        '<text:a xlink:href="../$ProjectName$ManuscriptSuffix.odt'
        '#$ID%7Cregion">$SectionNumber </text:a>'
        f'({_("Chp.")}$Chapter) $Title\n'
        '</text:p>\n'
    )
    _unusedSectionTemplate = (
        '<text:p text:style-name="Text_20_body">\n'
        f'$SectionNumber ({_("Chp.")}$Chapter) $Title ({_("Unused")})\n'
        '</text:p>\n'
    )
    _characterTemplate = (
        '<text:p text:style-name="Text_20_body">\n'
        '<text:a xlink:href='
        '"../$ProjectName$CharactersSuffix.odt#$ID%7Cregion">'
        '$Title</text:a> $FullName\n'
        '</text:p>\n'
    )
    _locationTemplate = (
        '<text:p text:style-name="Text_20_body">\n'
        '<text:a xlink:href='
        '"../$ProjectName$LocationsSuffix.odt#$ID%7Cregion">'
        '$Title</text:a>\n'
        '</text:p>\n'
    )
    _itemTemplate = (
        '<text:p text:style-name="Text_20_body">\n'
        '<text:a xlink:href="../$ProjectName$ItemsSuffix.odt#$ID%7Cregion">'
        '$Title</text:a>\n'
        '</text:p>\n'
    )
    _scnPerChrTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Sections")} {_("with")} {_("Character")} $Title:</text:h>\n'
    )
    _scnPerLocTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Sections")} {_("with")} {_("Location")} $Title:</text:h>\n'
    )
    _scnPerItmTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Sections")} {_("with")} {_("Item")} $Title:</text:h>\n'
    )
    _chrPerTagTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Characters")} {_("with")} {_("tag")} $Tag:</text:h>\n'
    )
    _locPerTagTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Locations")} {_("with")} {_("tag")} $Tag:</text:h>\n'
    )
    _itmPerTagTemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Items")} {_("with")} {_("tag")} $Tag:</text:h>\n'
    )
    _scnPerTagtemplate = (
        '<text:h text:style-name="Heading_20_2" text:outline-level="2">'
        f'{_("Sections")} {_("with")} {_("tag")} $Tag:</text:h>\n'
    )
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._xr = CrossReferences()

    def _get_characters(self):
        lines = []
        headerTemplate = Template(self._scnPerChrTemplate)
        for crId in self._xr.scnPerChr:
            if self._xr.scnPerChr[crId]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_characterMapping(crId)
                    )
                )
                lines.extend(
                    self._get_sections(
                        self._xr.scnPerChr[crId],
                    )
                )
        return lines

    def _get_characterTags(self):
        lines = []
        headerTemplate = Template(self._chrPerTagTemplate)
        template = Template(self._characterTemplate)
        for tag in self._xr.chrPerTag:
            if self._xr.chrPerTag[tag]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_tagMapping(tag)
                    )
                )
                for crId in self._xr.chrPerTag[tag]:
                    lines.append(
                        template.safe_substitute(
                            self._get_characterMapping(crId)
                        )
                    )
        return lines

    def _get_items(self):
        lines = []
        headerTemplate = Template(self._scnPerItmTemplate)
        for itId in self._xr.scnPerItm:
            if self._xr.scnPerItm[itId]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_itemMapping(itId)
                    )
                )
                lines.extend(self._get_sections(self._xr.scnPerItm[itId]))
        return lines

    def _get_itemTags(self):
        lines = []
        headerTemplate = Template(self._itmPerTagTemplate)
        template = Template(self._itemTemplate)
        for tag in self._xr.itmPerTag:
            if self._xr.itmPerTag[tag]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_tagMapping(tag)
                    )
                )
                for itId in self._xr.itmPerTag[tag]:
                    lines.append(
                        template.safe_substitute(
                            self._get_itemMapping(itId)
                        )
                    )
        return lines

    def _get_locations(self):
        lines = []
        headerTemplate = Template(self._scnPerLocTemplate)
        for lcId in self._xr.scnPerLoc:
            if self._xr.scnPerLoc[lcId]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_locationMapping(lcId)
                    )
                )
                lines.extend(self._get_sections(self._xr.scnPerLoc[lcId]))
        return lines

    def _get_locationTags(self):
        lines = []
        headerTemplate = Template(self._locPerTagTemplate)
        template = Template(self._locationTemplate)
        for tag in self._xr.locPerTag:
            if self._xr.locPerTag[tag]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_tagMapping(tag)
                    )
                )
                for lcId in self._xr.locPerTag[tag]:
                    lines.append(
                        template.safe_substitute(
                            self._get_locationMapping(lcId)
                        )
                    )
        return lines

    def _get_sectionMapping(self, scId, **kwargs):
        sectionNumber = self._xr.srtSections.index(scId) + 1
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            0,
            **kwargs
        )
        chapterNumber = self.novel.tree.get_children(
            CH_ROOT).index(self._xr.chpPerScn[scId]) + 1
        sectionMapping['Chapter'] = str(chapterNumber)
        return sectionMapping

    def _get_sections(self, sections):
        lines = []
        for scId in sections:
            if self.novel.sections[scId].scType == 0:
                template = Template(self._sectionTemplate)
            elif self.novel.sections[scId].scType == 1:
                template = Template(self._unusedSectionTemplate)
            else:
                continue

            lines.append(template.safe_substitute(
                self._get_sectionMapping(scId))
            )
        return lines

    def _get_sectionTags(self):
        lines = []
        headerTemplate = Template(self._scnPerTagtemplate)
        for tag in self._xr.scnPerTag:
            if self._xr.scnPerTag[tag]:
                lines.append(
                    headerTemplate.safe_substitute(
                        self._get_tagMapping(tag)
                    )
                )
                lines.extend(self._get_sections(self._xr.scnPerTag[tag]))
        return lines

    def _get_tagMapping(self, tag):
        tagMapping = dict(
            Tag=tag,
        )
        return tagMapping

    def _get_text(self):
        self._xr.generate_xref(self.novel)
        lines = self._get_fileHeader()
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_sectionTags())
        lines.extend(self._get_characterTags())
        lines.extend(self._get_locationTags())
        lines.extend(self._get_itemTags())
        lines.append(self._fileFooter)
        return ''.join(lines)


class NovxConversion:
    EXPORT_SOURCE_CLASSES = [NovxFile]
    EXPORT_TARGET_CLASSES = [
        DataWriter,
        OdsWCharList,
        OdsWChapterList,
        OdsWGrid,
        OdsWItemList,
        OdsWLocList,
        OdsWMetadataText,
        OdsWPartList,
        OdsWPlotList,
        OdsWSectionList,
        OdtWBriefSynopsis,
        OdtWChapterDesc,
        OdtWCharacters,
        OdtWExport,
        OdtWFull,
        OdtWItems,
        OdtWLocations,
        OdtWManuscript,
        OdtWPartDesc,
        OdtWPlotlines,
        OdtWProjectNotes,
        OdtWProof,
        OdtWSectionDesc,
        OdtWStages,
        OdtWXref,
    ]
    IMPORT_SOURCE_CLASSES = [
        OdtRChapterDesc,
        OdsRChapterList,
        OdsRCharList,
        OdsRGrid,
        OdsRItemList,
        OdsRLocList,
        OdsRMetadataText,
        OdsRPartList,
        OdtRCharacters,
        OdtRFull,
        OdtRItems,
        OdtRLocations,
        OdtRManuscript,
        OdtRPartDesc,
        OdtRPlotlines,
        OdtRProjectNotes,
        OdtRProof,
        OdtRSectionDesc,
        OdtRStages,
    ]
    IMPORT_TARGET_CLASSES = [NovxFile]
    CREATE_SOURCE_CLASSES = []



class ReimportDialog(ModalDialog, SubController, NovxConversion):

    def __init__(self, model, view, controller, **kw):
        if model.prjFile.filePath is None:
            return

        super().__init__(view, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._ui.restore_status()

        self.title(_('Exported documents'))
        self.iconphoto(False, view.icons.updateFromManuscriptIcon)
        window = ttk.Frame(self)
        window.pack(fill='both', expand=True)

        columns = 'Document', 'Date'
        self._documentCollection = ttk.Treeview(
            window,
            columns=columns,
            show='headings',
            selectmode='browse'
        )
        self._documentCollection.pack(fill='both', expand=True)
        self._documentCollection.bind(
            '<<TreeviewSelect>>', self._on_select_document)
        self._documentCollection.tag_configure(
            'newer', foreground='green')
        self._documentCollection.tag_configure(
            'locked', foreground='red')

        self._documentCollection.column(
            'Document', width=300, minwidth=250, stretch=True)
        self._documentCollection.heading(
            'Document', text=_('Document'), anchor='w')
        self._documentCollection.column(
            'Date', minwidth=120, stretch=False)
        self._documentCollection.heading(
            'Date', text=_('Date'), anchor='w')

        IMPORT_MODES = [
            _("Discard documents only if the project structure is modified"),
            _("Always discard documents after import"),
            _("Import documents even if locked; do not discard")
        ]
        try:
            importMode = int(prefs['import_mode'])
        except:
            importMode = 0
        if importMode >= len(IMPORT_MODES):
            importMode = 0

        self._importModeVar = tk.IntVar(window, value=importMode)
        for i, buttonLabel in enumerate(IMPORT_MODES):
            ttk.Radiobutton(
                window,
                text=buttonLabel,
                variable=self._importModeVar,
                value=i,
                command=self._save_options,
            ).pack(padx=5, pady=1, anchor='w')

        self._importButton = ttk.Button(
            window, text=_('Import'),
            command=self._import_document,
            state='disabled'
        )
        self._importButton.pack(padx=5, pady=5, side='left')

        self._deleteButton = ttk.Button(
            window, text=_('Discard'),
            command=self._delete_document,
            state='disabled'
        )
        self._deleteButton.pack(padx=5, pady=5, side='left')

        self._refreshButton = ttk.Button(
            window,
            text=_('Refresh view'),
            command=self._list_documents
        )
        self._refreshButton.pack(padx=5, pady=5, side='left')

        ttk.Button(
            window,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            window,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)
        self._documentCollection.bind(
            '<Double-1>', self._import_document)
        self._documentCollection.bind(
            '<Return>', self._import_document)

        self._docTypes = {}
        for docClass in self.IMPORT_SOURCE_CLASSES:
            self._docTypes[f'{docClass.SUFFIX}{docClass.EXTENSION}'
                           ] = docClass.DESCRIPTION

        self._list_documents()

    def _delete_document(self, event=None):
        filePath = self._documentCollection.selection()[0]
        if filePath and self._ui.ask_yes_no(
            message=_('Delete file?'),
            detail=norm_path(filePath),
            title=_('Discard'),
            parent=self
            ):
            try:
                os.remove(filePath)
                self._documentCollection.delete(filePath)
            except Exception as ex:
                self._ui.set_status(f'!{str(ex)}')

    def _import_document(self, event=None):
        self._ui.restore_status()
        try:
            filePath = self._documentCollection.selection()[0]
        except IndexError:
            pass
        else:
            self._ctrl.import_odf(sourcePath=filePath, parent=self)
        importButtonState = 'disabled'
        self._importButton.configure(state=importButtonState)
        self._list_documents()

    def _list_documents(self):
        if not self._mdl.prjFile:
            return

        prjDir, prjFile = os.path.split(self._mdl.prjFile.filePath)
        prjName, __ = os.path.splitext(prjFile)
        self._prjDocuments = {}
        for file in os.listdir(prjDir):
            for docType in self._docTypes:
                if file == f'{prjName}{docType}':
                    self._prjDocuments[f'{prjDir}/{file}'] = (
                        self._docTypes[docType]
                    )
        self._reset_tree()
        for filePath in self._prjDocuments:
            timestamp = os.path.getmtime(filePath)
            nodeTags = []
            try:
                documentType = self._prjDocuments[filePath]
            except:
                documentType = _('No document type')
            try:
                documentDate = datetime.fromtimestamp(timestamp).strftime('%c')
            except:
                documentDate = _('unknown')
            columns = [documentType, documentDate]
            if odf_is_locked(filePath):
                nodeTags.append('locked')
            elif timestamp > self._mdl.prjFile.timestamp:
                nodeTags.append('newer')
            self._documentCollection.insert(
                '',
                'end',
                filePath,
                values=columns,
                tags=tuple(nodeTags)
            )

    def _on_select_document(self, event=None):
        try:
            filePath = self._documentCollection.selection()[0]
        except IndexError:
            delButtonState = 'disabled'
            impButtonState = 'disabled'
        else:
            if odf_is_locked(filePath):
                delButtonState = 'disabled'
                if self._importModeVar.get() != 2:
                    impButtonState = 'disabled'
                else:
                    impButtonState = 'normal'
            else:
                delButtonState = 'normal'
                impButtonState = 'normal'
        self._deleteButton.configure(state=delButtonState)
        self._importButton.configure(state=impButtonState)

    def _open_help(self, event=None):
        NvHelp.open_help_page(f'import_menu.html')

    def _reset_tree(self):
        for child in self._documentCollection.get_children(''):
            self._documentCollection.delete(child)

    def _save_options(self, event=None, *args):
        prefs['import_mode'] = str(self._importModeVar.get())

from tkinter import ttk



class DragDropListbox(tk.Listbox):

    def __init__(self, master, **kw):
        kw['selectmode'] = 'single'
        tk.Listbox.__init__(self, master, kw)
        self.bind('<Button-1>', self._set_current)
        self.bind('<B1-Motion>', self._shift_selection)
        self.curIndex = None

    def _set_current(self, event):
        self.curIndex = self.nearest(event.y)

    def _shift_selection(self, event):
        i = self.nearest(event.y)
        if i < self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i + 1, x)
            self.curIndex = i
        elif i > self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i - 1, x)
            self.curIndex = i


class ViewOptionsDialog(ModalDialog, SubController):

    def __init__(self, view, **kw):
        super().__init__(view, **kw)
        self._ui = view

        self.title(_('"View" options'))
        self.iconphoto(False, view.icons.settingsIcon)
        window = ttk.Frame(self)
        window.pack(
            fill='both',
        )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')

        ttk.Separator(
            window,
            orient='vertical',
        ).pack(fill='y', side='left')
        frame2 = ttk.Frame(window)
        frame2.pack(fill='both', side='left')

        coloringModeFrame = ttk.Frame(frame1)
        coloringModeFrame.pack(padx=5, pady=5, anchor='w')
        self._coloringModeStrVar = tk.StringVar()
        ttk.Label(
            coloringModeFrame,
            text=f"{_('Coloring mode')}:",
        ).pack(side='left')

        ttk.OptionMenu(
            coloringModeFrame,
            self._coloringModeStrVar,
            self._ui.tv.COLORING_MODES[self._ui.tv.coloringMode],
            *self._ui.tv.COLORING_MODES,
            command=self._change_colors,
        ).pack()

        self._colorTreeVar = tk.BooleanVar(
            frame1,
            value=prefs['color_tree'],
        )
        ttk.Checkbutton(
            frame1,
            text=_('Display the entire project tree in color'),
            variable=self._colorTreeVar,
            command=self._change_color_tree,
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(frame1, orient='horizontal').pack(fill='x')

        self._largeIconsVar = tk.BooleanVar(
            frame1,
            value=prefs['large_icons'],
        )
        ttk.Checkbutton(
            frame1,
            text=_('Large icons'),
            variable=self._largeIconsVar,
            command=self._change_icon_size,
        ).pack(padx=5, pady=5, anchor='w')

        self._localizeDateVar = tk.BooleanVar(
            frame1,
            value=prefs['localize_date'],
        )
        ttk.Checkbutton(
            frame1,
            text=_('Display localized dates'),
            variable=self._localizeDateVar,
            command=self._change_localize_date,
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Label(
            frame2,
            text=_('Columns'),
        ).pack(padx=5, pady=5, anchor='w')
        self._coIdsByTitle = {}
        for coId, title, __ in self._ui.tv.columns:
            self._coIdsByTitle[title] = coId
        self._colEntriesVar = tk.Variable(
            value=list(self._coIdsByTitle),
        )
        DragDropListbox(
            frame2,
            listvariable=self._colEntriesVar,
            width=20,
        ).pack(padx=5, pady=5, anchor='w')
        ttk.Button(
            frame2,
            text=_('Apply'),
            command=self._change_column_order,
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_color_tree(self, *args):
        prefs['color_tree'] = self._colorTreeVar.get()
        self._ui.tv.refresh()

    def _change_colors(self, *args, **kwargs):
        self._ui.tv.coloringMode = self._ui.tv.COLORING_MODES.index(
            self._coloringModeStrVar.get()
        )
        self._ui.tv.refresh()

    def _change_column_order(self, *args, **kwargs):
        srtColumns = []
        titles = self._colEntriesVar.get()
        for title in titles:
            srtColumns.append(self._coIdsByTitle[title])
        prefs['column_order'] = list_to_string(srtColumns)
        self._ui.tv.configure_columns()
        self._ui.tv.refresh()

    def _change_icon_size(self, *args):
        prefs['large_icons'] = self._largeIconsVar.get()
        self._ui.show_info(
            message=_('Icon size changed'),
            detail=f"{_('The change takes effect after next startup')}.",
            title=_('"View" options'),
            parent=self
        )

    def _change_localize_date(self, *args):
        prefs['localize_date'] = self._localizeDateVar.get()
        self._ui.tv.refresh()
        self._ui.propertiesView.refresh()

    def _open_help(self, event=None):
        NvHelp.open_help_page(f'view_menu.html#{_("options").lower()}')


class Commands:

    def add_multiple_new_chapters(self):
        if not self.check_lock():
            return self.elementManager.add_multiple_new_chapters()

    def add_multiple_new_sections(self):
        if not self.check_lock():
            return self.elementManager.add_multiple_new_sections()

    def add_new_chapter(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_chapter(**kwargs)

    def add_new_character(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_character(**kwargs)

    def add_new_child(self, event=None):
        if not self.check_lock():
            return self.elementManager.add_new_child()

    def add_new_element(self, event=None):
        if not self.check_lock():
            return self.elementManager.add_new_element()

    def add_new_item(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_item(**kwargs)

    def add_new_location(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_location(**kwargs)

    def add_new_parent(self, event=None):
        if not self.check_lock():
            return self.elementManager.add_new_parent()

    def add_new_part(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_part(**kwargs)

    def add_new_plot_line(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_plot_line(**kwargs)

    def add_new_plot_point(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_plot_point(**kwargs)

    def add_new_project_note(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_project_note(**kwargs)

    def add_new_section(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_section(**kwargs)

    def add_new_stage(self, **kwargs):
        if not self.check_lock():
            return self.elementManager.add_new_stage(**kwargs)

    def clone_section(self, scId=None):
        if not self.check_lock():
            return self.elementManager.clone_section(scId)

    def close_project(self, event=None, doNotSave=False):
        return self.on_close(doNotSave=doNotSave)

    def copy_css(self, event=None):
        self.fileManager.copy_css()
        return 'break'

    def create_project(self, event=None):
        return self.fileManager.create_project()

    def cut_element(self, event=None):
        self.clipboardManager.cut_element()

    def copy_element(self, event=None):
        self.clipboardManager.copy_element()

    def delete_elements(self, event=None, elements=None):
        if not self.check_lock():
            self.elementManager.delete_elements(elements)
        return 'break'

    def discard_manuscript(self):
        self.fileManager.discard_manuscript()

    def exclude_plot_line(self, event=None):
        if not self.check_lock():
            self.elementManager.exclude_plot_line()

    def export_brief_synopsis(self, event=None):
        self.fileManager.export_document(
            BRF_SYNOPSIS_SUFFIX,
            lock=False,
            overwrite=True,
        )

    def export_chapter_desc(self, event=None):
        self.fileManager.export_document(CHAPTERS_SUFFIX)

    def export_chapter_table(self, event=None):
        self.fileManager.export_document(CHAPTERLIST_SUFFIX)

    def export_character_desc(self, event=None):
        self.fileManager.export_document(CHARACTERS_SUFFIX)

    def export_character_table(self, event=None):
        self.fileManager.export_document(CHARLIST_SUFFIX)

    def export_cross_references(self, event=None):
        self.fileManager.export_document(
            XREF_SUFFIX,
            lock=False,
            overwrite=True,
        )

    def export_filtered_manuscript(self, event=None):
        self.fileManager.export_document(
            MANUSCRIPT_SUFFIX,
            filter=self._ui.selectedNode,
            ask=False,
        )

    def export_filtered_synopsis(self, event=None):
        self.fileManager.export_document(
            SECTIONS_SUFFIX,
            filter=self._ui.selectedNode,
            ask=False,
        )

    def export_final_document(self, event=None):
        self.fileManager.export_document('', lock=False)

    def export_item_desc(self, event=None):
        self.fileManager.export_document(ITEMS_SUFFIX)

    def export_item_table(self, event=None):
        self.fileManager.export_document(ITEMLIST_SUFFIX)

    def export_location_desc(self, event=None):
        self.fileManager.export_document(LOCATIONS_SUFFIX)

    def export_location_table(self, event=None):
        self.fileManager.export_document(LOCLIST_SUFFIX)

    def export_part_desc(self, event=None):
        self.fileManager.export_document(PARTS_SUFFIX)

    def export_part_table(self, event=None):
        self.fileManager.export_document(PARTLIST_SUFFIX)

    def export_manuscript(self, event=None):
        self.fileManager.export_document(MANUSCRIPT_SUFFIX)

    def export_manuscript_with_unused(self, event=None):
        self.fileManager.export_document(FULL_MANUSCRIPT_SUFFIX)

    def export_metadata_text(self, event=None):
        self.fileManager.export_document(METADATA_TEXT_SUFFIX)

    def export_plot_grid(self, event=None):
        self.fileManager.export_document(GRID_SUFFIX)

    def export_plot_lines_desc(self, event=None):
        self.fileManager.export_document(PLOTLINES_SUFFIX, lock=False)

    def export_plot_list(self, event=None):
        self.fileManager.export_document(PLOTLIST_SUFFIX, lock=False)

    def export_project_notes(self, event=None):
        self.fileManager.export_document(PROJECTNOTES_SUFFIX)

    def export_proofing_manuscript(self, event=None):
        self.fileManager.export_document(PROOF_SUFFIX)

    def export_section_desc(self, event=None):
        self.fileManager.export_document(SECTIONS_SUFFIX)

    def export_section_table(self, event=None):
        self.fileManager.export_document(SECTIONLIST_SUFFIX, lock=False)

    def export_story_structure_desc(self, event=None):
        self.fileManager.export_document(STAGES_SUFFIX)

    def export_xml_data_files(self, event=None):
        self.fileManager.export_document(DATA_SUFFIX, lock=False, show=False)

    def import_character_data(self, event=None):
        if not self.check_lock():
            self.elementManager.import_elements(CHARACTER_PREFIX)

    def import_item_data(self, event=None):
        if not self.check_lock():
            self.elementManager.import_elements(ITEM_PREFIX)

    def import_location_data(self, event=None):
        if not self.check_lock():
            self.elementManager.import_elements(LOCATION_PREFIX)

    def import_odf(
            self,
            sourcePath=None,
            defaultExtension='.odt',
            parent=None,
    ):
        if not self.check_lock():
            self.fileManager.import_odf(
                sourcePath,
                defaultExtension,
                parent,
            )

    def import_plot_lines(self, event=None):
        if not self.check_lock():
            self.elementManager.import_elements(PLOT_LINE_PREFIX)

    def include_plot_line(self, event=None):
        if not self.check_lock():
            self.elementManager.include_plot_line()

    def insert_chapter(self, event=None):
        if not self.isLocked:
            self.elementManager.insert_chapter()
        return 'break'

    def join_sections(self, event=None, scId0=None, scId1=None):
        if not self.check_lock():
            self.elementManager.join_sections(scId0, scId1)

    def move_node(self, event=None, node=None, targetNode=None):
        if self.isLocked:
            return 'break'

        if event is not None:
            node = self._ui.selectedNode
            targetNode = self._ui.tv.tree.identify_row(event.y)
        self.elementManager.move_node(node, targetNode)
        return 'break'

    def open_backup_options(self, event=None):
        BackupOptionsDialog(self._ui)
        return 'break'

    def open_export_options(self, event=None):
        ExportOptionsDialog(self._ui, self)
        return 'break'

    def open_help(self, event=None):
        NvHelp.open_help_page('')

    def open_homepage(self, event=None):
        webbrowser.open(HOME_URL)

    def open_installationFolder(self, event=None):
        self.fileManager.open_installationFolder()
        return 'break'

    def open_link(self, element, linkIndex):
        self.linkProcessor.open_link_by_index(element, linkIndex)

    def open_manuscript(self, event=None):
        self.fileManager.export_document(
            MANUSCRIPT_SUFFIX,
            ask=False,
            doNotExport=self.isLocked,
        )

    def open_news(self, event=None):
        webbrowser.open(NEWS_URL)

    def open_plugin_manager(self, event=None):
        PluginManagerDialog(self._ui, self)
        return 'break'

    def open_project(self, event=None, filePath='', doNotSave=False):
        return self.fileManager.open_project(
            filePath=filePath,
            doNotSave=doNotSave,
        )

    def open_project_folder(self, event=None):
        self.fileManager.open_project_folder()
        return 'break'

    def open_project_updater(self, event=None):
        if not self.check_lock():
            ReimportDialog(self._mdl, self._ui, self)
        return 'break'

    def open_view_options(self, event=None):
        ViewOptionsDialog(self._ui)
        return 'break'

    def paste_element(self, event=None):
        self.clipboardManager.paste_element()

    def refresh_tree(self, event=None):
        if not self.isLocked:
            self._ui.propertiesView.apply_changes()
            self._mdl.renumber_chapters()
            self._mdl.prjFile.adjust_section_types()
            self._mdl.novel.update_plot_lines()
        return 'break'

    def reload_project(self, event=None):
        if not self.isLocked:
            self.fileManager.reload_project()
        return 'break'

    def remove_chapter_keep_sections(self, event=None):
        if not self.isLocked:
            self.elementManager.remove_chapter_keep_sections()
        return 'break'

    def reset_color(self, event=None, prefix=None):
        if not self.isLocked:
            self.elementManager.reset_color(prefix=prefix)
        return 'break'

    def reset_color_ch(self, event=None):
        if not self.isLocked:
            self.elementManager.reset_color(
                prefix=CHAPTER_PREFIX,
            )

    def reset_color_cr(self, event=None):
        if not self.isLocked:
            self.elementManager.reset_color(
                prefix=CHARACTER_PREFIX,
            )

    def reset_color_it(self, event=None):
        if not self.isLocked:
            self.elementManager.reset_color(
                prefix=ITEM_PREFIX,
            )

    def reset_color_lc(self, event=None):
        if not self.isLocked:
            self.elementManager.reset_color(
                prefix=LOCATION_PREFIX,
            )

    def reset_color_pl(self, event=None):
        if not self.isLocked:
            self.elementManager.reset_color(
                prefix=PLOT_LINE_PREFIX,
            )

    def reset_color_sc(self, event=None):
        if not self.isLocked:
            self.elementManager.reset_color(
                prefix=SECTION_PREFIX,
            )

    def restore_backup(self, event=None):
        self.fileManager.restore_backup()
        return 'break'

    def save_as(self, event=None):
        return self.fileManager.save_as()

    def save_project(self, event=None):
        if not self.isLocked:
            return self.fileManager.save_project()

    def set_chr_status_major(self, event=None):
        if not self.check_lock():
            self.elementManager.set_character_status(True)

    def set_chr_status_minor(self, event=None):
        if not self.check_lock():
            self.elementManager.set_character_status(False)

    def set_color(self, event=None, title='', prefix=None):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=prefix,
            )

    def set_color_ch(self, event=None, title=''):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=CHAPTER_PREFIX,
            )

    def set_color_cr(self, event=None, title=''):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=CHARACTER_PREFIX,
            )

    def set_color_it(self, event=None, title=''):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=ITEM_PREFIX,
            )

    def set_color_lc(self, event=None, title=''):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=LOCATION_PREFIX,
            )

    def set_color_pl(self, event=None, title=''):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=PLOT_LINE_PREFIX,
            )

    def set_color_sc(self, event=None, title=''):
        if not self.isLocked:
            self.elementManager.set_color(
                title=title,
                prefix=SECTION_PREFIX,
            )

    def set_level_1(self, event=None):
        if not self.check_lock():
            self.elementManager.set_level(1)

    def set_level_2(self, event=None):
        if not self.check_lock():
            self.elementManager.set_level(2)

    def set_scn_status_outline(self, event=None):
        if not self.check_lock():
            self.elementManager.set_completion_status(1)

    def set_scn_status_draft(self, event=None):
        if not self.check_lock():
            self.elementManager.set_completion_status(2)

    def set_scn_status_1st_edit(self, event=None):
        if not self.check_lock():
            self.elementManager.set_completion_status(3)

    def set_scn_status_2nd_edit(self, event=None):
        if not self.check_lock():
            self.elementManager.set_completion_status(4)

    def set_scn_status_done(self, event=None):
        if not self.check_lock():
            self.elementManager.set_completion_status(5)

    def set_type_normal(self, event=None):
        if not self.check_lock():
            self.elementManager.set_type(0)

    def set_type_unused(self, event=None):
        if not self.check_lock():
            self.elementManager.set_type(1)

    def set_viewpoint(self, event=None):
        if not self.check_lock():
            self.elementManager.set_viewpoint()

    def show_character_table(self, event=None):
        self.fileManager.show_report(CHARACTER_REPORT_SUFFIX)

    def show_notes_list(self, event=None):
        self.fileManager.show_report(ELEMENT_NOTES_SUFFIX)

    def show_item_list(self, event=None):
        self.fileManager.show_report(ITEM_REPORT_SUFFIX)

    def show_location_list(self, event=None):
        self.fileManager.show_report(LOCATION_REPORT_SUFFIX)

    def show_plot_grid(self, event=None):
        self.fileManager.show_report(GRID_REPORT_SUFFIX)

    def show_plot_table(self, event=None):
        self.fileManager.show_report(PLOTLIST_SUFFIX)

    def show_plot_line_board(self, event=None):
        self.fileManager.show_report(PLOT_LINE_BOARD_SUFFIX)

    def show_projectnotes_list(self, event=None):
        self.fileManager.show_report(PROJECTNOTES_REPORT_SUFFIX)

    def show_chapter_board(self, event=None):
        self.fileManager.show_report(CHAPTER_BOARD_SUFFFIX)

    def show_story_structure_board(self, event=None):
        self.fileManager.show_report(STORY_STRUCT_BOARD_SUFFIX)

    def show_time_table(self, event=None):
        self.fileManager.show_report(TIMETABLE_SUFFIX)

    def show_viewpoint_board(self, event=None):
        self.fileManager.show_report(VIEWPOINT_BOARD_SUFFFIX)

    def split_file(self, event=None):
        if not self.check_lock():
            self.fileSplitter.split_project()

    def toggle_lock(self, event=None):
        if self.isLocked:
            self.unlock()
        else:
            self.lock()
        return 'break'

    def update_from_manuscript(self, event=None):
        if not self.check_lock():
            fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
            self.fileManager.import_odf(
                sourcePath=f'{fileName}{MANUSCRIPT_SUFFIX}.odt'
            )
        return 'break'

import glob
import importlib



class RejectedPlugin:
    VERSION = '-'
    API_VERSION = '-'
    URL = ''

    def __init__(self, filePath, message):
        self.filePath = filePath
        self.isActive = False
        self.isRejected = True
        self.DESCRIPTION = message



class PluginCollection(dict, SubController):

    def __init__(self, model, view, controller):
        dict.__init__(self)
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        versionStr = '5.60.0'

        try:
            majorStr, minorStr, patchStr = versionStr.split('.')
            self.majorVersion = int(majorStr)
            self.minorVersion = int(minorStr)
            self.patchlevel = int(patchStr)
        except ValueError:
            self.majorVersion = 5
            self.minorVersion = 60
            self.patchlevel = 0

    def uninstall_plugin(self, pluginName):
        if pluginName in self:
            try:
                if self[pluginName].filePath:
                    try:
                        self[pluginName].uninstall()
                    except AttributeError:
                        pass
                    os.remove(self[pluginName].filePath)
                    self[pluginName].filePath = ''
                    return True

            except Exception as ex:
                print(str(ex))
        return False

    def disable_menu(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].disable_menu()
                except:
                    pass

    def enable_menu(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].enable_menu()
                except:
                    pass

    def load_file(self, filePath):
        try:
            pluginName, __ = os.path.splitext(os.path.basename(filePath))

            pluginModule = importlib.import_module(pluginName)

            pluginObject = pluginModule.Plugin()
            try:
                apiVerStr = pluginObject.API_VERSION
                isCompatible = True
            except AttributeError:
                apiVerStr = pluginObject.NOVELTREE_API
                isCompatible = False
            majorStr, minorStr = apiVerStr.split('.')
            apiMajorVersion = int(majorStr)
            apiMinorVersion = int(minorStr)
            if apiMajorVersion != self.majorVersion:
                isCompatible = False
            if apiMinorVersion > self.minorVersion:
                isCompatible = False
            if isCompatible:
                pluginObject.install(self._mdl, self._ui, self._ctrl)

            pluginObject.isActive = isCompatible
            pluginObject.isRejected = False

            self[pluginName] = pluginObject

            pluginObject.filePath = filePath
            return True

        except Exception as ex:
            self[pluginName] = RejectedPlugin(filePath, str(ex))
            return False

    def load_plugins(self, pluginPath):
        if not os.path.isdir(pluginPath):
            print('Plugin directory not found.')
            return False

        sys.path.append(pluginPath)
        for file in glob.iglob(f'{pluginPath}/nv_*.py'):
            self.load_file(file)

        return True

    def lock(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].lock()
                except:
                    pass

    def on_close(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].on_close()
                except:
                    pass

    def on_open(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].on_open()
                except:
                    pass

    def on_quit(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].on_quit()
                except:
                    pass

    def unlock(self):
        for pluginName in self:
            if self[pluginName].isActive:
                try:
                    self[pluginName].unlock()
                except:
                    pass

from xml.etree import ElementTree as ET



class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller


class ClipboardManager(ServiceBase):

    def cut_element(self, elemPrefix=None):
        if self._mdl.prjFile is None:
            return

        if self._ctrl.check_lock():
            return

        try:
            node = self._ui.selectedNode
        except:
            return

        if self.copy_element(elemPrefix) is None:
            return

        if self._ui.tv.tree.prev(node):
            self._ui.tv.go_to_node(self._ui.tv.tree.prev(node))
        else:
            self._ui.tv.go_to_node(self._ui.tv.tree.parent(node))
        self._mdl.delete_element(node, trash=False)
        return 'break'

    def copy_element(self, elemPrefix=None):
        if self._mdl.prjFile is None:
            return

        try:
            node = self._ui.selectedNode
        except:
            return

        nodePrefix = node[:2]
        if elemPrefix is not None:
            if nodePrefix != elemPrefix:
                return

        elementContainers = {
            CHAPTER_PREFIX: (
                self._mdl.novel.chapters,
                'CHAPTER',
                self._mdl.prjFile.chapterCnv,
            ),
            SECTION_PREFIX: (
                self._mdl.novel.sections,
                'SECTION',
                self._mdl.prjFile.sectionCnv,
            ),
            PLOT_LINE_PREFIX: (
                self._mdl.novel.plotLines,
                'ARC',
                self._mdl.prjFile.plotLineCnv,
            ),
            PLOT_POINT_PREFIX: (
                self._mdl.novel.plotPoints,
                'POINT',
                self._mdl.prjFile.plotPointCnv,
            ),
            CHARACTER_PREFIX: (
                self._mdl.novel.characters,
                'CHARACTER',
                self._mdl.prjFile.characterCnv,
            ),
            LOCATION_PREFIX: (
                self._mdl.novel.locations,
                'LOCATION',
                self._mdl.prjFile.worldElementCnv,
            ),
            ITEM_PREFIX: (
                self._mdl.novel.items,
                'ITEM',
                self._mdl.prjFile.worldElementCnv,
            ),
            PRJ_NOTE_PREFIX: (
                self._mdl.novel.projectNotes,
                'PROJECTNOTE',
                self._mdl.prjFile.basicElementCnv,
            ),
        }
        if not nodePrefix in elementContainers:
            return

        elementContainer, xmlTag, elementCnv = elementContainers[nodePrefix]
        element = elementContainer[node]
        xmlElement = ET.Element(xmlTag)
        elementCnv.export_data(element, xmlElement)
        self._remove_references(xmlElement)

        if nodePrefix == CHAPTER_PREFIX:
            for scId in self._mdl.novel.tree.get_children(node):
                xmlSection = ET.SubElement(xmlElement, 'SECTION')
                self._mdl.prjFile.sectionCnv.export_data(
                    self._mdl.novel.sections[scId],
                    xmlSection
                )
                self._remove_references(xmlSection)
        elif nodePrefix == PLOT_LINE_PREFIX:
            for ppId in self._mdl.novel.tree.get_children(node):
                xmlPlotPoint = ET.SubElement(xmlElement, 'POINT')
                self._mdl.prjFile.plotPointCnv.export_data(
                    self._mdl.novel.plotPoints[ppId],
                    xmlPlotPoint
                )
                self._remove_references(xmlPlotPoint)

        text = ET.tostring(xmlElement)
        self._ui.root.clipboard_clear()
        self._ui.root.clipboard_append(text)
        self._ui.root.update()
        return 'break'

    def paste_element(self, elemPrefix=None):
        if self._mdl.prjFile is None:
            return

        if self._ctrl.check_lock():
            return

        try:
            node = self._ui.selectedNode
        except:
            return

        try:
            text = self._ui.root.clipboard_get()
            xmlElement = ET.fromstring(text)
        except:
            return

        prefixes = {
            'CHAPTER': CHAPTER_PREFIX,
            'SECTION': SECTION_PREFIX,
            'ARC': PLOT_LINE_PREFIX,
            'POINT': PLOT_POINT_PREFIX,
            'CHARACTER': CHARACTER_PREFIX,
            'LOCATION': LOCATION_PREFIX,
            'ITEM': ITEM_PREFIX,
            'PROJECTNOTE': PRJ_NOTE_PREFIX
        }
        nodePrefix = prefixes.get(xmlElement.tag, None)
        if nodePrefix is None:
            return

        if elemPrefix is not None:
            if nodePrefix != elemPrefix:
                return

        if nodePrefix == SECTION_PREFIX:
            typeStr = xmlElement.get('type', 0)
            if int(typeStr) > 1:
                elemCreator = self._mdl.add_new_stage
            else:
                elemCreator = self._mdl.add_new_section
            elemContainer = self._mdl.novel.sections
            elemCnv = self._mdl.prjFile.sectionCnv
        else:
            elementControls = {
                CHAPTER_PREFIX: (
                    self._mdl.add_new_chapter,
                    self._mdl.novel.chapters,
                    self._mdl.prjFile.chapterCnv,
                ),
                PLOT_LINE_PREFIX: (
                    self._mdl.add_new_plot_line,
                    self._mdl.novel.plotLines,
                    self._mdl.prjFile.plotLineCnv,
                ),
                PLOT_POINT_PREFIX: (
                    self._mdl.add_new_plot_point,
                    self._mdl.novel.plotPoints,
                    self._mdl.prjFile.plotPointCnv,
                ),
                CHARACTER_PREFIX: (
                    self._mdl.add_new_character,
                    self._mdl.novel.characters,
                    self._mdl.prjFile.characterCnv,
                ),
                LOCATION_PREFIX: (
                    self._mdl.add_new_location,
                    self._mdl.novel.locations,
                    self._mdl.prjFile.worldElementCnv
                ),
                ITEM_PREFIX: (
                    self._mdl.add_new_item,
                    self._mdl.novel.items,
                    self._mdl.prjFile.worldElementCnv
                ),
                PRJ_NOTE_PREFIX: (
                    self._mdl.add_new_project_note,
                    self._mdl.novel.projectNotes,
                    self._mdl.prjFile.basicElementCnv,
                )
            }
            if not nodePrefix in elementControls:
                return

            elemCreator, elemContainer, elemCnv = elementControls[nodePrefix]

        elemId = elemCreator(targetNode=node)
        if not elemId:
            return

        elemCnv.import_data(
            elemContainer[elemId],
            xmlElement
        )

        targetNode = elemId
        if nodePrefix == CHAPTER_PREFIX:
            for xmlSection in xmlElement.iterfind('SECTION'):
                typeStr = xmlSection.get('type', 0)
                if int(typeStr) > 1:
                    scId = self._mdl.add_new_stage(targetNode=targetNode)
                else:
                    scId = self._mdl.add_new_section(targetNode=targetNode)
                self._mdl.prjFile.sectionCnv.import_data(
                    self._mdl.novel.sections[scId],
                    xmlSection
                )
                targetNode = scId
        elif nodePrefix == PLOT_LINE_PREFIX:
            for xmlPoint in xmlElement.iterfind('POINT'):
                ppId = self._mdl.add_new_plot_point(targetNode=targetNode)
                self._mdl.prjFile.plotPointCnv.import_data(
                    self._mdl.novel.plotPoints[ppId],
                    xmlPoint
                )
                targetNode = ppId

        self._ctrl.refresh_tree()
        self._ui.tv.go_to_node(elemId)
        return 'break'

    def _remove_references(self, xmlElement):
        references = [
            'Characters',
            'Locations',
            'Items',
            'PlotlineNotes',
            'Sections',
            'Section',
            'Viewpoint',
        ]
        for ref in references:
            for xmlRef in xmlElement.findall(ref):
                xmlElement.remove(xmlRef)


class CharacterDataReader(NovxFile):
    DESCRIPTION = _('XML character data file')
    EXTENSION = '.xml'

    def read(self):
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        self._read_characters(root)



class ItemDataReader(NovxFile):
    DESCRIPTION = _('XML item data file')
    EXTENSION = '.xml'

    def read(self):
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        self._read_items(root)



class LocationDataReader(NovxFile):
    DESCRIPTION = _('XML location data file')
    EXTENSION = '.xml'

    def read(self):
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        self._read_locations(root)



class PlotLineReader(NovxFile):
    DESCRIPTION = _('XML plot line file')
    EXTENSION = '.xml'

    def read(self):
        self._references = [
            'Sections',
            'Section',
        ]
        tree = ET.parse(self.filePath)
        root = ET.Element('ROOT')
        root.append(tree.getroot())
        xmlPlotLines = root.find('ARCS')
        if xmlPlotLines is not None:
            for xmlPlotLine in xmlPlotLines.iterfind('ARC'):
                self._remove_references(xmlPlotLine)
                for xmlPlotPoint in xmlPlotLine.iterfind('POINT'):
                    self._remove_references(xmlPlotPoint)
        self._read_plot_lines_and_points(root)

    def _remove_references(self, xmlElement):
        for ref in self._references:
            for xmlRef in xmlElement.findall(ref):
                xmlElement.remove(xmlRef)


class DataImporter(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self.sourceNovel = None
        self.sourceElements = None

    def read_source(self, filePath, prefix):
        sources = {
            CHARACTER_PREFIX:CharacterDataReader,
            LOCATION_PREFIX:LocationDataReader,
            ITEM_PREFIX:ItemDataReader,
            PLOT_LINE_PREFIX:PlotLineReader,
        }
        source = sources[prefix](filePath)
        source.novel = self._mdl.nvService.new_novel()

        errorMessages = {
            CHARACTER_PREFIX:_('No character data found'),
            LOCATION_PREFIX:_('No location data found'),
            ITEM_PREFIX:_('No item data found'),
            PLOT_LINE_PREFIX:_('No plot lines found'),
        }
        try:
            source.read()
        except:
            raise RuntimeError(
                f'{_("Cannot process file")}: {norm_path(filePath)}'
            )

        sourceElements = {
            CHARACTER_PREFIX:source.novel.characters,
            LOCATION_PREFIX:source.novel.locations,
            ITEM_PREFIX:source.novel.items,
            PLOT_LINE_PREFIX:source.novel.plotLines,
        }
        if not sourceElements[prefix]:
            raise UserWarning(
                f'{errorMessages[prefix]}: {norm_path(filePath)}'
            )

        self.sourceElements = sourceElements[prefix]
        self.sourceNovel = source.novel

    def add_elements(self, selectedIds=None):
        if self.sourceNovel is None:
            return

        if self.sourceElements is None:
            return

        if selectedIds is None:
            selectedIds = self.sourceElements

        targetElements = {
            CHARACTER_PREFIX:self._mdl.novel.characters,
            LOCATION_PREFIX:self._mdl.novel.locations,
            ITEM_PREFIX:self._mdl.novel.items,
            PLOT_LINE_PREFIX:self._mdl.novel.plotLines,
        }
        elemParents = {
            CHARACTER_PREFIX:CR_ROOT,
            LOCATION_PREFIX:LC_ROOT,
            ITEM_PREFIX:IT_ROOT,
            PLOT_LINE_PREFIX:PL_ROOT,
        }
        add_children = {
            CHARACTER_PREFIX:self._do_nothing,
            LOCATION_PREFIX:self._do_nothing,
            ITEM_PREFIX:self._do_nothing,
            PLOT_LINE_PREFIX:self._add_plot_points,
        }
        i = 0
        for  elemId in selectedIds:
            prefix = elemId[:2]
            newId = new_id(targetElements[prefix], prefix=prefix)
            targetElements[prefix][newId] = self.sourceElements[elemId]
            self._mdl.novel.tree.append(elemParents[prefix], newId)
            add_children[prefix](newId, elemId)
            i += 1
        if i > 0:
            self._ui.tv.go_to_node(newId)
            self._ui.set_status(f'{i} {_("elements imported")}')
        self.sourceNovel = None
        self.sourceElements = None

    def _add_plot_points(self, plId, srcPlId):
        srcPlotPoints = self.sourceNovel.tree.get_children(srcPlId)
        if srcPlotPoints:
            for srcPpId in srcPlotPoints:
                ppId = new_id(
                    self._mdl.novel.plotPoints,
                    prefix=PLOT_POINT_PREFIX,
                )
                self._mdl.novel.plotPoints[ppId] = (
                    self.sourceNovel.plotPoints[srcPpId]
                )
                self._mdl.novel.tree.append(plId, ppId)

    def _do_nothing(self, *args):
        pass

from abc import ABC, abstractmethod


class FileFactory(ABC):

    def __init__(self, fileClasses):
        self._fileClasses = fileClasses

    @abstractmethod
    def new_file_objects(self, sourcePath, **kwargs):
        pass


class ImportSourceFactory(FileFactory):

    def new_file_objects(self, sourcePath, **kwargs):
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX is not None:
                if sourcePath.endswith(
                    f'{fileClass.SUFFIX }{fileClass.EXTENSION}'
                ):
                    sourceFile = fileClass(sourcePath, **kwargs)
                    return sourceFile, None

        raise RuntimeError(
            f'{_("This document is not meant to be written back")}.'
        )



class ImportTargetFactory(FileFactory):

    def new_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        sourceSuffix = kwargs['suffix']
        if sourceSuffix:
            e = fileName.split(sourceSuffix)
            if len(e) > 1:
                e.pop()
            ywPathBasis = ''.join(e)
        else:
            ywPathBasis = fileName

        for fileClass in self._fileClasses:
            if os.path.isfile(f'{ywPathBasis}{fileClass.EXTENSION}'):
                targetFile = fileClass(
                    f'{ywPathBasis}{fileClass.EXTENSION}',
                    **kwargs
                )
                return None, targetFile

        raise RuntimeError(f'{_("No novelibre project to write")}.')

from xml.sax.saxutils import unescape



class OdtRImport(OdtRFormatted):
    DESCRIPTION = _('Work in progress')
    SUFFIX = ''
    _SECTION_DIVIDER = '* * *'
    _LOW_WORDCOUNT = 10

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._chCount = 0
        self._scCount = 0

    def handle_data(self, data):
        if self._scId is not None and self._SECTION_DIVIDER in data:
            self._scId = None
            return

        self._lines.append(data)

    def handle_endtag(self, tag):
        if tag in (
            'p',
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            self._lines.append(f'</{tag}>')
            if self._scId is None:
                return

            sectionText = ''.join(self._lines).rstrip()
            sectionText = self._remove_redundant_tags(sectionText)
            self.novel.sections[self._scId].sectionContent = sectionText
            if self.novel.sections[self._scId].wordCount < self._LOW_WORDCOUNT:
                self.novel.sections[self._scId].status = 1
            else:
                self.novel.sections[self._scId].status = 2
            return

        if tag in (
            'em',
            'strong',
            'comment',
            'creator',
            'date',
            'note',
            'note-citation',
            'ul',
            'li',
        ):
            self._lines.append(f'</{tag}>')
            return

        if tag == 'lang':
            self._lines.append('</span>')
            return

        if tag in ('h1', 'h2'):
            self.novel.chapters[self._chId].title = unescape(
                re.sub('<.*?>', '', ''.join(self._lines))
            )
            self._lines.clear()
            return

        if tag == 'title':
            self.novel.title = ''.join(self._lines)

    def handle_starttag(self, tag, attrs):
        if tag in (
            'p',
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            if self._scId is None and self._chId is not None:

                self._lines.clear()
                self._scCount += 1
                self._scId = new_id(
                    self.novel.sections,
                    prefix=SECTION_PREFIX
                )
                self.novel.sections[self._scId] = Section(
                    title=f'{_("Section")} {self._scCount}',
                    scType=0,
                    scene=0,
                    status=1,
                )
                self.novel.tree.append(self._chId, self._scId)
            attributes = ''
            try:
                for att in attrs:
                    attributes = f'{attributes} {att[0]}="{att[1]}"'
                    if att[0] == 'lang':
                        if not att[1] in self.novel.languages:
                            self.novel.languages.append(att[1])
            except:
                pass
            self._lines.append(f'<{tag}{attributes}>')
            return

        if tag in(
            'em',
            'strong',
            'comment',
            'creator',
            'date',
            'note-citation',
            'ul',
            'li',
        ):
            self._lines.append(f'<{tag}>')
            return

        if tag == 'lang':
            if attrs[0][0] == 'lang':
                if not attrs[0][1] in self.novel.languages:
                    self.novel.languages.append(attrs[0][1])
                self._lines.append(f'<span xml:lang="{attrs[0][1]}">')
            return

        if tag == 'note':
            attributes = ''
            for att in attrs:
                attributes = f'{attributes} {att[0]}="{att[1]}"'
            self._lines.append(f'<note {attributes}>')
            return

        if tag in ('h1', 'h2'):
            self._scId = None
            self._lines.clear()
            self._chCount += 1
            self._chId = f'{CHAPTER_PREFIX}{self._chCount}'
            self.novel.chapters[self._chId] = Chapter(chType=0)
            self.novel.tree.append(CH_ROOT, self._chId)
            if tag == 'h1':
                self.novel.chapters[self._chId].chLevel = 1
            else:
                self.novel.chapters[self._chId].chLevel = 2
            return

        if tag == 'div':
            self._scId = None
            self._chId = None
            return

        if tag == 'meta':
            if attrs[0][1] == 'author':
                self.novel.authorName = attrs[1][1]
            if attrs[0][1] == 'description':
                self.novel.desc = attrs[1][1]
            return

        if tag == 'title':
            self._lines.clear()
            return

        if tag == 'body':
            self._set_novel_language(attrs)
            return

        if tag == 's':
            self._lines.append(' ')

    def read(self):
        self.novel.languages = []
        super().read()

from xml.sax.saxutils import unescape



class OdtROutline(OdtReader):
    DESCRIPTION = _('Novel outline')
    SUFFIX = ''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._chCount = 0
        self._scCount = 0

    def handle_data(self, data):
        self._lines.append(data)

    def handle_endtag(self, tag):
        text = ''.join(self._lines)
        if tag == 'p':
            self._lines = [f'{text.strip()}\n']
            if self._scId is not None:
                self.novel.sections[self._scId].desc = text
                return

            if self._chId is not None:
                self.novel.chapters[self._chId].desc = text
            return

        if tag in ('h1', 'h2'):
            self.novel.chapters[self._chId].title = unescape(
                re.sub('<.*?>', '', text).strip()
            )
            self._lines.clear()
            return

        if tag == 'h3':
            if self._chId is None:
                return

            self.novel.sections[self._scId].title = unescape(
                re.sub('<.*?>', '', text).strip()
            )
            self._lines.clear()
            return

        if tag == 'title':
            self.novel.title = text.strip()

    def handle_starttag(self, tag, attrs):
        if tag in ('h1', 'h2'):
            self._scId = None
            self._lines.clear()
            self._chCount += 1
            self._chId = f'{CHAPTER_PREFIX}{self._chCount}'
            self.novel.chapters[self._chId] = Chapter(chType=0)
            self.novel.tree.append(CH_ROOT, self._chId)
            if tag == 'h1':
                self.novel.chapters[self._chId].chLevel = 1
            else:
                self.novel.chapters[self._chId].chLevel = 2
            return

        if tag == 'h3':
            if self._chId is None:
                return

            self._lines.clear()
            self._scCount += 1
            self._scId = f'{SECTION_PREFIX}{self._scCount}'
            self.novel.sections[self._scId] = Section(
                scType=0,
                scene=0,
                status=1,
            )
            self.novel.tree.append(self._chId, self._scId)
            self.novel.sections[self._scId].sectionContent = ''
            return

        if tag == 'div':
            self._scId = None
            self._chId = None
            return

        if tag == 'meta':
            if attrs[0][1] == 'author':
                self.novel.authorName = attrs[1][1]
                return

            if attrs[0][1] == 'description':
                self.novel.desc = attrs[1][1]
            return

        if tag == 'title':
            self._lines.clear()
            return

        if tag == 'body':
            self._set_novel_language(attrs)
            return

        if tag == 's':
            self._lines.append(' ')


class NewProjectFactory(FileFactory):
    DO_NOT_IMPORT = [XREF_SUFFIX, BRF_SYNOPSIS_SUFFIX]

    def new_file_objects(self, sourcePath, **kwargs):
        if not self._canImport(sourcePath):
            raise RuntimeError(
                f'{_("This document is not meant to be written back")}.'
            )

        fileName, __ = os.path.splitext(sourcePath)
        targetFile = NovxFile(f'{fileName}{NovxFile.EXTENSION}', **kwargs)
        if sourcePath.endswith('.odt'):
            try:
                with zipfile.ZipFile(sourcePath, 'r') as odfFile:
                    content = odfFile.read('content.xml')
            except:
                raise RuntimeError(
                    f'{_("Cannot read file")}: "{norm_path(sourcePath)}".'
                )

            if bytes('Heading_20_3', encoding='utf-8') in content:
                sourceFile = OdtROutline(sourcePath, **kwargs)
            else:
                sourceFile = OdtRImport(sourcePath, **kwargs)
            return sourceFile, targetFile

        else:
            for fileClass in self._fileClasses:
                if fileClass.SUFFIX is not None:
                    if sourcePath.endswith(
                        f'{fileClass.SUFFIX}{fileClass.EXTENSION}'
                    ):
                        sourceFile = fileClass(sourcePath, **kwargs)
                        return sourceFile, targetFile

            raise RuntimeError(
                f'{_("File type is not supported")}: '
                f'"{norm_path(sourcePath)}".'
            )

    def _canImport(self, sourcePath):
        fileName, __ = os.path.splitext(sourcePath)
        for suffix in self.DO_NOT_IMPORT:
            if fileName.endswith(suffix):
                return False

        return True


class DocImporter(ServiceBase, NovxConversion):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self.importSourceFactory = ImportSourceFactory(
            self.IMPORT_SOURCE_CLASSES
        )
        self.newProjectFactory = NewProjectFactory(
            self.CREATE_SOURCE_CLASSES
        )
        self.importTargetFactory = ImportTargetFactory(
            [NovxFile]
        )
        self.newFile = None
        self.prefs = self._ctrl.get_preferences()

    def import_document(self, sourcePath, parent=None):
        try:
            message = self._run(sourcePath, parent=parent)
        except UserWarning as ex:
            self._ui.set_status(f'#{str(ex)}')
            return

        except RuntimeError as ex:
            self._ui.set_status(f'!{str(ex)}')
            return

        if self.newFile:
            self._ctrl.open_project(filePath=self.newFile)
            if (
                os.path.isfile(sourcePath)
                and self.prefs['import_mode'] == '1'
            ):
                os.replace(sourcePath, f'{sourcePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
            self._ui.set_status(message)

    def _run(self, sourcePath, **kwargs):
        self.newFile = None
        if not os.path.isfile(sourcePath):
            raise RuntimeError(
                f'{_("File not found")}: "{norm_path(sourcePath)}".'
            )

        try:
            source, __ = self.importSourceFactory.new_file_objects(
                sourcePath,
                **kwargs
            )
        except RuntimeError:

            source, target = self.newProjectFactory.new_file_objects(
                sourcePath,
                **kwargs
            )
            if os.path.isfile(target.filePath):
                raise RuntimeError(
                    f'{_("File already exists")}: '
                    f'"{norm_path(target.filePath)}".'
                )

            self._check_source_file(source)
            source.novel = self._mdl.nvService.new_novel()
            source.read()
            target.novel = source.novel
            target.write()
            self.newFile = target.filePath
            return f'{_("File written")}: "{norm_path(target.filePath)}".'

        else:

            kwargs['suffix'] = source.SUFFIX
            __, target = self.importTargetFactory.new_file_objects(
                sourcePath,
                **kwargs
            )
            self.newFile = None
            self._check_source_file(source)
            target.novel = self._mdl.nvService.new_novel()
            target.read()
            source.novel = target.novel
            source.read()
            if source.projectStructureModified and source.is_locked():
                raise RuntimeError(f'{_("Please close the document first")}.')

            if os.path.isfile(target.filePath):
                if not self._ui.ask_yes_no(
                    message=_('Update the project?'),
                    detail=f"{_('Source document')}: {source.DESCRIPTION}",
                    parent=kwargs.get('parent', None)
                ):
                    raise UserWarning(f'{_("Action canceled by user")}.')

            target.novel = source.novel
            target.write()
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self.newFile = target.filePath
            if source.projectStructureModified:
                os.replace(source.filePath, f'{source.filePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
            return message

    def _check_source_file(self, source):
        if source.filePath is None:
            raise RuntimeError(f'{_("File type is not supported")}.')

        if not os.path.isfile(source.filePath):
            raise RuntimeError(
                f'{_("File not found")}: "{norm_path(source.filePath)}".'
            )

        if source.is_locked():
            if self.prefs['import_mode'] != '2':
                raise RuntimeError(f'{_("Please close the document first")}.')

from tkinter import filedialog

from tkinter import messagebox
from tkinter import ttk



class SimpleDialog:

    def __init__(self, master,
                 text='', buttons=[], default=None, cancel=None,
                 title=None, class_=None):
        if class_:
            self.root = tk.Toplevel(master, class_=class_)
        else:
            self.root = tk.Toplevel(master)
        if title:
            self.root.title(title)
            self.root.iconname(title)

        _setup_dialog(self.root)

        self.message = tk.Message(self.root, text=text, aspect=400, bg='white')
        self.message.pack(expand=1, fill='both')
        self.frame = ttk.Frame(self.root)
        self.frame.pack()
        self.num = default
        self.cancel = cancel
        self.default = default
        self.root.bind('<Return>', self.return_event)
        for num in range(len(buttons)):
            s = buttons[num]
            b = ttk.Button(
                self.frame,
                text=s,
                command=(lambda self=self, num=num: self.done(num))
                )
            if num == default:
                b.configure(default='active')
            b.pack(side='left', fill='both', expand=1, padx=5, pady=10)
        self.root.protocol('WM_DELETE_WINDOW', self.wm_delete_window)
        self.root.transient(master)
        _place_window(self.root, master)

    def go(self):
        self.root.wait_visibility()
        self.root.lift()
        self.root.focus_force()
        self.root.grab_set()
        self.root.mainloop()
        self.root.destroy()
        return self.num

    def return_event(self, event):
        if self.default is None:
            self.root.bell()
        else:
            self.done(self.default)

    def wm_delete_window(self):
        if self.cancel is None:
            self.root.bell()
        else:
            self.done(self.cancel)

    def done(self, num):
        self.num = num
        self.root.quit()


class Dialog(tk.Toplevel):


    def __init__(self, parent, title=None):
        master = parent
        tk.Toplevel.__init__(self, master)

        self.withdraw()  # remain invisible for now
        if parent is not None and parent.winfo_viewable():
            self.transient(parent)

        if title:
            self.title(title)

        _setup_dialog(self)

        self.parent = parent

        self.result = None

        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        if self.initial_focus is None:
            self.initial_focus = self

        self.protocol('WM_DELETE_WINDOW', self.cancel)

        _place_window(self, parent)

        self.initial_focus.focus_set()

        self.wait_visibility()
        self.grab_set()
        self.wait_window(self)

    def destroy(self):
        self.initial_focus = None
        tk.Toplevel.destroy(self)


    def body(self, master):
        pass

    def buttonbox(self):

        box = ttk.Frame(self)

        w = ttk.Button(
            box,
            text=_('OK'),
            width=10,
            command=self.ok,
            default='active',
        )
        w.pack(side='left', padx=5, pady=10)
        w = ttk.Button(
            box,
            text=_('Cancel'),
            width=10,
            command=self.cancel,
        )
        w.pack(side='left', padx=5, pady=10)

        self.bind('<Return>', self.ok)
        self.bind('<Escape>', self.cancel)

        box.pack()


    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set()  # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        try:
            self.apply()
        finally:
            self.cancel()

    def cancel(self, event=None):

        if self.parent is not None:
            self.parent.focus_set()
        self.destroy()


    def validate(self):

        return 1  # override

    def apply(self):

        pass  # override


def _place_window(w, parent=None):
    w.wm_withdraw()  # Remain invisible while we figure out the geometry
    w.update_idletasks()  # Actualize geometry information

    minwidth = w.winfo_reqwidth()
    minheight = w.winfo_reqheight()
    maxwidth = w.winfo_vrootwidth()
    maxheight = w.winfo_vrootheight()
    if parent is not None and parent.winfo_ismapped():
        x = parent.winfo_rootx() + (parent.winfo_width() - minwidth) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - minheight) // 2
        vrootx = w.winfo_vrootx()
        vrooty = w.winfo_vrooty()
        x = min(x, vrootx + maxwidth - minwidth)
        x = max(x, vrootx)
        y = min(y, vrooty + maxheight - minheight)
        y = max(y, vrooty)
        if w._windowingsystem == 'aqua':
            y = max(y, 22)
    else:
        x = (w.winfo_screenwidth() - minwidth) // 2
        y = (w.winfo_screenheight() - minheight) // 2

    w.wm_maxsize(maxwidth, maxheight)
    w.wm_geometry('+%d+%d' % (x, y))
    w.wm_deiconify()  # Become visible at the desired location


def _setup_dialog(w):
    if w._windowingsystem == 'aqua':
        w.tk.call('::tk::unsupported::MacWindowStyle', 'style',
                  w, 'moveableModal', '')
    elif w._windowingsystem == 'x11':
        w.wm_attributes('-type', 'dialog')



class _QueryDialog(Dialog):

    def __init__(self, title, prompt,
                 initialvalue=None,
                 minvalue=None, maxvalue=None,
                 parent=None):

        self.prompt = prompt
        self.minvalue = minvalue
        self.maxvalue = maxvalue

        self.initialvalue = initialvalue

        Dialog.__init__(self, parent, title)

    def destroy(self):
        self.entry = None
        Dialog.destroy(self)

    def body(self, master):

        w = ttk.Label(master, text=self.prompt, justify='left')
        w.grid(row=0, padx=5, sticky='w')

        self.entry = ttk.Entry(master, name='entry')
        self.entry.grid(row=1, padx=5, pady=5, sticky='w' + 'e')

        if self.initialvalue is not None:
            self.entry.insert(0, self.initialvalue)
            self.entry.select_range(0, 'end')

        return self.entry

    def validate(self):
        try:
            result = self.getresult()
        except ValueError:
            messagebox.showwarning(
                _('Illegal value'),
                f'{self.errormessage}\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.minvalue is not None and result < self.minvalue:
            messagebox.showwarning(
                _('Too small'),
                (
                    f'{_("The allowed minimum value is")} '
                    f'{self.minvalue}.\n{_("Please try again")}.'
                ),
                parent=self
            )
            return 0

        if self.maxvalue is not None and result > self.maxvalue:
            messagebox.showwarning(
                _('Too large'),
                (
                    f'{_("The allowed maximum value is")} '
                    f'{self.maxvalue}.\n{_("Please try again")}.'
                ),
                parent=self,
            )
            return 0

        self.result = result

        return 1


class _QueryInteger(_QueryDialog):
    errormessage = _('Not an integer.')

    def getresult(self):
        return self.getint(self.entry.get())


def askinteger(title, prompt, **kw):
    d = _QueryInteger(title, prompt, **kw)
    return d.result


class _QueryFloat(_QueryDialog):
    errormessage = _('Not a floating point value.')

    def getresult(self):
        return self.getdouble(self.entry.get())


def askfloat(title, prompt, **kw):
    d = _QueryFloat(title, prompt, **kw)
    return d.result


class _QueryString(_QueryDialog):

    def __init__(self, *args, **kw):
        if 'show' in kw:
            self.__show = kw['show']
            del kw['show']
        else:
            self.__show = None
        _QueryDialog.__init__(self, *args, **kw)

    def body(self, master):
        entry = _QueryDialog.body(self, master)
        if self.__show is not None:
            entry.configure(show=self.__show)
        return entry

    def getresult(self):
        return self.entry.get()


def askstring(title, prompt, **kw):
    d = _QueryString(title, prompt, **kw)
    return d.result

from tkinter import ttk



class PickList(ModalDialog):

    LIST_WIDTH = 300

    def __init__(
        self,
        master,
        title,
        valueDict,
        command,
        icon=None,
        multiple=True,
    ):

        def pick_elements(event=None):
            selection = pList.selection()
            self.destroy()
            self._command(selection)

        super().__init__(master)
        self.title(title)
        if icon is not None:
            self.iconphoto(False, icon)
        self._command = command

        listFrame = ttk.Frame(self)
        listFrame.pack(
            fill='both',
            expand=True,
            padx=4,
            pady=4,
        )

        if multiple:
            selectmode = 'extended'
        else:
            selectmode = 'browse'

        pList = ttk.Treeview(
            listFrame,
            selectmode=selectmode,
            show='tree',
        )
        vbar = ttk.Scrollbar(
            listFrame,
            orient='vertical',
            command=pList.yview,
        )
        vbar.pack(side='right', fill='y')
        pList.pack(
            side='left',
            fill='both',
            expand=True,
        )
        pList.config(yscrollcommand=vbar.set)
        pList.column('#0', width=self.LIST_WIDTH)

        ttk.Button(
            self,
            text=_('OK'),
            command=pick_elements,
        ).pack(padx=5, pady=5, side='left')

        if not multiple:
            pList.bind('<Double-1>', pick_elements)

        ttk.Button(
            self,
            text=_('Cancel'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        for key in valueDict:
            pList.insert(
                '',
                'end',
                key,
                text=valueDict[key],
            )



class ElementManager(ServiceBase):

    _MAX_NR_NEW_SECTIONS = 20
    _INI_NR_NEW_SECTIONS = 1
    _MAX_NR_NEW_CHAPTERS = 20
    _INI_NR_NEW_CHAPTERNS = 1

    def add_multiple_new_chapters(self):
        n = askinteger(
            title=_('New'),
            prompt=_('How many chapters to add?'),
            initialvalue=self._INI_NR_NEW_CHAPTERNS,
            minvalue=0,
            maxvalue=self._MAX_NR_NEW_CHAPTERS,
        )
        if n is not None:
            newNodes = []
            for __ in range(n):
                newNodes.append(self.add_new_chapter())
            return newNodes

    def add_multiple_new_sections(self):
        n = askinteger(
            title=_('New'),
            prompt=_('How many sections to add?'),
            initialvalue=self._INI_NR_NEW_SECTIONS,
            minvalue=0,
            maxvalue=self._MAX_NR_NEW_SECTIONS,
        )
        if n is not None:
            newNodes = []
            for __ in range(n):
                newNodes.append(self.add_new_section())
            return newNodes

    def add_new_chapter(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_chapter(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_character(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_character(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_child(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        try:
            selection = self._ui.selectedNode
        except:
            return

        if selection == CH_ROOT:
            return self.add_new_chapter(targetNode=selection)

        if selection.startswith(CHAPTER_PREFIX):
            return self.add_new_section(targetNode=selection)

        if selection.startswith(PLOT_LINE_PREFIX):
            return self.add_new_plot_point(targetNode=selection)

        if selection == CR_ROOT:
            return self.add_new_character(targetNode=selection)

        if selection == LC_ROOT:
            return self.add_new_location(targetNode=selection)

        if selection == IT_ROOT:
            return self.add_new_item(targetNode=selection)

        if selection == PL_ROOT:
            return self.add_new_plot_line(targetNode=selection)

        if selection == PN_ROOT:
            return self.add_new_project_note(targetNode=selection)

    def add_new_element(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        try:
            selection = self._ui.selectedNode
        except:
            return

        if selection.startswith(SECTION_PREFIX):
            if self._mdl.novel.sections[selection].scType < 2:
                return self.add_new_section(targetNode=selection)

            return self.add_new_stage(targetNode=selection)

        if CHAPTER_PREFIX in selection:
            return self.add_new_chapter(targetNode=selection)

        if CHARACTER_PREFIX in selection:
            return self.add_new_character(targetNode=selection)

        if LOCATION_PREFIX in selection:
            return self.add_new_location(targetNode=selection)

        if ITEM_PREFIX in selection:
            return self.add_new_item(targetNode=selection)

        if PLOT_LINE_PREFIX in selection:
            return self.add_new_plot_line(targetNode=selection)

        if PRJ_NOTE_PREFIX in selection:
            return self.add_new_project_note(targetNode=selection)

        if selection.startswith(PLOT_POINT_PREFIX):
            return self.add_new_plot_point(targetNode=selection)

    def add_new_item(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_item(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_location(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_location(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_parent(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        try:
            selection = self._ui.selectedNode
        except:
            return

        if selection.startswith(SECTION_PREFIX):
            return self.add_new_chapter(targetNode=selection)

        if selection.startswith(PLOT_POINT_PREFIX):
            return self.add_new_plot_line(targetNode=selection)

    def add_new_part(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_part(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_plot_line(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_plot_line(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_plot_point(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_plot_point(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_project_note(self, **kwargs):
        self._ui.restore_status()
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_project_note(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_section(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_section(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def add_new_stage(self, **kwargs):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.add_new_stage(**kwargs)
        self.view_new_element(newNode)
        return newNode

    def clone_section(self, scId=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if scId is None:
            try:
                scId = self._ui.selectedNode
            except:
                pass
        newNode = self._mdl.clone_section(scId)
        self.view_new_element(newNode)
        return newNode

    def delete_elements(self, elements=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if elements is None:
            try:
                elements = self._ui.selectedNodes
            except:
                return

        if self._ui.tv.tree.prev(elements[0]):
            newSelection = self._ui.tv.tree.prev(elements[0])
        else:
            newSelection = self._ui.tv.tree.parent(elements[0])
        selectAfterDeleting = elements[0]
        deletedChildren = []
        ask = True
        for  elemId in elements:
            if elemId in deletedChildren:
                continue

            if elemId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[elemId].scType < 2:
                    candidate = (
                        _("Section"),
                        self._mdl.novel.sections[elemId].title
                    )
                else:
                    candidate = (
                        _("Stage"),
                        self._mdl.novel.sections[elemId].title
                    )
            elif elemId.startswith(CHAPTER_PREFIX):
                candidate = (
                    _("Chapter"),
                    self._mdl.novel.chapters[elemId].title
                )
            elif elemId.startswith(CHARACTER_PREFIX):
                candidate = (
                    _("Character"),
                    self._mdl.novel.characters[elemId].title
                )
            elif elemId.startswith(LOCATION_PREFIX):
                candidate = (
                    _("Location"),
                    self._mdl.novel.locations[elemId].title
                )
            elif elemId.startswith(ITEM_PREFIX):
                candidate = (
                    _("Item"),
                    self._mdl.novel.items[elemId].title
                )
            elif elemId.startswith(PLOT_LINE_PREFIX):
                candidate = (
                    _("Plot line"),
                    self._mdl.novel.plotLines[elemId].title
                )
            elif elemId.startswith(PLOT_POINT_PREFIX):
                candidate = (
                    _("Plot point"),
                    self._mdl.novel.plotPoints[elemId].title
                )
            elif elemId.startswith(PRJ_NOTE_PREFIX):
                candidate = (
                    _("Project note"),
                    self._mdl.novel.projectNotes[elemId].title
                )
            else:
                return

            elementType, elementTitle = candidate
            if len(elements) == 1:
                if not self._ui.ask_yes_no(
                    message=_('Delete {}?').format(elementType),
                    detail=elementTitle,
                ):
                    return

            elif ask:
                result = self._ui.ask_delete_all_skip_cancel(
                    text=(
                        f"\n\n{_('Delete {}?').format(elementType)}\n\n"
                        f"{elementTitle}\n"
                    ),
                    default=0,
                    title=_('Delete multiple elements'),
                )
                if result == 3:
                    return

                if result == 2:
                    continue

                if result == 1:
                    ask = False
            if (
                elemId.startswith(CHAPTER_PREFIX)
                or elemId.startswith(PLOT_LINE_PREFIX)
            ):
                deletedChildren.extend(
                    self._ui.tv.tree.get_children(elemId)
                )
            self._mdl.delete_element(elemId)
            if elemId == elements[0]:
                selectAfterDeleting = newSelection
        self._ui.tv.go_to_node(selectAfterDeleting)

    def exclude_plot_line(self, plId=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if plId is None:
            plId = self._ui.selectedNode

        if not plId.startswith(PLOT_LINE_PREFIX):
            return

        sections = self._mdl.novel.plotLines[plId].sections
        if sections:
            self._mdl.set_type(1, sections)

    def include_plot_line(self, plId=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if plId is None:
            plId = self._ui.selectedNode

        if not plId.startswith(PLOT_LINE_PREFIX):
            return

        sections = self._mdl.novel.plotLines[plId].sections
        if sections:
            self._mdl.set_type(0, sections)

    def import_elements(self, prefix):
        self._ui.restore_status()
        filePath = filedialog.askopenfilename(
            filetypes=[(_('XML data file'), '.xml')]
        )
        if not filePath:
            return

        try:
            self._ctrl.dataImporter.read_source(filePath, prefix)
        except UserWarning as ex:
            self._ui.set_status(f'#{str(ex)}')
            return

        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')
            return

        sourceElements = {}
        for elemId in self._ctrl.dataImporter.sourceElements:
            sourceElements[
                elemId] = self._ctrl.dataImporter.sourceElements[elemId].title
        if not sourceElements:
            return

        windowTitles = {
            CHARACTER_PREFIX:_('Select characters'),
            LOCATION_PREFIX:_('Select locations'),
            ITEM_PREFIX:_('Select items'),
            PLOT_LINE_PREFIX:_('Select plot lines'),
        }
        PickList(
            self._ui,
            windowTitles[prefix],
            sourceElements,
            self._ctrl.dataImporter.add_elements,
            icon=self._ui.icons.importIcon,
            multiple=True,
        )

    def insert_chapter(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        scId = self._ui.selectedNode
        if not scId.startswith(SECTION_PREFIX):
            return

        if not self._ui.ask_yes_no(
            message=_('Insert a chapter?'),
            detail=f"{_('The following sections will be moved to the new chapter')}.",
        ):
            return

        chId = self._mdl.add_new_chapter(targetNode=scId)

        while self._mdl.novel.tree.next(scId):
            self._mdl.novel.tree.move(
                self._mdl.novel.tree.next(scId),
                chId,
                'end'
            )
        self._ctrl.refresh_tree()
        self._ui.tv.go_to_node(chId)
        self._ui.tv.open_children(chId)

    def join_sections(self, scId0=None, scId1=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if scId0 is None or scId1 is None:
            try:
                scId1 = self._ui.selectedNode
            except:
                return

            if not scId1.startswith(SECTION_PREFIX):
                return

            scId0 = self._ui.tv.prev_node(scId1)
            if not scId0:
                self._ui.show_error(
                    message=_('Cannot join sections'),
                    detail=f"{_('There is no previous section')}.",
                )
                return

        if self._ui.ask_yes_no(
            message=_('Join with previous?'),
            detail=(
                f"{self._mdl.novel.sections[scId0].title} & "
                f"{self._mdl.novel.sections[scId1].title}"
            )
        ):
            try:
                self._mdl.join_sections(scId0, scId1)
            except RuntimeError as ex:
                self._ui.show_error(
                    message=_('Cannot join sections'),
                    detail=str(ex),
                )
                return

            self.view_new_element(scId0)

    def move_node(self, node, targetNode):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if (
            (
                node.startswith(SECTION_PREFIX)
                and targetNode.startswith(CHAPTER_PREFIX)
            )or
            (
                node.startswith(PLOT_POINT_PREFIX)
                and targetNode.startswith(PLOT_LINE_PREFIX)
            )
        ):
            self._ui.tv.open_children(targetNode)
        self._mdl.move_node(node, targetNode)

    def remove_chapter_keep_sections(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        chId = self._ui.selectedNode
        if not chId.startswith(CHAPTER_PREFIX):
            return

        prevChId = self._ui.tv.tree.prev(chId)
        if not prevChId:
            self._ui.set_status(
                f'#{_("Cannot remove the first chapter")}.'
            )
            return

        if not self._ui.ask_yes_no(
            message=_('Remove this chapter?'),
            detail=f"{_('Sections will be moved to the previous chapter')}.",
        ):
            return

        for scId in self._mdl.novel.tree.get_children(chId):
            self._mdl.novel.tree.move(scId, prevChId, 'end')

        self._mdl.novel.chapters[prevChId].desc = (
            f'{self._mdl.novel.chapters[prevChId].desc}\n'
            f'{self._mdl.novel.chapters[chId].desc}'
        )

        if not self._mdl.novel.renumberChapters:
            self._mdl.novel.chapters[prevChId].title = (
                f'{self._mdl.novel.chapters[prevChId].title} & '
                f'{self._mdl.novel.chapters[chId].title}'
            )

        self._mdl.delete_element(chId)
        self._ctrl.refresh_tree()
        self._ui.tv.go_to_node(prevChId)

    def reset_color(self, elemIds=None, prefix=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        validIds = list(elemIds)
        if prefix is not None:
            for elemId in elemIds:
                if not elemId.startswith(prefix):
                    validIds.remove(elemId)
            if not validIds:
                self._ui.set_status(
                    f'#{_("The selection does not contain matching elements")}.'
                )
                return

        self._mdl.set_color(None, validIds)

    def set_character_status(self, isMajor, elemIds=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        if not self._applies_to_character(elemIds):
            self._ui.set_status(
                f'#{_("Cannot set the character status at this position")}.'
            )
            return

        self._ui.tv.open_children(CR_ROOT)
        self._mdl.set_character_status(isMajor, elemIds)

    def set_color(self, title='', elemIds=None, prefix=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        validIds = list(elemIds)
        if prefix is not None:
            for elemId in elemIds:
                if not elemId.startswith(prefix):
                    validIds.remove(elemId)
            if not validIds:
                self._ui.set_status(
                    f'#{_("The selection does not contain matching elements")}.'
                )
                return

        for elemId in validIds:
            color = self._mdl.get_color(elemId)
            if color is not None:
                break

        color = self._ui.choose_color(
            title=title,
            initialcolor=color,
        )
        if color is not None:
            self._mdl.set_color(color, validIds)

    def set_completion_status(self, newStatus, elemIds=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        if not self._applies_to_book(elemIds):
            self._ui.set_status(
                f'#{_("Cannot set the section status at this position")}.'
            )
            return

        self._ui.tv.open_children(elemIds[0])
        self._mdl.set_completion_status(newStatus, elemIds)

    def set_level(self, newLevel, elemIds=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        if not self._applies_to_levelled(elemIds):
            self._ui.set_status(
                f'#{_("Cannot change the level at this position")}.'
            )
            return

        self._mdl.set_level(newLevel, elemIds)

    def set_type(self, newType, elemIds=None):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        if not self._applies_to_book(elemIds):
            self._ui.set_status(
                f'#{_("Cannot set the type at this position")}.'
            )
            return

        self._ui.tv.open_children(elemIds[0])
        self._mdl.set_type(newType, elemIds)

    def set_viewpoint(self, crId=None, elemIds=None):

        def set_vp(crId):
            if crId is None:
                message = _('Clear viewpoints of the selected sections')
                newVp = ''
            else:
                message = _('Assign viewpoint to the selected sections')
                newVp = self._mdl.novel.characters[crId].title
            if self._ui.ask_yes_no(
                message=f'{message}?',
                detail=newVp,
            ):
                self._ui.tv.open_children(elemIds[0])
                self._mdl.set_viewpoint(crId, elemIds)

        def set_selected_vp(crIds):
            crId = crIds[0]
            if crId == '00':
                crId = None
            set_vp(crId)

        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        elemIds = elemIds or self._ui.selectedNodes
        if elemIds is None:
            return

        if not self._applies_to_book(elemIds):
            self._ui.set_status(
                f'#{_("Cannot assign a viewpoint at this position")}.'
            )
            return

        characters = {'00': f"({_('Clear assignment')})"}
        if crId is None:
            for crId in self._mdl.novel.tree.get_children(CR_ROOT):
                characters[crId] = self._mdl.novel.characters[crId].title

            PickList(
                self._ui,
                _('Select viewpoint'),
                characters,
                set_selected_vp,
                icon=self._ui.icons.povIcon,
                multiple=False,
            )
        else:
            set_vp(crId)

    def view_new_element(self, newNode):
        if newNode:
            self._ui.tv.go_to_node(newNode)
            self._ui.propertiesView.show_properties(newNode)
            self._ui.propertiesView.focus_title()
        else:
            self._ui.set_status(
                f'#{_("Cannot create the element at this position")}.'
            )

    def _applies_to_book(self, elemIds):
        for elemId in elemIds:
            if (
                elemId.startswith(SECTION_PREFIX)
                or elemId.startswith(CHAPTER_PREFIX)
                or elemId.startswith(CH_ROOT)
            ):
                return True

        return False

    def _applies_to_levelled(self, elemIds):
        for elemId in elemIds:
            if elemId.startswith(CHAPTER_PREFIX):
                return True

            if (
                elemId.startswith(SECTION_PREFIX)
                and self._mdl.novel.sections[elemId].scType > 1
            ):
                return True

        return False

        return False

    def _applies_to_character(self, elemIds):
        for elemId in elemIds:
            if (
                elemId.startswith(CR_ROOT)
                or elemId.startswith(CHARACTER_PREFIX)
            ):
                return True

        return False

from shutil import copy2
from tkinter import filedialog

from datetime import datetime




class ExportTargetFactory(FileFactory):

    def new_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        suffix = kwargs['suffix']
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX == suffix:
                if suffix is None:
                    suffix = ''
                targetFile = fileClass(
                    f'{fileName}{suffix}{fileClass.EXTENSION}',
                    **kwargs
                )
                return None, targetFile

        raise RuntimeError(
            f'{_("Export type is not supported")}: "{suffix}".'
        )


class ChChFilter(Filter):

    def __init__(self, chId):
        self._chId = chId

    def accept(self, source, chId):
        if chId == self._chId:
            return True

        return False



class ChPlFilter(Filter):

    def __init__(self, plId):
        self._plId = plId

    def accept(self, source, chId):
        for scId in source.novel.tree.get_children(chId):
            try:
                if self._plId in source.novel.sections[scId].scPlotLines:
                    return True

            except:
                pass
        return False

    def get_message(self, source):
        return (
            f'{_("Chapters belonging to plot line")}: '
            f'"{source.novel.plotLines[self._plId].title}"'
        )


class ChVpFilter(Filter):

    def __init__(self, crId):
        self._crId = crId

    def accept(self, source, chId):
        for scId in source.novel.tree.get_children(chId):
            try:
                if self._crId == source.novel.sections[scId].viewpoint:
                    return True

            except:
                pass
        return False

    def get_message(self, source):
        return (
            f'{_("Chapters from viewpoint")}: '
            f'{source.novel.characters[self._crId].title}'
        )


class ScPlFilter(Filter):

    def __init__(self, plId):
        self._plId = plId

    def accept(self, source, scId):
        try:
            if self._plId in source.novel.sections[scId].scPlotLines:
                return True

        except:
            pass
        return False

    def get_message(self, source):
        return (
            f'{_("Sections belonging to plot line")}: '
            f'"{source.novel.plotLines[self._plId].title}"'
        )


class ScVpFilter(Filter):

    def __init__(self, crId):
        self._crId = crId

    def accept(self, source, scId):
        try:
            if self._crId == source.novel.sections[scId].viewpoint:
                return True

        except:
            pass
        return False

    def get_message(self, source):
        return (
            f'{_("Sections from viewpoint")}: '
            f'{source.novel.characters[self._crId].title}'
        )


class FilterFactory:

    @staticmethod
    def get_section_filter(filterElementId):
        if filterElementId.startswith(CHARACTER_PREFIX):
            return ScVpFilter(filterElementId)

        if filterElementId.startswith(PLOT_LINE_PREFIX):
            return ScPlFilter(filterElementId)

        return Filter()

    @staticmethod
    def get_chapter_filter(filterElementId):
        if filterElementId.startswith(CHARACTER_PREFIX):
            return ChVpFilter(filterElementId)

        if filterElementId.startswith(CHAPTER_PREFIX):
            return ChChFilter(filterElementId)

        if filterElementId.startswith(PLOT_LINE_PREFIX):
            return ChPlFilter(filterElementId)

        return Filter()


class NvDocExporter(NovxConversion):

    def __init__(self, ui):
        self._ui = ui
        self.exportTargetFactory = ExportTargetFactory(
            self.EXPORT_TARGET_CLASSES
        )
        self._source = None
        self._target = None

    def run(self, source, suffix, **kwargs):
        filterElementId = kwargs.get('filter', '')

        self._source = source
        self._isNewer = False
        __, self._target = self.exportTargetFactory.new_file_objects(
            self._source.filePath,
            suffix=suffix,
        )

        if kwargs.get('doNotExport', False):
            return self._open_document_if_up_to_date()

        if os.path.isfile(USER_STYLES_XML):
            self._target.userStylesXml = USER_STYLES_XML

        if (
            os.path.isfile(self._target.filePath)
            and not kwargs.get('overwrite', False)
        ):
            targetTimestamp = os.path.getmtime(self._target.filePath)
            targetIsUpToDate = False
            try:
                if  targetTimestamp > self._source.timestamp:
                    timeStatus = _('Newer than the project file')
                    targetIsUpToDate = True
                    defaultChoice = 1
                else:
                    timeStatus = _('Older than the project file')
                    defaultChoice = 0
            except Exception:
                timeStatus = ''
                defaultChoice = 0
            self._targetFileDate = datetime.fromtimestamp(
                targetTimestamp).strftime('%c')
            message = (
                '\n\n'
                f'{_("{} already exists.").format(self._target.DESCRIPTION)}\n'
                f'{_("Last saved on")} {self._targetFileDate}.\n'
                f'{timeStatus}.\n\n'
                f'{_("Open this document instead of overwriting it?")}\n\n'
            )
            result = self._ui.ask_overwrite_open_cancel(
                text=message,
                default=defaultChoice,
                title=_('Export document')
            )
            if result == 2:
                raise UserWarning(f'{_("Action canceled by user")}.')

            elif result == 1:
                return self._open_existing_document(targetIsUpToDate)

        self._target.sectionFilter = FilterFactory.get_section_filter(
            filterElementId
        )
        self._target.chapterFilter = FilterFactory.get_chapter_filter(
            filterElementId
        )
        self._target.novel = self._source.novel
        self._target.write()
        self._targetFileDate = datetime.now().replace(
            microsecond=0
        ).isoformat(sep=' ')
        if kwargs.get('show', True):
            if(
                not kwargs.get('ask', True)
                or not prefs['ask_doc_open']
                or self._ui.ask_yes_no(
                    message=_('Open the created document?'),
                    detail=(
                        f"{self._target.novel.title} - "
                        f"{norm_path(self._target.DESCRIPTION)}"
                    )
                )
            ):
                open_document(self._target.filePath)
        return _('Created {0} on {1}.').format(
            self._target.DESCRIPTION,
            self._targetFileDate
        )

    def _open_existing_document(self, isUpToDate):
        open_document(self._target.filePath)
        if isUpToDate:
            prefix = ''
        else:
            prefix = '#'
        fileData = _("Opened existing {0} (last saved on {1})").format(
            self._target.DESCRIPTION,
            self._targetFileDate
        )
        return f'{prefix}{fileData}.'

    def _open_document_if_up_to_date(self):
        if os.path.isfile(self._target.filePath):
            targetTimestamp = os.path.getmtime(self._target.filePath)
            if  targetTimestamp > self._source.timestamp:
                self._targetFileDate = datetime.fromtimestamp(
                    targetTimestamp).strftime('%c')
                return self._open_existing_document(True)

            else:
                message = _('{0} is not up to date.').format(
                    self._target.DESCRIPTION)
        else:
            message = _('{0} does not exist.').format(
                self._target.DESCRIPTION)
        return f'!{message}'

from xml import sax



class HtmlReport(FileExport):
    DESCRIPTION = 'HTML report'
    EXTENSION = '.html'
    SUFFIX = '_report'

    _fileHeader = (
        '<!DOCTYPE html>\n'
        '<html>\n'
        '<head>\n'
        '<meta http-equiv="Content-Type" content="text/html; '
        'charset=utf-8"/>\n\n'
        '<style type="text/css">\n'
        'body {font-family: sans-serif}\n'
        'p.title {font-size: larger; font-weight: bold}\n'
        'table, td {vertical-align: top}\n'
        'td {'
        'padding: 10;'
        'padding-right: 0.5em; '
        'padding-left: 0.5em; '
        '}\n'
        '</style>\n'
    )

    _fileFooter = (
        '</body>\n'
        '</html>\n'
    )

    def _convert_from_novx(self, text, quick=False, **kwargs):
        if not text:
            return ''

        text = text.rstrip()
        entities = {
            "'": '&apos;',
            '"': '&quot;',
        }
        text = sax.saxutils.escape(text, entities=entities)
        if quick:
            return text.replace('\n', ' ')

        newlines = []
        for line in text.split('\n'):
            newlines.append(f'<p>{line}</p>')
        return '\n'.join(newlines)

    def _new_cell(self, text, attr=''):
        return f'<td {attr}>{self._convert_from_novx(text)}</td>'



class HtmlBoard(HtmlReport):

    _extraStyles = (
        '<style type="text/css">\n'
        'body {background-color: #dfdfdf}\n'
        '<style type="text/css">\n'
        'table, td {'
        'border:0px solid transparent; '
        '}\n'
        'table {border-spacing:1em 0px;} '
        'td {'
        'table-layout:fixed; width:15em; overflow:hidden; '
        'word-wrap:break-word; '
        'min-width:15em; max-widh:15em; '
        '}\n'
        '</style>\n'
    )
    _fileHeader = f'{HtmlReport._fileHeader}{_extraStyles}'

    def _get_card_header_styles(
        self,
        elements,
        defaultBorderColor='#ffffff',
        invert=False,
    ):

        BLACK = '#000000'
        WHITE = '#ffffff'
        htmlText = []
        htmlText.append('<style type="text/css">')
        for elemId in elements:
            elemColor = elements[elemId].color
            fgColor = BLACK
            bgColor = WHITE
            borderColor = elemColor or defaultBorderColor
            if invert:
                bgColor = elemColor or BLACK
                if HexColor.is_dark(bgColor):
                    fgColor = WHITE
                borderColor = bgColor
            htmlText.append(
                f'td.h{elemId} {{'
                'font-weight: bold; '
                f'border-top: 0.2em solid {borderColor}; '
                f'border-right: 0.2em solid {borderColor}; '
                f'border-left: 0.2em solid {borderColor}; '
                f'background: {bgColor}; '
                f'color: {fgColor}'
                '}'
            )
        htmlText.append(
            '</style>\n'
        )
        return htmlText

    def _get_card_body_styles(self, elements, defaultBorderColor='#ffffff'):

        htmlText = []
        htmlText.append('<style type="text/css">')
        for elemId in elements:
            elemColor = elements[elemId].color
            if elemColor is not None:
                borderColor = elemColor
            else:
                borderColor = defaultBorderColor
            htmlText.append(
                f'td.{elemId} {{'
                f'border-top: 0.1em solid #ff0000; '
                f'border-right: 0.2em solid {borderColor}; '
                f'border-left: 0.2em solid {borderColor}; '
                f'border-bottom: 0.2em solid {borderColor}; '
                'background: #ffffff; '
                '}'
            )
        htmlText.append(
            '</style>\n'
        )
        return htmlText



class HtmlChapterBoard(HtmlBoard):
    DESCRIPTION = _('HTML Chapter board')
    SUFFIX = CHAPTER_BOARD_SUFFFIX

    def write(self):

        srtChapters = {}
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chType == 0:
                srtChapters[chId] = self.novel.chapters[chId]

        if not srtChapters:
            raise UserWarning(f'{_("No chapters found")}.')

        htmlText = [self._fileHeader]

        htmlText.extend(
            self._get_card_header_styles(srtChapters, invert=True)
        )
        htmlText.extend(self._get_card_body_styles(srtChapters))

        sections = {}
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                sections[scId] = self.novel.sections[scId]
        htmlText.extend(self._get_card_header_styles(sections))
        htmlText.extend(self._get_card_body_styles(sections))

        htmlText.append(
            f'<title>{_("Chapter board")} ({self.novel.title})</title>\n'
            '</head>\n'
            '<body>\n'
            f'<p class=title>{self.novel.title} - {_("Chapter board")}</p>\n'
            '<table>\n'
        )

        for chId in srtChapters:
            htmlText.append('<tr>')
            htmlText.append(
                self._new_cell(
                    srtChapters[chId].title,
                    attr=f'class="h{chId}"',
                )
            )
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    htmlText.append(
                        self._new_cell(
                            self.novel.sections[scId].title,
                            attr=f'class="h{scId}"',
                        )
                    )
            htmlText.append('</tr>')
            htmlText.append('<tr>')
            htmlText.append(
                self._new_cell(
                    srtChapters[chId].desc,
                    attr=f'class="{chId}"',
                )
            )
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    htmlText.append(
                        self._new_cell(
                            self.novel.sections[scId].desc,
                            attr=f'class="{scId}"',
                        )
                    )
            htmlText.append('</tr>')
            htmlText.append(f'<tr>')
            htmlText.append('<td><br></td></tr>')
        htmlText.append('</table>')
        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))



class HtmlTable(HtmlReport):

    _extraStyles = (
        '<style type="text/css">\n'
        'tr.heading {'
        'font-size:smaller; font-weight: bold; '
        'background-color:#f0f0f0'
        '}\n'
        'table {border-spacing: 0}\n'
        'table, td {'
        'border: #f0f0f0 solid 1px; '
        '}\n'
        'td.title {font-weight: bold}\n'
        'td.chaptertitle {color: green; font-weight: bold}\n'
        'td.chapter {color: green}\n'
        'td.parttitle {'
        'color: white; '
        'background-color: green; '
        'font-weight: bold; '
        '}\n'
        'td.part {color: white; background-color: green}\n'
        'td.stage {color: red}\n'
        'td.stagetitle {color: red; font-weight: bold}\n'
        '</style>\n'
    )
    _fileHeader = f'{HtmlReport._fileHeader}{_extraStyles}'
    _fileFooter = (
        '</table>\n'
        '</body>\n'
        '</html>\n'
    )

    def _get_extra_styles(self, elements):

        DEFAULT_COLOR = '#ffffff'

        htmlText = ['<style type="text/css">']
        for elemId in elements:
            elemColor = elements[elemId].color
            if elemColor is not None:
                bgColor = elemColor
            else:
                bgColor = DEFAULT_COLOR
            htmlText.append(
                f'td.{elemId} {{'
                'font-weight: bold; '
                f'border-left: 0.5em solid {bgColor}'
                '}'
            )
        htmlText.append('</style>\n')
        return htmlText

    def _get_plot_line_styles(self):

        NODE_BACKGROUND = '#dfdfdf'
        NODE_FOREGROUND = BLACK = '#000000'
        WHITE = '#ffffff'
        DEFAULT_PL_COLOR = BLACK

        htmlText = ['<style type="text/css">']
        for plId in self.novel.plotLines:
            plColor = self.novel.plotLines[plId].color or DEFAULT_PL_COLOR
            if HexColor.is_dark(plColor):
                fgColor = WHITE
            else:
                fgColor = BLACK
            bgColor = plColor

            htmlText.append(
                f'td.h{plId} {{'
                f'background: {bgColor}; '
                f'color: {fgColor}'
                '}'
            )

            htmlText.append(
                f'td.{plId} {{'
                f'border-left: 0.5em solid {bgColor}; '
                f'background: {NODE_BACKGROUND}; '
                f'color: {NODE_FOREGROUND}'
                '}'
            )
        htmlText.append(
            '</style>\n'
        )
        return htmlText



class HtmlCharacters(HtmlTable):
    DESCRIPTION = 'HTML charcters report'
    EXTENSION = '.html'
    SUFFIX = CHARACTER_REPORT_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}$Styles'
        f'<title>{_("Characters")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - '
        f'{_("Characters")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td class="chtitle">{_("Name")}</td>\n'
        f'<td>{_("Full name")}</td>\n'
        f'<td>{_("AKA")}</td>\n'
        f'<td>{_("Tags")}</td>\n'
        f'<td>{_("Description")}</td>\n'
        '<td>$CharacterField1</td>\n'
        '<td>$CharacterField2</td>\n'
        f'<td>{_("Birth date")}</td>\n'
        f'<td>{_("Death date")}</td>\n'
        f'<td>{_("Notes")}</td>\n'
        '</tr>\n'
    )
    _characterTemplate = (
        '<tr>\n'
        '<td class="$ID"><p>$Title</p></td>\n'
        '<td><p>$FullName</p></td>\n'
        '<td><p>$AKA</p></td>\n'
        '<td><p>$Tags</p></td>\n'
        '<td>$Desc</td>\n'
        '<td>$Bio</td>\n'
        '<td>$Goals</td>\n'
        '<td><p>$BirthDate</p></td>\n'
        '<td><p>$DeathDate</p></td>\n'
        '<td>$Notes</td>\n'
        '</tr>\n'
    )

    def write(self):
        if not self.novel.characters:
            raise UserWarning(f'{_("No characters found")}.')
        super().write()

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = '\n'.join(
            self._get_extra_styles(self.novel.characters)
        )
        return fileHeaderMapping

    def _get_characterMapping(self, crId):
        characterMapping = super()._get_characterMapping(crId)
        if self.localizeDate:
            try:
                characterMapping['BirthDate'] = PyCalendar.locale_date(
                    characterMapping['BirthDate']
                )
            except:
                pass
            try:
                characterMapping['DeathDate'] = PyCalendar.locale_date(
                    characterMapping['DeathDate']
                )
            except:
                pass
        return characterMapping


class HtmlElementNotes(HtmlTable):
    DESCRIPTION = 'HTML element notes report'
    EXTENSION = '.html'
    SUFFIX = ELEMENT_NOTES_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}\n'
        f'<title>{_("Notes")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - {_("Notes")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td class="chtitle">{_("Title")}</td>\n'
        f'<td>{_("Text")}</td>\n'
        '</tr>\n'
    )
    _characterHeadingTemplate = (
        '<tr class="heading">\n'
        f'<td>{_("Characters")}</td>\n'
        '<td>\n'
        '</tr>\n'
    )
    _locationHeadingTemplate = (
        '<tr class="heading">\n'
        f'<td>{_("Locations")}</td>\n'
        '<td>\n'
        '</tr>\n'
    )
    _itemHeadingTemplate = (
        '<tr class="heading">\n'
        f'<td>{_("Items")}</td>\n'
        '<td>\n'
        '</tr>\n'
    )
    _plotLineHeadingTemplate = (
        '<tr class="heading">\n'
        f'<td>{_("Plot lines")}</td>\n'
        '<td>\n'
        '</tr>\n'
    )
    _partTemplate = (
        '<tr>\n'
        '<td class="parttitle"><p>$Title</p></td>\n'
        '<td class="part">$Notes</td>\n'
        '</tr>\n'
    )
    _chapterTemplate = (
        '<tr>\n'
        '<td class="chaptertitle"><p>$Title</p></td>\n'
        '<td class="chapter">$Notes</td>\n'
        '</tr>\n'
    )
    __plotLineTemplate = (
        '<tr>\n'
        '<td class="title"><p>$Title</p></td>\n'
        '<td>$Notes</td>\n'
        '</tr>\n'
    )
    _sectionTemplate = _characterTemplate = _locationTemplate = \
    _itemTemplate = _plotPointTemplate = (
        '<tr>\n'
        '<td><p>$Title</p></td>\n'
        '<td>$Notes</td>\n'
        '</tr>\n'
    )
    _stage1Template = (
        '<tr>\n'
        '<td class="stagetitle"><p>$Title</p></td>\n'
        '<td class="stage">$Notes</td>\n'
        '</tr>\n'
    )
    _stage2Template = (
        '<tr>\n'
        '<td class="stage"><p>$Title</p></td>\n'
        '<td class="stage">$Notes</td>\n'
        '</tr>\n'
    )


class HtmlItems(HtmlTable):
    DESCRIPTION = 'HTML items report'
    EXTENSION = '.html'
    SUFFIX = ITEM_REPORT_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}$Styles'
        f'<title>{_("Items")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - {_("Items")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td class="chtitle">{_("Name")}</td>\n'
        f'<td>{_("AKA")}</td>\n'
        f'<td>{_("Tags")}</td>\n'
        f'<td>{_("Description")}</td>\n'
        '</tr>\n'
    )
    _itemTemplate = (
        '<tr>\n'
        '<td class="$ID"><p>$Title</p></td>\n'
        '<td><p>$AKA</p></td>\n'
        '<td><p>$Tags</p></td>\n'
        '<td>$Desc</td>\n'
        '</tr>\n'
    )

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = '\n'.join(
            self._get_extra_styles(self.novel.items)
        )
        return fileHeaderMapping

    def write(self):
        if not self.novel.items:
            raise UserWarning(f'{_("No items found")}.')
        super().write()


class HtmlLocations(HtmlTable):
    DESCRIPTION = 'HTML locations report'
    EXTENSION = '.html'
    SUFFIX = LOCATION_REPORT_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}$Styles'
        f'<title>{_("Locations")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - '
        f'{_("Locations")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td class="chtitle">{_("Name")}</td>\n'
        f'<td>{_("AKA")}</td>\n'
        f'<td>{_("Tags")}</td>\n'
        f'<td>{_("Description")}</td>\n'
        '</tr>\n'
    )
    _locationTemplate = (
        '<tr>\n'
        '<td class="$ID"><p>$Title</p></td>\n'
        '<td><p>$AKA</p></td>\n'
        '<td><p>$Tags</p></td>\n'
        '<td>$Desc</td>\n'
        '</tr>\n'
    )

    def write(self):
        if not self.novel.locations:
            raise UserWarning(f'{_("No locations found")}.')
        super().write()

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = '\n'.join(
            self._get_extra_styles(self.novel.locations)
        )
        return fileHeaderMapping


class HtmlPlotList(HtmlTable):
    DESCRIPTION = _('HTML Plot table')
    SUFFIX = PLOTLIST_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}$Styles'
        f'<title>{_("Plot lines")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - '
        f'{_("Plot lines")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td>{_("Title")}</td>\n'
        '$PlotlineCells\n'
        '</tr>\n'
    )
    _sectionTemplate = (
        '<tr>\n'
        '<td class="$ID"><p>$Title</p></td>\n'
        '$PlotlineCells\n'
        '</tr>\n'
    )

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()

        fileHeaderMapping['PlotlineCells'] = '\n'.join([
            f'<td class="h{plId}"><p>{self.novel.plotLines[plId].title}</p></td>\n'
            for plId in self.novel.tree.get_children(PL_ROOT)
        ])
        extraStyles = self._get_extra_styles(self.novel.sections)
        extraStyles.extend(self._get_plot_line_styles())
        fileHeaderMapping['Styles'] = '\n'.join(extraStyles)
        return fileHeaderMapping

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter=False,
            isEpigraph=False,
    ):
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter,
            isEpigraph,
        )

        plotlineCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            if scId in self.novel.plotLines[plId].sections:
                attr = f' class="{plId}"'
                plotPoints = []
                for ppId in self.novel.tree.get_children(plId):
                    if (
                        scId ==
                        self.novel.plotPoints[ppId].sectionAssoc
                    ):
                        plotPoints.append(
                            self.novel.plotPoints[ppId].title
                        )
                plotPointTitles = list_to_string(
                    plotPoints,
                    divider=self._DIVIDER
                )
            else:
                attr = ''
                plotPointTitles = ''
            plotlineCells.append(
                f'<td{attr}><p>{plotPointTitles}</p></td>\n'
            )
        sectionMapping['PlotlineCells'] = '\n'.join(plotlineCells)
        return sectionMapping



class HtmlGrid(HtmlPlotList):
    DESCRIPTION = f"HTML {_('Plot grid')}"
    SUFFIX = GRID_REPORT_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}$Styles'
        f'<title>{_("Plot grid")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - '
        f'{_("Plot grid")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td>{_("Date")}</td>\n'
        f'<td>{_("Time")}</td>\n'
        f'<td>{_("Duration")}</td>\n'
        f'<td>{_("Title")}</td>\n'
        f'<td>{_("Description")}</td>\n'
        f'<td>{_("Viewpoint")}</td>\n'
        '$PlotlineCells\n'
        f'<td>{_("Tags")}</td>\n'
        f'<td>{_("Scene")}</td>\n'
        f'<td>$NotASceneField1 / {_("Goal")} / {_("Reaction")} / $OtherSceneField1</td>\n'
        f'<td>$NotASceneField2 / {_("Conflict")} / {_("Dilemma")} / $OtherSceneField2</td>\n'
        f'<td>$NotASceneField3 / {_("Outcome")} / {_("Choice")} / $OtherSceneField3</td>\n'
        f'<td>{_("Notes")}</td>\n'
        '</tr>\n'
    )
    _sectionTemplate = _epigraphTemplate = (
        '<tr>\n'
        '<td><p>$ScDate</p></td>\n'
        '<td><p>$Time</p></td>\n'
        '<td><p>$Duration</p></td>\n'
        '<td class="$ID"><p>$Title</p></td>\n'
        '<td>$Desc</td>\n'
        '<td style="border-left: 0.5em solid $VpColor">$Viewpoint</td>\n'
        '$PlotlineCells\n'
        '<td><p>$Tags</p></td>\n'
        '<td><p>$Scene</p></td>\n'
        '<td>$Goal</td>\n'
        '<td>$Conflict</td>\n'
        '<td>$Outcome</td>\n'
        '<td>$Notes</td>\n'
        '</tr>\n'
    )

    def _get_sectionMapping(
            self,
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter=False,
            isEpigraph=False,
    ):
        sectionMapping = super()._get_sectionMapping(
            scId,
            sectionNumber,
            wordsTotal,
            firstInChapter,
            isEpigraph,
        )
        crId = self.novel.sections[scId].viewpoint
        if crId is not None:
            vpColor = self.novel.characters[crId].color or '#ffffff'
        else:
            vpColor = '#ffffff'
        sectionMapping['VpColor'] = vpColor

        plotlineCells = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            if scId in self.novel.plotLines[plId].sections:
                attr = f' class="{plId}"'
            else:
                attr = ''
            plotlineNotes = self.novel.sections[scId].plotlineNotes
            if plotlineNotes:
                plotlineNote = plotlineNotes.get(plId, '')
            else:
                plotlineNote = ''
            plotlineCells.append(
                f'<td{attr}>{plotlineNote}</td>\n'
            )
        sectionMapping['PlotlineCells'] = '\n'.join(plotlineCells)

        return sectionMapping



class HtmlPlotLineBoard(HtmlBoard):
    DESCRIPTION = _('HTML Plot line board')
    SUFFIX = PLOT_LINE_BOARD_SUFFIX

    def write(self):

        srtPlotLines = self.novel.tree.get_children(PL_ROOT)
        if not srtPlotLines:
            raise UserWarning(f'{_("No plot lines found")}.')

        htmlText = [self._fileHeader]

        htmlText.extend(
            self._get_card_header_styles(
                self.novel.plotLines,
                invert=True,
            )
        )
        htmlText.extend(self._get_card_body_styles(self.novel.plotLines))

        htmlText.extend(self._get_card_header_styles(self.novel.plotPoints))
        htmlText.extend(self._get_card_body_styles(self.novel.plotPoints))

        htmlText.append(
            f'<title>{_("Plot line board")} ({self.novel.title})</title>\n'
            '</head>\n'
            '<body>\n'
            f'<p class=title>{self.novel.title} - {_("Plot line board")}</p>\n'
            '<table>\n'
        )

        for plId in srtPlotLines:
            htmlText.append('<tr>')
            htmlText.append(
                self._new_cell(
                    self.novel.plotLines[plId].title,
                    attr=f'class="h{plId}"',
                )
            )
            for ppId in self.novel.tree.get_children(plId):
                htmlText.append(
                    self._new_cell(
                        self.novel.plotPoints[ppId].title,
                        attr=f'class="h{ppId}"',
                    )
                )
            htmlText.append('</tr>')
            htmlText.append('<tr>')
            htmlText.append(
                self._new_cell(
                    self.novel.plotLines[plId].desc,
                    attr=f'class="{plId}"',
                )
            )
            for ppId in self.novel.tree.get_children(plId):
                htmlText.append(
                    self._new_cell(
                        self.novel.plotPoints[ppId].desc,
                        attr=f'class="{ppId}"',
                    )
                )
            htmlText.append('</tr>')
            htmlText.append(f'<tr>')
            htmlText.append('<td><br></td></tr>')
        htmlText.append('</table>')
        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))



class HtmlProjectNotes(HtmlTable):
    DESCRIPTION = 'HTML project notes report'
    EXTENSION = '.html'
    SUFFIX = PROJECTNOTES_REPORT_SUFFIX

    _fileHeader = (
        f'{HtmlTable._fileHeader}$Styles'
        f'<title>{_("Project notes")} ($Title)</title>\n'
        '</head>\n'
        '<body>\n'
        f'<p class=title>$Title {_("by")} $AuthorName - '
        f'{_("Project notes")}</p>\n'
        '<table>\n'
        '<tr class="heading">\n'
        f'<td class="chtitle">{_("Title")}</td>\n'
        f'<td>{_("Text")}</td>\n'
        '</tr>\n'
    )

    _projectNoteTemplate = (
        '<tr>\n'
        '<td class="$ID"><p>$Title</p></td>\n'
        '<td>$Desc</td>\n'
        '</tr>\n'
    )

    def write(self):
        if not self.novel.projectNotes:
            raise UserWarning(f'{_("No project notes found")}.')
        super().write()

    def _get_fileHeaderMapping(self):
        fileHeaderMapping = super()._get_fileHeaderMapping()
        fileHeaderMapping['Styles'] = '\n'.join(
            self._get_extra_styles(self.novel.projectNotes)
        )
        return fileHeaderMapping


class HtmlStoryStructureBoard(HtmlBoard):
    DESCRIPTION = _('HTML Story structure board')
    SUFFIX = STORY_STRUCT_BOARD_SUFFIX

    def write(self):

        stageId = NO_STAGE = ''
        stageTree = {stageId:[]}
        srtStages = {}
        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                section = self.novel.sections[scId]
                if section.scType > 1:
                    stageId = scId
                    srtStages[stageId] = self.novel.sections[scId]
                    stageTree[stageId] = []
                elif section.scType == 0:
                    stageTree[stageId].append(scId)

        if not srtStages:
            raise UserWarning(f'{_("No stages found")}.')

        htmlText = [self._fileHeader]

        stageColor = '#FF0000'
        if HexColor.is_dark(stageColor):
            fgColor = '#FFFFFF'
        else:
            fgColor = '#000000'
        borderColor = '#FFFFFF'
        htmlText.append(
            '<style type="text/css">\n'
            'td.hstage {'
            'font-weight: bold; '
            f'border-top: 0.2em solid {stageColor}; '
            f'border-right: 0.2em solid {stageColor}; '
            f'border-left: 0.2em solid {stageColor}; '
            f'border-bottom: 0.1em solid #ff0000; '
            f'background: {stageColor}; '
            f'color: {fgColor}'
            '}\n'
            f'td.stage1 {{'
            f'border-right: 0.2em solid {stageColor}; '
            f'border-left: 0.2em solid {stageColor}; '
            f'border-bottom: 0.2em solid {stageColor}; '
            'background: #ffffff; '
            '}\n'
            f'td.stage2 {{'
            f'border-right: 0.2em solid {borderColor}; '
            f'border-left: 0.2em solid {borderColor}; '
            f'border-bottom: 0.2em solid {borderColor}; '
            'background: #ffffff; '
            '}\n'
            '</style>\n'
        )

        sections = {}
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                sections[scId] = self.novel.sections[scId]
        htmlText.extend(self._get_card_header_styles(sections))
        htmlText.extend(self._get_card_body_styles(sections))

        htmlText.append(
            f'<title>{_("Story structure board")} ({self.novel.title})</title>\n'
            '</head>\n'
            '<body>\n'
            f'<p class=title>{self.novel.title} - {_("Story structure board")}</p>\n'
            '<table>\n'
        )

        for stageId in stageTree:
            htmlText.append('<tr>')
            if stageId == NO_STAGE:
                htmlText.append('<td>')
            else:
                if self.novel.sections[stageId].scType == 2:
                    style = 'stage1'
                else:
                    style = 'stage2'
                htmlText.append(
                    self._new_cell(
                        self.novel.sections[stageId].title,
                        attr='class="hstage"',
                    )
                )
            for scId in stageTree[stageId]:
                htmlText.append(
                    self._new_cell(
                        self.novel.sections[scId].title,
                        attr=f'class="h{scId}"',
                    )
                )
            htmlText.append('</tr>')
            htmlText.append('<tr>')
            if stageId == NO_STAGE:
                htmlText.append('<td>')
            else:
                htmlText.append(
                    self._new_cell(
                        self.novel.sections[stageId].desc,
                        attr=f'class="{style}"',
                    )
                )
            for scId in stageTree[stageId]:
                htmlText.append(
                    self._new_cell(
                        self.novel.sections[scId].desc,
                        attr=f'class="{scId}"',
                    )
                )
            htmlText.append('</tr>')
            htmlText.append(f'<tr>')
            htmlText.append('<td><br></td></tr>')
        htmlText.append('</table>')
        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))



class HtmlTimetable(HtmlTable):
    DESCRIPTION = _('HTML Time table')
    SUFFIX = TIMETABLE_SUFFIX

    def write(self):

        srtSections = self._sort_sections_by_date()
        if not srtSections:
            raise UserWarning(f'{_("No date/time data found")}.')

        htmlText = [self._fileHeader]
        htmlText.extend(self._get_plot_line_styles())

        htmlText.append(
            f'<title>{_("Time table")} ({self.novel.title})</title>\n'
            '</head>\n'
            '<body>\n'
            f'<p class=title>{self.novel.title} {_("by")} '
            f'{self.novel.authorName} - {_("Time table")}</p>\n'
            '<table>'
        )

        htmlText.append('<tr class="heading">')
        htmlText.append(self._new_cell(_('Date')))
        htmlText.append(self._new_cell(_('Time')))
        htmlText.append(self._new_cell(_('Section')))
        htmlText.append(self._new_cell(_('Description')))
        htmlText.append(self._new_cell(_('Duration')))
        htmlText.append(self._new_cell(_('Viewpoint')))
        htmlText.append(self._new_cell(_('Characters')))
        htmlText.append(self._new_cell(_('Locations')))
        htmlText.append(self._new_cell(_('Items')))
        plotLines = self.novel.tree.get_children(PL_ROOT)
        for plId in plotLines:
            htmlText.append(
                self._new_cell(
                    self.novel.plotLines[plId].title,
                    attr=f'class="h{plId}"',
                )
            )
        htmlText.append('</tr>')

        currentDateDayStr = ''
        for timestamp, scIds in srtSections:
            for scId in scIds:
                htmlText.append(f'<tr>')
                dateDayStr = (
                    f'{self._get_date_day_str(scId)} '
                    f'{self._get_week_day_str(scId, timestamp)}'
                )
                if dateDayStr != currentDateDayStr:
                    currentDateDayStr = dateDayStr
                else:
                    dateDayStr = ''
                htmlText.append(
                    self._new_cell(
                        dateDayStr
                    )
                )
                htmlText.append(
                    self._new_cell(
                        self._get_time_str(scId)
                    )
                )
                section = self.novel.sections[scId]
                color = section.color or '#ffffff'
                htmlText.append(
                    self._new_cell(
                        section.title,
                        attr=f'style="border-left: 0.5em solid {color}"'
                    )
                )
                htmlText.append(self._new_cell(section.desc))
                htmlText.append(
                    self._new_cell(PyCalendar.get_duration_str(section))
                )
                crId = self.novel.sections[scId].viewpoint
                if crId is not None:
                    vp = self.novel.characters[crId]
                    vpTitle = vp.title
                    color = vp.color or '#ffffff'
                    style = f'style="border-left: 0.5em solid {color}"'
                else:
                    vpTitle = ''
                    style = ''
                htmlText.append(self._new_cell(vpTitle, attr=style))
                htmlText.append(
                    self._new_cell(
                        self._get_relations_str(
                            section.characters,
                            self.novel.characters
                        )
                    )
                )
                htmlText.append(
                    self._new_cell(
                        self._get_relations_str(
                            section.locations,
                            self.novel.locations
                        )
                    )
                )
                htmlText.append(
                    self._new_cell(
                        self._get_relations_str(
                            section.items,
                            self.novel.items
                        )
                    )
                )
                for plId in plotLines:
                    if scId in self.novel.plotLines[plId].sections:
                        plNotes = self.novel.sections[scId].plotlineNotes.get(
                            plId,
                            ''
                        )
                        htmlText.append(
                            self._new_cell(
                                plNotes,
                                attr=f'class="{plId}"',
                            )
                        )
                    else:
                        htmlText.append(self._new_cell(''))
                htmlText.append(f'</tr>')
        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))

    def _get_date_day_str(self, scId):
        if (
            self.novel.sections[scId].date is not None
            and self.novel.sections[scId].date != Section.NULL_DATE
        ):
            dateDayStr = self.novel.sections[scId].localeDate
        else:
            if self.novel.sections[scId].day is not None:
                dateDayStr = f'{_("Day")} {self.novel.sections[scId].day}'
            else:
                dateDayStr = ''
        return dateDayStr

    def _get_relations_str(self, relations, elements):
        elementTitles = []
        for elemId in relations:
            elementTitles.append(elements[elemId].title)
        return list_to_string(
            elementTitles,
            divider=self._DIVIDER
        )

    def _get_time_str(self, scId):
        if self.novel.sections[scId].time is not None:
            return PyCalendar.time_disp(self.novel.sections[scId].time)

        else:
            return ''

    def _get_week_day_str(self, scId, timestamp):
        if (
            not self.novel.sections[scId].date
            and not self.novel.referenceDate
        ):
            return ''

        return PyCalendar.weekday_str(timestamp)

    def _sort_sections_by_date(self):
        referenceDate = self.novel.referenceDate
        if not referenceDate:
            referenceDate = PyCalendar.min
        scIdsByDate = {}
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                timestamp = PyCalendar.get_timestamp(
                    self.novel.sections[scId],
                    referenceDate,
                )
                if timestamp:
                    if not timestamp in scIdsByDate:
                        scIdsByDate[timestamp] = []
                    scIdsByDate[timestamp].append(scId)

        return sorted(scIdsByDate.items())



class HtmlViewpointBoard(HtmlBoard):
    DESCRIPTION = _('HTML Viewpoint board')
    SUFFIX = VIEWPOINT_BOARD_SUFFFIX

    def write(self):

        srtCharacters = self.novel.tree.get_children(CR_ROOT)
        if not srtCharacters:
            raise UserWarning(f'{_("No characters found")}.')

        DEFAULT_BG = '#dfdfdf'
        NO_VP = ''
        viewpointSections = {NO_VP: {}}
        viewpointCharacters = {}
        srtSections = []
        for crId in srtCharacters:
            viewpointSections[crId] = {}
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chType != 0:
                continue

            for scId in self.novel.tree.get_children(chId):
                section = self.novel.sections[scId]
                if section.scType != 0:
                    continue

                srtSections.append(scId)
                crId = section.viewpoint
                if crId:
                    viewpointSections[crId][scId] = section
                    if not crId in viewpointCharacters:
                        viewpointCharacters[crId] = self.novel.characters[crId]
                else:
                    viewpointSections[NO_VP][scId] = section

        if not viewpointCharacters:
            raise UserWarning(f'{_("No viewpoint defined")}.')

        htmlText = [self._fileHeader]

        htmlText.extend(
            self._get_card_header_styles(viewpointCharacters, invert=True)
        )

        sections = {}
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                sections[scId] = self.novel.sections[scId]
        htmlText.extend(self._get_card_header_styles(sections))
        htmlText.extend(self._get_card_body_styles(sections))

        htmlText.append(
            f'<title>{_("Viewpoint board")} ({self.novel.title})</title>\n'
            '</head>\n'
            '<body>\n'
            f'<p class=title>{self.novel.title} - {_("Viewpoint board")}</p>\n'
            '<table>\n'
        )

        for crId in viewpointSections:
            if not viewpointSections[crId]:
                continue

            if crId == NO_VP:
                bgcolor = DEFAULT_BG
            else:
                bgcolor = self.novel.characters[crId].color or '#000000'
            htmlText.append('<tr>')
            if crId == NO_VP:
                htmlText.append(
                    self._new_cell(
                        _('No viewpoint'),
                    )
                )
            else:
                htmlText.append(
                    self._new_cell(
                        self.novel.characters[crId].title,
                        attr=f'class="h{crId}"',
                    )
                )
            for scId in srtSections:
                if scId in viewpointSections[crId]:
                    htmlText.append(
                        self._new_cell(
                            self.novel.sections[scId].title,
                            attr=f'class="h{scId}"',
                        )
                    )
                else:
                    htmlText.append(f'<td style="border-bottom: 0.4em solid {bgcolor}">')
            htmlText.append('</tr>')
            htmlText.append(f'<tr>')
            htmlText.append('<td>')
            for scId in srtSections:
                if scId in viewpointSections[crId]:
                    htmlText.append(
                        self._new_cell(
                            self.novel.sections[scId].desc,
                            attr=f'class="{scId}"',
                        )
                    )
                else:
                    htmlText.append('<td>')
            htmlText.append('</tr>')
            htmlText.append(f'<tr style="background: {DEFAULT_BG}">')
            htmlText.append('<td><br></td></tr>')
        htmlText.append('</table>')
        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))



class NvHtmlReporter:
    EXPORT_TARGET_CLASSES = [
        HtmlChapterBoard,
        HtmlCharacters,
        HtmlElementNotes,
        HtmlGrid,
        HtmlItems,
        HtmlLocations,
        HtmlPlotLineBoard,
        HtmlPlotList,
        HtmlProjectNotes,
        HtmlStoryStructureBoard,
        HtmlTimetable,
        HtmlViewpointBoard,
    ]

    def __init__(self):
        self._exportTargetFactory = ExportTargetFactory(
            self.EXPORT_TARGET_CLASSES)

    def run(self, source, suffix, tempdir='.'):
        kwargs = {'suffix':suffix}
        __, target = self._exportTargetFactory.new_file_objects(
            source.filePath,
            **kwargs
        )
        filename = os.path.basename(target.filePath)
        target.filePath = f'{tempdir}/{filename}'
        target.novel = source.novel
        target.write()
        open_document(target.filePath)

from datetime import datetime



class NvWorkFile(NovxFile):
    DESCRIPTION = _('novelibre project')
    _LOCKFILE_PREFIX = '.LOCK.'
    _LOCKFILE_SUFFIX = '#'

    @property
    def fileDate(self):
        if self.timestamp is None:
            return _('Never')
        else:
            return datetime.fromtimestamp(self.timestamp).strftime('%c')

    def adjust_section_types(self):
        super().adjust_section_types()
        for chId in self.novel.tree.get_children(CH_ROOT):
            if (self.novel.chapters[chId].isTrash
                and self.novel.tree.next(chId)
            ):
                self.novel.tree.move(chId, CH_ROOT, 'end')
                return

    def get_lockfile_path(self, filePath):
        try:
            head, tail = os.path.split(filePath)
        except:
            return None

        if not head:
            head = '.'
        return (
            f'{head}/'
            f'{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        )

    def has_changed_on_disk(self):
        try:
            if self.timestamp != os.path.getmtime(self.filePath):
                return True
            else:
                return False

        except:
            return False

    def has_lockfile(self):
        if not self.filePath:
            return None

        return os.path.isfile(self.get_lockfile_path(self.filePath))

    def lock(self):
        if not self.filePath:
            return

        lockfilePath = self.get_lockfile_path(self.filePath)
        if not os.path.isfile(lockfilePath):
            with open(lockfilePath, 'w') as f:
                f.write('')

    def read(self):
        super().read()
        self.novel.check_locale()

    def unlock(self):
        if not self.filePath:
            return

        try:
            os.remove(self.get_lockfile_path(self.filePath))
        except:
            pass



class FileManager(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self.exporter = NvDocExporter(self._ui)
        self.reporter = NvHtmlReporter()
        self.prefs = self._ctrl.get_preferences()

    def create_project(self):
        self._ui.restore_status()
        if self._mdl.prjFile is not None:
            if self._ctrl.on_close() is None:
                return

        self._mdl.create_project(self._ui.tv.tree)
        self._ctrl.refresh_tree()
        self._ui.show_path(_('Unnamed'))
        self._ctrl.enable_menu()
        self._ctrl.update_status()
        self._ui.tv.update_tree()
        self._ui.tv.refresh()
        self._ui.tv.go_to_node(CH_ROOT)
        self.save_project()
        return True

    def copy_css(self):
        self._ui.restore_status()
        try:
            projectDir = os.path.dirname(self._mdl.prjFile.filePath)
            copy2(f'{INSTALL_DIR}/css/novx.css', projectDir)
            message = _('Style sheet copied into the project folder.')
        except Exception as ex:
            message = f'!{str(ex)}'
        self._ui.set_status(message)

    def copy_to_backup(self, filePath):
        if not self.prefs['enable_backup']:
            return

        backupDir = self.prefs['backup_dir']
        if not backupDir:
            self._ui.set_status(
                f'#{_("Backup directory not set")}. '
                f'{_("Please check the setting")}.'
            )
            return

        if not os.path.isdir(backupDir):
            self._ui.set_status(
                f'#{_("Backup directory not found")}: '
                f'"{norm_path(backupDir)}". '
                f'{_("Please check the setting")}.'
            )
            return

        try:
            basename = os.path.basename(filePath)
            zipfile.ZipFile(
                f'{backupDir}/{basename}.zip',
                mode='w',
            ).write(
                filePath,
                arcname=basename,
                compress_type=zipfile.ZIP_DEFLATED,
            )
        except Exception as ex:
            self._ui.set_status(f"#{_('Backup failed')}: {str(ex)}")

    def discard_manuscript(self):
        self._ui.restore_status()
        fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        manuscriptPath = f'{fileName}{MANUSCRIPT_SUFFIX}.odt'
        if not os.path.isfile(manuscriptPath):
            self._ui.set_status(f"#{_('Manuscript not found')}.")
            return

        if odf_is_locked(manuscriptPath):
            self._ui.set_status(
                f"!{_('Please close the manuscript first')}."
            )
        elif self._ui.ask_yes_no(
            message=_('Discard manuscript?'),
            detail=self._mdl.novel.title
            ):
            os.replace(
                manuscriptPath,
                f'{fileName}{MANUSCRIPT_SUFFIX}.odt.bak'
            )
            self._ui.set_status(f"{_('Manuscript discarded')}.")

    def export_document(self, suffix, **kwargs):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.prjFile is None:
            return

        if self._mdl.prjFile.filePath is None:
            if not self.save_project():
                return

        if self._mdl.isModified:
            if self._ui.ask_yes_no(
                message=_('Save changes?')
            ):
                self.save_project()
            else:
                self._ui.set_status(f'#{_("Action canceled by user")}.')
                return

        try:
            self._ui.set_status(
                self.exporter.run(
                    self._mdl.prjFile,
                    suffix,
                    **kwargs
                )
            )
        except UserWarning as ex:
            self._ui.set_status(f'#{str(ex)}')
        except RuntimeError as ex:
            self._ui.set_status(f'!{str(ex)}')
        else:
            if (
                kwargs.get('lock', True)
                and self.prefs['lock_on_export']
            ):
                self._ctrl.lock()

    def import_odf(
            self, sourcePath=None,
            defaultExtension='.odt',
            parent=None,
        ):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if sourcePath is None:
            if self.prefs['last_open']:
                startDir = os.path.dirname(self.prefs['last_open'])
            else:
                startDir = '.'
            sourcePath = filedialog.askopenfilename(
                filetypes=[
                    (_('ODF Text document'), '.odt'),
                    (_('ODF Spreadsheet document'), '.ods'),
                ],
                defaultextension=defaultExtension,
                initialdir=startDir,
            )
            if not sourcePath:
                return

        if self._mdl.isModified:
            doSave = self._ui.ask_yes_no_cancel(_('Save changes?'))
            if doSave is None:
                return

            elif doSave:
                if not self.save_project():
                    self._ui.show_error(
                        message=_('Cannot save the project')
                    )
                    return

        self._ctrl.docImporter.import_document(sourcePath, parent=parent)
        if self._mdl.prjFile:
            self.copy_to_backup(self._mdl.prjFile.filePath)

    def open_installationFolder(self):
        self._ui.restore_status()
        try:
            open_document(INSTALL_DIR)
        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')

    def open_project(self, filePath='', doNotSave=False):
        self._ui.restore_status()
        filePath = self.select_project(filePath)
        if not filePath:
            return False

        if self._mdl.prjFile is not None:
            if self._ctrl.on_close(doNotSave=doNotSave) is None:
                return False

        if prefs['warn_before_reopening']:
            pidfile = f'{filePath}.pid'
            if os.path.isfile(pidfile):
                message = (
                    f"{_('This project may be already open in novelibre')}:"
                    '\n'
                    f'"{norm_path(filePath)}"'
                )
                if not self._ui.ask_ok_cancel(
                    message=message,
                    detail=_('Open anyway?'),
                ):
                    return False

            with open(pidfile, 'w') as f:
                f.write(str(os.getpid()))

        self.prefs['last_open'] = filePath
        try:
            self._mdl.open_project(filePath)
        except RuntimeError as ex:
            self._ctrl.on_close(doNotSave=doNotSave)
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)}')
        self._ctrl.enable_menu()
        self._ctrl.refresh_tree()
        self._ui.show_path(_('{0} (last saved on {1})').format(
            norm_path(self._mdl.prjFile.filePath),
            self._mdl.prjFile.fileDate)
        )
        self._ctrl.update_status()
        self._ui.contentsView.view_text()

        if self._mdl.prjFile.has_lockfile():
            self._ctrl.lock()
        else:
            self._ctrl.unlock()

        self._ui.tv.show_branch(CH_ROOT)
        self._ctrl.on_open()
        return True

    def open_project_folder(self):
        self._ui.restore_status()
        if not self._mdl:
            return 'break'

        if not self._mdl.prjFile:
            return 'break'

        if self._mdl.prjFile.filePath is None:
            if not self._ui.ask_ok_cancel(
                message=_('Please save now'),
                detail=_('Project path unknown'),
            ):
                return 'break'

            if not self.save_project():
                return 'break'

        try:
            open_document(os.path.dirname(self._mdl.prjFile.filePath))
        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')
        return 'break'

    def reload_project(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if self._mdl.isModified and not self._ui.ask_yes_no(
            message=_('Discard changes and reload the project?')
        ):
            return

        if (
            self._mdl.prjFile.has_changed_on_disk()
            and not self._ui.ask_yes_no(
                message=_('File has changed on disk. Reload anyway?')
            )
        ):
            return

        if self.open_project(
            filePath=self._mdl.prjFile.filePath,
            doNotSave=True,
        ):
            self._ui.set_status(_('Project successfully restored from disk.'))
        return

    def restore_backup(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        latestBackup = f'{self._mdl.prjFile.filePath}.bak'
        if not os.path.isfile(latestBackup):
            self._ui.set_status(f'!{_("No backup available")}')
            return

        if self._mdl.isModified:
            if not self._ui.ask_yes_no(
                message=_('Discard changes and load the ".bak" file?')
            ):
                return

        elif not self._ui.ask_yes_no(
            message=_('Overwrite the last saved project file with the ".bak" file?')
        ):
            return

        try:
            os.replace(latestBackup, self._mdl.prjFile.filePath)
        except Exception as ex:
            self._ui.set_status(str(ex))
        else:
            if self.open_project(
                filePath=self._mdl.prjFile.filePath,
                doNotSave=True,
            ):
                self._ui.set_status(_('Latest backup successfully restored.'))
        return

    def restore_default_styles(self, *args):
        self._ui.restore_status()
        try:
            os.remove(USER_STYLES_XML)
        except:
            self._ui.set_status(f'#{_("Default styles are already set")}.')
        else:
            self._ui.set_status(f'{_("Default styles are restored")}.')

    def save_as(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return False

        if self.prefs['last_open']:
            initDir = os.path.dirname(self.prefs['last_open'])
        else:
            initDir = HOME_DIR
        fileTypes = [(NvWorkFile.DESCRIPTION, NvWorkFile.EXTENSION)]
        fileName = filedialog.asksaveasfilename(
            filetypes=fileTypes,
            defaultextension=fileTypes[0][1],
            initialdir=initDir,
        )
        if not fileName:
            return False

        self._ui.propertiesView.apply_changes()
        oldFileName = self._mdl.prjFile.filePath
        try:
            self._mdl.save_project(fileName)
        except RuntimeError as ex:
            self._ui.set_status(f'!{str(ex)}')
            return False
        try:
            os.rename(
                f'{oldFileName}.pid',
                f'{self._mdl.prjFile.filePath}.pid'
            )
        except FileNotFoundError:
            pass

        self._ctrl.unlock()
        self._ui.show_path(
            f'{norm_path(self._mdl.prjFile.filePath)} '
            f'({_("last saved on")} {self._mdl.prjFile.fileDate})'
        )
        self._ui.restore_status()
        self.prefs['last_open'] = self._mdl.prjFile.filePath
        self.copy_to_backup(self._mdl.prjFile.filePath)
        self._ctrl.on_open()
        return True

    def save_project(self):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return False

        if self._ctrl.check_lock():
            self._ui.set_status(
                f'!{_("Cannot save: The project is locked")}.'
            )
            return False

        if self._mdl.prjFile.filePath is None:
            return self.save_as()

        if (
            self._mdl.prjFile.has_changed_on_disk()
            and not self._ui.ask_yes_no(
                message=_('File has changed on disk. Save anyway?')
            )
        ):
            return False

        self._ui.propertiesView.apply_changes()
        try:
            self._mdl.save_project()
        except RuntimeError as ex:
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.show_path(
            f'{norm_path(self._mdl.prjFile.filePath)} '
            f'({_("last saved on")} {self._mdl.prjFile.fileDate})'
        )
        self._ui.restore_status()
        self.prefs['last_open'] = self._mdl.prjFile.filePath
        self.copy_to_backup(self._mdl.prjFile.filePath)
        return True

    def select_project(self, fileName):
        self._ui.restore_status()
        initDir = os.path.dirname(self.prefs.get('last_open', ''))
        if not initDir:
            initDir = HOME_DIR
        if not fileName or not os.path.isfile(fileName):
            fileTypes = [(NvWorkFile.DESCRIPTION, NvWorkFile.EXTENSION)]
            fileName = filedialog.askopenfilename(
                filetypes=fileTypes,
                defaultextension=fileTypes[0][1],
                initialdir=initDir,
            )
        if not fileName:
            return ''

        return fileName

    def set_user_styles(self, *args):
        self._ui.restore_status()
        os.makedirs(USER_STYLES_DIR, exist_ok=True)
        fileTypes = [
            (_("ODF Text Document"), '.odt') ,
            (_("ODF Text Document"), '.ott'),
        ]
        docTemplate = filedialog.askopenfilename(filetypes=fileTypes)
        if not docTemplate:
            return

        templateName = os.path.basename(docTemplate)
        try:
            with zipfile.ZipFile(docTemplate) as myzip:
                with myzip.open('styles.xml') as myfile:
                    stylesXmlStr = myfile.read().decode('utf-8')
            stylesXmlStr = OdtWriter.remove_novelibre_styles(stylesXmlStr)
            with open(USER_STYLES_XML, 'w', encoding='utf-8') as f:
                f.write(stylesXmlStr)
        except:
            self._ui.set_status(
                f'!{_("Invalid document template")}: '
                f'"{templateName}".'
            )
        else:
            self._ui.set_status(
                f'{_("Document template is set")}: '
                f'"{templateName}".'
            )

    def show_report(self, suffix):
        self._ui.restore_status()
        if self._mdl.prjFile is None:
            return

        if self._mdl.prjFile.filePath is None:
            return

        self._ui.propertiesView.apply_changes()
        HtmlReport.localizeDate = self.prefs['localize_date']
        try:
            self.reporter.run(
                self._mdl.prjFile,
                suffix,
                tempdir=self._ctrl.tempDir,
            )
        except UserWarning as ex:
            self._ui.set_status(f'#{str(ex)}')
        except RuntimeError as ex:
            self._ui.set_status(f'!{str(ex)}')

from tkinter import filedialog



class NvTree:

    def __init__(self):
        self.roots = {
            CH_ROOT:[],
            PL_ROOT:[],
            CR_ROOT:[],
            LC_ROOT:[],
            IT_ROOT:[],
            PN_ROOT:[],
        }
        self.srtSections = {}
        self.srtPlotPoints = {}

    def append(self, parent, iid):
        if parent in self.roots:
            self.roots[parent].append(iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtPlotPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].append(iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtPlotPoints:
                self.srtPlotPoints[parent].append(iid)
            else:
                self.srtPlotPoints[parent] = [iid]

    def delete(self, *items):
        raise NotImplementedError

    def delete_children(self, parent):
        if parent in self.roots:
            self.roots[parent] = []
            if parent == CH_ROOT:
                self.srtSections.clear()
                return

            if parent == PL_ROOT:
                self.srtPlotPoints.clear()
            return

        if parent.startswith(CHAPTER_PREFIX):
            self.srtSections[parent] = []
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            self.srtPlotPoints[parent] = []

    def get_children(self, item):
        if item in self.roots:
            return self.roots[item]

        if item.startswith(CHAPTER_PREFIX):
            return self.srtSections.get(item, [])

        if item.startswith(PLOT_LINE_PREFIX):
            return self.srtPlotPoints.get(item, [])

    def index(self, item):
        raise NotImplementedError

    def insert(self, parent, index, iid):
        if parent in self.roots:
            self.roots[parent].insert(index, iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtPlotPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].insert(index, iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtPlotPoints:
                self.srtPlotPoints[parent].insert(index, iid)
            else:
                self.srtPlotPoints[parent] = [iid]

    def move(self, item, parent, index):
        raise NotImplementedError

    def next(self, item):
        raise NotImplementedError

    def parent(self, item):
        if item.startswith(PLOT_POINT_PREFIX):
            for plId, ppIds in self.srtPlotPoints.items():
                if item in ppIds:
                    return plId

        elif item.startswith(SECTION_PREFIX):
            for chId, scIds in self.srtSections.items():
                if item in scIds:
                    return chId

        elif item in self.roots:
            return ''

        else:
            for root in self.roots:
                if item in root:
                    return root

        raise KeyError

    def prev(self, item):
        raise NotImplementedError

    def reset(self):
        for item in self.roots:
            self.roots[item] = []
        self.srtSections.clear()
        self.srtPlotPoints.clear()

    def set_children(self, item, newchildren):
        if item in self.roots:
            self.roots[item] = newchildren[:]
            if item == CH_ROOT:
                self.srtSections.clear()
                return

            if item == PL_ROOT:
                self.srtPlotPoints.clear()
            return

        if item.startswith(CHAPTER_PREFIX):
            self.srtSections[item] = newchildren[:]
            return

        if item.startswith(PLOT_LINE_PREFIX):
            self.srtPlotPoints[item] = newchildren[:]



class FileSplitter(ServiceBase):

    def split_project(self):

        if self._mdl.prjFile is None:
            return

        elements = self._ui.selectedNodes
        if not elements:
            return

        msg = _('Create a new project and move the selected chapters there?')
        if not self._ui.ask_yes_no(message=msg):
            return

        lastOpen = self._ctrl.get_preferences()['last_open']
        if lastOpen:
            startDir = os.path.dirname(lastOpen)
        else:
            startDir = '.'
        fileTypes = [(NvWorkFile.DESCRIPTION, NvWorkFile.EXTENSION)]
        fileName = filedialog.asksaveasfilename(
            filetypes=fileTypes,
            defaultextension=fileTypes[0][1],
            initialdir=startDir,
        )
        if not fileName:
            return

        if self._ui.tv.tree.prev(elements[0]):
            newSelection = self._ui.tv.tree.prev(elements[0])
        else:
            newSelection = self._ui.tv.tree.parent(elements[0])
        self._ui.tv.go_to_node(newSelection)

        self._ui.propertiesView.apply_changes()

        sourceNovel = self._mdl.novel
        newProject = self._mdl.nvService.new_novx_file(fileName)
        newNovel = Novel(
            links=sourceNovel.links,
            authorName=sourceNovel.authorName,
            languageCode=sourceNovel.languageCode,
            countryCode=sourceNovel.countryCode,
            renumberChapters=sourceNovel.renumberChapters,
            renumberParts=sourceNovel.renumberParts,
            renumberWithinParts=sourceNovel.renumberWithinParts,
            romanChapterNumbers=sourceNovel.romanChapterNumbers,
            romanPartNumbers=sourceNovel.romanPartNumbers,
            saveWordCount=sourceNovel.saveWordCount,
            workPhase=sourceNovel.workPhase,
            chapterHeadingPrefix=sourceNovel.chapterHeadingPrefix,
            chapterHeadingSuffix=sourceNovel.chapterHeadingSuffix,
            partHeadingPrefix=sourceNovel.partHeadingPrefix,
            partHeadingSuffix=sourceNovel.partHeadingSuffix,
            noSceneField1=sourceNovel.noSceneField1,
            noSceneField2=sourceNovel.noSceneField2,
            noSceneField3=sourceNovel.noSceneField3,
            otherSceneField1=sourceNovel.otherSceneField1,
            otherSceneField2=sourceNovel.otherSceneField2,
            otherSceneField3=sourceNovel.otherSceneField3,
            crField1=sourceNovel.crField1,
            crField2=sourceNovel.crField2,
            referenceDate=sourceNovel.referenceDate,
            tree=NvTree(),
        )

        for chId in elements:
            if chId.startswith(CHAPTER_PREFIX):
                newNovel.chapters[chId] = sourceNovel.chapters[chId]
                newNovel.tree.append(CH_ROOT, chId)
                for scId in sourceNovel.tree.get_children(chId):
                    newNovel.sections[scId] = sourceNovel.sections[scId]
                    newNovel.tree.append(chId, scId)
                    self._copy_related_elements(sourceNovel, newNovel, scId)
        newProject.novel = newNovel
        try:
            newProject.write()
        except RuntimeError as ex:
            self._ui.set_status(f'!{str(ex)}')
        else:
            for chId in elements:
                if chId.startswith(CHAPTER_PREFIX):
                    self._mdl.delete_element(chId, trash=False)
            for ppId in newNovel.plotPoints:
                self._mdl.delete_element(ppId)
            self._ctrl.refresh_tree()
            self._ui.set_status(
                f'{_("Chapters moved to new file")}: {norm_path(fileName)}'
            )

    def _copy_related_elements(self, sourceNovel, newNovel, scId):
        for crId in newNovel.sections[scId].characters:
            if not crId in newNovel.characters:
                newNovel.characters[crId] = sourceNovel.characters[crId]
                newNovel.tree.append(CR_ROOT, crId)
        for lcId in newNovel.sections[scId].locations:
            if not lcId in newNovel.locations:
                newNovel.locations[lcId] = sourceNovel.locations[lcId]
                newNovel.tree.append(LC_ROOT, lcId)
        for itId in newNovel.sections[scId].items:
            if not itId in newNovel.items:
                newNovel.items[itId] = sourceNovel.items[itId]
                newNovel.tree.append(IT_ROOT, itId)
        for plId in newNovel.sections[scId].scPlotLines:
            if not plId in newNovel.plotLines:
                newNovel.plotLines[plId] = sourceNovel.plotLines[plId]
                newNovel.tree.append(PL_ROOT, plId)
        for ppId in newNovel.sections[scId].scPlotPoints:
            if not ppId in newNovel.plotPoints:
                newNovel.plotPoints[ppId] = sourceNovel.plotPoints[ppId]
                plId = sourceNovel.tree.parent(ppId)
                newNovel.tree.append(plId, ppId)

import subprocess



class LinkProcessor(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self.externalOpeners = []

    def add_opener(self, method):
        self.externalOpeners.append(method)

    def expand_path(self, linkPath):
        if linkPath.startswith('~'):
            linkPath = linkPath.replace('~', HOME_DIR, 1)
        else:
            projectDir = os.path.dirname(self._mdl.prjFile.filePath)
            linkPath = os.path.join(projectDir, linkPath)
        return os.path.realpath(linkPath).replace('\\', '/')

    def open_link_by_index(self, element, linkIndex):
        self._ui.restore_status()
        relativePath = list(element.links)[linkIndex]
        fullPath = element.links[relativePath]
        try:
            self.open_link(relativePath)
        except:

            if fullPath is not None:
                newPath = self.shorten_path(fullPath)
            else:
                newPath = ''
            try:
                self.open_link(newPath)
            except Exception as ex:

                self._ui.show_error(
                    message=_('Cannot open link'),
                    detail=str(ex)
                    )
            else:
                if not self._ctrl.isLocked:
                    links = element.links
                    del links[relativePath]
                    links[newPath] = fullPath
                    element.links = links
                    self._ui.set_status(f"#{_('Broken link fixed')}")
        else:
            if not self._ctrl.isLocked:
                pathOk = self.expand_path(relativePath)
                if fullPath != pathOk:
                    links = element.links
                    links[relativePath] = pathOk
                    element.links = links
                    self._ui.set_status(f"#{_('Broken link fixed')}")

    def open_link(self, linkPath):
        linkPath = self.expand_path(linkPath)
        for externalOpener in self.externalOpeners:
            try:
                if externalOpener(linkPath):
                    return

            except:
                pass
        __, extension = os.path.splitext(linkPath)
        launcher = launchers.get(extension, '')
        if os.path.isfile(launcher):
            subprocess.Popen([launcher, linkPath])
            return

        if os.path.isfile(linkPath):
            try:
                open_document(linkPath)
            except Exception as ex:
                self._ui.set_status(f'!{str(ex)}')
            return

        raise FileNotFoundError(
            f"{_('File not found')}: {norm_path(linkPath)}"
        )

    def shorten_path(self, linkPath):
        projectDir = os.path.dirname(self._mdl.prjFile.filePath)
        try:
            linkPath = os.path.relpath(linkPath, projectDir)
        except ValueError:
            pass
        return linkPath.replace('\\', '/')

from tkinter import ttk, colorchooser

from tkinter import ttk

from xml import sax


class ContentViewParser(sax.ContentHandler):
    BULLET = '•'

    def __init__(self):
        super().__init__()
        self.textTag = ''
        self.xmlTag = ''
        self.emTag = ''
        self.strongTag = ''
        self.headingTag = ''
        self.commentTag = ''
        self.commentXmlTag = ''
        self.noteTag = ''
        self.noteXmlTag = ''
        self.showTags = None

        self.taggedText = None

        self._list = None
        self._comment = None
        self._note = None
        self._em = None
        self._strong = None
        self._heading = None

    def feed(self, xmlString):
        self.taggedText = []
        self._list = False
        self._comment = False
        self._note = False
        self._em = False
        self._strong = False
        self._heading = False
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):
        tag = self.textTag
        if self._em:
            tag = self.emTag
        elif self._strong:
            tag = self.strongTag
        if self._heading:
            tag = self.headingTag
        if self._comment:
            tag = self.commentTag
        elif self._note:
            tag = self.noteTag
        self.taggedText.append((content, tag))

    def endElement(self, name):
        tag = self.xmlTag
        suffix = ''
        if self._comment:
            tag = self.commentXmlTag
        elif self._note:
            tag = self.noteXmlTag
        if name == 'p' and not self._list:
            suffix = '\n'
        elif name == 'em':
            self._em = False
        elif name == 'strong':
            self._strong = False
        elif name in (
            'li',
            'creator',
            'date',
            'note-citation',
        ):
            suffix = '\n'
        elif name in (
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            suffix = '\n'
            self._heading = False
        elif name == 'ul':
            self._list = False
            if self.showTags:
                suffix = '\n'
        elif name == 'comment':
            self._comment = False
        elif name == 'note':
            self._note = False
        if self.showTags:
            self.taggedText.append((f'</{name}>{suffix}', tag))
        else:
            self.taggedText.append((suffix, tag))

    def startElement(self, name, attrs):
        attributes = ''
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            attributes = f'{attributes} {attrKey}="{attrValue}"'
        tag = self.xmlTag
        suffix = ''
        if name == 'em':
            self._em = True
        elif name == 'strong':
            self._strong = True
        elif name in (
            'h5',
            'h6',
            'h7',
            'h8',
            'h9',
        ):
            self._heading = True
        elif name == 'ul':
            self._list = True
            if self.showTags:
                suffix = '\n'
        elif name == 'comment':
            self._comment = True
            suffix = '\n'
        elif name == 'note':
            self._note = True
            suffix = '\n'
        elif name == 'li' and not self.showTags:
            suffix = f'{self.BULLET} '
        if self._comment:
            tag = self.commentXmlTag
        elif self._note:
            tag = self.noteXmlTag
        if self.showTags:
            self.taggedText.append((f'<{name}{attributes}>{suffix}', tag))
        else:
            self.taggedText.append((suffix, tag))
from tkinter import font as tkFont

from tkinter import font as tkFont
from tkinter import ttk


class RichTextTk(tk.Text):
    H1_TAG = 'h1'
    H2_TAG = 'h2'
    H3_TAG = 'h3'
    ITALIC_TAG = 'italic'
    BOLD_TAG = 'bold'
    CENTER_TAG = 'center'
    BULLET_TAG = 'bullet'

    H1_SIZE = 1.2
    H2_SIZE = 1.1
    H3_SIZE = 1.0
    H1_SPACING = 2
    H2_SPACING = 2
    H3_SPACING = 1.5
    CENTER_SPACING = 1.5

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        defaultFont = tkFont.nametofont(self.cget('font'))

        em = defaultFont.measure('m')
        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE), weight='bold')
        h2Font.configure(size=int(defaultSize * self.H2_SIZE), weight='bold')
        h3Font.configure(size=int(defaultSize * self.H3_SIZE), slant='italic')

        self.tag_configure(self.BOLD_TAG, font=boldFont)
        self.tag_configure(self.ITALIC_TAG, font=italicFont)
        self.tag_configure(
            self.H1_TAG,
            font=h1Font,
            spacing3=defaultSize,
            justify='center',
            spacing1=defaultSize * self.H1_SPACING,
        )
        self.tag_configure(
            self.H2_TAG,
            font=h2Font,
            spacing3=defaultSize,
            justify='center',
            spacing1=defaultSize * self.H2_SPACING,
        )
        self.tag_configure(
            self.H3_TAG,
            font=h3Font,
            spacing3=defaultSize,
            justify='center',
            spacing1=defaultSize * self.H3_SPACING,
        )
        self.tag_configure(
            self.CENTER_TAG,
            justify='center',
            spacing1=defaultSize * self.CENTER_SPACING,
        )

        lmargin2 = em + defaultFont.measure('\u2022 ')
        self.tag_configure(self.BULLET_TAG, lmargin1=em, lmargin2=lmargin2)

    def insert_bullet(self, index, text):
        self.insert(index, f'\u2022 {text}', self.BULLET_TAG)


class RichTextNv(RichTextTk):
    UNUSED_TAG = 'unused'
    H1_UNUSED_TAG = 'h1Unused'
    H2_UNUSED_TAG = 'h2Unused'
    H3_UNUSED_TAG = 'h3Unused'
    EPIGRAPH_TAG = 'epigraph'
    EPIGRAPH_SRC_TAG = 'epigraphSrc'
    H3_EPIGRAPH_TAG = 'h3epigraph'
    STAGE1_TAG = 'stage1'
    STAGE2_TAG = 'stage2'
    XML_TAG = 'xmlTag'
    COMMENT_TAG = 'commentTag'
    COMMENT_XML_TAG = 'commentXmlTag'
    NOTE_TAG = 'noteTag'
    NOTE_XML_TAG = 'noteXmlTag'
    EM_TAG = 'emTag'
    STRONG_TAG = 'strongTag'

    def __init__(self, *args, **kwargs):
        super().__init__(
            *args,
            height=20,
            width=60,
            spacing1=10,
            spacing2=2,
            wrap='word',
            padx=10,
            bg=kwargs['color_text_bg'],
            fg=kwargs['color_text_fg'],
        )
        defaultFont = tkFont.nametofont(self.cget('font'))
        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h1FontUnderline = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3FontItalic = tkFont.Font(**defaultFont.configure())
        h3FontUnderline = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(
            size=int(defaultSize * self.H1_SIZE),
            weight='bold',
        )
        h1FontUnderline.configure(
            size=int(defaultSize * self.H1_SIZE),
            weight='bold',
            underline=True
        )
        h2Font.configure(
            size=int(defaultSize * self.H2_SIZE),
            weight='bold',
        )
        h3FontItalic.configure(
            size=int(defaultSize * self.H3_SIZE),
            slant='italic',
        )
        h3FontUnderline.configure(
            size=int(defaultSize * self.H3_SIZE),
            underline=True
        )
        self.tag_configure(
            self.XML_TAG,
            foreground=kwargs['color_xml_tag'],
        )
        self.tag_configure(
            self.EM_TAG,
            font=italicFont,
        )
        self.tag_configure(
            self.STRONG_TAG,
            font=boldFont,
        )
        self.tag_configure(
            self.COMMENT_TAG,
            background=kwargs['color_comment_tag'],
        )
        self.tag_configure(
            self.COMMENT_XML_TAG,
            foreground=kwargs['color_xml_tag'],
            background=kwargs['color_comment_tag'],
        )
        self.tag_configure(
            self.NOTE_TAG,
            background=kwargs['color_note_tag'],
        )
        self.tag_configure(
            self.NOTE_XML_TAG,
            foreground=kwargs['color_xml_tag'],
            background=kwargs['color_note_tag'],
        )
        self.tag_configure(
            self.H1_TAG,
            font=h1Font,
            spacing3=defaultSize,
            foreground=kwargs['color_chapter'],
            justify='center',
            spacing1=defaultSize * self.H1_SPACING,
        )
        self.tag_configure(
            self.H1_UNUSED_TAG,
            font=h1Font,
            spacing3=defaultSize,
            foreground=kwargs['color_unused'],
            justify='center',
            spacing1=defaultSize * self.H1_SPACING,
        )
        self.tag_configure(
            self.H2_TAG,
            font=h2Font,
            spacing3=defaultSize,
            foreground=kwargs['color_chapter'],
            justify='center',
            spacing1=defaultSize * self.H2_SPACING,
        )
        self.tag_configure(
            self.H2_UNUSED_TAG,
            font=h2Font,
            spacing3=defaultSize,
            foreground=kwargs['color_unused'],
            justify='center',
            spacing1=defaultSize * self.H2_SPACING,
        )
        self.tag_configure(
            self.H3_UNUSED_TAG,
            font=h3FontItalic,
            spacing3=defaultSize,
            foreground=kwargs['color_unused'],
            justify='center',
            spacing1=defaultSize * self.H3_SPACING,
        )
        self.tag_configure(
            self.H3_EPIGRAPH_TAG,
            font=h3FontItalic,
            spacing3=defaultSize,
            foreground=kwargs['color_chapter'],
            justify='center',
            spacing1=defaultSize * self.H3_SPACING,
        )
        self.tag_configure(
            self.EPIGRAPH_SRC_TAG,
            font=italicFont,
            spacing3=defaultSize,
            foreground=kwargs['color_chapter'],
            justify='center',
            spacing1=defaultSize,
        )
        self.tag_configure(
            self.UNUSED_TAG,
            foreground=kwargs['color_unused'],
        )
        self.tag_configure(
            self.EPIGRAPH_TAG,
            foreground=kwargs['color_chapter'],
        )
        self.tag_configure(
            self.STAGE1_TAG,
            font=h1FontUnderline,
            spacing3=defaultSize,
            foreground=kwargs['color_stage'],
            justify='center',
            spacing1=defaultSize * self.H1_SPACING,
        )
        self.tag_configure(
            self.STAGE2_TAG,
            font=h3FontUnderline,
            spacing3=defaultSize,
            foreground=kwargs['color_stage'],
            justify='center',
            spacing1=defaultSize * self.H3_SPACING,
        )

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass


class ContentsViewer(RichTextNv, Observer, SubController):

    def __init__(self, parent, model, controller):
        prefs = controller.get_preferences()
        super().__init__(parent, **prefs)
        self._mdl = model

        self.pack(expand=True, fill='both')
        self.showMarkup = tk.BooleanVar(parent, value=prefs['show_markup'])
        ttk.Checkbutton(
            parent,
            text=_('Show markup'),
            variable=self.showMarkup,
            command=self.refresh,
        ).pack(anchor='w')
        self._textMarks = {}
        self._index = '1.0'
        self._parent = parent

        self._contentParser = ContentViewParser()
        self._contentParser.xmlTag = self.XML_TAG
        self._contentParser.emTag = self.EM_TAG
        self._contentParser.strongTag = self.STRONG_TAG
        self._contentParser.headingTag = self.CENTER_TAG
        self._contentParser.commentTag = self.COMMENT_TAG
        self._contentParser.commentXmlTag = self.COMMENT_XML_TAG
        self._contentParser.noteTag = self.NOTE_TAG
        self._contentParser.noteXmlTag = self.NOTE_XML_TAG

    def on_close(self):
        self.reset_view()

    def refresh(self, event=None, *args):
        if self._mdl.prjFile is None:
            return

        if self._parent.winfo_manager():
            self.view_text()
            try:
                super().see(self._index)
            except KeyError:
                pass

    def reset_view(self):
        self.config(state='normal')
        self.delete('1.0', 'end')
        self.config(state='disabled')

    def see(self, idStr):
        try:
            self._index = self._textMarks[idStr]
            super().see(self._index)
        except KeyError:
            pass

    def view_text(self):
        taggedText = self._get_tagged_text()
        self._textMarks.clear()

        self.config(state='normal')
        self.delete('1.0', 'end')

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index
        self.config(state='disabled')

    def _convert_from_novx(self, text, textTag):
        if not self.showMarkup.get():
            self._contentParser.showTags = False
        else:
            self._contentParser.showTags = True
        self._contentParser.textTag = textTag
        self._contentParser.feed(text)
        return self._contentParser.taggedText[1:-1]

    def _get_tagged_text(self):
        taggedText = []
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            chapter = self._mdl.novel.chapters[chId]
            taggedText.append(chId)
            if chapter.chLevel == 2:
                if chapter.chType == 0:
                    headingTag = self.H2_TAG
                else:
                    headingTag = self.H2_UNUSED_TAG
            else:
                if chapter.chType == 0:
                    headingTag = self.H1_TAG
                else:
                    headingTag = self.H1_UNUSED_TAG
            if chapter.title:
                heading = f'{chapter.title}\n'
            else:
                    heading = f"[{_('Unnamed')}]\n"
            taggedText.append((heading, headingTag))

            isEpigraph = chapter.hasEpigraph
            for scId in self._mdl.novel.tree.get_children(chId):
                section = self._mdl.novel.sections[scId]
                taggedText.append(scId)
                textTag = ''
                if section.title:
                    title = section.title
                else:
                    title = _('Unnamed')
                if section.scType == 3:
                    headingTag = self.STAGE2_TAG
                elif section.scType == 2:
                    headingTag = self.STAGE1_TAG
                elif section.scType == 0:
                    if isEpigraph:
                        headingTag = self.H3_EPIGRAPH_TAG
                        textTag = self.EPIGRAPH_TAG
                    else:
                        headingTag = self.H3_TAG
                else:
                    headingTag = self.H3_UNUSED_TAG
                    textTag = self.UNUSED_TAG
                if isEpigraph and section.scType == 0:
                    heading = ''
                if section.scType > 1:
                    heading = f'{title}\n'
                else:
                    heading = f"[{title}]\n"
                taggedText.append((heading, headingTag))

                if section.sectionContent:
                    textTuples = self._convert_from_novx(
                        section.sectionContent,
                        textTag
                    )
                    taggedText.extend(textTuples)

                if isEpigraph and section.scType == 0 and section.desc:
                    taggedText.append(
                        (f'{section.desc}\n', self.EPIGRAPH_SRC_TAG)
                    )

                if section.scType == 0:
                    isEpigraph = False

        if not taggedText:
            taggedText.append(
                (f'({_("No text available")})', self.ITALIC_TAG)
            )
        return taggedText



class PathBar(Observer, tk.Label):

    COLOR_MODIFIED_BG = 'goldenrod1'
    COLOR_MODIFIED_FG = 'maroon'
    COLOR_NORMAL_BG = 'light gray'
    COLOR_NORMAL_FG = 'black'
    COLOR_LOCKED_BG = 'dim gray'
    COLOR_LOCKED_FG = 'light gray'

    def __init__(self, master, model, **kw):
        tk.Label.__init__(self, master, **kw)
        self._mdl = model

    def refresh(self):
        if self._mdl.isModified:
            self.set_modified()
        else:
            self.set_normal()

    def set_locked(self):
        self.config(bg=self.COLOR_LOCKED_BG)
        self.config(fg=self.COLOR_LOCKED_FG)

    def set_modified(self):
        self.config(bg=self.COLOR_MODIFIED_BG)
        self.config(fg=self.COLOR_MODIFIED_FG)

    def set_normal(self):
        self.config(bg=self.COLOR_NORMAL_BG)
        self.config(fg=self.COLOR_NORMAL_FG)


class StatusBar(tk.Label):

    COLOR_NORMAL_BG = 'light gray'
    COLOR_NORMAL_FG = 'black'
    COLOR_SUCCESS_BG = 'green'
    COLOR_SUCCESS_FG = 'white'
    COLOR_ERROR_BG = 'red'
    COLOR_ERROR_FG = 'white'
    COLOR_NOTIFICATION_BG = 'yellow'
    COLOR_NOTIFICATION_FG = 'black'

    def __init__(self, master, **kw):
        tk.Label.__init__(self, master, **kw)
        self._statusText = ''

    def restore_status(self, event=None):
        self.update_status(self._statusText)

    def show_message(self, message, colors=None):
        if message is None:
            return ''

        try:
            self.config(bg=colors[0])
            self.config(fg=colors[1])
        except:
            if message.startswith('!'):
                self.config(bg=self.COLOR_ERROR_BG)
                self.config(fg=self.COLOR_ERROR_FG)
                message = message.lstrip('!').strip()
            elif message.startswith('#'):
                self.config(bg=self.COLOR_NOTIFICATION_BG)
                self.config(fg=self.COLOR_NOTIFICATION_FG)
                message = message.lstrip('#').strip()
            else:
                self.config(bg=self.COLOR_SUCCESS_BG)
                self.config(fg=self.COLOR_SUCCESS_FG)
        self.config(text=message)
        return message

    def update_status(self, statusText=''):
        self._statusText = statusText
        self.config(bg=self.COLOR_NORMAL_BG)
        self.config(fg=self.COLOR_NORMAL_FG)
        self.config(text=statusText)
from pathlib import Path



class Icons:

    def __init__(self):

        def new_icon(iconFile):
            try:
                return tk.PhotoImage(file=f'{iconPath}/{iconFile}')

            except:
                return None

        def get_icon_dir(size):
            try:
                homeDir = str(Path.home()).replace('\\', '/')
            except:
                return None

            iconPath = f"{homeDir}/.novx/{prefs['icon_set']}/{size}"
            if os.path.isdir(iconPath):
                return iconPath

            prefs['icon_set'] = 'icons'
            iconPath = f'{homeDir}/.novx/icons/{size}'
            if os.path.isdir(iconPath):
                return iconPath

            return None

        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16

        iconPath = get_icon_dir(size)

        self.addChildIcon = new_icon('addChild.png')

        self.addIcon = new_icon('add.png')

        self.addMultipleIcon = new_icon('add_multiple.png')

        self.addParentIcon = new_icon('addParent.png')

        self.chaptersIcon = new_icon('chapters.png')

        self.closeIcon = new_icon('close.png')

        self.collapseIcon = new_icon('collapse.png')

        self.colorsIcon = new_icon('colors.png')

        self.copyIcon = new_icon('copy.png')

        self.cutIcon = new_icon('cut.png')

        self.discardManuscriptIcon = new_icon('discardManuscript.png')

        self.exitIcon = new_icon('exit.png')

        self.expandIcon = new_icon('expand.png')

        self.exportIcon = new_icon('export.png')

        self.folderIcon = new_icon('folder.png')

        self.goBackIcon = new_icon('goBack.png')

        self.goForwardIcon = new_icon('goForward.png')

        self.gotoIcon = new_icon('goto.png')

        self.gridIcon = new_icon('grid.png')

        self.helpIcon = new_icon('help.png')

        self.highlightIcon = new_icon('highlight.png')

        self.homeIcon = new_icon('home.png')

        self.importIcon = new_icon('import.png')

        self.installationFolderIcon = new_icon('installation_folder.png')

        self.levelsIcon = new_icon('levels.png')

        self.lockIcon = new_icon('lock.png')

        self.manuscriptIcon = new_icon('manuscript.png')

        self.nLogoIcon = new_icon('nLogo.png')

        self.newProjectIcon = new_icon('newProject.png')

        self.newsIcon = new_icon('smile.png')

        self.openProjectIcon = new_icon('openProject.png')

        self.pasteIcon = new_icon('paste.png')

        self.pluginsIcon = new_icon('plugins.png')

        self.povIcon = new_icon('pov.png')

        self.propertiesIcon = new_icon('properties.png')

        self.reloadIcon = new_icon('reload.png')

        self.removeIcon = new_icon('remove.png')

        self.resetColorsIcon = new_icon('resetColors.png')

        self.resetHighlightIcon = new_icon('reset_highlight.png')

        self.saveAsIcon = new_icon('saveAs.png')

        self.saveIcon = new_icon('save.png')

        self.selectIcon = new_icon('select.png')

        self.settingsIcon = new_icon('settings.png')

        self.stageIcon = new_icon('stage.png')

        self.statusIcon = new_icon('status.png')

        self.stickyNoteIcon = new_icon('sticky_note.png')

        self.tagsIcon = new_icon('tag.png')

        self.typeIcon = new_icon('type.png')

        self.unlockIcon = new_icon('unlock.png')

        self.updateFromManuscriptIcon = new_icon('updateFromManuscript.png')

        self.viewBookIcon = new_icon('viewBook.png')

        self.viewCharactersIcon = new_icon('viewCharacters.png')

        self.viewItemsIcon = new_icon('viewItems.png')

        self.viewLocationsIcon = new_icon('viewLocations.png')

        self.viewPlotLinesIcon = new_icon('viewArcs.png')

        self.viewProjectnotesIcon = new_icon('viewProjectnotes.png')

        self.viewerIcon = new_icon('viewer.png')



class NvMenu(tk.Menu, SubController):

    def __init__(self):
        super().__init__(tearoff=0)
        self.disableOnLock = []
        self.disableOnClose = []

    def disable_menu(self):
        for label in self.disableOnClose:
            self.entryconfig(label, state='disabled')

    def enable_menu(self):
        for label in self.disableOnClose:
            self.entryconfig(label, state='normal')

    def lock(self):
        for label in self.disableOnLock:
            self.entryconfig(label, state='disabled')

    def unlock(self):
        for label in self.disableOnLock:
            self.entryconfig(label, state='normal')



class NvContextMenu(NvMenu):

    def __init__(self):
        super().__init__()
        self.bind('<FocusOut>', self._close)

    def open(self, event):
        try:
            self.tk_popup(event.x_root, event.y_root)
        finally:
            self.grab_release()

    def _close(self, event):
        self.unpost()


class TreeContextMenu:

    def __init__(self, model, view):
        self._mdl = model
        self._ui = view

    def open(self, event):
        if self._mdl.prjFile is None:
            return

        row = self._ui.tv.tree.identify_row(event.y)
        if not row:
            return

        self._ui.tv.go_to_node(row)
        if row.startswith(ROOT_PREFIX):
            prefix = row
        else:
            prefix = row[:2]

        if prefix == CH_ROOT:
            self._ui.bookContextMenu.open(event)
        elif prefix == CHAPTER_PREFIX:
            if row == self._mdl.trashBin:
                self._ui.trashContextMenu.open(event)
            else:
                self._ui.chapterContextMenu.open(event)
        elif prefix == SECTION_PREFIX:
            if self._mdl.novel.tree.parent(row) == self._mdl.trashBin:
                self._ui.trashContextMenu.open(event)
            elif self._mdl.novel.sections[row].scType < 2:
                self._ui.sectionContextMenu.open(event)
            else:
                self._ui.stageContextMenu.open(event)
        elif prefix in (
            LOCATION_PREFIX,
            ITEM_PREFIX,
            PRJ_NOTE_PREFIX,
            PLOT_POINT_PREFIX,
        ):
            self._ui.elementContextMenu.open(event)
        elif prefix in (
        ):
            self._ui.elementContextMenu.open(event)
        elif prefix in(
            LC_ROOT,
            IT_ROOT,
            PL_ROOT,
            PN_ROOT,
        ):
            self._ui.rootContextMenu.open(event)
        elif prefix == CR_ROOT:
            self._ui.crRootContextMenu.open(event)
        elif prefix == CHARACTER_PREFIX:
            self._ui.characterContextMenu.open(event)
        elif prefix == PLOT_LINE_PREFIX:
            self._ui.plotLineContextMenu.open(event)



class MainMenu:

    def add_add_command(self, menu):
        label = _('Add')
        menu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_element,
        )
        menu.disableOnLock.append(label)

    def add_add_section_command(self, menu):
        label = _('Add Section')
        menu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_section,
        )
        menu.disableOnLock.append(label)

    def add_clipboard_commands(self, menu):
        label = _('Cut')
        menu.add_command(
            label=label,
            accelerator=KEYS.CUT[1],
            image=self.icons.cutIcon,
            compound='left',
            command=self._ctrl.cut_element,
        )
        menu.disableOnLock.append(label)

        label = _('Copy')
        menu.add_command(
            label=label,
            accelerator=KEYS.COPY[1],
            image=self.icons.copyIcon,
            compound='left',
            command=self._ctrl.copy_element,
        )
        label = _('Paste')
        menu.add_command(
            label=label,
            accelerator=KEYS.PASTE[1],
            image=self.icons.pasteIcon,
            compound='left',
            command=self._ctrl.paste_element,
        )
        menu.disableOnLock.append(label)

    def add_clone_command(self, menu):
        label = _('Clone')
        menu.add_command(
            label=label,
            command=self._ctrl.clone_section,
        )
        menu.disableOnLock.append(label)

    def add_color_commands(self, menu, prefix=None):
        label = f"{_('Assign color')}..."
        menu.add_command(
            label=label,
            image=self.icons.colorsIcon,
            compound='left',
            command=lambda p=prefix: self._ctrl.set_color(prefix=p)
        )
        menu.disableOnLock.append(label)

        label = _('Reset color')
        menu.add_command(
            label=label,
            image=self.icons.resetColorsIcon,
            compound='left',
            command=lambda p=prefix: self._ctrl.reset_color(prefix=p)
        )
        menu.disableOnLock.append(label)

    def add_delete_command(self, menu):
        label = _('Delete')
        menu.add_command(

            label=label,
            accelerator=KEYS.DELETE[1],
            image=self.icons.removeIcon,
            compound='left',
            command=self._ctrl.delete_elements,
        )
        menu.disableOnLock.append(label)

    def add_change_level_cascade(self, menu):
        label = _('Change Level')
        menu.add_cascade(
            label=label,
            image=self.icons.levelsIcon,
            compound='left',
            menu=self.selectLevelMenu,
        )
        menu.disableOnLock.append(label)

    def add_chapter_part_commands(self, menu):
        label = _('Add Chapter')
        menu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_chapter
        )
        menu.disableOnLock.append(label)

        label = _('Add Part')
        menu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_part,
        )
        menu.disableOnLock.append(label)

    def add_highlight_related_command(self, menu):
        label = _('Highlight related sections')
        menu.add_command(
            label=label,
            image=self.icons.highlightIcon,
            compound='left',
            command=self.tv.highlight_related_sections,
        )

    def add_insert_stage_command(self, menu):
        label = _('Insert Stage')
        menu.add_command(
            label=label,
            image=self.icons.stageIcon,
            compound='left',
            command=self._ctrl.add_new_stage,
        )
        menu.disableOnLock.append(label)

    def add_set_cr_status_cascade(self, menu):
        label = _('Set Status')
        menu.add_cascade(
            label=label,
            image=self.icons.statusIcon,
            compound='left',
            menu=self.selectCharacterStatusMenu,
        )
        menu.disableOnLock.append(label)

    def add_set_status_cascade(self, menu):
        label = _('Set Status')
        menu.add_cascade(
            label=label,
            image=self.icons.statusIcon,
            compound='left',
            menu=self.selectSectionStatusMenu,
        )
        menu.disableOnLock.append(label)

    def add_set_type_cascade(self, menu):
        label = _('Set Type')
        menu.add_cascade(
            label=label,
            image=self.icons.typeIcon,
            compound='left',
            menu=self.selectTypeMenu,
        )
        menu.disableOnLock.append(label)

    def add_set_viewpoint_command(self, menu):
        label = _('Set Viewpoint...')
        menu.add_command(
            label=label,
            image=self.icons.povIcon,
            compound='left',
            command=self._ctrl.set_viewpoint,
        )
        menu.disableOnLock.append(label)

    def add_view_commands(self, menu):
        label = _('Chapter level')
        menu.add_command(
            label=label,
            image=self.icons.chaptersIcon,
            compound='left',
            command=self.tv.show_chapter_level,
        )
        menu.disableOnClose.append(label)

        label = _('Expand all')
        menu.add_command(
            label=label,
            image=self.icons.expandIcon,
            compound='left',
            command=self.tv.expand_all,
        )
        menu.disableOnClose.append(label)

        label = _('Collapse all')
        menu.add_command(
            label=label,
            image=self.icons.collapseIcon,
            compound='left',
            command=self.tv.collapse_all,
        )
        menu.disableOnClose.append(label)

    def create_menus(self):


        self.selectTypeMenu = NvMenu()

        label = _('Normal')
        self.selectTypeMenu.add_command(
            label=label,
            command=self._ctrl.set_type_normal,
        )

        label = _('Unused')
        self.selectTypeMenu.add_command(
            label=label,
            command=self._ctrl.set_type_unused,
        )

        self.selectLevelMenu = NvMenu()

        label = _('1st Level')
        self.selectLevelMenu.add_command(
            label=label,
            command=self._ctrl.set_level_1,
        )

        label = _('2nd Level')
        self.selectLevelMenu.add_command(
            label=label,
            command=self._ctrl.set_level_2,
        )

        self.selectSectionStatusMenu = NvMenu()

        label = _('Outline')
        self.selectSectionStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_scn_status_outline,
        )

        label = _('Draft')
        self.selectSectionStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_scn_status_draft,
        )

        label = _('1st Edit')
        self.selectSectionStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_scn_status_1st_edit,
        )

        label = _('2nd Edit')
        self.selectSectionStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_scn_status_2nd_edit,
        )

        label = _('Done')
        self.selectSectionStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_scn_status_done,
        )

        self.selectCharacterStatusMenu = NvMenu()

        label = _('Major Character')
        self.selectCharacterStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_chr_status_major,
        )

        label = _('Minor Character')
        self.selectCharacterStatusMenu.add_command(
            label=label,
            command=self._ctrl.set_chr_status_minor,
        )


        self.newMenu = NvMenu()

        label = _('Empty project')
        self.newMenu.add_command(
            label=label,
            command=self._ctrl.create_project,
        )

        label = _('Create from ODT...')
        self.newMenu.add_command(
            label=label,
            command=self._ctrl.import_odf,
        )

        self.fileMenu = NvMenu()

        label = _('New')
        self.fileMenu.add_cascade(
            label=label,
            image=self.icons.newProjectIcon,
            compound='left',
            menu=self.newMenu
        )

        label = _('Open...')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.OPEN_PROJECT[1],
            image=self.icons.openProjectIcon,
            compound='left',
            command=self._ctrl.open_project,
        )

        label = _('Reload')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.RELOAD_PROJECT[1],
            image=self.icons.reloadIcon,
            compound='left',
            command=self._ctrl.reload_project,
        )
        self.fileMenu.disableOnClose.append(label)
        self.fileMenu.disableOnLock.append(label)

        label = _('Restore backup')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.RESTORE_BACKUP[1],
            command=self._ctrl.restore_backup,
        )
        self.fileMenu.disableOnClose.append(label)
        self.fileMenu.disableOnLock.append(label)

        self.fileMenu.add_separator()

        label = _('Refresh Tree')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.REFRESH_TREE[1],
            command=self._ctrl.refresh_tree,
        )
        self.fileMenu.disableOnClose.append(label)
        self.fileMenu.disableOnLock.append(label)

        label = _('Lock')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.LOCK_PROJECT[1],
            image=self.icons.lockIcon,
            compound='left',
            command=self._ctrl.lock,
        )
        self.fileMenu.disableOnClose.append(label)

        label = _('Unlock')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.UNLOCK_PROJECT[1],
            image=self.icons.unlockIcon,
            compound='left',
            command=self._ctrl.unlock,
        )
        self.fileMenu.disableOnClose.append(label)

        self.fileMenu.add_separator()

        label = _('Open Project folder')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.FOLDER[1],
            image=self.icons.folderIcon,
            compound='left',
            command=self._ctrl.open_project_folder,
        )
        self.fileMenu.disableOnClose.append(label)

        label = _('Copy style sheet')
        self.fileMenu.add_command(
            label=label,
            command=self._ctrl.copy_css,
        )
        self.fileMenu.disableOnClose.append(label)

        label = _('Discard manuscript')
        self.fileMenu.add_command(
            label=label,
            image=self.icons.discardManuscriptIcon,
            compound='left',
             command=self._ctrl.discard_manuscript,
        )
        self.fileMenu.disableOnClose.append(label)
        self.fileMenu.disableOnLock.append(label)

        self.fileMenu.add_separator()

        label = _('Save')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.SAVE_PROJECT[1],
            image=self.icons.saveIcon,
            compound='left',
            command=self._ctrl.save_project,
        )
        self.fileMenu.disableOnClose.append(label)
        self.fileMenu.disableOnLock.append(label)

        label = _('Save as...')
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.SAVE_AS[1],
            image=self.icons.saveAsIcon,
            compound='left',
            command=self._ctrl.save_as,
        )
        self.fileMenu.disableOnClose.append(label)

        label = _('Close')
        self.fileMenu.add_command(
            label=label,
            image=self.icons.closeIcon,
            compound='left',
            command=self._ctrl.close_project,
        )
        self.fileMenu.disableOnClose.append(label)

        if PLATFORM == 'win':
            label = _('Exit'),
        else:
            label = _('Quit'),
        self.fileMenu.add_command(
            label=label,
            accelerator=KEYS.QUIT_PROGRAM[1],
            image=self.icons.exitIcon,
            compound='left',
            command=self._ctrl.on_quit,
        )

        self._ctrl.register_client(self.fileMenu)

        self.viewMenu = NvMenu()

        label = _('Highlight tagged elements')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.tagsIcon,
            compound='left',
            command=self.tv.select_tag_and_highlight_elements,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Reset Highlighting')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.resetHighlightIcon,
            compound='left',
            command=self.tv.reset_highlighting,
        )

        self.viewMenu.add_separator()

        label = _('Show Book')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.viewBookIcon,
            compound='left',
            command=self.tv.show_book,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Show Plot lines')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.viewPlotLinesIcon,
            compound='left',
            command=self.tv.show_plot_lines,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Show Characters')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.viewCharactersIcon,
            compound='left',
            command=self.tv.show_characters,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Show Locations')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.viewLocationsIcon,
            compound='left',
            command=self.tv.show_locations,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Show Items')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.viewItemsIcon,
            compound='left',
            command=self.tv.show_items,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Show Project notes')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.viewProjectnotesIcon,
            compound='left',
            command=self.tv.show_project_notes,
        )
        self.viewMenu.disableOnClose.append(label)

        self.viewMenu.add_separator()

        self.add_view_commands(self.viewMenu)

        label = _('Expand selected')
        self.viewMenu.add_command(
            label=label,
            command=self.tv.expand_selected,
        )
        self.viewMenu.disableOnClose.append(label)

        label = _('Collapse selected')
        self.viewMenu.add_command(
            label=label,
            command=self.tv.collapse_selected,
        )
        self.viewMenu.disableOnClose.append(label)

        self.viewMenu.add_separator()

        label = _('Toggle Text viewer')
        self.viewMenu.add_command(
            label=label,
            accelerator=KEYS.TOGGLE_VIEWER[1],
            image=self.icons.viewerIcon,
            compound='left',
            command=self.toggle_contents_view,
        )

        label = _('Toggle Properties')
        self.viewMenu.add_command(
            label=label,
            accelerator=KEYS.TOGGLE_PROPERTIES[1],
            image=self.icons.propertiesIcon,
            compound='left',
            command=self.toggle_properties_view,
        )

        label = _('Detach/Dock Properties')
        self.viewMenu.add_command(
            label=label,
            accelerator=KEYS.DETACH_PROPERTIES[1],
            command=self.toggle_properties_window,
        )

        self.viewMenu.add_separator()

        label = _('Options')
        self.viewMenu.add_command(
            label=label,
            image=self.icons.settingsIcon,
            compound='left',
            command=self._ctrl.open_view_options,
        )

        self._ctrl.register_client(self.viewMenu)

        self.chapterMenu = NvMenu()

        self.add_chapter_part_commands(self.chapterMenu)

        label = _('Add multiple chapters...')
        self.chapterMenu.add_command(
            label=label,
            image=self.icons.addMultipleIcon,
            compound='left',
            command=self._ctrl.add_multiple_new_chapters,
        )
        self.chapterMenu.disableOnLock.append(label)

        self.chapterMenu.add_separator()

        self.add_set_type_cascade(self.chapterMenu)
        self.add_change_level_cascade(self.chapterMenu)
        self.add_color_commands(self.chapterMenu, prefix=CHAPTER_PREFIX)

        self.chapterMenu.add_separator()

        label = _('Move selected chapters to new project')
        self.chapterMenu.add_command(
            label=label,
            command=self._ctrl.split_file,
        )
        self.chapterMenu.disableOnLock.append(label)

        self.chapterMenu.add_separator()

        label = _('Export chapter descriptions for editing')
        self.chapterMenu.add_command(
            label=label,
            command=self._ctrl.export_chapter_desc,
        )
        self.chapterMenu.disableOnLock.append(label)

        label = _('Export part descriptions for editing')
        self.chapterMenu.add_command(
            label=label,
            command=self._ctrl.export_part_desc,
        )
        self.chapterMenu.disableOnLock.append(label)

        label = _('Export chapter table')
        self.chapterMenu.add_command(
            label=label,
            command=self._ctrl.export_chapter_table,
        )
        self.chapterMenu.disableOnLock.append(label)

        label = _('Export part table')
        self.chapterMenu.add_command(
            label=label,
            command=self._ctrl.export_part_table,
        )
        self.chapterMenu.disableOnLock.append(label)

        self.chapterMenu.add_separator()

        label = _('Show chapter board in browser')
        self.chapterMenu.add_command(
            label=label,
            command=self._ctrl.show_chapter_board,
        )

        self._ctrl.register_client(self.chapterMenu)

        self.sectionMenu = NvMenu()

        label = _('Add')
        self.sectionMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_section,
        )
        self.sectionMenu.disableOnLock.append(label)

        label = _('Add multiple sections...')
        self.sectionMenu.add_command(
            label=label,
            image=self.icons.addMultipleIcon,
            compound='left',
            command=self._ctrl.add_multiple_new_sections,
        )
        self.sectionMenu.disableOnLock.append(label)

        self.add_clone_command(self.sectionMenu)

        self.sectionMenu.add_separator()

        self.add_set_type_cascade(self.sectionMenu)
        self.add_set_status_cascade(self.sectionMenu)
        self.add_set_viewpoint_command(self.sectionMenu)
        self.add_color_commands(self.sectionMenu, prefix=SECTION_PREFIX)

        self.sectionMenu.add_separator()

        label = _('Export section descriptions for editing')
        self.sectionMenu.add_command(
            label=label,
            command=self._ctrl.export_section_desc,
        )
        self.sectionMenu.disableOnLock.append(label)

        self.sectionMenu.add_separator()

        label = _('Section table (export only)')
        self.sectionMenu.add_command(
            label=label,
            command=self._ctrl.export_section_table,
        )

        label = _('Show Time table')
        self.sectionMenu.add_command(
            label=label,
            command=self._ctrl.show_time_table,
        )

        self._ctrl.register_client(self.sectionMenu)

        self.characterMenu = NvMenu()

        label = _('Add')
        self.characterMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_character,
        )
        self.characterMenu.disableOnLock.append(label)

        self.characterMenu.add_separator()

        self.add_set_cr_status_cascade(self.characterMenu)
        self.add_color_commands(self.characterMenu, prefix=CHARACTER_PREFIX)

        self.characterMenu.add_separator()

        label = _('Import')
        self.characterMenu.add_command(
            label=label,
            image=self.icons.importIcon,
            compound='left',
            command=self._ctrl.import_character_data,
        )
        self.characterMenu.disableOnLock.append(label)

        self.characterMenu.add_separator()

        label = _('Export character descriptions for editing')
        self.characterMenu.add_command(
            label=label,
            command=self._ctrl.export_character_desc,
        )
        self.characterMenu.disableOnLock.append(label)

        label = _('Export character table')
        self.characterMenu.add_command(
            label=label,
            command=self._ctrl.export_character_table,
        )
        self.characterMenu.disableOnLock.append(label)

        self.characterMenu.add_separator()

        label = _('Show table in Browser')
        self.characterMenu.add_command(
            label=label,
            command=self._ctrl.show_character_table,
        )

        label = _('Show viewpoint board in browser')
        self.characterMenu.add_command(
            label=label,
            command=self._ctrl.show_viewpoint_board,
        )

        self._ctrl.register_client(self.characterMenu)

        self.locationMenu = NvMenu()

        label = _('Add')
        self.locationMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_location,
        )
        self.locationMenu.disableOnLock.append(label)

        self.locationMenu.add_separator()
        self.add_color_commands(self.locationMenu, prefix=LOCATION_PREFIX)
        self.locationMenu.add_separator()

        label = _('Import')
        self.locationMenu.add_command(
            label=label,
            image=self.icons.importIcon,
            compound='left',
            command=self._ctrl.import_location_data,
        )
        self.locationMenu.disableOnLock.append(label)

        self.locationMenu.add_separator()

        label = _('Export location descriptions for editing')
        self.locationMenu.add_command(
            label=label,
            command=self._ctrl.export_location_desc,
        )
        self.locationMenu.disableOnLock.append(label)

        label = _('Export location table')
        self.locationMenu.add_command(
            label=label,
            command=self._ctrl.export_location_table,
        )
        self.locationMenu.disableOnLock.append(label)

        self.locationMenu.add_separator()

        label = _('Show table in Browser')
        self.locationMenu.add_command(
            label=label,
            command=self._ctrl.show_location_list,
        )

        self._ctrl.register_client(self.locationMenu)

        self.itemMenu = NvMenu()

        label = _('Add')
        self.itemMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_item,
        )
        self.itemMenu.disableOnLock.append(label)

        self.itemMenu.add_separator()
        self.add_color_commands(self.itemMenu, prefix=ITEM_PREFIX)
        self.itemMenu.add_separator()

        label = _('Import')
        self.itemMenu.add_command(
            label=label,
            image=self.icons.importIcon,
            compound='left',
            command=self._ctrl.import_item_data,
        )
        self.itemMenu.disableOnLock.append(label)

        self.itemMenu.add_separator()

        label = _('Export item descriptions for editing')
        self.itemMenu.add_command(
            label=label,
            command=self._ctrl.export_item_desc,
        )
        self.itemMenu.disableOnLock.append(label)

        label = _('Export item table')
        self.itemMenu.add_command(
            label=label,
            command=self._ctrl.export_item_table,
        )
        self.itemMenu.disableOnLock.append(label)

        self.itemMenu.add_separator()

        label = _('Show table in Browser')
        self.itemMenu.add_command(
            label=label,
            command=self._ctrl.show_item_list,
        )

        self._ctrl.register_client(self.itemMenu)

        self.storyStructureMenu = NvMenu()

        self.add_insert_stage_command(self.storyStructureMenu)
        self.add_change_level_cascade(self.storyStructureMenu)

        self.storyStructureMenu.add_separator()

        label = _('Export story structure description for editing')
        self.storyStructureMenu.add_command(
            label=label,
            command=self._ctrl.export_story_structure_desc,
        )
        self.storyStructureMenu.disableOnLock.append(label)

        self.storyStructureMenu.add_separator()

        label = _('Show story structure board in browser')
        self.storyStructureMenu.add_command(
            label=label,
            command=self._ctrl.show_story_structure_board,
        )

        self._ctrl.register_client(self.storyStructureMenu)

        self.plotLinesMenu = NvMenu()

        label = _('Add Plot line')
        self.plotLinesMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_plot_line,
        )
        self.plotLinesMenu.disableOnLock.append(label)

        label = _('Add Plot point')
        self.plotLinesMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_plot_point,
        )
        self.plotLinesMenu.disableOnLock.append(label)

        self.plotLinesMenu.add_separator()

        self.add_color_commands(self.plotLinesMenu, prefix=PLOT_LINE_PREFIX)

        self.plotLinesMenu.add_separator()

        label = _('Import plot lines')
        self.plotLinesMenu.add_command(
            label=label,
            image=self.icons.importIcon,
            compound='left',
            command=self._ctrl.import_plot_lines,
        )
        self.plotLinesMenu.disableOnLock.append(label)

        self.plotLinesMenu.add_separator()

        label = _('Export plot grid for editing')
        self.plotLinesMenu.add_command(
            label=label,
            image=self.icons.gridIcon,
            compound='left',
            command=self._ctrl.export_plot_grid,
        )
        self.plotLinesMenu.disableOnLock.append(label)

        label = _('Export plot line descriptions for editing')
        self.plotLinesMenu.add_command(
            label=label,
            command=self._ctrl.export_plot_lines_desc,
        )
        self.plotLinesMenu.disableOnLock.append(label)

        self.plotLinesMenu.add_separator()

        label = _('Plot table (export only)')
        self.plotLinesMenu.add_command(
            label=label,
            command=self._ctrl.export_plot_list,
        )

        label = _('Show Plot table in browser')
        self.plotLinesMenu.add_command(
            label=label,
            command=self._ctrl.show_plot_table,
        )

        label = _('Show Plot line board in browser')
        self.plotLinesMenu.add_command(
            label=label,
            command=self._ctrl.show_plot_line_board,
        )

        label = _('Show Plot grid in browser')
        self.plotLinesMenu.add_command(
            label=label,
            command=self._ctrl.show_plot_grid,
        )

        self._ctrl.register_client(self.plotLinesMenu)

        self.prjNoteMenu = NvMenu()

        label = _('Add')
        self.prjNoteMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_project_note,
        )
        self.prjNoteMenu.disableOnLock.append(label)

        self.prjNoteMenu.add_separator()
        self.add_color_commands(self.prjNoteMenu, prefix=PRJ_NOTE_PREFIX)
        self.prjNoteMenu.add_separator()

        label = _('Export project notes for editing')
        self.prjNoteMenu.add_command(
            label=label,
            command=self._ctrl.export_project_notes,
        )
        self.prjNoteMenu.disableOnLock.append(label)

        self.prjNoteMenu.add_separator()

        label = _('Show table in Browser')
        self.prjNoteMenu.add_command(
            label=label,
            command=self._ctrl.show_projectnotes_list,
        )

        self._ctrl.register_client(self.prjNoteMenu)

        self.exportMenu = NvMenu()

        label = _('Manuscript for editing')
        self.exportMenu.add_command(
            label=label,
            image=self.icons.manuscriptIcon,
            compound='left',
            command=self._ctrl.export_manuscript,
        )
        self.exportMenu.disableOnLock.append(label)
        self.exportMenu.disableOnClose.append(label)

        label = _('Manuscript for third-party word processing')
        self.exportMenu.add_command(
            label=label,
            command=self._ctrl.export_proofing_manuscript,
        )
        self.exportMenu.disableOnLock.append(label)
        self.exportMenu.disableOnClose.append(label)

        label = _('Manuscript including unused text')
        self.exportMenu.add_command(
            label=label,
            command=self._ctrl.export_manuscript_with_unused,
        )
        self.exportMenu.disableOnLock.append(label)
        self.exportMenu.disableOnClose.append(label)

        label = _('Metadata text table for editing')
        self.exportMenu.add_command(
            label=label,
            command=self._ctrl.export_metadata_text,
        )
        self.exportMenu.disableOnLock.append(label)
        self.exportMenu.disableOnClose.append(label)

        self.exportMenu.add_separator()

        label = _('Final manuscript document (export only)')
        self.exportMenu.add_command(
            label=label,
            command=self._ctrl.export_final_document,
        )
        self.exportMenu.disableOnClose.append(label)

        label = _('Brief synopsis (export only)')
        self.exportMenu.add_command(
            label=label,
            command=self._ctrl.export_brief_synopsis,
        )
        self.exportMenu.disableOnClose.append(label)

        label = _('Cross references (export only)')
        self.exportMenu.add_command(
            label=label,
            command=self._ctrl.export_cross_references,
        )
        self.exportMenu.disableOnClose.append(label)

        self.exportMenu.add_separator()

        label = _('XML data files')
        self.exportMenu.add_command(
            label=label,
            image=self.icons.exportIcon,
            compound='left',
            command=self._ctrl.export_xml_data_files,
        )
        self.exportMenu.disableOnClose.append(label)

        self.exportMenu.add_separator()

        label = _('Options')
        self.exportMenu.add_command(
            label=label,
            image=self.icons.settingsIcon,
            compound='left',
            command=self._ctrl.open_export_options,
        )

        self._ctrl.register_client(self.exportMenu)

        self.toolsMenu = NvMenu()

        label = _('Backup options')
        self.toolsMenu.add_command(
            label=label,
            image=self.icons.settingsIcon,
            compound='left',
            command=self._ctrl.open_backup_options,
        )

        self.toolsMenu.add_separator()

        label = _('Open installation folder')
        self.toolsMenu.add_command(
            label=label,
            image=self.icons.installationFolderIcon,
            compound='left',
            command=self._ctrl.open_installationFolder,
        )

        self.toolsMenu.add_separator()

        label = _('Plugin Manager')
        self.toolsMenu.add_command(
            label=label,
            image=self.icons.pluginsIcon,
            compound='left',
            command=self._ctrl.open_plugin_manager,
        )

        self.toolsMenu.add_separator()

        label = _('Show notes')
        self.toolsMenu.add_command(
            label=label,
            image=self.icons.stickyNoteIcon,
            compound='left',
            command=self._ctrl.show_notes_list,
        )
        self.toolsMenu.disableOnClose.append(label)

        self.toolsMenu.add_separator()

        self._ctrl.register_client(self.toolsMenu)

        self.helpMenu = NvMenu()

        label = _('Online help')
        self.helpMenu.add_command(
            label=label,
            accelerator=KEYS.OPEN_HELP[1],
            image=self.icons.helpIcon,
            compound='left',
            command=self._ctrl.open_help,
        )

        label = _('About novelibre')
        self.helpMenu.add_command(
            label=label,
            image=self.icons.nLogoIcon,
            compound='left',
            command=self._about,
        )

        label = f"novelibre {_('Home page')}"
        self.helpMenu.add_command(
            label=label,
            image=self.icons.homeIcon,
            compound='left',
            command=self._ctrl.open_homepage,
        )

        label = _('News about novelibre')
        self.helpMenu.add_command(
            label=label,
            image=self.icons.newsIcon,
            compound='left',
            command=self._ctrl.open_news,
        )

        self.helpMenu.add_separator()

        self._ctrl.register_client(self.helpMenu)

        self.mainMenu = NvMenu()

        label = _('File')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.fileMenu,
        )

        label = _('View')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.viewMenu
        )

        label = _('Chapter')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.chapterMenu,
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Section')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.sectionMenu,
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Story structure')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.storyStructureMenu
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Plot lines')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.plotLinesMenu
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Characters')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.characterMenu,
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Locations')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.locationMenu,
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Items')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.itemMenu,
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Project notes')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.prjNoteMenu,
        )
        self.mainMenu.disableOnClose.append(label)

        label = _('Import')
        self.mainMenu.add_command(
            label=label,
            command=self._ctrl.open_project_updater
        )
        self.mainMenu.disableOnLock.append(label)
        self.mainMenu.disableOnClose.append(label)

        label = _('Export')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.exportMenu,
        )

        label = _('Tools')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.toolsMenu
        )

        label = _('Help')
        self.mainMenu.add_cascade(
            label=label,
            menu=self.helpMenu,
        )

        self._ctrl.register_client(self.mainMenu)
        self.root.config(menu=self.mainMenu)


        self.bookContextMenu = NvContextMenu()

        self.add_chapter_part_commands(self.bookContextMenu)

        self.bookContextMenu.add_separator()

        self.add_set_status_cascade(self.bookContextMenu)
        self.add_set_viewpoint_command(self.bookContextMenu)

        self.bookContextMenu.add_separator()

        self.add_view_commands(self.bookContextMenu)

        self._ctrl.register_client(self.bookContextMenu)

        self.chapterContextMenu = NvContextMenu()

        self.add_add_section_command(self.chapterContextMenu)
        self.add_chapter_part_commands(self.chapterContextMenu)
        self.add_insert_stage_command(self.chapterContextMenu)

        self.chapterContextMenu.add_separator()

        label = _('Remove this chapter, keep sections')
        self.chapterContextMenu.add_command(
            label=label,
            command=self._ctrl.remove_chapter_keep_sections,
        )
        self.chapterContextMenu.disableOnLock.append(label)

        self.add_delete_command(self.chapterContextMenu)

        self.chapterContextMenu.add_separator()

        self.add_clipboard_commands(self.chapterContextMenu)

        self.chapterContextMenu.add_separator()

        self.add_change_level_cascade(self.chapterContextMenu)
        self.add_set_type_cascade(self.chapterContextMenu)
        self.add_set_status_cascade(self.chapterContextMenu)
        self.add_set_viewpoint_command(self.chapterContextMenu)
        self.add_color_commands(self.chapterContextMenu)

        self.chapterContextMenu.add_separator()

        label = _('Export this chapter')
        self.chapterContextMenu.add_cascade(
            label=label,
            image=self.icons.manuscriptIcon,
            compound='left',
            command=self._ctrl.export_filtered_manuscript,
        )
        self.chapterContextMenu.disableOnLock.append(label)

        self.chapterContextMenu.add_separator()

        self.add_view_commands(self.chapterContextMenu)

        self._ctrl.register_client(self.chapterContextMenu)

        self.characterContextMenu = NvContextMenu()

        self.add_add_command(self.characterContextMenu)

        self.characterContextMenu.add_separator()

        self.add_delete_command(self.characterContextMenu)

        self.characterContextMenu.add_separator()

        self.add_clipboard_commands(self.characterContextMenu)

        self.characterContextMenu.add_separator()

        self.add_set_cr_status_cascade(self.characterContextMenu)
        self.add_color_commands(self.characterContextMenu)

        self.characterContextMenu.add_separator()

        label = _('Export manuscript filtered by viewpoint')
        self.characterContextMenu.add_command(
            label=label,
            image=self.icons.manuscriptIcon,
            compound='left',
            command=self._ctrl.export_filtered_manuscript,
        )
        self.characterContextMenu.disableOnLock.append(label)

        label = _('Export synopsis filtered by viewpoint')
        self.characterContextMenu.add_command(
            label=label,
            command=self._ctrl.export_filtered_synopsis,
        )
        self.characterContextMenu.disableOnLock.append(label)

        self.characterContextMenu.add_separator()

        self.add_view_commands(self.characterContextMenu)

        self.characterContextMenu.add_separator()

        label = _('Highlight sections with this viewpoint')
        self.characterContextMenu.add_command(
            label=label,
            image=self.icons.highlightIcon,
            compound='left',
            command=self.tv.highlight_viewpoint_sections,
        )

        self.add_highlight_related_command(self.characterContextMenu)

        self._ctrl.register_client(self.characterContextMenu)

        self.crRootContextMenu = NvContextMenu()

        self.add_add_command(self.crRootContextMenu)

        self.crRootContextMenu.add_separator()

        self.add_set_cr_status_cascade(self.crRootContextMenu)

        self.crRootContextMenu.add_separator()

        self.add_view_commands(self.crRootContextMenu)

        self._ctrl.register_client(self.crRootContextMenu)

        self.elementContextMenu = NvContextMenu()

        self.add_add_command(self.elementContextMenu)

        self.elementContextMenu.add_separator()

        self.add_delete_command(self.elementContextMenu)

        self.elementContextMenu.add_separator()

        self.add_clipboard_commands(self.elementContextMenu)

        self.elementContextMenu.add_separator()
        self.add_color_commands(self.elementContextMenu)
        self.elementContextMenu.add_separator()

        self.add_view_commands(self.elementContextMenu)

        self.elementContextMenu.add_separator()

        self.add_highlight_related_command(self.elementContextMenu)

        self._ctrl.register_client(self.elementContextMenu)

        self.plotLineContextMenu = NvContextMenu()

        label = _('Add Plot line')
        self.plotLineContextMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_plot_line,
        )
        self.plotLineContextMenu.disableOnLock.append(label)

        label = _('Add Plot point')
        self.plotLineContextMenu.add_command(
            label=label,
            image=self.icons.addIcon,
            compound='left',
            command=self._ctrl.add_new_plot_point,
        )
        self.plotLineContextMenu.disableOnLock.append(label)

        self.plotLineContextMenu.add_separator()

        self.add_delete_command(self.plotLineContextMenu)

        self.plotLineContextMenu.add_separator()

        self.add_clipboard_commands(self.plotLineContextMenu)

        self.plotLineContextMenu.add_separator()
        self.add_color_commands(self.plotLineContextMenu)
        self.plotLineContextMenu.add_separator()

        label = _('Change sections to Unused')
        self.plotLineContextMenu.add_command(
            label=label,
            command=self._ctrl.exclude_plot_line,
        )
        self.plotLineContextMenu.disableOnLock.append(label)

        label = _('Change sections to Normal')
        self.plotLineContextMenu.add_command(
            label=label,
            command=self._ctrl.include_plot_line
        )
        self.plotLineContextMenu.disableOnLock.append(label)

        self.plotLineContextMenu.add_separator()

        label = _('Export manuscript filtered by plot line')
        self.plotLineContextMenu.add_command(
            label=label,
            image=self.icons.manuscriptIcon,
            compound='left',
            command=self._ctrl.export_filtered_manuscript,
        )
        self.plotLineContextMenu.disableOnLock.append(label)

        label = _('Export synopsis filtered by plot line')
        self.plotLineContextMenu.add_command(
            label=label,
            command=self._ctrl.export_filtered_synopsis,
        )
        self.plotLineContextMenu.disableOnLock.append(label)

        self.plotLineContextMenu.add_separator()

        self.add_view_commands(self.plotLineContextMenu)

        self.plotLineContextMenu.add_separator()

        self.add_highlight_related_command(self.plotLineContextMenu)

        self._ctrl.register_client(self.plotLineContextMenu)

        self.rootContextMenu = NvContextMenu()

        self.add_add_command(self.rootContextMenu)

        self.rootContextMenu.add_separator()

        self.add_view_commands(self.rootContextMenu)

        self._ctrl.register_client(self.rootContextMenu)

        self.sectionContextMenu = NvContextMenu()

        self.add_add_section_command(self.sectionContextMenu)
        self.add_insert_stage_command(self.sectionContextMenu)

        label = _('Insert Chapter')
        self.sectionContextMenu.add_command(
            label=label,
            command=self._ctrl.insert_chapter,
        )
        self.sectionContextMenu.disableOnLock.append(label)

        self.add_clone_command(self.sectionContextMenu)
        label = _('Join with previous')
        self.sectionContextMenu.add_command(
            label=label,
            command=self._ctrl.join_sections,
        )
        self.sectionContextMenu.disableOnLock.append(label)

        self.sectionContextMenu.add_separator()

        self.add_delete_command(self.sectionContextMenu)

        self.sectionContextMenu.add_separator()

        self.add_clipboard_commands(self.sectionContextMenu)

        self.sectionContextMenu.add_separator()

        self.add_set_type_cascade(self.sectionContextMenu)
        self.add_set_status_cascade(self.sectionContextMenu)
        self.add_set_viewpoint_command(self.sectionContextMenu)
        self.add_color_commands(self.sectionContextMenu)

        self.sectionContextMenu.add_separator()

        self.add_view_commands(self.sectionContextMenu)

        self._ctrl.register_client(self.sectionContextMenu)

        self.stageContextMenu = NvContextMenu()

        self.add_add_section_command(self.stageContextMenu)
        self.add_insert_stage_command(self.stageContextMenu)

        self.stageContextMenu.add_separator()

        self.add_delete_command(self.stageContextMenu)

        self.stageContextMenu.add_separator()

        self.add_clipboard_commands(self.stageContextMenu)

        self.stageContextMenu.add_separator()

        self.add_change_level_cascade(self.stageContextMenu)

        self.stageContextMenu.add_separator()

        self.add_view_commands(self.stageContextMenu)

        self._ctrl.register_client(self.stageContextMenu)

        self.trashContextMenu = NvContextMenu()

        self.add_delete_command(self.trashContextMenu)

        self._ctrl.register_client(self.trashContextMenu)

        self.contextMenu = TreeContextMenu(self._mdl, self)

from tkinter import messagebox



class MsgBoxes:

    def ask_delete_all_skip_cancel(self, text, default=0, title='novelibre'):
        return SimpleDialog(
            None,
            text=text,
            buttons=[
                _('Delete'),
                _('All'),
                _('Skip'),
                _('Cancel'),
            ],
            default=default,
            cancel=3,
            title=title
        ).go()

    def ask_ok_cancel(
            self,
            message='',
            detail='',
            title='novelibre',
            **options
    ):
        return messagebox.askokcancel(
            message=message,
            detail=detail,
            title=title,
            **options
        )

    def ask_overwrite_open_cancel(self, text, default=0, title='novelibre'):
        return SimpleDialog(
            None,
            text=text,
            buttons=[_('Overwrite'), _('Open existing'), _('Cancel')],
            default=default,
            cancel=2,
            title=title
        ).go()

    def ask_yes_no(self, message='', detail='', title='novelibre', **options):
        return messagebox.askyesno(
            message=message,
            detail=detail,
            title=title,
            **options
        )

    def ask_yes_no_cancel(
            self,
            message='',
            detail='',
            title='novelibre',
            **options
    ):
        return messagebox.askyesnocancel(
            message=message,
            detail=detail,
            title=title,
            **options
        )

    def show_error(self, message='', detail='', title='novelibre', **options):
        messagebox.showerror(
            message=message,
            detail=detail,
            title=title,
            **options
        )

    def show_info(self, message='', detail='', title='novelibre', **options):
        messagebox.showinfo(
            message=message,
            detail=detail,
            title=title,
            **options
        )

    def show_warning(
            self,
            message='',
            detail='',
            title='novelibre',
            **options
    ):
        messagebox.showwarning(
            message=message,
            detail=detail,
            title=title,
            **options
        )

from tkinter import ttk

from tkinter import ttk

from tkinter import colorchooser
from tkinter import filedialog
from tkinter import ttk

from tkinter import ttk



class BlankView(ttk.Frame, SubController):

    def __init__(self, parent, model, view, controller, **kw):
        super().__init__(parent, **kw)
        self._parent = parent
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.element = None

    def apply_changes(self, event=None):
        pass

    def configure_display(self):
        pass

    def focus_title(self):
        pass

    def hide(self):
        self.element = None
        self.pack_forget()

    def set_data(self, elementId):
        pass

    def show(self):
        self.pack(expand=True, fill='both')

from tkinter import ttk



class TooltipBase:

    def __init__(self, anchor_widget):
        self.anchor_widget = anchor_widget
        self.tipwindow = None

    def __del__(self):
        self.hidetip()

    def showtip(self):
        if self.tipwindow:
            return
        self.tipwindow = tw = tk.Toplevel(self.anchor_widget)
        tw.wm_overrideredirect(1)
        try:
            tw.tk.call("::tk::unsupported::MacWindowStyle", "style", tw._w,
                       "help", "noActivates")
        except tk.TclError:
            pass

        self.position_window()
        self.showcontents()
        self.tipwindow.update_idletasks()  # Needed on MacOS -- see #34275.
        self.tipwindow.lift()  # work around bug in Tk 8.5.18+ (issue #24570)

    def position_window(self):
        x, y = self.get_position()
        root_x = self.anchor_widget.winfo_rootx() + x
        root_y = self.anchor_widget.winfo_rooty() + y
        self.tipwindow.wm_geometry("+%d+%d" % (root_x, root_y))

    def get_position(self):
        return 20, self.anchor_widget.winfo_height() + 1

    def showcontents(self):
        raise NotImplementedError

    def hidetip(self):
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            try:
                tw.destroy()
            except tk.TclError:  # pragma: no cover
                pass


class OnHoverTooltipBase(TooltipBase):

    def __init__(self, anchor_widget, hover_delay=1000):
        super().__init__(anchor_widget)
        self.hover_delay = hover_delay

        self._after_id = None
        self._id1 = self.anchor_widget.bind("<Enter>", self._show_event)
        self._id2 = self.anchor_widget.bind("<Leave>", self._hide_event)
        self._id3 = self.anchor_widget.bind("<Button>", self._hide_event)

    def __del__(self):
        try:
            self.anchor_widget.unbind("<Enter>", self._id1)
            self.anchor_widget.unbind("<Leave>", self._id2)  # pragma: no cover
            self.anchor_widget.unbind("<Button>", self._id3)  # pragma: no cover
        except tk.TclError:
            pass
        super().__del__()

    def _show_event(self, event=None):
        if self.hover_delay:
            self.schedule()
        else:
            self.showtip()

    def _hide_event(self, event=None):
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self._after_id = self.anchor_widget.after(self.hover_delay,
                                                  self.showtip)

    def unschedule(self):
        after_id = self._after_id
        self._after_id = None
        if after_id:
            self.anchor_widget.after_cancel(after_id)

    def hidetip(self):
        try:
            self.unschedule()
        except tk.TclError:  # pragma: no cover
            pass
        super().hidetip()


class Hovertip(OnHoverTooltipBase):
    "A tooltip that pops up when a mouse hovers over an anchor widget."

    def __init__(self, anchor_widget, text, hover_delay=1000):
        super().__init__(anchor_widget, hover_delay=hover_delay)
        self.text = text

    def showcontents(self):
        label = tk.Label(self.tipwindow, text=self.text, justify='left',
                      background="#ffffe0", relief='solid', borderwidth=1)
        label.pack()



class CollectionBox(ttk.Frame):

    def __init__(
        self,
        master,
        cmdAdd=None,
        lblAdd=None,
        iconAdd=None,
        cmdOpen=None,
        lblOpen=None,
        iconOpen=None,
        cmdRemove=None,
        lblRemove=None,
        iconRemove=None,
        cmdSelect=None,
        **kw
    ):

        def on_change_selection(event=None):
            if cmdSelect is not None:
                try:
                    cmdSelect(self._cList.curselection()[0])
                except:
                    pass

        super().__init__(master, **kw)

        listFrame = ttk.Frame(self)
        listFrame.pack(side='left', fill='both', expand=True)

        self._cListVar = tk.StringVar()
        self._cList = tk.Listbox(
            listFrame,
            listvariable=self._cListVar,
            selectmode='single',
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
        )
        vbar = ttk.Scrollbar(
            listFrame,
            orient='vertical',
            command=self._cList.yview,
        )
        vbar.pack(side='right', fill='y')
        self._cList.pack(
            side='left',
            fill='both',
            expand=True,
        )
        self._cList.config(yscrollcommand=vbar.set)
        self._cList.bind('<<ListboxSelect>>', on_change_selection)
        self._cList.configure(exportselection=False)

        buttonbar = ttk.Frame(self)
        buttonbar.pack(anchor='n', side='right', fill='x', padx=5)
        self.inputWidgets = []

        kwargs = dict(
            command=cmdOpen,
            image=iconOpen,
        )
        if lblOpen is None:
            kwargs['text'] = _('Open')
        else:
            kwargs['text'] = lblOpen
        self.btnOpen = ttk.Button(buttonbar, **kwargs)
        if cmdOpen is not None:
            self.btnOpen.pack(fill='x', expand=True)
            self._cList.bind('<Double-1>', cmdOpen)
            self._cList.bind('<Return>', cmdOpen)

        kwargs = dict(
            command=cmdAdd,
            image=iconAdd,
        )
        if lblAdd is None:
            kwargs['text'] = _('Add')
        else:
            kwargs['text'] = lblAdd
        self.btnAdd = ttk.Button(buttonbar, **kwargs)
        if cmdAdd is not None:
            self.btnAdd.pack(fill='x', expand=True)
            self.inputWidgets.append(self.btnAdd)

        kwargs = dict(
            command=cmdRemove,
            image=iconRemove,
        )
        if lblRemove is None:
            kwargs['text'] = _('Remove')
        else:
            kwargs['text'] = lblRemove
        self.btnRemove = ttk.Button(buttonbar, **kwargs)
        if cmdRemove is not None:
            self.btnRemove.pack(fill='x', expand=True)
            self.inputWidgets.append(self.btnRemove)
            self._cList.bind(KEYS.DELETE[0], cmdRemove)

        self._set_hovertips()

    @property
    def selection(self):
        try:
            return self._cList.curselection()[0]

        except:
            return None

    @selection.setter
    def selection(self, listIndex):
        try:
            self._cList.selection_set(listIndex)
        except:
            pass

    def enable_buttons(self, event=None):
        self.btnOpen.config(state='normal')
        self.btnRemove.config(state='normal')

    def disable_buttons(self, event=None):
        self.btnOpen.config(state='disabled')
        self.btnRemove.config(state='disabled')

    def set(self, newList):
        self._cList.selection_clear(0, 'end')
        self._cListVar.set(newList)
        self.disable_buttons()

    def set_height(self, newVal):
        self._cList.config(height=newVal)

    def _set_hovertips(self):
        if not prefs['enable_hovertips']:
            return

        Hovertip(
            self.btnAdd,
            self.btnAdd['text']
        )
        Hovertip(
            self.btnOpen,
            self.btnOpen['text']
        )
        Hovertip(
            self.btnRemove,
            f"{self.btnRemove['text']} ({KEYS.DELETE[1]})"
        )
from tkinter import ttk


class FoldingFrame(ttk.Frame):
    _PREFIX_SHOW = '▽  '
    _PREFIX_HIDE = '▷  '

    def __init__(self, parent, buttonText, command, **kw):
        super().__init__(parent, **kw)
        self.buttonText = buttonText
        self.titleBar = ttk.Frame(parent)
        self.titleBar.pack(fill='x', expand=False)
        self._toggleButton = ttk.Label(self.titleBar)
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self._toggleButton.pack(side='left', fill='x', expand=True, pady=2)
        self._toggleButton.bind('<Button-1>', command)

    def show(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_SHOW}{self.buttonText}'
        self.pack(after=self.titleBar, fill='x', pady=5)

    def hide(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self.pack_forget()

from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = (
                vars(tk.Pack).keys()
                | vars(tk.Grid).keys()
                | vars(tk.Place).keys()
            )
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return text

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self, default=None):
        value = super().get()
        if value == '':
            value = default
            if default is not None:
                self.set(default)
        return value


class IndexCard(tk.Frame):

    def __init__(
            self,
            master=None,
            cnf={},
            fg='black',
            bg='white',
            font=None,
            scrollbar=True,
            **kw
    ):
        super().__init__(master=master, cnf=cnf, **kw)
        self._bgColor = bg

        titleFrame = tk.Frame(
            self,
            background=bg,
        )
        titleFrame.pack(
            fill='x',
        )
        self.colorField = tk.Label(
            titleFrame,
            width=2,
            background=bg,
        )
        self.colorField.pack(
            side='right',
            expand=False,
        )
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            titleFrame,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
            background=bg,
            foreground=fg,
            insertbackground=fg,
        )
        self.titleEntry.pack(
            side='left',
            ipady=6,
            fill='x',
            expand=True,
        )

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
        )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def reset_color(self):
        self.colorField.configure(
            bg=self._bgColor,
            text='◈',
        )

    def set_color(self, color):
        self.colorField.configure(
            bg=color,
            text='',
        )

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')


class ElementView(BlankView):
    _HELP_PAGE = 'properties.html'
    _LABEL_WIDTH = 15

    _HEIGHT_LIMIT = 10
    _CHECK = '☑'

    def __init__(self, parent, model, view, controller, **kw):
        super().__init__(parent, model, view, controller, **kw)
        self._pickingMode = False
        self._pickCommand = None
        self.isLocked = False
        self._uiEscBinding = ''
        self._uiBtn1Binding = ''
        self._lastSelected = ''
        self._doNotUpdate = False
        self._colorFieldIsActive = False

        self.elementId = None
        self.inputWidgets = []

        self._propertiesFrame = ttk.Frame(self)
        self._propertiesFrame.pack(expand=True, fill='both')

        self._prefsShowLinks = None
        self._create_frames()

    def add_link(self):
        fileTypes = [
            (_('Image file'), '.jpg'),
            (_('Image file'), '.jpeg'),
            (_('Image file'), '.png'),
            (_('Image file'), '.gif'),
            (_('Text file'), '.txt'),
            (_('Text file'), '.md'),
            (_('ODF document'), '.odt'),
            (_('ODF document'), '.ods'),
            (_('All files'), '.*'),
            ]
        selectedPath = filedialog.askopenfilename(filetypes=fileTypes)
        if selectedPath:
            shortPath = self._ctrl.linkProcessor.shorten_path(selectedPath)
            links = self.element.links
            if links is None:
                links = {}
            links[shortPath] = selectedPath
            self.element.links = links

    def apply_changes(self, event=None):
        if self.element is None:
            return

        titleStr = self._indexCard.title.get()
        if titleStr:
            titleStr = titleStr.strip()
        elif self.elementId != CH_ROOT:
            titleStr = self.elementId
        self.element.title = titleStr

        if self._indexCard.bodyBox.hasChanged:
            self.element.desc = self._indexCard.bodyBox.get_text()

        if hasattr(self.element, 'notes') and self.notesWindow.hasChanged:
            self.element.notes = self.notesWindow.get_text()

    def configure_display(self):

        if hasattr(self.element, 'links'):
            if prefs[self._prefsShowLinks]:
                self.linksWindow.show()
                self.linksPreviewVar.set('')
            else:
                self.linksWindow.hide()
                linksCount = len(self.element.links)
                if linksCount:
                    self.linksPreviewVar.set(str(linksCount))
                else:
                    self.linksPreviewVar.set('')

    def focus_title(self):
        self._indexCard.titleEntry.focus()
        self._indexCard.titleEntry.icursor(0)
        self._indexCard.titleEntry.selection_range(0, 'end')

    def lock(self):
        self._indexCard.lock()
        try:
            self.notesWindow.config(state='disabled')
        except:
            pass
        for widget in self.inputWidgets:
            widget.config(state='disabled')
        self.isLocked = True

    def open_link(self, event=None):
        linkIndex = self.linkCollection.selection
        if linkIndex is not None:
            self._ctrl.open_link(self.element, linkIndex)

    def set_data(self, elementId):
        self.elementId = elementId
        if self.element is None:
            return

        self.configure_display()

        self._indexCard.title.set(self.element.title)

        self._indexCard.bodyBox.clear()
        self._indexCard.bodyBox.set_text(self.element.desc)

        if hasattr(self.element, 'links'):
            self.linkCollection.set([
                os.path.basename(path) for path in self.element.links
            ])
            listboxSize = len(self.element.links)
            if listboxSize > self._HEIGHT_LIMIT:
                listboxSize = self._HEIGHT_LIMIT
            self.linkCollection.set_height(listboxSize)
            self._configure_link_buttons()

        if hasattr(self.element, 'notes'):
            self.notesWindow.clear()
            self.notesWindow.set_text(self.element.notes)

        if self._colorFieldIsActive:
            if self.element.color is not None:
                self._indexCard.set_color(self.element.color)
            else:
                self._indexCard.reset_color()

    def unlock(self):
        self._indexCard.unlock()
        try:
            self.notesWindow.config(state='normal')
        except:
            pass
        for widget in self.inputWidgets:
            widget.config(state='normal')
        self.isLocked = False
        if hasattr(self.element, 'links'):
            self._configure_link_buttons()

    def _activate_color_field(self):
        self._colorFieldIsActive = True
        self._indexCard.colorField.bind(
            MOUSE.CHOOSE_COLOR,
            self._set_color,
        )
        self._indexCard.colorField.bind(
            MOUSE.RESET_COLOR,
            self._ctrl.reset_color,
        )
        Hovertip(
            self._indexCard.colorField,
            _('Color'),
        )

    def _add_separator(self):
        ttk.Separator(
            self._propertiesFrame,
            orient='horizontal'
        ).pack(fill='x')

    def _set_color(self, event=None):
        self._ctrl.set_color(
            title=f"{_('Choose color')}: {self.element.title}"
        )

    def _configure_link_buttons(self, event=None):
        if self.element.links and self.linkCollection.selection is not None:
            if self.isLocked:
                self.linkCollection.btnOpen.config(state='normal')
                self.linkCollection.btnRemove.config(state='disabled')
            else:
                self.linkCollection.enable_buttons()
        else:
            self.linkCollection.disable_buttons()

    def _create_button_bar(self):
        self._buttonBar = ttk.Frame(self)
        self._buttonBar.pack(fill='x')

        ttk.Button(
            self._buttonBar,
            text=_('Previous'),
            command=self._ui.tv.load_prev,
        ).pack(side='left', fill='x', expand=True, padx=1, pady=2)

        ttk.Button(
            self._buttonBar,
            text=_('Online help'),
            command=self._open_help,
        ).pack(side='left', fill='x', expand=True, padx=1, pady=2)

        ttk.Button(
            self._buttonBar,
            text=_('Next'),
            command=self._ui.tv.load_next,
        ).pack(side='left', fill='x', expand=True, padx=1, pady=2)

    def _create_element_info_window(self):
        self._elementInfoWindow = ttk.Frame(self._propertiesFrame)
        self._elementInfoWindow.pack(fill='x')

    def _create_frames(self):
        pass

    def _create_index_card(self):
        self._indexCard = IndexCard(
            self._propertiesFrame,
            bd=2,
            fg=prefs['color_text_fg'],
            bg=prefs['color_text_bg'],
            relief='ridge'
        )
        self._indexCard.bodyBox['height'] = prefs['index_card_height']
        self._indexCard.pack(expand=False, fill='both')
        self._indexCard.titleEntry.bind('<Return>', self.apply_changes)
        self._indexCard.titleEntry.bind('<FocusOut>', self.apply_changes)
        self._indexCard.bodyBox.bind('<FocusOut>', self.apply_changes)

    def _create_links_window(self):
        ttk.Separator(
            self._propertiesFrame,
            orient='horizontal'
        ).pack(fill='x')
        self.linksWindow = FoldingFrame(
            self._propertiesFrame,
            _('Links'),
            self._toggle_links_window
        )
        self.linksWindow.pack(fill='x')

        self.linksPreviewVar = MyStringVar()
        linksPreview = ttk.Label(
            self.linksWindow.titleBar,
            textvariable=self.linksPreviewVar,
        )
        linksPreview.pack(side='left', padx=2)
        linksPreview.bind('<Button-1>', self._toggle_links_window)

        self.linkCollection = CollectionBox(
            self.linksWindow,
            cmdAdd=self.add_link,
            cmdRemove=self._remove_link,
            cmdOpen=self.open_link,
            lblOpen=_('Open link'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon,
            cmdSelect=self._configure_link_buttons,
        )
        self.inputWidgets.extend(self.linkCollection.inputWidgets)
        self.linkCollection.pack(fill='x')

    def _create_notes_window(self):
        self.notesWindow = TextBox(
            self._propertiesFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=0,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_notes_bg'],
            fg=prefs['color_notes_fg'],
            insertbackground=prefs['color_notes_fg'],
        )
        self.notesWindow.pack(expand=True, fill='both')
        self.notesWindow.bind('<FocusOut>', self.apply_changes)

    def _end_picking_mode(self, event=None):
        if self._pickingMode:
            if self._pickCommand is not None:
                self._pickCommand()
                self._pickCommand = None
            self._ui.root.bind('<Button-1>', self._uiBtn1Binding)
            self._ui.root.bind('<Escape>', self._uiEscBinding)
            self._ui.tv.config(cursor='arrow')
            self._ui.tv.see_node(self._lastSelected)
            self._ui.tv.tree.selection_set(self._lastSelected)
            self._pickingMode = False
        self._ui.restore_status()

    def _open_help(self, event=None):
        NvHelp.open_help_page(self._HELP_PAGE)

    def _remove_link(self, event=None):
        try:
            selection = self.linkCollection.selection
        except:
            return

        linkPath = list(self.element.links)[selection]
        if self._ui.ask_yes_no(
            message=_('Remove link?'),
            detail=norm_path(self.element.links[linkPath]),
            ):
            links = self.element.links
            try:
                del links[linkPath]
            except:
                pass
            else:
                self.element.links = links

    def _report_missing_reference_date(self):
        self._ui.show_error(
            message=_('Cannot convert date/days'),
            detail=f"{_('Please enter a reference date')}."
            )

    def _start_picking_mode(self, event=None, command=None):
        self._pickCommand = command
        if not self._pickingMode:
            self._lastSelected = self._ui.selectedNode
            self._ui.tv.config(cursor='plus')
            self._uiEscBinding = self._ui.root.bind('<Escape>')
            self._ui.root.bind('<Escape>', self._end_picking_mode)
            self._uiBtn1Binding = self._ui.root.bind('<Button-1>')
            self._ui.root.bind('<Button-1>', self._end_picking_mode)
            self._pickingMode = True
        self._ui.set_status(
            _('Pick Mode (click here or press Esc to exit)'),
            colors=('maroon', 'white')
        )

    def _toggle_folding_frame(self):
        if not self._ctrl.isLocked:
            self.apply_changes()
        self.configure_display()

    def _toggle_links_window(self, event=None):
        if prefs[self._prefsShowLinks]:
            self.linksWindow.hide()
            prefs[self._prefsShowLinks] = False
        else:
            self.linksWindow.show()
            prefs[self._prefsShowLinks] = True
        self._toggle_folding_frame()



class ChapterView(ElementView):
    _HELP_PAGE = 'chapter_view.html'

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._isUnusedVar = tk.BooleanVar()
        self._isUnusedCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            text=_('Unused'),
            variable=self._isUnusedVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._isUnusedCheckbox.pack(anchor='w')
        inputWidgets.append(self._isUnusedCheckbox)

        self._noNumberVar = tk.BooleanVar()
        self._noNumberCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            variable=self._noNumberVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._noNumberCheckbox.pack(anchor='w')
        inputWidgets.append(self._noNumberCheckbox)

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._hasEpigraphVar = tk.BooleanVar()
        self._hasEpigraphCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            text=_('The first section is an epigraph'),
            variable=self._hasEpigraphVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._hasEpigraphCheckbox.pack(anchor='w')
        inputWidgets.append(self._hasEpigraphCheckbox)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self.inputWidgets.append(widget)

        self._prefsShowLinks = 'show_ch_links'

    def apply_changes(self, event=None):
        if self.element is None:
            return

        if self.element.isTrash:
            return

        super().apply_changes()

        if self._isUnusedVar.get():
            self._ctrl.set_type_unused()
        else:
            self._ctrl.set_type_normal()

        self.element.noNumber = self._noNumberVar.get()

        self.element.hasEpigraph = self._hasEpigraphVar.get()

    def set_data(self, elementId):
        self.element = self._mdl.novel.chapters[elementId]
        super().set_data(elementId)

        if self.element.chType > 0:
            self._isUnusedVar.set(True)
        else:
            self._isUnusedVar.set(False)

        if self.element.chLevel == 1:
            labelText = _('Do not auto-number this part')
        else:
            labelText = _('Do not auto-number this chapter')
        self._noNumberCheckbox.configure(text=labelText)
        self._noNumberVar.set(self.element.noNumber)

        self._hasEpigraphVar.set(self.element.hasEpigraph)

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

from tkinter import ttk

from tkinter import ttk

from tkinter import ttk


class LabelEntry(ttk.Frame):

    def __init__(self, parent, text, textvariable, command, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self.entry = ttk.Entry(self, textvariable=textvariable)
        self.entry.pack(side='left', fill='x', expand=True)
        self.entry.bind('<Return>', command)

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None, state=None):
        if text is not None:
            self._label['text'] = text
        if state is not None:
            self.entry.config(state=state)


class WorldElementView(ElementView):
    _HELP_PAGE = 'world_view.html'

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._fullNameFrame = ttk.Frame(self._elementInfoWindow)
        self._fullNameFrame.pack(anchor='w', fill='x')

        self._akaVar = MyStringVar()
        self._akaEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('AKA'),
            textvariable=self._akaVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._akaEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._akaEntry)

        self._tagsVar = MyStringVar()
        self._tagsEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Tags'),
            textvariable=self._tagsVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._tagsEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._tagsEntry)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self.inputWidgets.append(widget)

    def apply_changes(self, event=None):
        if self.element is None:
            return

        super().apply_changes()

        self.element.aka = self._akaVar.get()

        self.element.tags = string_to_list(self._tagsVar.get())

    def set_data(self, elementId):
        super().set_data(elementId)

        self._akaVar.set(self.element.aka)

        self._tagsVar.set(list_to_string(self.element.tags))

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()



class CharacterView(WorldElementView):
    _HELP_PAGE = 'character_view.html'
    _LABEL_WIDTH = 15

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._fullNameVar = MyStringVar()
        self._fullNameEntry = LabelEntry(
            self._fullNameFrame,
            text=_('Full name'),
            textvariable=self._fullNameVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._fullNameEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._fullNameEntry)

        self._isMajorVar = tk.BooleanVar()
        self._isMajorCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            text=_('Major Character'),
            variable=self._isMajorVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._isMajorCheckbox.pack(anchor='w')
        inputWidgets.append(self._isMajorCheckbox)

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._birthDateVar = MyStringVar()
        self._birthDateEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Birth date'),
            textvariable=self._birthDateVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._birthDateEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._birthDateEntry)

        self._deathDateVar = MyStringVar()
        self._deathDateEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Death date'),
            textvariable=self._deathDateVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._deathDateEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._deathDateEntry)

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._crField1Frame = FoldingFrame(
            self._elementInfoWindow,
            '',
            self._toggle_crField1_window,
        )

        self._crField1PreviewVar = MyStringVar()
        crField1Preview = ttk.Label(
            self._crField1Frame.titleBar,
            textvariable=self._crField1PreviewVar,
        )
        crField1Preview.pack(side='left', padx=2)
        crField1Preview.bind('<Button-1>', self._toggle_crField1_window)

        self._crField1Box = TextBox(
            self._crField1Frame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=10,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
        )
        self._crField1Box.pack(fill='x')
        inputWidgets.append(self._crField1Box)

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._crField2Frame = FoldingFrame(
            self._elementInfoWindow,
            '',
            self._toggle_crField2_window,
        )

        self._crField2PreviewVar = MyStringVar()
        crField2Preview = ttk.Label(
            self._crField2Frame.titleBar,
            textvariable=self._crField2PreviewVar,
        )
        crField2Preview.pack(side='left', padx=2)
        crField2Preview.bind('<Button-1>', self._toggle_crField2_window)

        self._crField2Box = TextBox(self._crField2Frame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=10,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
        )
        self._crField2Box.pack(fill='x')
        inputWidgets.append(self._crField2Box)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self.inputWidgets.append(widget)

        self._prefsShowLinks = 'show_cr_links'

    def apply_changes(self, event=None):
        if self.element is None:
            return

        super().apply_changes()

        self.element.fullName = self._fullNameVar.get()

        self.element.isMajor = self._isMajorVar.get()

        birthDateStr = self._birthDateVar.get()
        if not birthDateStr:
            self.element.birthDate = None
        elif birthDateStr != self.element.birthDate:
            try:
                PyCalendar.verified_date(birthDateStr)
            except:
                self._birthDateVar.set(self.element.birthDate)
                self._ui.show_error(
                    message=_('Input rejected'),
                    detail=(
                        f'{_("Wrong date")}: "{birthDateStr}"\n'
                        f'{_("Required")}: {PyCalendar.DATE_FORMAT}'
                    )
                )
            else:
                self.element.birthDate = birthDateStr

        deathDateStr = self._deathDateVar.get()
        if not deathDateStr:
            self.element.deathDate = None
        elif deathDateStr != self.element.deathDate:
            try:
                PyCalendar.verified_date(deathDateStr)
            except:
                self._deathDateVar.set(self.element.deathDate)
                self._ui.show_error(
                    message=_('Input rejected'),
                    detail=(
                        f'{_("Wrong date")}: "{deathDateStr}"\n'
                        f'{_("Required")}: {PyCalendar.DATE_FORMAT}'
                    )
                )
            else:
                self.element.deathDate = deathDateStr

        if self._crField1Box.hasChanged:
            self.element.bio = self._crField1Box.get_text()

        if self._crField2Box.hasChanged:
            self.element.goals = self._crField2Box.get_text()

    def configure_display(self):
        super().configure_display()

        if self._mdl.novel.crField1:
            self._crField1Frame.buttonText = self._mdl.novel.crField1
        else:
            self._crField1Frame.buttonText = f"{_('Field')} 1"
        if prefs['show_cr_field_1']:
            self._crField1Frame.show()
            self._crField1PreviewVar.set('')
        else:
            self._crField1Frame.hide()
            if self.element.bio:
                self._crField1PreviewVar.set(self._CHECK)
            else:
                self._crField1PreviewVar.set('')

        if self._mdl.novel.crField2:
            self._crField2Frame.buttonText = self._mdl.novel.crField2
        else:
            self._crField2Frame.buttonText = f"{_('Field')} 2"
        if prefs['show_cr_field_2']:
            self._crField2Frame.show()
            self._crField2PreviewVar.set('')
        else:
            self._crField2Frame.hide()
            if self.element.goals:
                self._crField2PreviewVar.set(self._CHECK)
            else:
                self._crField2PreviewVar.set('')

    def set_data(self, elementId):
        self.element = self._mdl.novel.characters[elementId]
        super().set_data(elementId)

        self._fullNameVar.set(self.element.fullName)

        self._isMajorVar.set(self.element.isMajor)

        self._birthDateVar.set(self.element.birthDate)
        self._deathDateVar.set(self.element.deathDate)

        self._crField1Box.set_text(self.element.bio)

        self._crField2Box.set_text(self.element.goals)

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _toggle_crField1_window(self, event=None):
        if prefs['show_cr_field_1']:
            self._crField1Frame.hide()
            prefs['show_cr_field_1'] = False
        else:
            self._crField1Frame.show()
            prefs['show_cr_field_1'] = True
        self._toggle_folding_frame()

    def _toggle_crField2_window(self, event=None):
        if prefs['show_cr_field_2']:
            self._crField2Frame.hide()
            prefs['show_cr_field_2'] = False
        else:
            self._crField2Frame.show()
            prefs['show_cr_field_2'] = True
        self._toggle_folding_frame()



class ItemView(WorldElementView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_it_links'

    def set_data(self, elementId):
        self.element = self._mdl.novel.items[elementId]
        super().set_data(elementId)


class LocationView(WorldElementView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_lc_links'

    def set_data(self, elementId):
        self.element = self._mdl.novel.locations[elementId]
        super().set_data(elementId)
from tkinter import ttk



class PlotLineView(ElementView):
    _HELP_PAGE = 'plotline_view.html'
    _LABEL_WIDTH = 22

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._shortNameVar = MyStringVar()
        self._shortNameEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Short name'),
            textvariable=self._shortNameVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._shortNameEntry.pack(anchor='w')
        inputWidgets.append(self._shortNameEntry)

        self._plotFrame = ttk.Frame(self._elementInfoWindow)
        self._plotFrame.pack(fill='x')
        self._nrSectionsView = ttk.Label(
            self._plotFrame,
        )
        self._nrSectionsView.pack(side='left')
        self._clearButton = ttk.Button(
            self._plotFrame,
            text=_('Clear section assignments'),
            command=self._remove_sections,
        )
        self._clearButton.pack(padx=1, pady=2)
        inputWidgets.append(self._clearButton)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self.inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pl_links'

    def apply_changes(self, event=None):
        if self.element is None:
            return

        super().apply_changes()

        self.element.shortName = self._shortNameVar.get()

    def set_data(self, elementId):
        self.element = self._mdl.novel.plotLines[elementId]
        super().set_data(elementId)

        self._shortNameVar.set(self.element.shortName)

        if self.element.sections is not None:
            i = 0
            for scId in self.element.sections:
                if self._mdl.novel.sections[scId].scType == 0:
                    i += 1
            self._nrSectionsView['text'] = f'{_("Number of sections")}: {i}'

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _remove_sections(self):
        if self._ui.ask_yes_no(
            message=_('Remove all sections from the plot line?'),
            detail=f'({self.element.shortName}) {self.element.title}'
        ):
            if self.element.sections:
                self._doNotUpdate = True
                for scId in self.element.sections:
                    print(self._mdl.novel.sections[scId].scPlotLines)
                    self._mdl.novel.sections[scId].scPlotLines.remove(
                        self.elementId)
                for ppId in self._mdl.novel.tree.get_children(self.elementId):
                    scId = self._mdl.novel.plotPoints[ppId].sectionAssoc
                    if scId is not None:
                        del(self._mdl.novel.sections[scId].scPlotPoints[ppId])
                        self._mdl.novel.plotPoints[ppId].sectionAssoc = None
                self.element.sections = []
                self.set_data(self.elementId)
                self._doNotUpdate = False

from tkinter import ttk



class PlotPointView(ElementView):
    _HELP_PAGE = 'point_view.html'

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._sectionFrame = ttk.Frame(self._elementInfoWindow)
        self._sectionFrame.pack(anchor='w', fill='x')
        ttk.Label(
            self._sectionFrame,
            text=f"{_('Section')}:"
        ).pack(anchor='w')
        self._sectionAssocTitle = tk.Label(
            self._sectionFrame,
            anchor='w',
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
        )
        self._sectionAssocTitle.pack(anchor='w', pady=2, fill='x')

        buttonBar1 = ttk.Frame(self._sectionFrame)
        buttonBar1.pack(pady=2, fill='x', expand=True)

        self._assignSectionButton = ttk.Button(
            buttonBar1,
            text=_('Assign section'),
            command=self.pick_section,
        )
        self._assignSectionButton.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._assignSectionButton)

        self._clearAssignmentButton = ttk.Button(
            buttonBar1,
            text=_('Clear assignment'),
            command=self.clear_assignment,
        )
        self._clearAssignmentButton.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._clearAssignmentButton)

        ttk.Button(
            buttonBar1,
            text=_('Go to section'),
            command=self.go_to_assigned_section).pack(
                side='left',
                fill='x',
                expand=True,
            )

        self._notesFrame = FoldingFrame(
            self._sectionFrame,
            _("The assigned section's plot line notes"),
            self._toggle_notes_frame,
        )

        self._plotNotesWindow = TextBox(
            self._notesFrame,
            wrap='word',
            height=self._indexCard.bodyBox['height'],
            padx=5,
            pady=5,
            bg=prefs['color_inactive_bg'],
            fg=prefs['color_text_fg'],
        )
        self._plotNotesWindow.pack(fill='x')

        buttonBar2 = ttk.Frame(self._notesFrame)
        buttonBar2.pack(pady=2, fill='x', expand=True)

        self._submitNotesButton = ttk.Button(
            buttonBar2,
            text=_('Replace this with the plot point description'),
            command=self._submit_plotline_notes,
        )
        self._submitNotesButton.pack(fill='x', expand=True)
        inputWidgets.append(self._submitNotesButton)

        self._adoptNotesButton = ttk.Button(
            buttonBar2,
            text=_('Replace the plot point description with this'),
            command=self._adopt_plotline_notes,
        )
        self._adoptNotesButton.pack(fill='x', expand=True)
        inputWidgets.append(self._adoptNotesButton)

        for widget in inputWidgets:
            self.inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pp_links'

    def clear_assignment(self):
        scId = self.element.sectionAssoc
        if scId is not None:
            del(self._mdl.novel.sections[scId].scPlotPoints[self.elementId])
            self.element.sectionAssoc = None

    def configure_display(self):
        super().configure_display()
        if prefs['show_plotline_notes']:
            self._notesFrame.show()
        else:
            self._notesFrame.hide()

    def go_to_assigned_section(self):
        if self.element.sectionAssoc is not None:
            targetNode = self.element.sectionAssoc
            self._ui.tv.see_node(targetNode)
            self._ui.tv.tree.selection_set(targetNode)

    def pick_section(self):
        self._ui.tv.save_branch_status()
        self._ui.tv.close_children('')
        self._ui.tv.open_children(CH_ROOT)
        self._start_picking_mode(command=self._assign_section)
        self._ui.tv.see_node(CH_ROOT)

    def set_data(self, elementId):
        self.element = self._mdl.novel.plotPoints[elementId]
        super().set_data(elementId)

        scId = self.element.sectionAssoc
        self._plotNotesWindow.config(state='normal')
        try:
            associatedSection = self._mdl.novel.sections[scId]
        except:
            sectionTitle = ''
            self._plotNotesWindow.clear()
        else:
            sectionTitle = associatedSection.title or ''
            plId = self._ui.tv.tree.parent(self.elementId)
            plotlineNotes = self._mdl.novel.sections[scId].plotlineNotes.get(plId, None)
            if plotlineNotes is None:
                self._plotNotesWindow.clear()
            else:
                self._plotNotesWindow.set_text(plotlineNotes)
        self._plotNotesWindow.config(state='disabled')
        self._sectionAssocTitle['text'] = sectionTitle

    def _adopt_plotline_notes(self):
        scId = self.element.sectionAssoc
        if scId is None:
            return

        plId = self._ui.tv.tree.parent(self.elementId)
        plotlineNotes = self._mdl.novel.sections[scId].plotlineNotes.get(plId, None)
        if plotlineNotes is not None:
            self.element.desc = plotlineNotes

    def _assign_section(self, event=None):
        nodeId = self._ui.tv.tree.selection()[0]
        if nodeId.startswith(SECTION_PREFIX):
            if self._mdl.novel.sections[nodeId].scType == 0:
                self.clear_assignment()
                plId = self._ui.tv.tree.parent(self.elementId)
                arcSections = self._mdl.novel.plotLines[plId].sections
                if arcSections is None:
                    arcSections = [nodeId]
                elif not nodeId in arcSections:
                    arcSections.append(nodeId)
                self._mdl.novel.plotLines[plId].sections = arcSections
                self._mdl.novel.sections[
                    nodeId].scPlotPoints[self.elementId] = plId
                if not plId in self._mdl.novel.sections[nodeId].scPlotLines:
                    self._mdl.novel.sections[nodeId].scPlotLines.append(plId)
                self.element.sectionAssoc = nodeId

                if not self._mdl.novel.sections[nodeId].plotlineNotes.get(plId, None):
                    self._submit_plotline_notes()
                elif not self.element.desc:
                    self._adopt_plotline_notes()

        self._ui.tv.restore_branch_status()

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _submit_plotline_notes(self):
        if not self.element.desc:
            return

        scId = self.element.sectionAssoc
        if scId is None:
            return

        plotlineNotes = self._mdl.novel.sections[scId].plotlineNotes
        plId = self._ui.tv.tree.parent(self.elementId)
        plotlineNotes[plId] = self.element.desc
        self._mdl.novel.sections[scId].plotlineNotes = plotlineNotes

    def _toggle_notes_frame(self, event=None):
        if prefs['show_plotline_notes']:
            self._notesFrame.hide()
            prefs['show_plotline_notes'] = False
        else:
            self._notesFrame.show()
            prefs['show_plotline_notes'] = True
        self._toggle_folding_frame()



class ProjectNoteView(ElementView):
    _HELP_PAGE = 'project_note_view.html'

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_pn_links'

    def set_data(self, elementId):
        self.element = self._mdl.novel.projectNotes[elementId]
        super().set_data(elementId)

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_button_bar()
from tkinter import ttk



class ProjectView(ElementView):
    _HELP_PAGE = 'book_view.html'
    _LABEL_WIDTH = 20

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._authorNameVar = MyStringVar()
        self._authorNameEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Author'),
            textvariable=self._authorNameVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._authorNameEntry.pack(anchor='w')
        inputWidgets.append(self._authorNameEntry)

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal',
        ).pack(fill='x')

        self._languageFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Document language'),
            self._toggle_language_frame,
        )

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal',
        ).pack(fill='x')


        self._localePreviewVar = MyStringVar()
        localePreview = ttk.Label(
            self._languageFrame.titleBar,
            textvariable=self._localePreviewVar,
        )
        localePreview.pack(side='left', padx=2)
        localePreview.bind('<Button-1>', self._toggle_language_frame,)

        self._languageCodeVar = MyStringVar()
        self._languageCodeEntry = LabelEntry(
            self._languageFrame,
            text=_('Language code'),
            textvariable=self._languageCodeVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._languageCodeEntry.pack(anchor='w')
        inputWidgets.append(self._languageCodeEntry)

        self._countryCodeVar = MyStringVar()
        self._countryCodeEntry = LabelEntry(
            self._languageFrame,
            text=_('Country code'),
            textvariable=self._countryCodeVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._countryCodeEntry.pack(anchor='w')
        inputWidgets.append(self._countryCodeEntry)

        self._numberingFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Auto numbering'),
            self._toggle_numbering_frame,
        )

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal',
        ).pack(fill='x')

        self._numberingPreviewVar = MyStringVar()
        numberingPreview = ttk.Label(
            self._numberingFrame.titleBar,
            textvariable=self._numberingPreviewVar,
        )
        numberingPreview.pack(side='left', padx=2)
        numberingPreview.bind('<Button-1>', self._toggle_numbering_frame)

        self._renumberChaptersVar = tk.BooleanVar(value=False)
        self._renumberChaptersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Auto number chapters when refreshing the tree'),
            variable=self._renumberChaptersVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._renumberChaptersCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberChaptersCheckbox)

        self._chapterHeadingPrefixVar = MyStringVar()
        self._chapterHeadingPrefixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Chapter number prefix'),
            textvariable=self._chapterHeadingPrefixVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._chapterHeadingPrefixEntry.pack(anchor='w')
        inputWidgets.append(self._chapterHeadingPrefixEntry)

        self._chapterHeadingSuffixVar = MyStringVar()
        self._chapterHeadingSuffixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Chapter number suffix'),
            textvariable=self._chapterHeadingSuffixVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._chapterHeadingSuffixEntry.pack(anchor='w')
        inputWidgets.append(self._chapterHeadingSuffixEntry)

        self.romanChapterNumbersVar = tk.BooleanVar()
        self._romanChapterNumbersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Use Roman chapter numbers'),
            variable=self.romanChapterNumbersVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._romanChapterNumbersCheckbox.pack(anchor='w')
        inputWidgets.append(self._romanChapterNumbersCheckbox)

        self._renumberWithinPartsVar = tk.BooleanVar()
        self._renumberWithinPartsCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Restart chapter numbering at part beginning'),
            variable=self._renumberWithinPartsVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._renumberWithinPartsCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberWithinPartsCheckbox)

        self._renumberPartsVar = tk.BooleanVar()
        self._renumberPartsCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Auto number parts when refreshing the tree'),
            variable=self._renumberPartsVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._renumberPartsCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberPartsCheckbox)

        self._partHeadingPrefixVar = MyStringVar()
        self._partHeadingPrefixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Part number prefix'),
            textvariable=self._partHeadingPrefixVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._partHeadingPrefixEntry.pack(anchor='w')
        inputWidgets.append(self._partHeadingPrefixEntry)

        self._partHeadingSuffixVar = MyStringVar()
        self._partHeadingSuffixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Part number suffix'),
            textvariable=self._partHeadingSuffixVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._partHeadingSuffixEntry.pack(anchor='w')
        inputWidgets.append(self._partHeadingSuffixEntry)

        self._romanPartNumbersVar = tk.BooleanVar()
        self._romanPartNumbersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Use Roman part numbers'),
            variable=self._romanPartNumbersVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._romanPartNumbersCheckbox.pack(anchor='w')
        inputWidgets.append(self._romanPartNumbersCheckbox)

        self._fieldNamesFame = FoldingFrame(
            self._elementInfoWindow, _('Field names'),
            self._toggle_field_names_frame,
        )

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal',
        ).pack(fill='x')
        ttk.Label(
            self._fieldNamesFame,
            text=_('Not a scene'),
        ).pack(anchor='w')

        self._noSceneField1Var = MyStringVar()
        self._noSceneField1Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 1",
            textvariable=self._noSceneField1Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._noSceneField1Entry.pack(anchor='w')
        inputWidgets.append(self._noSceneField1Entry)

        self._noSceneField2Var = MyStringVar()
        self._noSceneField2Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 2",
            textvariable=self._noSceneField2Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._noSceneField2Entry.pack(anchor='w')
        inputWidgets.append(self._noSceneField2Entry)

        self._noSceneField3Var = MyStringVar()
        self._noSceneField3Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 3",
            textvariable=self._noSceneField3Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._noSceneField3Entry.pack(anchor='w')
        inputWidgets.append(self._noSceneField3Entry)

        ttk.Separator(
            self._fieldNamesFame,
            orient='horizontal',
        ).pack(fill='x', pady=5)
        ttk.Label(
            self._fieldNamesFame,
            text=_('Other scene'),
        ).pack(anchor='w')

        self._otherSceneField1Var = MyStringVar()
        self._otherSceneField1Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 1",
            textvariable=self._otherSceneField1Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._otherSceneField1Entry.pack(anchor='w')
        inputWidgets.append(self._otherSceneField1Entry)

        self._otherSceneField2Var = MyStringVar()
        self._otherSceneField2Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 2",
            textvariable=self._otherSceneField2Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._otherSceneField2Entry.pack(anchor='w')
        inputWidgets.append(self._otherSceneField2Entry)

        self._otherSceneField3Var = MyStringVar()
        self._otherSceneField3Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 3",
            textvariable=self._otherSceneField3Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._otherSceneField3Entry.pack(anchor='w')
        inputWidgets.append(self._otherSceneField3Entry)

        ttk.Separator(
            self._fieldNamesFame,
            orient='horizontal',
        ).pack(fill='x', pady=5)

        ttk.Label(
            self._fieldNamesFame,
            text=_('Character'),
        ).pack(anchor='w'),

        self._crField1Var = MyStringVar()
        self._crField1Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 1",
            textvariable=self._crField1Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._crField1Entry.pack(anchor='w')
        inputWidgets.append(self._crField1Entry)

        self._crField2Var = MyStringVar()
        self._crField2Entry = LabelEntry(
            self._fieldNamesFame,
            text=f"{_('Field')} 2",
            textvariable=self._crField2Var,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._crField2Entry.pack(anchor='w')
        inputWidgets.append(self._crField2Entry)

        self._narrativeTimeFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Story time'),
            self._toggle_narrative_time_frame,
        )

        self._datePreviewVar = MyStringVar()
        datePreview = ttk.Label(
            self._narrativeTimeFrame.titleBar,
            textvariable=self._datePreviewVar,
        )
        datePreview.pack(side='left', padx=2)
        datePreview.bind('<Button-1>', self._toggle_narrative_time_frame)

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal',
        ).pack(fill='x')

        self._referenceDateVar = MyStringVar()
        self._referenceDateEntry = LabelEntry(
            self._narrativeTimeFrame,
            text=_('Reference date'),
            textvariable=self._referenceDateVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._referenceDateEntry.pack(anchor='w')
        inputWidgets.append(self._referenceDateEntry)

        _displayDateFrame = ttk.Frame(self._narrativeTimeFrame)
        _displayDateFrame.pack(fill='x')
        ttk.Label(
            _displayDateFrame,
            width=self._LABEL_WIDTH,
        ).pack(side='left')
        self._displayDateVar = MyStringVar()
        ttk.Label(
            _displayDateFrame,
            textvariable=self._displayDateVar,
        ).pack(anchor='w')

        self._datesToDaysButton = ttk.Button(
            self._narrativeTimeFrame,
            text=_('Convert dates to days'),
            command=self.dates_to_days,
        )
        self._datesToDaysButton.pack(
            side='left',
            fill='x',
            expand=True,
            padx=1,
            pady=2,
        )
        inputWidgets.append(self._datesToDaysButton)

        self._daysToDatesButton = ttk.Button(
            self._narrativeTimeFrame,
            text=_('Convert days to dates'),
            command=self.days_to_dates,
        )
        self._daysToDatesButton.pack(
            side='left',
            fill='x',
            expand=True,
            padx=1,
            pady=2,
        )
        inputWidgets.append(self._daysToDatesButton)

        self._progressFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Writing progress'),
            self._toggle_progress_frame
        )

        self._progressPreviewVar = MyStringVar()
        progressPreview = ttk.Label(
            self._progressFrame.titleBar,
            textvariable=self._progressPreviewVar,
        )
        progressPreview.pack(side='left', padx=2)
        progressPreview.bind('<Button-1>', self._toggle_progress_frame)

        self._saveWordCountVar = tk.BooleanVar()
        self._saveWordCountEntry = ttk.Checkbutton(
            self._progressFrame,
            text=_('Log writing progress'),
            variable=self._saveWordCountVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._saveWordCountEntry.pack(anchor='w')
        inputWidgets.append(self._saveWordCountEntry)

        ttk.Separator(
            self._progressFrame,
            orient='horizontal',
        ).pack(fill='x')

        self._wordTargetVar = MyStringVar()
        self._wordTargetEntry = LabelEntry(
            self._progressFrame,
            text=_('Words to write'),
            textvariable=self._wordTargetVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._wordTargetEntry.pack(anchor='w')
        inputWidgets.append(self._wordTargetEntry)

        self._wordCountStartVar = MyStringVar()
        self._wordCountStartEntry = LabelEntry(
            self._progressFrame,
            text=_('Starting count'),
            textvariable=self._wordCountStartVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._wordCountStartEntry.pack(anchor='w')
        inputWidgets.append(self._wordCountStartEntry)

        self._setInitialWcButton = ttk.Button(
            self._progressFrame,
            text=_('Set actual wordcount as start'),
            command=self.set_initial_wc,
        )
        self._setInitialWcButton.pack(pady=2)
        inputWidgets.append(self._setInitialWcButton)

        self._wordsWrittenVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('Words written'),
            textvariable=self._wordsWrittenVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')

        ttk.Separator(
            self._progressFrame,
            orient='horizontal',
        ).pack(fill='x')

        self._totalUsedVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('Used'),
            textvariable=self._totalUsedVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._totalOutlineVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('Outline'),
            textvariable=self._totalOutlineVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._totalDraftVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('Draft'),
            textvariable=self._totalDraftVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._total1stEditVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('1st Edit'),
            textvariable=self._total1stEditVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._total2ndEditVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('2nd Edit'),
            textvariable=self._total2ndEditVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._totalDoneVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('Done'),
            textvariable=self._totalDoneVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._totalUnusedVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('Unused'),
            textvariable=self._totalUnusedVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')
        self._totalWordsVar = MyStringVar()
        LabelDisp(
            self._progressFrame,
            text=_('All'),
            textvariable=self._totalWordsVar,
            lblWidth=self._LABEL_WIDTH,
        ).pack(anchor='w')

        phaseFrame = ttk.Frame(self._progressFrame)
        phaseFrame.pack(fill='x', expand=True)
        ttk.Label(
            phaseFrame,
            text=_('Work phase'),
            anchor='w',
            width=self._LABEL_WIDTH,
        ).pack(side='left')
        self._workPhases = [
            _('Undefined'),
            _('Outline'),
            _('Draft'),
            _('1st Edit'),
            _('2nd Edit'),
            _('Done'),
        ]
        self._phaseVar = MyStringVar()
        phaseOptionMenu = ttk.OptionMenu(
            phaseFrame,
            self._phaseVar,
            self._workPhases[0],
            *self._workPhases,
            command=self.apply_changes
        )
        phaseOptionMenu.pack(anchor='w')
        inputWidgets.append(phaseOptionMenu)

        self._coverFile = None

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self.inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pr_links'

    def apply_changes(self, event=None):
        if self.element is None:
            return

        super().apply_changes()

        authorName = self._authorNameVar.get()
        if authorName:
            authorName = authorName.strip()
        self.element.authorName = authorName

        self.element.languageCode = self._languageCodeVar.get()
        self.element.countryCode = self._countryCodeVar.get()
        self.element.check_locale()

        self.element.renumberChapters = self._renumberChaptersVar.get()
        self.element.renumberParts = self._renumberPartsVar.get()
        self.element.renumberWithinParts = self._renumberWithinPartsVar.get()
        self.element.romanChapterNumbers = self.romanChapterNumbersVar.get()
        self.element.romanPartNumbers = self._romanPartNumbersVar.get()
        self.element.saveWordCount = self._saveWordCountVar.get()

        self.element.chapterHeadingPrefix = self._chapterHeadingPrefixVar.get()
        self.element.chapterHeadingSuffix = self._chapterHeadingSuffixVar.get()
        self.element.partHeadingPrefix = self._partHeadingPrefixVar.get()
        self.element.partHeadingSuffix = self._partHeadingSuffixVar.get()

        self.element.noSceneField1 = self._noSceneField1Var.get(
            default=NO_SCENE_FIELD_1_DEFAULT
        )
        self.element.noSceneField2 = self._noSceneField2Var.get(
              default=NO_SCENE_FIELD_2_DEFAULT
        )
        self.element.noSceneField3 = self._noSceneField3Var.get(
            default=NO_SCENE_FIELD_3_DEFAULT
        )
        self.element.otherSceneField1 = self._otherSceneField1Var.get(
            default=OTHER_SCENE_FIELD_1_DEFAULT
        )
        self.element.otherSceneField2 = self._otherSceneField2Var.get(
            default=OTHER_SCENE_FIELD_2_DEFAULT
        )
        self.element.otherSceneField3 = self._otherSceneField3Var.get(
            default=OTHER_SCENE_FIELD_3_DEFAULT
        )
        self.element.crField1 = self._crField1Var.get(
            default=CR_FIELD_1_DEFAULT
        )
        self.element.crField2 = self._crField2Var.get(
            default=CR_FIELD_2_DEFAULT
        )

        refDateStr = self._referenceDateVar.get()
        if not refDateStr:
            self.element.referenceDate = None
        elif refDateStr != self.element.referenceDate:
            try:
                PyCalendar.verified_date(refDateStr)
            except ValueError:
                self._referenceDateVar.set(self.element.referenceDate)
                self._ui.show_error(
                    message=_('Input rejected'),
                    detail=(
                        f'{_("Wrong date")}: "{refDateStr}"\n'
                        f'{_("Required")}: {PyCalendar.DATE_FORMAT}'
                    )
                )
            else:
                self.element.referenceDate = refDateStr

        wordTargetStr = self._wordTargetVar.get()
        if wordTargetStr is None:
            self.element.wordTarget = None
        else:
            try:
                self.element.wordTarget = int(wordTargetStr)
            except (ValueError, TypeError):
                self._wordTargetVar.set(self.element.wordTarget)

        wordCountStartStr = self._wordCountStartVar.get()
        if wordCountStartStr is None:
            self.element.wordCountStart = 0
            self._wordCountStartVar.set('0')
        else:
            try:
                self.element.wordCountStart = int(wordCountStartStr)
            except (ValueError, TypeError):
                self._wordCountStartVar.set(self.element.wordCountStart)

        selectionIndex = self._workPhases.index(self._phaseVar.get())
        if selectionIndex:
            self.element.workPhase = selectionIndex
        else:
            self.element.workPhase = None

    def configure_display(self):
        super().configure_display()

        if prefs['show_language_settings']:
            self._languageFrame.show()
            self._localePreviewVar.set('')
        else:
            self._languageFrame.hide()
            if self.element.languageCode and self.element.countryCode:
                self._localePreviewVar.set(
                    f'{self.element.languageCode}-{self.element.countryCode}')
            elif self.element.languageCode:
                self._localePreviewVar.set(self.element.languageCode)
            else:
                self._localePreviewVar.set('')

        if prefs['show_auto_numbering']:
            self._numberingFrame.show()
            self._numberingPreviewVar.set('')
        else:
            self._numberingFrame.hide()
            renumberings = []
            if self.element.renumberChapters:
                renumberings.append(_('Chapters'))
            if self.element.renumberParts:
                renumberings.append(_('Parts'))
            self._numberingPreviewVar.set(
                list_to_string(renumberings, divider=f' {_("and")} ')
                )

        if prefs['show_renamings']:
            self._fieldNamesFame.show()
        else:
            self._fieldNamesFame.hide()

        displayDate = []
        datePreview = []
        if (self.element.referenceDate is not None
            and self.element.referenceWeekDay is not None
        ):
            dispWeekday = PyCalendar.WEEKDAYS[self.element.referenceWeekDay]
            dispDate = PyCalendar.get_locale_date(
                self.element.referenceDate,
                prefs['localize_date']
            )
            displayDate.append(dispWeekday)
            displayDate.append(dispDate)
            datePreview.append(_('Reference date'))
            datePreview.append(dispWeekday)
            datePreview.append(dispDate)

        if prefs['show_narrative_time']:
            self._narrativeTimeFrame.show()
            self._displayDateVar.set(list_to_string(displayDate, divider=' '))
            self._datePreviewVar.set('')
        else:
            self._narrativeTimeFrame.hide()
            self._displayDateVar.set('')
            self._datePreviewVar.set(list_to_string(datePreview, divider=' '))

        wordsWritten = None
        wordPercentage = None

        if (self.element.wordTarget is not None
            and self.element.wordCountStart is not None
        ):
            try:
                wordsWritten = self._mdl.wordCount - self.element.wordCountStart
                wordPercentage = round(
                    100 * wordsWritten / self.element.wordTarget
                )
            except Exception:
                pass

        wordsWrittenDisp = []
        progressPreview = []
        if wordsWritten is not None:
            wordsWrittenDisp.append(str(wordsWritten))
        if wordPercentage is not None:
            wordsWrittenDisp.append(f'({wordPercentage}%)')
            progressPreview.append(f'{wordPercentage}%')

        if prefs['show_writing_progress']:
            self._progressFrame.show()
            self._progressPreviewVar.set('')
            self._wordsWrittenVar.set(
                list_to_string(wordsWrittenDisp, divider=' ')
            )
        else:
            self._progressFrame.hide()
            self._wordsWrittenVar.set('')
            if not self.element.saveWordCount:
                progressPreview.append(_('Logging is off'))
            self._progressPreviewVar.set(
                list_to_string(progressPreview, divider=' - ')
            )

    def dates_to_days(self):
        buttonText = self._datesToDaysButton['text']
        self._datesToDaysButton['text'] = _('Please wait ...')
        if self.element.referenceDate:
            if self._ui.ask_yes_no(
                message=_('Convert all section dates to days relative to the reference date?'),
                detail=self._reference_dt_disp()
            ):
                self._doNotUpdate = True
                for scId in self.element.sections:
                    self.element.sections[scId].date_to_day(
                        self.element.referenceDate
                    )
                self._doNotUpdate = False
        else:
            self._report_missing_reference_date()
        self._datesToDaysButton['text'] = buttonText

    def days_to_dates(self):
        buttonText = self._daysToDatesButton['text']
        self._daysToDatesButton['text'] = _('Please wait ...')
        if self.element.referenceDate:
            if self._ui.ask_yes_no(
                message=_('Convert all section days to dates using the reference date?'),
                detail=self._reference_dt_disp()
            ):
                self._doNotUpdate = True
                for scId in self.element.sections:
                    self.element.sections[scId].day_to_date(
                        self.element.referenceDate
                    )
                self._doNotUpdate = False
        else:
            self._report_missing_reference_date()
        self._daysToDatesButton['text'] = buttonText

    def set_data(self, elementId):
        self.element = self._mdl.novel
        super().set_data(elementId)

        self._authorNameVar.set(self.element.authorName)


        self._languageCodeVar.set(self.element.languageCode)
        self._countryCodeVar.set(self.element.countryCode)


        if self.element.renumberChapters:
            self._renumberChaptersVar.set(True)
        else:
            self._renumberChaptersVar.set(False)

        self._chapterHeadingPrefixVar.set(self.element.chapterHeadingPrefix)

        self._chapterHeadingSuffixVar.set(self.element.chapterHeadingSuffix)

        if self.element.romanChapterNumbers:
            self.romanChapterNumbersVar.set(True)
        else:
            self.romanChapterNumbersVar.set(False)

        if self.element.renumberWithinParts:
            self._renumberWithinPartsVar.set(True)
        else:
            self._renumberWithinPartsVar.set(False)

        if self.element.renumberParts:
            self._renumberPartsVar.set(True)
        else:
            self._renumberPartsVar.set(False)

        self._partHeadingPrefixVar.set(self.element.partHeadingPrefix)

        self._partHeadingSuffixVar.set(self.element.partHeadingSuffix)

        if self.element.romanPartNumbers:
            self._romanPartNumbersVar.set(True)
        else:
            self._romanPartNumbersVar.set(False)

        self._noSceneField1Var.set(self.element.noSceneField1)
        self._noSceneField2Var.set(self.element.noSceneField2)
        self._noSceneField3Var.set(self.element.noSceneField3)
        self._otherSceneField1Var.set(self.element.otherSceneField1)
        self._otherSceneField2Var.set(self.element.otherSceneField2)
        self._otherSceneField3Var.set(self.element.otherSceneField3)
        self._crField1Var.set(self.element.crField1)
        self._crField2Var.set(self.element.crField2)

        self._referenceDateVar.set(self.element.referenceDate)


        if self.element.saveWordCount:
            self._saveWordCountVar.set(True)
        else:
            self._saveWordCountVar.set(False)

        self._wordTargetVar.set(self.element.wordTarget)

        self._wordCountStartVar.set(self.element.wordCountStart)

        normalWordsTotal, allWordsTotal = self._mdl.prjFile.count_words()
        self._totalWordsVar.set(allWordsTotal)
        self._totalUsedVar.set(normalWordsTotal)
        self._totalUnusedVar.set(allWordsTotal - normalWordsTotal)
        statusCounts = self._mdl.get_status_counts()
        self._totalOutlineVar.set(statusCounts[1])
        self._totalDraftVar.set(statusCounts[2])
        self._total1stEditVar.set(statusCounts[3])
        self._total2ndEditVar.set(statusCounts[4])
        self._totalDoneVar.set(statusCounts[5])

        if self.element.workPhase is None:
            selectionIndex = 0
        else:
            selectionIndex = int(self.element.workPhase)
        self._phaseVar.set(self._workPhases[selectionIndex])

    def set_initial_wc(self):
        self.element.wordCountStart = self._mdl.wordCount

    def show(self):
        try:
            coverFile = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}.png'
            if self._coverFile != coverFile:
                self._coverFile = coverFile
                coverPic = tk.PhotoImage(file=coverFile)
                self._cover.configure(image=coverPic)
                self._cover.image = coverPic
        except:
            self._coverFile = None
            self._cover.configure(image=None)
            self._cover.image = None
        super().show()

    def _create_button_bar(self):
        self._buttonBar = ttk.Frame(self._propertiesFrame)
        self._buttonBar.pack(fill='x')

        ttk.Button(
            self._buttonBar,
            text=_('Online help'),
            command=self._open_help,
        ).pack(side='left', fill='x', expand=True, padx=1, pady=2)

    def _create_cover_window(self):
        self._cover = tk.Label(self._propertiesFrame)
        self._cover.pack()

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_button_bar()
        self._create_cover_window()

    def _reference_dt_disp(self):
        referenceDtDisp = [f"{_('Day 0')}:"]
        referenceDtDisp.append(
            PyCalendar.WEEKDAYS[self.element.referenceWeekDay]
        )
        referenceDtDisp.append(
            PyCalendar.get_locale_date(
                self.element.referenceDate,
                prefs['localize_date']
            )
        )
        return ' '.join(referenceDtDisp)

    def _toggle_language_frame(self, event=None):
        if prefs['show_language_settings']:
            self._languageFrame.hide()
            prefs['show_language_settings'] = False
        else:
            self._languageFrame.show()
            prefs['show_language_settings'] = True
        self._toggle_folding_frame()

    def _toggle_narrative_time_frame(self, event=None):
        if prefs['show_narrative_time']:
            self._narrativeTimeFrame.hide()
            prefs['show_narrative_time'] = False
        else:
            self._narrativeTimeFrame.show()
            prefs['show_narrative_time'] = True
        self._toggle_folding_frame()

    def _toggle_numbering_frame(self, event=None):
        if prefs['show_auto_numbering']:
            self._numberingFrame.hide()
            prefs['show_auto_numbering'] = False
        else:
            self._numberingFrame.show()
            prefs['show_auto_numbering'] = True
        self._toggle_folding_frame()

    def _toggle_progress_frame(self, event=None):
        if prefs['show_writing_progress']:
            self._progressFrame.hide()
            prefs['show_writing_progress'] = False
        else:
            self._progressFrame.show()
            prefs['show_writing_progress'] = True
        self._toggle_folding_frame()

    def _toggle_field_names_frame(self, event=None):
        if prefs['show_renamings']:
            self._fieldNamesFame.hide()
            prefs['show_renamings'] = False
        else:
            self._fieldNamesFame.show()
            prefs['show_renamings'] = True
        self._toggle_folding_frame()

from tkinter import ttk



class SectionView(ElementView):
    _HELP_PAGE = 'section_view.html'
    _HEIGHT_LIMIT = 10
    _DT_LABEL_WIDTH = 15

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._tagsVar = MyStringVar()
        self._tagsEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Tags'),
            textvariable=self._tagsVar,
            command=self.apply_changes,
            lblWidth=self._LABEL_WIDTH,
        )
        self._tagsEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._tagsEntry)

        self._sectionExtraFrame = ttk.Frame(self._elementInfoWindow)
        self._sectionExtraFrame.pack(anchor='w', fill='x')

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._relationFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Relationships'),
            self._toggle_relation_frame,
        )

        self._relationsPreviewVar = MyStringVar()
        relationsPreview = ttk.Label(
            self._relationFrame.titleBar,
            textvariable=self._relationsPreviewVar,
        )
        relationsPreview.pack(side='left', padx=2)
        relationsPreview.bind('<Button-1>', self._toggle_relation_frame)

        crHeading = ttk.Frame(self._relationFrame)
        self._characterLabel = ttk.Label(crHeading, text=_('Characters'))
        self._characterLabel.pack(anchor='w', side='left')
        ttk.Button(
            crHeading,
            text=_('Show ages'),
            command=self.show_ages,
        ).pack(anchor='e')
        crHeading.pack(fill='x')
        self._characterCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self.pick_character,
            cmdRemove=self.remove_character,
            cmdOpen=self.go_to_character,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon,
            cmdSelect=self._configure_character_buttons,
        )
        self._characterCollection.pack(fill='x')
        inputWidgets.extend(self._characterCollection.inputWidgets)

        self._locationLabel = ttk.Label(
            self._relationFrame,
            text=_('Locations')
        )
        self._locationLabel.pack(anchor='w')
        self._locationCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self.pick_location,
            cmdRemove=self.remove_location,
            cmdOpen=self.go_to_location,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon,
            cmdSelect=self._configure_location_buttons,
        )
        self._locationCollection.pack(fill='x')
        inputWidgets.extend(self._locationCollection.inputWidgets)

        self._itemLabel = ttk.Label(self._relationFrame, text=_('Items'))
        self._itemLabel.pack(anchor='w')
        self._itemCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self.pick_item,
            cmdRemove=self.remove_item,
            cmdOpen=self.go_to_item,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon,
            cmdSelect=self._configure_item_buttons,
        )
        self._itemCollection.pack(fill='x')
        inputWidgets.extend(self._itemCollection.inputWidgets)

        self._prefsShowLinks = 'show_sc_links'

        ttk.Separator(
            self._elementInfoWindow,
            orient='horizontal'
        ).pack(fill='x')

        self._dateTimeFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Date/Time'),
            self._toggle_date_time_frame,
        )

        self._datePreviewVar = MyStringVar()
        datePreview = ttk.Label(
            self._dateTimeFrame.titleBar,
            textvariable=self._datePreviewVar,
        )
        datePreview.pack(side='left', padx=2)
        datePreview.bind('<Button-1>', self._toggle_date_time_frame)

        sectionStartFrame = ttk.Frame(self._dateTimeFrame)
        sectionStartFrame.pack(fill='x')

        displayDateFrame = ttk.Frame(sectionStartFrame)
        displayDateFrame.pack(fill='x')
        ttk.Label(
            displayDateFrame,
            text=_('Start'),
            width=self._DT_LABEL_WIDTH,
        ).pack(side='left')

        self._displayDateVar = MyStringVar()
        displayDate = ttk.Label(
            displayDateFrame,
            textvariable=self._displayDateVar,
        )
        displayDate.pack(side='left')

        ttk.Button(
            displayDateFrame,
            text=_('Moon phase'),
            command=self.show_moonphase,
        ).pack(anchor='e')

        self._startDateVar = MyStringVar()
        self._startDateEntry = LabelEntry(
            sectionStartFrame,
            text=_('Date'),
            textvariable=self._startDateVar,
            command=self.apply_changes,
            lblWidth=self._DT_LABEL_WIDTH,
        )
        self._startDateEntry.pack(anchor='w')
        inputWidgets.append(self._startDateEntry)

        self._startTimeVar = MyStringVar()
        self._startTimeEntry = LabelEntry(
            sectionStartFrame,
            text=_('Time'),
            textvariable=self._startTimeVar,
            command=self.apply_changes,
            lblWidth=self._DT_LABEL_WIDTH,
        )
        self._startTimeEntry.pack(anchor='w')
        inputWidgets.append(self._startTimeEntry)

        self._startDayVar = MyStringVar()
        self._startDayEntry = LabelEntry(
            sectionStartFrame,
            text=_('Day'),
            textvariable=self._startDayVar,
            command=self.apply_changes,
            lblWidth=self._DT_LABEL_WIDTH,
        )
        self._startDayEntry.pack(anchor='w')
        inputWidgets.append(self._startDayEntry)
        self._startDayEntry.entry.bind('<Return>', self.change_day)

        self._clearDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Clear date/time'),
            command=self.clear_start,
        )
        self._clearDateButton.pack(
            side='left',
            fill='x',
            expand=True,
            padx=1,
            pady=2,
            )
        inputWidgets.append(self._clearDateButton)

        self._generateDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Generate'),
            command=self.auto_set_date,
        )
        self._generateDateButton.pack(
            side='left',
            fill='x',
            expand=True,
            padx=1,
            pady=2,
        )
        inputWidgets.append(self._generateDateButton)

        self._toggleDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Convert date/day'),
            command=self.toggle_date,
        )
        self._toggleDateButton.pack(
            side='left',
            fill='x',
            expand=True,
            padx=1,
            pady=2,
        )
        inputWidgets.append(self._toggleDateButton)

        ttk.Separator(
            self._dateTimeFrame,
            orient='horizontal'
        ).pack(fill='x', pady=2)

        sectionDurationFrame = ttk.Frame(self._dateTimeFrame)
        sectionDurationFrame.pack(fill='x')

        displayDurationFrame = ttk.Frame(sectionDurationFrame)
        displayDurationFrame.pack(fill='x')
        ttk.Label(
            displayDurationFrame,
            text=_('Duration'),
            width=self._DT_LABEL_WIDTH,
        ).pack(side='left')

        self.displayDurationVar = MyStringVar()
        displayDuration = ttk.Label(
            displayDurationFrame,
            textvariable=self.displayDurationVar,
        )
        displayDuration.pack(side='left', padx=2)

        self._lastsDaysVar = MyStringVar()
        self._lastsDaysEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Days'),
            textvariable=self._lastsDaysVar,
            command=self.apply_changes,
            lblWidth=self._DT_LABEL_WIDTH,
        )
        self._lastsDaysEntry.pack(anchor='w')
        inputWidgets.append(self._lastsDaysEntry)

        self._lastsHoursVar = MyStringVar()
        self._lastsHoursEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Hours'),
            textvariable=self._lastsHoursVar,
            command=self.apply_changes,
            lblWidth=self._DT_LABEL_WIDTH,
        )
        self._lastsHoursEntry.pack(anchor='w')
        inputWidgets.append(self._lastsHoursEntry)

        self._lastsMinutesVar = MyStringVar()
        self._lastsMinutesEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Minutes'),
            textvariable=self._lastsMinutesVar,
            command=self.apply_changes,
            lblWidth=self._DT_LABEL_WIDTH,
        )
        self._lastsMinutesEntry.pack(anchor='w')
        inputWidgets.append(self._lastsMinutesEntry)

        self._clearDurationButton = ttk.Button(
            sectionDurationFrame,
            text=_('Clear duration'),
            command=self.clear_duration,
        )
        self._clearDurationButton.pack(side='left', padx=1, pady=2)
        inputWidgets.append(self._clearDurationButton)

        self._generatDurationButton = ttk.Button(
            sectionDurationFrame,
            text=_('Generate'),
            command=self.auto_set_duration,
        )
        self._generatDurationButton.pack(side='left', padx=1, pady=2)
        inputWidgets.append(self._generatDurationButton)

        viewpointFrame = ttk.Frame(self._sectionExtraFrame)
        viewpointFrame.pack(fill='x', expand=True, pady=2)
        ttk.Label(
            viewpointFrame,
            text=_('Viewpoint'),
            anchor='w',
            width=self._LABEL_WIDTH,
        ).pack(side='left')
        self._viewpointVar = MyStringVar()
        self._viewpointCombobox = ttk.Combobox(
            viewpointFrame,
            textvariable=self._viewpointVar,
            values=[],
        )
        self._viewpointCombobox.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._viewpointCombobox)
        self._viewpointCombobox.bind(
            '<<ComboboxSelected>>', self.apply_changes)
        self._vpIdList = []

        self._isUnusedVar = tk.BooleanVar()
        self._isUnusedCheckbox = ttk.Checkbutton(
            self._sectionExtraFrame,
            text=_('Unused'),
            variable=self._isUnusedVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._isUnusedCheckbox.pack(anchor='w')
        inputWidgets.append(self._isUnusedCheckbox)

        self._appendToPrevVar = tk.BooleanVar()
        self._appendToPrevCheckbox = ttk.Checkbutton(
            self._sectionExtraFrame,
            text=_('Append to previous section'),
            variable=self._appendToPrevVar,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
        )
        self._appendToPrevCheckbox.pack(anchor='w')
        inputWidgets.append(self._appendToPrevCheckbox)

        ttk.Separator(
            self._sectionExtraFrame, orient='horizontal').pack(fill='x')

        self._plotFrame = FoldingFrame(
            self._sectionExtraFrame,
            _('Plot'),
            self._toggle_plot_frame,
        )

        self._plotPreviewVar = MyStringVar()
        plotlinesPreview = ttk.Label(
            self._plotFrame.titleBar,
            textvariable=self._plotPreviewVar,
        )
        plotlinesPreview.pack(side='left', padx=2)
        plotlinesPreview.bind('<Button-1>', self._toggle_plot_frame)

        self._plotlineLabel = ttk.Label(self._plotFrame, text=_('Plot lines'))
        self._plotlineLabel.pack(anchor='w')
        self._plotlineCollection = CollectionBox(
            self._plotFrame,
            cmdAdd=self.pick_plotline,
            cmdRemove=self.remove_plotline,
            cmdOpen=self.go_to_plotline,
            cmdSelect=self.on_select_plotline,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon,
        )
        self._plotlineCollection.pack(fill='x')
        inputWidgets.extend(self._plotlineCollection.inputWidgets)
        self._selectedPlotline = None

        ttk.Label(
            self._plotFrame,
            text=_('Notes on the selected plot line'),
        ).pack(anchor='w')
        self._plotNotesWindow = TextBox(
            self._plotFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
        )
        self._plotNotesWindow.pack(fill='x')
        inputWidgets.append(self._plotNotesWindow)

        ttk.Label(self._plotFrame, text=_('Plot points')).pack(anchor='w')
        self._plotPointsDisplay = tk.Label(
            self._plotFrame,
            anchor='w',
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
        )
        self._plotPointsDisplay.pack(anchor='w', fill='x')

        ttk.Separator(
            self._sectionExtraFrame, orient='horizontal').pack(fill='x')

        self._sceneFrame = FoldingFrame(
            self._sectionExtraFrame,
            _('Scene'),
            self._toggle_scene_frame,
        )

        self._scenePreviewVar = MyStringVar()
        scenePreview = ttk.Label(
            self._sceneFrame.titleBar,
            textvariable=self._scenePreviewVar,
        )
        scenePreview.pack(side='left', padx=2)
        scenePreview.bind('<Button-1>', self._toggle_scene_frame)

        selectionFrame = ttk.Frame(self._sceneFrame)
        self._noSceneField1Var = ''
        self._noSceneField2Var = ''
        self._noSceneField3Var = ''
        self._otherSceneField1Var = ''
        self._otherSceneField2Var = ''
        self._otherSceneField3Var = ''
        self.sceneVar = tk.IntVar()

        self._kindsOfScene = [
            _('Not a scene'),
            _('Action'),
            _('Reaction'),
            _('Other'),
        ]
        sceneChoice = 0
        self._notApplicableRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=self._kindsOfScene[sceneChoice],
            variable=self.sceneVar,
            value=sceneChoice,
            command=self.set_not_applicable,
        )
        self._notApplicableRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._notApplicableRadiobutton)

        sceneChoice += 1
        self._actionRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=self._kindsOfScene[sceneChoice],
            variable=self.sceneVar,
            value=sceneChoice,
            command=self.set_action_scene,
        )
        self._actionRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._actionRadiobutton)

        sceneChoice += 1
        self._reactionRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=self._kindsOfScene[sceneChoice],
            variable=self.sceneVar,
            value=sceneChoice,
            command=self.set_reaction_scene,
        )
        self._reactionRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._reactionRadiobutton)

        sceneChoice += 1
        self._customRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=self._kindsOfScene[sceneChoice],
            variable=self.sceneVar,
            value=sceneChoice,
            command=self.set_custom_scene,
        )
        self._customRadiobutton.pack(anchor='w')
        inputWidgets.append(self._customRadiobutton)

        selectionFrame.pack(fill='x')

        self._goalLabel = ttk.Label(self._sceneFrame)
        self._goalLabel.pack(anchor='w')
        self._goalBox = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
        )
        self._goalBox.pack(fill='x')
        inputWidgets.append(self._goalBox)

        self._conflictLabel = ttk.Label(self._sceneFrame)
        self._conflictLabel.pack(anchor='w')
        self._conflictBox = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
        )
        self._conflictBox.pack(fill='x')
        inputWidgets.append(self._conflictBox)

        self._outcomeLabel = ttk.Label(self._sceneFrame)
        self._outcomeLabel.pack(anchor='w')
        self._outcomeBox = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
        )
        self._outcomeBox.pack(fill='x')
        inputWidgets.append(self._outcomeBox)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self.inputWidgets.append(widget)

    def apply_changes(self, event=None):
        if self.element is None:
            return

        super().apply_changes()


        self.element.tags = string_to_list(self._tagsVar.get())


        dateStr = self._startDateVar.get()
        if not dateStr:
            self.element.date = None
        elif dateStr != self.element.date:
            try:
                dateStr = PyCalendar.verified_date(dateStr)
            except ValueError:
                self._startDateVar.set(self.element.date)
                self._ui.show_error(
                    message=_('Input rejected'),
                    detail=(
                        f'{_("Wrong date")}: '
                        f'"{dateStr}"\n{_("Required")}: '
                        f'{PyCalendar.DATE_FORMAT}'
                    ),
                )
            else:
                self.element.date = dateStr

        timeStr = self._startTimeVar.get()
        if not timeStr:
            self.element.time = None
        else:
            if self.element.time:
                dispTime = PyCalendar.time_disp(self.element.time)
            else:
                dispTime = ''
            if timeStr != dispTime:
                try:
                    timeStr = PyCalendar.verified_time(timeStr)
                except ValueError:
                    self._startTimeVar.set(dispTime)
                    self._ui.show_error(
                        message=_('Input rejected'),
                        detail=(
                            f'{_("Wrong time")}: '
                            f'"{timeStr}"\n{_("Required")}: '
                            f'{PyCalendar.TIME_FORMAT}'
                        ),
                    )
                else:
                    self.element.time = timeStr
                    dispTime = PyCalendar.time_disp(self.element.time)
                    self._startTimeVar.set(dispTime)

        if self.element.date:
            self.element.day = None
        else:
            self.change_day()

        wrongEntry = False
        newEntry = False

        hoursLeft = 0
        lastsMinutesStr = self._lastsMinutesVar.get()
        if lastsMinutesStr or self.element.lastsMinutes:
            if lastsMinutesStr != self.element.lastsMinutes:
                if not lastsMinutesStr:
                    lastsMinutesStr = 0
                try:
                    minutes = int(lastsMinutesStr)
                except ValueError:
                    wrongEntry = True
                else:
                    hoursLeft, minutes = divmod(minutes, 60)
                    if minutes > 0:
                        lastsMinutesStr = str(minutes)
                    else:
                        lastsMinutesStr = None
                    self._lastsMinutesVar.set(lastsMinutesStr)
                    newEntry = True

        daysLeft = 0
        lastsHoursStr = self._lastsHoursVar.get()
        if hoursLeft or lastsHoursStr or self.element.lastsHours:
            if hoursLeft or lastsHoursStr != self.element.lastsHours:
                try:
                    if lastsHoursStr:
                        hoursLeft += int(lastsHoursStr)
                    daysLeft, hoursLeft = divmod(hoursLeft, 24)
                    if hoursLeft > 0:
                        lastsHoursStr = str(hoursLeft)
                    else:
                        lastsHoursStr = None
                    self._lastsHoursVar.set(lastsHoursStr)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        lastsDaysStr = self._lastsDaysVar.get()
        if daysLeft or lastsDaysStr or self.element.lastsDays:
            if daysLeft or lastsDaysStr != self.element.lastsDays:
                try:
                    if lastsDaysStr:
                        daysLeft += int(lastsDaysStr)
                    if daysLeft > 0:
                        lastsDaysStr = str(daysLeft)
                    else:
                        lastsDaysStr = None
                    self._lastsDaysVar.set(lastsDaysStr)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        if wrongEntry:
            self._lastsMinutesVar.set(self.element.lastsMinutes)
            self._lastsHoursVar.set(self.element.lastsHours)
            self._lastsDaysVar.set(self.element.lastsDays)
            self._ui.show_error(
                message=_('Input rejected'),
                detail=f'{_("Wrong entry: number required")}.'
            )
        elif newEntry:
            self.element.lastsMinutes = lastsMinutesStr
            self.element.lastsHours = lastsHoursStr
            self.element.lastsDays = lastsDaysStr

        option = self._viewpointCombobox.current()
        if option >= 0:
            vpId = self._vpIdList[option]
            self.element.viewpoint = vpId

        if self._isUnusedVar.get():
            self._ctrl.set_type_unused()
        elif self.element.scType > 0:
            self._ctrl.set_type_normal()
        if self.element.scType > 0:
            self._isUnusedVar.set(True)

        self.element.appendToPrev = self._appendToPrevVar.get()

        self.save_plot_notes()

        if self._goalBox.hasChanged:
            self.element.goal = self._goalBox.get_text()
        if self._conflictBox.hasChanged:
            self.element.conflict = self._conflictBox.get_text()

        if self._outcomeBox.hasChanged:
            self.element.outcome = self._outcomeBox.get_text()

    def auto_set_date(self):
        prevScId = self._ui.tv.prev_node(self.elementId)
        if not prevScId:
            self._ui.show_error(
                message=_('Cannot generate date/time'),
                detail=f"{_('There is no previous section')}."
            )
            return

        (
            newDate,
            newTime,
            newDay
        ) = self._mdl.novel.sections[prevScId].get_end_date_time()
        if newTime is None:
            self._ui.show_error(
                message=_('Cannot generate date/time'),
                detail=f"{_('The previous section has no time set')}."
            )
            return

        if self.element.date or self.element.time or self.element.day:
            if (
                self.element.date != newDate or
                self.element.time != newTime or
                self.element.day != newDay
            ):
                newLocDate = PyCalendar.get_locale_date(
                    newDate,
                    prefs['localize_date']
                )
                if not self._ui.ask_yes_no(
                    message=_('Overwrite date/time?'),
                    detail=(
                        f"{_('Previous section ends:')} "
                        f"{PyCalendar.dt_disp(newDay, newLocDate, newTime)}"
                    )
                ):
                    return

        self.element.date = newDate
        self.element.time = newTime
        self.element.day = newDay

    def auto_set_duration(self):

        nextScId = self._ui.tv.next_node(self.elementId)
        if not nextScId:
            self._ui.show_error(
                message=_('Cannot generate duration'),
                detail=f"{_('There is no next section')}."
            )
            return

        thisTimeIso = self.element.time
        if not thisTimeIso:
            self._ui.show_error(
                message=_('Cannot generate duration'),
                detail=f"{_('This section has no time set')}."
            )
            return

        nextTimeIso = self._mdl.novel.sections[nextScId].time
        if not nextTimeIso:
            self._ui.show_error(
                message=_('Cannot generate duration'),
                detail=f"{_('The next section has no time set')}."
            )
            return

        refDateIso = self._mdl.novel.referenceDate
        if not refDateIso:
            refDateIso = PyCalendar.min
        if self._mdl.novel.sections[nextScId].date:
            nextDateIso = self._mdl.novel.sections[nextScId].date
        elif self._mdl.novel.sections[nextScId].day:
            nextDateIso = PyCalendar.specific_date(
                self._mdl.novel.sections[nextScId].day, refDateIso,)
        elif self.element.day:
            nextDateIso = self.element.day
        else:
            nextDateIso = None

        if self.element.date:
            thisDateIso = self.element.date
            if nextDateIso is None:
                nextDateIso = thisDateIso
        elif self.element.day:
            thisDateIso = PyCalendar.specific_date(
                self.element.day, refDateIso)
            if nextDateIso is None:
                nextDateIso = thisDateIso
        else:
            if nextDateIso is not None:
                thisDateIso = nextDateIso
            else:
                nextDateIso = thisDateIso = PyCalendar.min
        newDays, newHours, newMinutes = PyCalendar.duration(
            thisDateIso,
            thisTimeIso,
            nextDateIso,
            nextTimeIso,
        )

        if self.element.date or self.element.time or self.element.day:
            if (
                self.element.lastsDays != newDays or
                self.element.lastsHours != newHours or
                self.element.lastsMinutes != newMinutes
            ):
                dispDuration = PyCalendar.duration_disp(
                    newDays,
                    newHours,
                    newMinutes
                )
                if not self._ui.ask_yes_no(
                    message=_('Overwrite duration?'),
                    detail=f"{_('Next section begins in')} {dispDuration}"
                ):
                    return

        self.element.lastsDays = newDays
        self.element.lastsHours = newHours
        self.element.lastsMinutes = newMinutes

    def change_day(self, event=None):
        dayStr = self._startDayVar.get()
        if dayStr or self.element.day:
            if dayStr != self.element.day:
                if not dayStr:
                    self.element.day = None
                else:
                    try:
                        int(dayStr)
                    except ValueError:
                        self._startDayVar.set(self.element.day)
                        self._ui.show_error(
                            message=_('Input rejected'),
                            detail=f'{_("Wrong entry: number required")}.'
                        )
                    else:
                        self.element.day = dayStr
                        self.element.date = None

    def clear_duration(self):
        durationData = [
            self.element.lastsDays,
            self.element.lastsHours,
            self.element.lastsMinutes,
        ]
        hasData = False
        for dataElement in durationData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(
            message=_('Clear duration from this section?')
        ):
            self.element.lastsDays = None
            self.element.lastsHours = None
            self.element.lastsMinutes = None

    def clear_start(self):
        startData = [
            self.element.date,
            self.element.time,
            self.element.day,
        ]
        hasData = False
        for dataElement in startData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(
            message=_('Clear date/time from this section?')
        ):
            self.element.date = None
            self.element.time = None
            self.element.day = None

    def configure_display(self):
        super().configure_display()

        if prefs['show_relationships']:
            self._relationFrame.show()
            self._relationsPreviewVar.set('')
        else:
            self._relationFrame.hide()
            relationsPreview = []
            relationCounts = {
                _('Characters'): len(self.element.characters),
                _('Locations'):len(self.element.locations),
                _('Items'):len(self.element.items),
            }
            for elementType in relationCounts:
                if relationCounts[elementType]:
                    relationsPreview.append(
                        f"{elementType}: {relationCounts[elementType]}"
                    )
            self._relationsPreviewVar.set(
                list_to_string(relationsPreview, divider=', ')
            )

        dispDateTime = []
        if self.element.date and self.element.weekDay is not None:
            dispDateTime.append(
                PyCalendar.WEEKDAYS[self.element.weekDay]
            )
        elif (
            self.element.day
            and self._mdl.novel.referenceWeekDay is not None
        ):
            wd = (int(self.element.day) + self._mdl.novel.referenceWeekDay) % 7
            dispDateTime.append(PyCalendar.WEEKDAYS[wd])
        self._startDateVar.set(self.element.date)
        if self.element.localeDate:
            if prefs['localize_date']:
                dispDateTime.append(self.element.localeDate)
            else:
                dispDateTime.append(self.element.date)
        elif self.element.day:
            dispDateTime.append(f'{_("Day")} {self.element.day}')

        if self.element.time:
            dispDateTime.append(PyCalendar.time_disp(self.element.time))

        if prefs['show_date_time']:
            self._dateTimeFrame.show()
            self._displayDateVar.set(
                list_to_string(dispDateTime, divider=' ')
            )
            self._datePreviewVar.set('')
            self.displayDurationVar.set(
                PyCalendar.get_duration_str(self.element))
        else:
            self._dateTimeFrame.hide()
            self._datePreviewVar.set(
                list_to_string(dispDateTime, divider=' ')
            )

        if prefs['show_plot']:
            self._plotFrame.show()
            self._plotPreviewVar.set('')
        else:
            self._plotFrame.hide()
            plotPreview = []
            plotCounts = {
                _('Plot lines'): len(self.element.scPlotLines),
                _('Plot points'):len(self.element.scPlotPoints),
            }
            for elementType in plotCounts:
                if plotCounts[elementType]:
                    plotPreview.append(
                        f"{elementType}: {plotCounts[elementType]}"
                    )
            self._plotPreviewVar.set(
                list_to_string(plotPreview, divider=', '))

        if prefs['show_scene']:
            self._sceneFrame.show()
            self._scenePreviewVar.set('')
        else:
            self._sceneFrame.hide()
            if (self.element.scene
                or self.element.goal
                or self.element.conflict
                or self.element.outcome
            ):
                self._scenePreviewVar.set(
                    self._kindsOfScene[self.element.scene])
            else:
                self._scenePreviewVar.set('')

    def go_to_character(self, event=None):
        crIndex = self._characterCollection.selection
        if crIndex is not None:
            self._ui.tv.go_to_node(self.element.characters[crIndex])

    def go_to_item(self, event=None):
        itIndex = self._itemCollection.selection
        if itIndex is not None:
            self._ui.tv.go_to_node(self.element.items[itIndex])

    def go_to_location(self, event=None):
        lcIndex = self._locationCollection.selection
        if lcIndex is not None:
            self._ui.tv.go_to_node(self.element.locations[lcIndex])

    def go_to_plotline(self, event=None):
        plIndex = self._plotlineCollection.selection
        if plIndex is not None:
            self._ui.tv.go_to_node(self.element.scPlotLines[plIndex])

    def on_select_plotline(self, plIndex):
        self.save_plot_notes()
        self._selectedPlotline = self.element.scPlotLines[plIndex]
        self._plotNotesWindow.config(state='normal')
        if self.element.plotlineNotes:
            self._plotNotesWindow.set_text(
                self.element.plotlineNotes.get(self._selectedPlotline, '')
            )
        else:
            self._plotNotesWindow.clear()
        if self.isLocked:
            self._plotNotesWindow.config(state='disabled')
        self._plotNotesWindow.config(bg=prefs['color_text_bg'])
        self._configure_plotline_buttons()

    def pick_character(self, event=None):
        self._ui.tv.save_branch_status()
        self._ui.tv.close_children('')
        self._ui.tv.open_children(CR_ROOT)
        self._start_picking_mode(command=self._add_character)
        self._ui.tv.see_node(CR_ROOT)

    def pick_item(self, event=None):
        self._ui.tv.save_branch_status()
        self._ui.tv.close_children('')
        self._ui.tv.open_children(IT_ROOT)
        self._start_picking_mode(command=self._add_item)
        self._ui.tv.see_node(IT_ROOT)

    def pick_location(self, event=None):
        self._ui.tv.save_branch_status()
        self._ui.tv.close_children('')
        self._ui.tv.open_children(LC_ROOT)
        self._start_picking_mode(command=self._add_location)
        self._ui.tv.see_node(LC_ROOT)

    def pick_plotline(self, event=None):
        self._ui.tv.save_branch_status()
        self._ui.tv.close_children('')
        self._ui.tv.open_children(PL_ROOT)
        self._start_picking_mode(command=self._add_plotline)
        self._ui.tv.see_node(PL_ROOT)

    def remove_character(self, event=None):
        if self.isLocked:
            return

        crIndex = self._characterCollection.selection
        if crIndex is None:
            return

        crId = self.element.characters[crIndex]
        if self._ui.ask_yes_no(
            message=_('Remove character from the list?'),
            detail=self._mdl.novel.characters[crId].title
        ):
            crList = self.element.characters
            crList.remove(crId)
            self.element.characters = crList

    def remove_item(self, event=None):
        if self.isLocked:
            return

        itIndex = self._itemCollection.selection
        if itIndex is None:
            return

        itId = self.element.items[itIndex]
        if self._ui.ask_yes_no(
            message=_('Remove item from the list?'),
            detail=self._mdl.novel.items[itId].title
        ):
            itList = self.element.items
            itList.remove(itId)
            self.element.items = itList

    def remove_location(self, event=None):
        if self.isLocked:
            return

        lcIndex = self._locationCollection.selection
        if lcIndex is None:
            return

        lcId = self.element.locations[lcIndex]
        if self._ui.ask_yes_no(
            message=_('Remove location from the list?'),
            detail=self._mdl.novel.locations[lcId].title
        ):
            lcList = self.element.locations
            lcList.remove(lcId)
            self.element.locations = lcList

    def remove_plotline(self, event=None):
        if self.isLocked:
            return

        plIndex = self._plotlineCollection.selection
        if plIndex is None:
            return

        plId = self.element.scPlotLines[plIndex]
        if not self._ui.ask_yes_no(
            message=_('Remove plot line from the list?'),
            detail=(
                f"({self._mdl.novel.plotLines[plId].shortName}) "
                f"{self._mdl.novel.plotLines[plId].title}"
            )
        ):
            return

        arcList = self.element.scPlotLines
        arcList.remove(plId)
        self.element.scPlotLines = arcList

        arcSections = self._mdl.novel.plotLines[plId].sections
        if self.elementId in arcSections:
            arcSections.remove(self.elementId)
            self._mdl.novel.plotLines[plId].sections = arcSections

            for ppId in list(self.element.scPlotPoints):
                if self.element.scPlotPoints[ppId] == plId:
                    del(self.element.scPlotPoints[ppId])
                    self._mdl.novel.plotPoints[ppId].sectionAssoc = None

    def save_plot_notes(self):
        if self._selectedPlotline and self._plotNotesWindow.hasChanged:
            plotlineNotes = self.element.plotlineNotes
            if plotlineNotes is None:
                plotlineNotes = {}
            plotlineNotes[self._selectedPlotline] = (
                self._plotNotesWindow.get_text()
            )
            self._doNotUpdate = True
            self.element.plotlineNotes = plotlineNotes
            self._doNotUpdate = False

    def set_action_scene(self, event=None):
        self._goalLabel.config(text=_('Goal'))
        self._conflictLabel.config(text=_('Conflict'))
        self._outcomeLabel.config(text=_('Outcome'))
        self.element.scene = self.sceneVar.get()

    def set_custom_scene(self, event=None):
        if self._otherSceneField1Var:
            self._goalLabel.config(text=self._otherSceneField1Var)
        else:
            self._goalLabel.config(text=f"{_('Field')} 1")

        if self._otherSceneField2Var:
            self._conflictLabel.config(text=self._otherSceneField2Var)
        else:
            self._conflictLabel.config(text=f"{_('Field')} 2")

        if self._otherSceneField3Var:
            self._outcomeLabel.config(text=self._otherSceneField3Var)
        else:
            self._outcomeLabel.config(text=f"{_('Field')} 3")

        self.element.scene = self.sceneVar.get()

    def set_data(self, elementId):
        self.element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        self._tagsVar.set(list_to_string(self.element.tags))


        self._characterCollection.set([
            self._mdl.novel.characters[crId].title
            for crId in self.element.characters
        ])
        listboxSize = len(self.element.characters)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._characterCollection.set_height(listboxSize)
        self._configure_character_buttons()

        self._locationCollection.set([
            self._mdl.novel.locations[lcId].title
            for lcId in self.element.locations
        ])
        listboxSize = len(self.element.locations)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._locationCollection.set_height(listboxSize)
        self._configure_location_buttons()

        self._itemCollection.set([
            self._mdl.novel.items[itId].title
            for itId in self.element.items
        ])
        listboxSize = len(self.element.items)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._itemCollection.set_height(listboxSize)


        if self.element.time:
            self._startTimeVar.set(
                PyCalendar.time_disp(self.element.time)
            )
        else:
            self._startTimeVar.set('')

        self._startDayVar.set(self.element.day)
        self._lastsDaysVar.set(self.element.lastsDays)
        self._lastsHoursVar.set(self.element.lastsHours)
        self._lastsMinutesVar.set(self.element.lastsMinutes)

        if self.element.viewpoint:
            charNames = [f"({_('Clear assignment')})"]
            preset = self._mdl.novel.characters[self.element.viewpoint].title
        else:
            charNames = [NOT_ASSIGNED]
            preset = NOT_ASSIGNED
        self._vpIdList = [None]
        for crId in self._mdl.novel.tree.get_children(CR_ROOT):
            charNames.append(self._mdl.novel.characters[crId].title)
            self._vpIdList.append(crId)
        self._viewpointCombobox.configure(values=charNames)
        self._viewpointVar.set(value=preset)

        if self.element.scType > 0:
            self._isUnusedVar.set(True)
        else:
            self._isUnusedVar.set(False)

        self._appendToPrevVar.set(self.element.appendToPrev)

        if self._mdl.novel.noSceneField1:
            self._noSceneField1Var = self._mdl.novel.noSceneField1
        else:
            self._noSceneField1Var = ''

        if self._mdl.novel.noSceneField2:
            self._noSceneField2Var = (
                self._mdl.novel.noSceneField2
            )
        else:
            self._noSceneField2Var = ''

        if self._mdl.novel.noSceneField3:
            self._noSceneField3Var = self._mdl.novel.noSceneField3
        else:
            self._noSceneField3Var = ''

        if self._mdl.novel.otherSceneField1:
            self._otherSceneField1Var = self._mdl.novel.otherSceneField1
        else:
            self._otherSceneField1Var = ''

        if self._mdl.novel.otherSceneField2:
            self._otherSceneField2Var = self._mdl.novel.otherSceneField2
        else:
            self._otherSceneField2Var = ''

        if self._mdl.novel.otherSceneField3:
            self._otherSceneField3Var = self._mdl.novel.otherSceneField3
        else:
            self._otherSceneField3Var = ''


        self._plotlineCollection.set([
            (
                f'({self._mdl.novel.plotLines[plId].shortName}) '
                f'{self._mdl.novel.plotLines[plId].title}'
            )for plId in self.element.scPlotLines
        ])
        listboxSize = len(self.element.scPlotLines)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._plotlineCollection.set_height(listboxSize)
        self._configure_plotline_buttons()


        self._plotNotesWindow.clear()
        self._plotNotesWindow.config(state='disabled')
        self._plotNotesWindow.config(bg=prefs['color_inactive_bg'])
        if self.element.scPlotLines:
            self._plotlineCollection.selection = 0
            self.on_select_plotline(0)
        else:
            self._selectedPlotline = None

        plotPointTitles = []
        for ppId in self.element.scPlotPoints:
            plId = self.element.scPlotPoints[ppId]
            plotPointTitles.append(
                f'{self._mdl.novel.plotLines[plId].shortName}: '
                f'{self._mdl.novel.plotPoints[ppId].title}'
            )
        self._plotPointsDisplay.config(text=list_to_string(plotPointTitles))


        self.sceneVar.set(self.element.scene)

        self._goalBox.set_text(self.element.goal)

        self._conflictBox.set_text(self.element.conflict)

        self._outcomeBox.set_text(self.element.outcome)

        if self.element.scene == 3:
            self.set_custom_scene()
        elif self.element.scene == 2:
            self.set_reaction_scene()
        elif self.element.scene == 1:
            self.set_action_scene()
        else:
            self.set_not_applicable()

    def set_not_applicable(self, event=None):
        if self._noSceneField1Var:
            self._goalLabel.config(text=self._noSceneField1Var)
        else:
            self._goalLabel.config(text=f"{_('Field')} 1")

        if self._noSceneField2Var:
            self._conflictLabel.config(text=self._noSceneField2Var)
        else:
            self._conflictLabel.config(text=f"{_('Field')} 2")

        if self._noSceneField3Var:
            self._outcomeLabel.config(text=self._noSceneField3Var)
        else:
            self._outcomeLabel.config(text=f"{_('Field')} 3")

        self.element.scene = self.sceneVar.get()

    def set_reaction_scene(self, event=None):
        self._goalLabel.config(text=_('Reaction'))
        self._conflictLabel.config(text=_('Dilemma'))
        self._outcomeLabel.config(text=_('Choice'))
        self.element.scene = self.sceneVar.get()

    def show_ages(self, event=None):
        if self.element.date is not None:
            now = self.element.date
        else:
            try:
                now = PyCalendar.specific_date(
                    self.element.day,
                    self._mdl.novel.referenceDate
                )
            except Exception:
                self._report_missing_date()
                return

        charList = []
        for crId in self.element.characters:
            birthDate = self._mdl.novel.characters[crId].birthDate
            deathDate = self._mdl.novel.characters[crId].deathDate
            try:
                yearsOld, yearsDead, daysOld, daysDead = PyCalendar.age(
                    now,
                    birthDate,
                    deathDate
                )
                if yearsDead is not None:
                    if yearsDead:
                        time = yearsDead
                        suffix = _('years after death')
                    else:
                        time = daysDead
                        suffix = _('days after death')
                    if yearsOld:
                        suffix = f"{suffix} {_('at age')} {yearsOld}"

                elif yearsOld:
                    suffix = _('years old')
                    time = yearsOld
                else:
                    suffix = _('days old')
                    time = daysOld
                charList.append(
                    f'{self._mdl.novel.characters[crId].title}: '
                    f'{time} {suffix}'
                )
            except Exception:
                charList.append(
                    f'{self._mdl.novel.characters[crId].title}: '
                    f'({_("no data")})'
                )

        if charList:
            self._ui.show_info(
                message=f'{_("Date")}: {PyCalendar.get_locale_date(now, prefs["localize_date"])}',
                detail='\n'.join(charList),
                title=_('Show ages')
            )

    def show_moonphase(self, event=None):
        if self.element.date is not None:
            now = self.element.date
        else:
            try:
                now = PyCalendar.specific_date(
                    self.element.day,
                    self._mdl.novel.referenceDate
                )
            except:
                self._report_missing_date()
                return

        self._ui.show_info(
            message=f'{_("Date")}: {PyCalendar.get_locale_date(now, prefs["localize_date"])}',
            detail=f'{self._mdl.nvService.get_moon_phase_str(now)}',
            title=_("Moon phase")
        )

    def toggle_date(self, event=None):
        if not self._mdl.novel.referenceDate:
            self._report_missing_reference_date()
            return

        self._doNotUpdate = True
        if self.element.date:
            self.element.date_to_day(self._mdl.novel.referenceDate)
        elif self.element.day:
            self.element.day_to_date(self._mdl.novel.referenceDate)
        else:
            self._report_missing_date()
            return

        self._doNotUpdate = False
        self.set_data(self.elementId)

    def unlock(self):
        super().unlock()
        if self._selectedPlotline is None:
            self._plotNotesWindow.config(state='disabled')
        if self.element is not None:
            self._configure_character_buttons()
            self._configure_item_buttons()
            self._configure_location_buttons()
            self._configure_plotline_buttons()

    def _add_character(self, event=None):
        if self.element is None:
            return

        crList = self.element.characters
        crId = self._ui.tv.tree.selection()[0]
        if crId.startswith(CHARACTER_PREFIX) and not crId in crList:
            crList.append(crId)
            self.element.characters = crList
        self._ui.tv.restore_branch_status()

    def _add_item(self, event=None):
        if self.element is None:
            return

        itList = self.element.items
        itId = self._ui.tv.tree.selection()[0]
        if itId.startswith(ITEM_PREFIX)and not itId in itList:
            itList.append(itId)
            self.element.items = itList
        self._ui.tv.restore_branch_status()

    def _add_location(self, event=None):
        if self.element is None:
            return

        lcList = self.element.locations
        lcId = self._ui.tv.tree.selection()[0]
        if lcId.startswith(LOCATION_PREFIX)and not lcId in lcList:
            lcList.append(lcId)
            self.element.locations = lcList
        self._ui.tv.restore_branch_status()

    def _add_plotline(self, event=None):
        if self.element is None:
            return

        plotlineList = self.element.scPlotLines
        plId = self._ui.tv.tree.selection()[0]
        if plId.startswith(PLOT_LINE_PREFIX) and not plId in plotlineList:
            plotlineList.append(plId)
            self.element.scPlotLines = plotlineList
            plotlineSections = self._mdl.novel.plotLines[plId].sections
            if not self.elementId in plotlineSections:
                plotlineSections.append(self.elementId)
                self._mdl.novel.plotLines[plId].sections = plotlineSections
        self._ui.tv.restore_branch_status()

    def _configure_character_buttons(self, event=None):
        if (
            self.element.characters
            and self._characterCollection.selection is not None
        ):
            if self.isLocked:
                self._characterCollection.btnOpen.config(state='normal')
                self._characterCollection.btnRemove.config(state='disabled')
            else:
                self._characterCollection.enable_buttons()
        else:
            self._characterCollection.disable_buttons()

    def _configure_item_buttons(self, event=None):
        if (
            self.element.items
            and self._itemCollection.selection is not None
        ):
            if self.isLocked:
                self._itemCollection.btnOpen.config(state='normal')
                self._itemCollection.btnRemove.config(state='disabled')
            else:
                self._itemCollection.enable_buttons()
        else:
            self._itemCollection.disable_buttons()

    def _configure_location_buttons(self, event=None):
        if (
            self.element.locations
            and self._locationCollection.selection is not None
        ):
            if self.isLocked:
                self._locationCollection.btnOpen.config(state='normal')
                self._locationCollection.btnRemove.config(state='disabled')
            else:
                self._locationCollection.enable_buttons()
        else:
            self._locationCollection.disable_buttons()

    def _configure_plotline_buttons(self, event=None):
        if self.element.scPlotLines:
            if self.isLocked:
                self._plotlineCollection.btnOpen.config(state='normal')
                self._plotlineCollection.btnRemove.config(state='disabled')
            else:
                self._plotlineCollection.enable_buttons()
        else:
            self._plotlineCollection.disable_buttons()

    def _create_frames(self):
        self._create_index_card()
        self._activate_color_field()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _report_missing_date(self):
        self._ui.show_error(
            message=_('Date information is missing'),
            detail=f"{_('Please enter either a section date or a day and a reference date')}.",
        )

    def _toggle_date_time_frame(self, event=None):
        if prefs['show_date_time']:
            self._dateTimeFrame.hide()
            prefs['show_date_time'] = False
        else:
            self._dateTimeFrame.show()
            prefs['show_date_time'] = True
        self._toggle_folding_frame()

    def _toggle_plot_frame(self, event=None):
        if prefs['show_plot']:
            self._plotFrame.hide()
            prefs['show_plot'] = False
        else:
            self._plotFrame.show()
            prefs['show_plot'] = True
        self._toggle_folding_frame()

    def _toggle_relation_frame(self, event=None):
        if prefs['show_relationships']:
            self._relationFrame.hide()
            prefs['show_relationships'] = False
        else:
            self._relationFrame.show()
            prefs['show_relationships'] = True
        self._toggle_folding_frame()

    def _toggle_scene_frame(self, event=None):
        if prefs['show_scene']:
            self._sceneFrame.hide()
            prefs['show_scene'] = False
        else:
            self._sceneFrame.show()
            prefs['show_scene'] = True
        self._toggle_folding_frame()



class StageView(ElementView):
    _HELP_PAGE = 'stage_view.html'

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_st_links'

    def set_data(self, elementId):
        self.element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()


class PropertiesViewer(ttk.Frame, SubController):

    def __init__(self, parent, model, view, controller, **kw):
        super().__init__(parent, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._clients = []

        self.noView = self._make_view(BlankView)
        self.projectView = self._make_view(ProjectView)
        self.chapterView = self._make_view(ChapterView)
        self.stageView = self._make_view(StageView)
        self.sectionView = self._make_view(SectionView)
        self.characterView = self._make_view(CharacterView)
        self.locationView = self._make_view(LocationView)
        self.itemView = self._make_view(ItemView)
        self.plotlineView = self._make_view(PlotLineView)
        self.plotPointView = self._make_view(PlotPointView)
        self.projectnoteView = self._make_view(ProjectNoteView)

        self.activeView = self.noView
        self.activeView.set_data(None)
        self.activeView._doNotUpdate = False

    def apply_changes(self, event=None):
        if not self._ctrl.isLocked:
            self.activeView._doNotUpdate = True
            self.activeView.apply_changes()
            self.activeView._doNotUpdate = False

    def focus_title(self):
        self.activeView.focus_title()

    def lock(self):
        for client in self._clients:
            client.lock()

    def on_close(self):
        self._view_nothing()

    def show_properties(self, nodeId):
        if self._mdl is None:
            self._view_nothing()
        elif nodeId.startswith(SECTION_PREFIX):
            self._view_section(nodeId)
        elif nodeId == self._mdl.trashBin:
            self._view_nothing()
        elif nodeId.startswith(CHAPTER_PREFIX):
            self._view_chapter(nodeId)
        elif nodeId.startswith(CH_ROOT):
            self._view_project()
        elif nodeId.startswith(CHARACTER_PREFIX):
            self._view_character(nodeId)
        elif nodeId.startswith(LOCATION_PREFIX):
            self._view_location(nodeId)
        elif nodeId.startswith(ITEM_PREFIX):
            self._view_item(nodeId)
        elif nodeId.startswith(PLOT_LINE_PREFIX):
            self._view_plotline(nodeId)
        elif nodeId.startswith(PLOT_POINT_PREFIX):
            self._view_plot_point(nodeId)
        elif nodeId.startswith(PRJ_NOTE_PREFIX):
            self._view_projectnote(nodeId)
        else:
            self._view_nothing()
        self.activeView._doNotUpdate = False

    def refresh(self):
        if not self.activeView._doNotUpdate:
            try:
                self.show_properties(self.activeView.elementId)
            except:
                pass

    def unlock(self):
        for client in self._clients:
            client.unlock()

    def _make_view(self, viewClass):
        newView = viewClass(self, self._mdl, self._ui, self._ctrl)
        self._clients.append(newView)
        return newView

    def _set_data(self, elemId):
        if self._ctrl.isLocked:
            self.activeView.unlock()
            self.activeView.set_data(elemId)
            self.activeView.lock()
        else:
            self.activeView.set_data(elemId)

    def _view_plotline(self, plId):
        if not self.activeView is self.plotlineView:
            self.activeView.hide()
            self.activeView = self.plotlineView
            self.activeView.show()
        self._set_data(plId)

    def _view_chapter(self, chId):
        if not self.activeView is self.chapterView:
            self.activeView.hide()
            self.activeView = self.chapterView
            self.activeView.show()
        self._set_data(chId)

    def _view_character(self, crId):
        if not self.activeView is self.characterView:
            self.activeView.hide()
            self.activeView = self.characterView
            self.activeView.show()
        self._set_data(crId)

    def _view_item(self, itId):
        if not self.activeView is self.itemView:
            self.activeView.hide()
            self.activeView = self.itemView
            self.activeView.show()
        self._set_data(itId)

    def _view_location(self, lcId):
        if not self.activeView is self.locationView:
            self.activeView.hide()
            self.activeView = self.locationView
            self.activeView.show()
        self._set_data(lcId)

    def _view_nothing(self):
        if not self.activeView is self.noView:
            self.activeView.hide()
            self.activeView = self.noView
            self.activeView.show()

    def _view_project(self):
        if not self.activeView is self.projectView:
            self.activeView.hide()
            self.activeView = self.projectView
            self.activeView.show()
        self._set_data(CH_ROOT)

    def _view_projectnote(self, pnId):
        if not self.activeView is self.projectnoteView:
            self.activeView.hide()
            self.activeView = self.projectnoteView
            self.activeView.show()
        self._set_data(pnId)

    def _view_section(self, scId):
        if self._mdl.novel.sections[scId].scType > 1:
            if not self.activeView is self.stageView:
                self.activeView.hide()
                self.activeView = self.stageView
                self.activeView.show()
        else:
            if not self.activeView is self.sectionView:
                self.activeView.hide()
                self.activeView = self.sectionView
                self.activeView.show()
            if self._mdl.tree.parent(scId) == self._mdl.trashBin:
                self.activeView.lock()
            elif self.activeView.isLocked and not self._ctrl.isLocked:
                self.activeView.unlock()
        self._set_data(scId)

    def _view_plot_point(self, ppId):
        if not self.activeView is self.plotPointView:
            self.activeView.hide()
            self.activeView = self.plotPointView
            self.activeView.show()
        self._set_data(ppId)



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import ttk



class Toolbar(SubController):

    def __init__(self, view, controller):
        self._ui = view
        self._ctrl = controller
        self.disableOnLock = []
        self._disableOnClose = []

        self.masterBar = ttk.Frame(self._ui.mainWindow)
        self.buttonBar = ttk.Frame(self.masterBar)
        self.buttonBar.pack(fill='both', side='left')

        self.goBackButton = self.new_button(
            text=_('Back'),
            image=self._ui.icons.goBackIcon,
            command=self._ui.tv.go_back,
            disableOnLock=False,
            accelerator=KEYS.BACK[1],
        )
        self.goBackButton.pack(side='left')

        self.goForwardButton = self.new_button(
            text=_('Forward'),
            image=self._ui.icons.goForwardIcon,
            command=self._ui.tv.go_forward,
            disableOnLock=False,
            accelerator=KEYS.FORWARD[1],
        )
        self.goForwardButton.pack(side='left')

        self.add_separator()

        self.viewBookButton = self.new_button(
            text=_('Show Book'),
            image=self._ui.icons.viewBookIcon,
            command=self._ui.tv.show_book,
            disableOnLock=False,
        )
        self.viewBookButton.pack(side='left')

        self.viewPlotLinesButton = self.new_button(
            text=_('Show Plot lines'),
            image=self._ui.icons.viewPlotLinesIcon,
            command=self._ui.tv.show_plot_lines,
            disableOnLock=False,
        )
        self.viewPlotLinesButton.pack(side='left')

        self.viewCharactersButton = self.new_button(
            text=_('Show Characters'),
            image=self._ui.icons.viewCharactersIcon,
            command=self._ui.tv.show_characters,
            disableOnLock=False,
        )
        self.viewCharactersButton.pack(side='left')

        self.viewLocationsButton = self.new_button(
            text=_('Show Locations'),
            image=self._ui.icons.viewLocationsIcon,
            command=self._ui.tv.show_locations,
            disableOnLock=False,
        )
        self.viewLocationsButton.pack(side='left')

        self.viewItemsButton = self.new_button(
            text=_('Show Items'),
            image=self._ui.icons.viewItemsIcon,
            command=self._ui.tv.show_items,
            disableOnLock=False,
        )
        self.viewItemsButton.pack(side='left')

        self.viewProjectnotesButton = self.new_button(
            text=_('Show Project notes'),
            image=self._ui.icons.viewProjectnotesIcon,
            command=self._ui.tv.show_project_notes,
            disableOnLock=False,
        )
        self.viewProjectnotesButton.pack(side='left')

        self.add_separator()

        self.saveButton = self.new_button(
            text=_('Save'),
            image=self._ui.icons.saveIcon,
            command=self._ctrl.save_project,
            accelerator=KEYS.SAVE_PROJECT[1],
        )
        self.saveButton.pack(side='left')

        self.lockButton = self.new_button(
            text=_('Lock/unlock'),
            image=self._ui.icons.lockIcon,
            command=self._ctrl.toggle_lock,
            disableOnLock=False,
        )
        self.lockButton.pack(side='left')

        self.updateButton = self.new_button(
            text=_('Update from manuscript'),
            image=self._ui.icons.updateFromManuscriptIcon,
            command=self._ctrl.update_from_manuscript,
        )
        self.updateButton.pack(side='left')

        self.manuscriptButton = self.new_button(
            text=_('Export Manuscript'),
            image=self._ui.icons.manuscriptIcon,
            command=self._ctrl.open_manuscript,
            disableOnLock=False,
        )
        self.manuscriptButton.pack(side='left')

        self.add_separator()

        self.addElementButton = self.new_button(
            text=_('Add'),
            image=self._ui.icons.addIcon,
            command=self._ctrl.add_new_element,
            accelerator=KEYS.ADD_ELEMENT[1],
        )
        self.addElementButton.pack(side='left')

        self.addChildButton = self.new_button(
            text=_('Add child'),
            image=self._ui.icons.addChildIcon,
            command=self._ctrl.add_new_child,
            accelerator=KEYS.ADD_CHILD[1],
        )
        self.addChildButton.pack(side='left')

        self.addParentButton = self.new_button(
            text=_('Add parent'),
            image=self._ui.icons.addParentIcon,
            command=self._ctrl.add_new_parent,
            accelerator=KEYS.ADD_PARENT[1],
        )
        self.addParentButton.pack(side='left')

        self.deleteElementButton = self.new_button(
            text=_('Delete'),
            image=self._ui.icons.removeIcon,
            command=self._ctrl.delete_elements,
            accelerator=KEYS.DELETE[1],
        )
        self.deleteElementButton.pack(side='left')

        self.add_separator()

        self.cutButton = self.new_button(
            text=f"{_('Cut')} ({KEYS.CUT[1]})",
            image=self._ui.icons.cutIcon,
            command=self._ctrl.cut_element,
        )
        self.cutButton.pack(side='left')

        self.copyButton = self.new_button(
            text=f"{_('Copy')} ({KEYS.COPY[1]})",
            image=self._ui.icons.copyIcon,
            command=self._ctrl.copy_element,
        )
        self.copyButton.pack(side='left')

        self.pasteButton = self.new_button(
            text=f"{_('Paste')} ({KEYS.PASTE[1]})",
            image=self._ui.icons.pasteIcon,
            command=self._ctrl.paste_element,
        )
        self.pasteButton.pack(side='left')

        self.add_separator(master=self.masterBar)

        self.highlightTaggedButton = self.new_button(
            text=_('Highlight tagged elements'),
            image=self._ui.icons.tagsIcon,
            command=self._ui.tv.select_tag_and_highlight_elements,
            disableOnLock=False,
            master=self.masterBar,
        )
        self.highlightTaggedButton.pack(side='left')

        self.selectHighlightedButton = self.new_button(
            text=_('Select highlighted elements'),
            image=self._ui.icons.selectIcon,
            command=self._ui.tv.select_highlighted_elements,
            disableOnLock=False,
            disableOnClose=False,
            master=self.masterBar,
        )
        self.selectHighlightedButton.configure(
            state='disabled',
        )
        self.selectHighlightedButton.pack(side='left')

        self.resetHighlightingButton = self.new_button(
            text=_('Reset Highlighting'),
            image=self._ui.icons.resetHighlightIcon,
            command=self._ui.tv.reset_highlighting,
            disableOnLock=False,
            disableOnClose=False,
            master=self.masterBar,
        )
        self.resetHighlightingButton.configure(
            state='disabled',
        )
        self.resetHighlightingButton.pack(side='left')
        self.highlightingLabel = tk.Label(
            self.masterBar,
            fg=prefs['color_text_fg'],
            bg=prefs['color_highlight'],
        )


        self.propertiesButton = self.new_button(
            text=_('Toggle Properties'),
            image=self._ui.icons.propertiesIcon,
            command=self._ui.toggle_properties_view,
            disableOnClose=False,
            disableOnLock=False,
            accelerator=KEYS.TOGGLE_PROPERTIES[1],
            master=self.masterBar,
        )
        self.propertiesButton.pack(side='right')

        self.viewerButton = self.new_button(
            text=_('Toggle Text viewer'),
            image=self._ui.icons.viewerIcon,
            command=self._ui.toggle_contents_view,
            disableOnClose=False,
            disableOnLock=False,
            accelerator=KEYS.TOGGLE_VIEWER[1],
            master=self.masterBar,
        )
        self.viewerButton.pack(side='right')

        self.masterBar.pack(
            expand=False,
            before=self._ui.appWindow,
            fill='both',
        )

    def add_separator(
        self,
        master=None,
        ):
        if master is None:
            master = self.buttonBar
        tk.Frame(
            master,
            bg=prefs['color_separator'],
            width=1,
        ).pack(side='left', fill='y', padx=4)

    def disable_menu(self):
        for button in self._disableOnClose:
            button.config(state='disabled')

    def enable_menu(self):
        for button in self._disableOnClose:
            button.config(state='normal')

    def lock(self):
        for button in self.disableOnLock:
            button.config(state='disabled')

    def new_button(
        self,
        text,
        image,
        command,
        disableOnClose=True,
        disableOnLock=True,
        accelerator=None,
        master=None,
    ):
        if master is None:
            master = self.buttonBar
        newButton = ttk.Button(
            master,
            text=text,
            image=image,
            command=command,
        )
        newButton.image = image
        if disableOnClose:
            self._disableOnClose.append(newButton)
        if disableOnLock:
            self.disableOnLock.append(newButton)

        if prefs['enable_hovertips']:
            if accelerator is None:
                hoverText = text
            else:
                hoverText = f'{text} ({accelerator})'
            Hovertip(newButton, hoverText)

        return newButton

    def reset_section_highlighting(self):
        self.highlightingLabel.pack_forget()
        self.resetHighlightingButton.configure(state='disabled')
        self.selectHighlightedButton.configure(state='disabled')

    def set_section_highlighting(self, text):
        self.highlightingLabel.pack(
            side='left',
            padx=5,
            after=self.resetHighlightingButton,
        )
        self.highlightingLabel.configure(text=text)
        self.resetHighlightingButton.configure(state='normal')
        self.selectHighlightedButton.configure(state='normal')

    def unlock(self):
        for button in self.disableOnLock:
            button.config(state='normal')

from tkinter import ttk



class HistoryList:

    def __init__(self):
        self._historyList = []
        self._pointer = None
        self._lock = False

    def append_node(self, node):
        if not self._lock:
            try:
                del self._historyList[self._pointer + 1:]
            except:
                pass
            if (
                self._pointer is None
                or self._historyList[self._pointer] != node
            ):
                self._historyList.append(node)
                self._pointer = len(self._historyList) - 1
        self._lock = False

    def go_back(self):
        if self._pointer is None:
            return None

        if self._pointer > 0:
            self._pointer -= 1
        return self._historyList[self._pointer]

    def go_forward(self):
        if self._pointer is None:
            return None

        if self._pointer + 1 < len(self._historyList):
            self._pointer += 1
        return self._historyList[self._pointer]

    def lock(self):
        self._lock = True

    def reset(self):
        self._historyList = []
        self._pointer = None
        self._lock = False

from tkinter import ttk



class NvTreeview(ttk.Treeview):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.on_element_change = self.do_nothing

        self.append('', CH_ROOT)
        self.append('', PL_ROOT)
        self.append('', CR_ROOT)
        self.append('', LC_ROOT)
        self.append('', IT_ROOT)
        self.append('', PN_ROOT)

    def append(self, parent, iid, text=None):
        if text is None:
            text = iid
        self.insert(parent, 'end', iid, text=text)

    def delete(self, *items):
        super().delete(*items)
        self.on_element_change()

    def delete_children(self, parent):
        for child in self.get_children(parent):
            self.delete(child)

    def insert(self, parent, index, iid=None, **kw):
        super().insert(parent, index, iid, **kw)
        self.on_element_change()

    def move(self, item, parent, index):
        super().move(item, parent, index)
        self.on_element_change()

    def reset(self):
        self.on_element_change = self.do_nothing
        for rootElement in self.get_children(''):
            for child in self.get_children(rootElement):
                self.delete(child)

    def do_nothing(self):
        pass
import tkinter.font as tkFont


class TreeViewer(ttk.Frame, Observer, SubController):
    COLORING_MODES = [
        _('None'),
        _('Status'),
        _('Work phase'),
        _('Viewpoint'),
    ]

    _COLUMNS = dict(
        wc=(_('Words'), 'wc_width'),
        vp=(_('Viewpoint'), 'vp_width'),
        st=(_('Status'), 'status_width'),
        nt=(f"{_('N')}◳", 'nt_width'),
        dt=(_('Date'), 'date_width'),
        tm=(_('Time'), 'time_width'),
        dr=(_('Duration'), 'duration_width'),
        tg=(_('Tags'), 'tags_width'),
        po=(_('Position'), 'ps_width'),
        ac=(_('Plot lines'), 'arcs_width'),
        sc=(_('Scene'), 'scene_width'),
        tp=(_('Plot points'), 'points_width'),
    )

    _ROOT_TITLES = {
        CH_ROOT: _('Book'),
        CR_ROOT: _('Characters'),
        LC_ROOT: _('Locations'),
        IT_ROOT: _('Items'),
        PL_ROOT: _('Plot lines'),
        PN_ROOT: _('Project notes'),
    }

    _SCENE = [
        '-',
        _('A'),
        _('R'),
        'x',
    ]

    _NOTE_INDICATOR = _('N')
    _COMMENT_INDICATOR = '◳'

    def __init__(self, parent, model, view, **kw):
        super().__init__(parent, **kw)
        self._mdl = model
        self._ui = view
        self._wordsTotal = None

        self.skipUpdate = False
        self._branch_status = {}

        self.tree = NvTreeview(self)
        scrollX = ttk.Scrollbar(
            self,
            orient='horizontal',
            command=self.tree.xview,
        )
        scrollY = ttk.Scrollbar(
            self.tree,
            orient='vertical',
            command=self.tree.yview,
        )
        self.tree.configure(xscrollcommand=scrollX.set)
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollX.pack(side='bottom', fill='x')
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)

        self.configure_columns()

        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure(
            'root',
            font=('', fontSize, 'bold'),
        )
        self.tree.tag_configure(
            'chapter',
            foreground=prefs['color_chapter'],
        )
        self.tree.tag_configure(
            'plot_line',
            font=('', fontSize, 'bold'),
        )
        self.tree.tag_configure(
            'unused',
            foreground=prefs['color_unused'],
        )
        self.tree.tag_configure(
            'epigraph',
            foreground=prefs['color_chapter'],
        )
        self.tree.tag_configure(
            'stage1',
            font=('', fontSize, 'bold underline'),
            foreground=prefs['color_stage'],
        )
        self.tree.tag_configure(
            'stage2',
            font=('', fontSize, 'underline'),
            foreground=prefs['color_stage'],
        )
        self.tree.tag_configure(
            'part',
            font=('', fontSize, 'bold'),
        )
        self.tree.tag_configure(
            'major',
            font=('', fontSize, 'bold'),
        )
        self.tree.tag_configure(
            'status1',
            foreground=prefs['color_outline'],
        )
        self.tree.tag_configure(
            'status2',
            foreground=prefs['color_draft'],
        )
        self.tree.tag_configure(
            'status3',
            foreground=prefs['color_1st_edit'],
        )
        self.tree.tag_configure(
            'status4',
            foreground=prefs['color_2nd_edit'],
        )
        self.tree.tag_configure(
            'status5',
            foreground=prefs['color_done'],
        )
        self.tree.tag_configure(
            'On_schedule',
            foreground=prefs['color_on_schedule'],
        )
        self.tree.tag_configure(
            'Behind_schedule',
            foreground=prefs['color_behind_schedule'],
        )
        self.tree.tag_configure(
            'Before_schedule',
            foreground=prefs['color_before_schedule'],
        )
        self.tree.tag_configure(
            'highlighted',
            background=prefs['color_highlight'],
        )

        self._history = HistoryList()

        try:
            self.coloringMode = int(prefs['coloring_mode'])
        except:
            self.coloringMode = 0
        if self.coloringMode > len(self.COLORING_MODES):
            self.coloringMode = 0

        self._highlightTag = None
        self._highlightViewpoint = None
        self._highlightRelated = None
        self.highlightedElements = []

    def close_children(self, parent):
        self.tree.item(parent, open=False)
        self._update_node_values(parent, collect=True)
        for child in self.tree.get_children(parent):
            self.close_children(child)

    def collapse_all(self, event=None):
        self.close_children('')

    def collapse_selected(self, event=None):
        self.close_children(self.tree.selection()[0])

    def configure_columns(self):
        self._colPos = {}
        self.columns = []
        titles = []
        srtColumns = string_to_list(prefs['column_order'])

        for coId in self._COLUMNS:
            if not coId in srtColumns:
                srtColumns.append(coId)
        i = 0
        for coId in srtColumns:
            try:
                title, width = self._COLUMNS[coId]
            except:
                continue

            self._colPos[coId] = i
            i += 1
            self.columns.append((coId, title, width))
            titles.append(title)
        self.tree.configure(columns=tuple(titles))
        for column in self.columns:
            self.tree.heading(column[1], text=column[1], anchor='w')
            self.tree.column(
                column[1],
                width=int(prefs[column[2]]),
                minwidth=3,
                stretch=False
            )
        self.tree.column(
            '#0',
            width=int(prefs['title_width']),
            stretch=False
        )

    def expand_all(self, event=None):
        self.open_children('')
        try:
            node = self.tree.selection()[0]
        except:
            pass
        else:
            self.see_node(node)
            self.tree.focus(node)

    def expand_selected(self, event=None):
        self.open_children(self.tree.selection()[0])

    def go_back(self, event=None):
        self._browse_tree(self._history.go_back())
        return('break')

    def go_forward(self, event=None):
        self._browse_tree(self._history.go_forward())
        return('break')

    def go_to_node(self, node):
        try:
            self.tree.focus_set()
            self.tree.selection_set(node)
            self.see_node(node)
            self.tree.focus(node)
            self._ui.on_change_selection(node)
        except:
            pass

    def highlight_tagged_elements(self, tag):
        self._ui.restore_status()
        self.reset_highlighting()
        self._highlightTag = tag
        self.update_tree()
        if not self.highlightedElements:
            self._ui.set_status(f'#{_("No elements tagged with")} "{tag}".')
            return

        self.expand_all()
        self.see_node(self.highlightedElements[0])
        self._ui.toolbar.set_section_highlighting(
            f'{_("Tag")}: "{tag}"'
        )

    def highlight_viewpoint_sections(self):
        self._ui.restore_status()
        self.reset_highlighting()
        selectedNode = self.tree.selection()[0]
        self._highlightViewpoint = selectedNode
        self.update_tree()
        if not self.highlightedElements:
            self._ui.set_status(f'#{_("Not a viewpoint character")}.')
            return

        self.show_book()
        self.see_node(self.highlightedElements[0])
        self._ui.toolbar.set_section_highlighting(
            f'{_("Viewpoint")}: '
            f'{self._mdl.novel.characters[selectedNode].title}'
        )

    def highlight_related_sections(self):
        self._ui.restore_status()
        self.reset_highlighting()
        selectedNode = self.tree.selection()[0]
        self._highlightRelated = selectedNode
        self.update_tree()
        if not self.highlightedElements:
            self._ui.set_status(f'#{_("No relationship found")}.')
            return

        self.show_book()
        self.see_node(self.highlightedElements[0])
        text = ''
        if selectedNode.startswith(CHARACTER_PREFIX):
            highlighted = self._mdl.novel.characters[selectedNode].title
            text = f"{_('Character')}: {highlighted}"
        elif selectedNode.startswith(LOCATION_PREFIX):
            highlighted = self._mdl.novel.locations[selectedNode].title
            text = f"{_('Location')}: {highlighted}"
        elif selectedNode.startswith(LOCATION_PREFIX):
            highlighted = self._mdl.novel.items[selectedNode].title
            text = f"{_('Item')}: {highlighted}"
        elif selectedNode.startswith(PLOT_LINE_PREFIX):
            highlighted = self._mdl.novel.plotLines[selectedNode].title
            text = f"{_('Plot line')}: {highlighted}"
        elif selectedNode.startswith(PLOT_POINT_PREFIX):
            highlighted = self._mdl.novel.plotPoints[selectedNode].title
            text = f"{_('Plot point')}: {highlighted}"
        self._ui.toolbar.set_section_highlighting(text)

    def load_next(self, event=None):
        thisNode = self.tree.selection()[0]
        nextNode = self.next_node(thisNode)
        if nextNode:
            self.go_to_node(nextNode)
        return('break')

    def load_prev(self, event=None):
        thisNode = self.tree.selection()[0]
        prevNode = self.prev_node(thisNode)
        if prevNode:
            self.go_to_node(prevNode)
        return('break')

    def next_node(self, thisNode):

        def search_tree(parent, result, flag):
            for child in self.tree.get_children(parent):
                if result:
                    break

                if child.startswith(prefix):
                    if prefix == CHAPTER_PREFIX:
                        if (self._mdl.novel.chapters[child].chLevel
                            != self._mdl.novel.chapters[thisNode].chLevel
                        ):
                            continue

                    elif prefix == SECTION_PREFIX:
                        if self._mdl.novel.sections[thisNode].scType > 1:
                            if (self._mdl.novel.sections[child].scType
                                != self._mdl.novel.sections[thisNode].scType
                            ):
                                continue

                        elif self._mdl.novel.sections[thisNode].scType < 2:
                            if self._mdl.novel.sections[child].scType > 1:
                                continue

                    if flag:
                        result = child
                        break

                    elif child == thisNode:
                        flag = True
                else:
                    result, flag = search_tree(child, result, flag)
            return result, flag

        prefix = thisNode[:2]
        root = self.tree.parent(thisNode)
        while not root.startswith(ROOT_PREFIX):
            root = self.tree.parent(root)
        nextNode, __ = search_tree(root, None, False)
        return nextNode

    def on_close(self):
        self.reset_view()

    def on_quit(self):
        prefs['title_width'] = self.tree.column('#0', 'width')
        for i, column in enumerate(self.columns):
            prefs[column[2]] = self.tree.column(i, 'width')

        prefs['coloring_mode'] = self.coloringMode

    def open_children(self, parent):
        self.tree.item(parent, open=True)
        self._update_node_values(parent, collect=False)
        for child in self.tree.get_children(parent):
            self.open_children(child)

    def prev_node(self, thisNode):

        def search_tree(parent, result, prevNode):
            for child in self.tree.get_children(parent):
                if result:
                    break

                if child.startswith(prefix):
                    if prefix == CHAPTER_PREFIX:
                        if (self._mdl.novel.chapters[child].chLevel
                            != self._mdl.novel.chapters[thisNode].chLevel
                        ):
                            continue

                    elif prefix == SECTION_PREFIX:
                        if self._mdl.novel.sections[thisNode].scType > 1:
                            if (self._mdl.novel.sections[child].scType
                                != self._mdl.novel.sections[thisNode].scType
                            ):
                                continue

                        elif self._mdl.novel.sections[thisNode].scType < 2:
                            if self._mdl.novel.sections[child].scType > 1:
                                continue

                    if child == thisNode:
                        result = prevNode
                        break
                    else:
                        prevNode = child
                else:
                    result, prevNode = search_tree(child, result, prevNode)
            return result, prevNode

        prefix = thisNode[:2]
        root = self.tree.parent(thisNode)
        while not root.startswith(ROOT_PREFIX):
            root = self.tree.parent(root)
        prevNode, __ = search_tree(root, None, None)
        return prevNode

    def refresh(self, event=None):
        if self.skipUpdate:
            self.skipUpdate = False
            return

        if self._mdl.prjFile is None:
            return

        self.update_tree()
        self.tree.configure(selectmode='extended')

    def reset_highlighting(self):
        self.highlightedElements.clear()
        self._highlightTag = None
        self._highlightViewpoint = None
        self._highlightRelated = None
        self.update_tree()
        self._ui.toolbar.reset_section_highlighting()

    def reset_view(self):
        self._history.reset()
        for rootElement in self.tree.get_children(''):
            self.tree.item(rootElement, text='')
        self.tree.configure({'selectmode': 'none'})
        self.reset_highlighting()
        self._mdl.reset_tree()

    def restore_branch_status(self):
        for branch in self._branch_status:
            try:
                self.tree.item(
                    branch,
                    open=self._branch_status[branch]
                )
            except:
                pass

    def update_tree(self):

        def update_branch(node, scnPos=0, isEpigraph=False):
            for elemId in self.tree.get_children(node):
                if elemId.startswith(SECTION_PREFIX):
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_section_row_data(
                        elemId,
                        isEpigraph,
                        position=scnPos
                    )
                    if self._mdl.novel.sections[elemId].scType == 0:
                        scnPos += self._mdl.novel.sections[elemId].wordCount
                        isEpigraph = False
                elif elemId.startswith(CHARACTER_PREFIX):
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_character_row_data(elemId)
                elif elemId.startswith(LOCATION_PREFIX):
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_location_row_data(elemId)
                elif elemId.startswith(ITEM_PREFIX):
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_item_row_data(elemId)
                elif elemId.startswith(CHAPTER_PREFIX):
                    chpPos = scnPos
                    scnPos = update_branch(
                        elemId,
                        scnPos=scnPos,
                        isEpigraph=self._mdl.novel.chapters[elemId].hasEpigraph
                    )
                    isCollapsed = not self.tree.item(elemId, 'open')
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_chapter_row_data(
                        elemId,
                        position=chpPos,
                        collect=isCollapsed
                    )
                elif elemId.startswith(PLOT_LINE_PREFIX):
                    update_branch(elemId, scnPos)
                    isCollapsed = not self.tree.item(elemId, 'open')
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_plot_line_row_data(
                        elemId,
                        collect=isCollapsed
                    )
                elif elemId.startswith(PLOT_POINT_PREFIX):
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_plot_point_row_data(elemId)
                elif elemId.startswith(PRJ_NOTE_PREFIX):
                    (
                        title,
                        nodeValues,
                        nodeTags
                    ) = self._get_prj_note_row_data(elemId)
                else:
                    title = self._ROOT_TITLES[elemId]
                    nodeValues = []
                    nodeTags = 'root'
                    update_branch(elemId, scnPos)
                self.tree.item(
                    elemId, text=title,
                    values=nodeValues,
                    tags=nodeTags
                )
            return scnPos

        self._wordsTotal = self._mdl.get_counts()[0]
        self.highlightedElements.clear()
        update_branch('')

    def save_branch_status(self):
        self._branch_status.clear()
        for category in self.tree.get_children(''):
            self._branch_status[category] = self.tree.item(
                category, option='open')
            for branch in self.tree.get_children(category):
                self._branch_status[branch] = self.tree.item(
                    branch, option='open')

    def see_node(self, node):
        try:
            self.tree.see(node)
            parent = self.tree.parent(node)
            self._update_node_values(parent, collect=False)
        except:
            pass

    def select_highlighted_elements(self):
        if not self.highlightedElements:
            self._ui.set_status(f'#{_("No elements highlighted")}.')
            return

        self.tree.selection_remove(self.tree.selection())
        self.tree.selection_add(self.highlightedElements)

    def select_tag_and_highlight_elements(self):

        def highlight_selected(selectedTags):
            if selectedTags:
                self.highlight_tagged_elements(selectedTags[0])

        tagList = sorted(list(self._mdl.novel.get_tags()))
        if not tagList:
            self._ui.set_status(f'#{_("No tags defined")}.')
            return

        tags = {}
        for tag in tagList:
            tags[tag] = tag
        PickList(
            self._ui,
            _('Select tag'),
            tags,
            highlight_selected,
            icon=self._ui.icons.tagsIcon,
            multiple=False,
        )

    def show_book(self, event=None):
        self.collapse_all()
        self.show_branch(CH_ROOT)

    def show_branch(self, node):
        self.go_to_node(node)
        self.open_children(node)
        return 'break'

    def show_chapter_level(self, event=None):

        def show_chapters(parent):
            if parent.startswith(CHAPTER_PREFIX):
                self.tree.item(parent, open=False)
                self._update_node_values(parent, collect=True)
            else:
                self.tree.item(parent, open=True)
                for child in self.tree.get_children(parent):
                    show_chapters(child)

        show_chapters(CH_ROOT)
        return 'break'

    def show_characters(self, event=None):
        self.collapse_all()
        self.show_branch(CR_ROOT)

    def show_items(self, event=None):
        self.collapse_all()
        self.show_branch(IT_ROOT)

    def show_locations(self, event=None):
        self.collapse_all()
        self.show_branch(LC_ROOT)

    def show_plot_lines(self, event=None):
        self.collapse_all()
        self.show_branch(PL_ROOT)

    def show_project_notes(self, event=None):
        self.collapse_all()
        self.show_branch(PN_ROOT)

    def _browse_tree(self, node):
        if node and self.tree.exists(node):
            if self.tree.selection()[0] != node:
                self._history.lock()
                self.go_to_node(node)
        else:
            self._history.reset()
            self._history.append_node(self.tree.selection()[0])

    def _collect_ch_comment_indicators(self, chId):
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType != 1:
                    if self._mdl.novel.sections[scId].hasComment:
                        return self._COMMENT_INDICATOR

        return ''

    def _collect_ch_note_indicators(self, chId):
        if self._mdl.novel.chapters[chId].notes:
            return self._NOTE_INDICATOR

        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType != 1:
                    if self._mdl.novel.sections[scId].notes:
                        return self._NOTE_INDICATOR

        return ''

    def _collect_pl_note_indicators(self, plId):
        if self._mdl.novel.plotLines[plId].notes:
            return self._NOTE_INDICATOR

        for ppId in self.tree.get_children(plId):
            if self._mdl.novel.plotPoints[ppId].notes:
                return self._NOTE_INDICATOR

        return ''

    def _collect_plot_lines(self, chId):
        chPlotlineShortNames = []
        chPlotPointTitles = []
        chPlotlines = {}
        for plId in self._mdl.novel.plotLines:
            chPlotlines[plId] = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    scPlotlines = self._mdl.novel.sections[scId].scPlotLines
                    for plId in scPlotlines:
                        shortName = self._mdl.novel.plotLines[plId].shortName
                        if not shortName in chPlotlineShortNames:
                            chPlotlineShortNames.append(shortName)
                    for ppId in self._mdl.novel.sections[scId].scPlotPoints:
                        chPlotlines[plId].append(ppId)
            if len(chPlotlineShortNames) == 1:
                for plId in chPlotlines:
                    for ppId in chPlotlines[plId]:
                        chPlotPointTitles.append(
                            self._mdl.novel.plotPoints[ppId].title)
            else:
                for plId in chPlotlines:
                    for ppId in chPlotlines[plId]:
                        chPlotPointTitles.append(
                            f'{self._mdl.novel.plotLines[plId].shortName}'
                            f': {self._mdl.novel.plotPoints[ppId].title}'
                        )
        return (
            list_to_string(chPlotlineShortNames),
            list_to_string(chPlotPointTitles)
        )

    def _collect_tags(self, chId):
        chapterTags = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    if self._mdl.novel.sections[scId].tags:
                        for tag in self._mdl.novel.sections[scId].tags:
                            if not tag in chapterTags:
                                chapterTags.append(tag)
        return list_to_string(chapterTags)

    def _collect_viewpoints(self, chId):
        chapterViewpoints = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    try:
                        crId = self._mdl.novel.sections[scId].viepoint
                        viewpoint = self._mdl.novel.characters[crId].title
                        if not viewpoint in chapterViewpoints:
                            chapterViewpoints.append(viewpoint)
                    except:
                        pass
        return list_to_string(chapterViewpoints)

    def _count_words(self, chId):
        chapterWordCount = 0
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    chapterWordCount += (
                        self._mdl.novel.sections[scId].wordCount
                    )
        return chapterWordCount

    def _date_is_valid(self, section):
        if section.date is None:
            return False

        if section.date == section.NULL_DATE:
            return False

        return True

    def _get_chapter_row_data(self, chId, position=None, collect=False):
        nodeValues = [''] * len(self.columns)
        nodeTags = []
        if self._mdl.novel.chapters[chId].chType != 0:
            nodeTags.append('unused')
            if self._mdl.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')
        else:
            nodeTags.append('chapter')
            try:
                positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
            except:
                positionStr = ''
            wordCount = self._count_words(chId)
            if self._mdl.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')

                srtChapters = self.tree.get_children(CH_ROOT)
                i = srtChapters.index(chId) + 1
                while i < len(srtChapters):
                    c = srtChapters[i]
                    if self._mdl.novel.chapters[c].chLevel == 1:
                        break
                    i += 1
                    wordCount += self._count_words(c)
            nodeValues[self._colPos['wc']] = wordCount
            nodeValues[self._colPos['po']] = positionStr
            if collect:
                nodeValues[self._colPos['vp']] = self._collect_viewpoints(chId)
        if collect:
            nodeValues[self._colPos['tg']] = self._collect_tags(chId)
            (
                nodeValues[self._colPos['ac']],
                nodeValues[self._colPos['tp']]
            ) = self._collect_plot_lines(chId)
            nodeValues[self._colPos['nt']] = (
                f'{self._collect_ch_note_indicators(chId)}'
                f'{self._collect_ch_comment_indicators(chId)}'
            )
        else:
            nodeValues[self._colPos['nt']] = self._get_notes_indicator(
                self._mdl.novel.chapters[chId])
        return to_string(
            self._mdl.novel.chapters[chId].title), nodeValues, tuple(nodeTags)

    def _add_color_tag(self, elemId, nodeTags):
        if not prefs['color_tree']:
            return

        prefix = elemId[:2]
        color = self._mdl.novel.elementsByPrefix[prefix][elemId].color
        if color is None:
            return

        self.tree.tag_configure(
            f'{elemId}_color',
            foreground=color,
        )
        nodeTags.append(f'{elemId}_color')

    def _get_character_row_data(self, crId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(
            self._mdl.novel.characters[crId])

        wordCount = 0
        for scId in self._mdl.novel.sections:
            if self._mdl.novel.sections[scId].scType == 0:
                if self._mdl.novel.sections[scId].characters:
                    if self._mdl.novel.sections[scId].viewpoint == crId:
                        wordCount += self._mdl.novel.sections[scId].wordCount
        if wordCount > 0:
            nodeValues[self._colPos['wc']] = wordCount

            try:
                percentage = round(100 * wordCount / self._wordsTotal, 1)
                percentageStr = f'{percentage}%'
            except:
                percentageStr = ''
            nodeValues[self._colPos['vp']] = percentageStr

        try:
            nodeValues[self._colPos['tg']] = list_to_string(
                self._mdl.novel.characters[crId].tags)
        except:
            pass

        nodeTags = []

        if self._mdl.novel.characters[crId].isMajor:
            nodeTags.append('major')

        if self._element_is_highlighted(self._mdl.novel.characters[crId]):
            nodeTags.append('highlighted')
            self.highlightedElements.append(crId)

        self._add_color_tag(crId, nodeTags)

        return (
            to_string(self._mdl.novel.characters[crId].title),
            nodeValues, tuple(nodeTags)
        )

    def _get_date_or_day(self, scId):
        if self._date_is_valid(self._mdl.novel.sections[scId]):
            if prefs['localize_date']:
                return self._mdl.novel.sections[scId].localeDate
            else:
                return self._mdl.novel.sections[scId].date

        if self._mdl.novel.sections[scId].day is not None:
            return f'{_("Day")} {self._mdl.novel.sections[scId].day}'

        return ''

    def _get_item_row_data(self, itId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(
            self._mdl.novel.items[itId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(
                self._mdl.novel.items[itId].tags)
        except:
            pass

        nodeTags = []

        if self._element_is_highlighted(self._mdl.novel.items[itId]):
            nodeTags.append('highlighted')
            self.highlightedElements.append(itId)

        self._add_color_tag(itId, nodeTags)

        return to_string(
            self._mdl.novel.items[itId].title
            ), nodeValues, tuple(nodeTags)

    def _get_location_row_data(self, lcId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(
            self._mdl.novel.locations[lcId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(
                self._mdl.novel.locations[lcId].tags)
        except:
            pass

        nodeTags = []

        if self._element_is_highlighted(self._mdl.novel.locations[lcId]):
            nodeTags.append('highlighted')
            self.highlightedElements.append(lcId)

        self._add_color_tag(lcId, nodeTags)

        return to_string(
            self._mdl.novel.locations[lcId].title
            ), nodeValues, tuple(nodeTags)

    def _get_comment_indicator(self, element):
        if element.hasComment:
            return self._COMMENT_INDICATOR

        return ''

    def _get_notes_indicator(self, element):
        if element.notes:
            return self._NOTE_INDICATOR

        return ''

    def _get_plot_line_row_data(self, plId, collect=False):
        fullName = to_string(self._mdl.novel.plotLines[plId].title)
        title = f'({self._mdl.novel.plotLines[plId].shortName}) {fullName}'
        nodeValues = [''] * len(self.columns)
        if collect:
            nodeValues[self._colPos['nt']] = (
                self._collect_pl_note_indicators(plId)
            )
        else:
            nodeValues[self._colPos['nt']] = (
                self._get_notes_indicator(self._mdl.novel.plotLines[plId])
            )

        nodeTags = ['plot_line']

        self._add_color_tag(plId, nodeTags)

        return title, nodeValues, tuple(nodeTags)

    def _get_plot_point_row_data(self, ppId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(
            self._mdl.novel.plotPoints[ppId])

        scId = self._mdl.novel.plotPoints[ppId].sectionAssoc
        if scId:
            sectionTitle = self._mdl.novel.sections[scId].title
            if sectionTitle is not None:
                nodeValues[self._colPos['tp']] = sectionTitle

        nodeTags = []
        self._add_color_tag(ppId, nodeTags)

        return to_string(
            self._mdl.novel.plotPoints[ppId].title
            ), nodeValues, tuple(nodeTags)

    def _get_prj_note_row_data(self, pnId):
        nodeValues = [''] * len(self.columns)

        nodeTags = []
        self._add_color_tag(pnId, nodeTags)

        return to_string(
            self._mdl.novel.projectNotes[pnId].title
            ), nodeValues, tuple(nodeTags)

    def _get_section_row_data(self, scId, isEpigraph, position=None):

        if self._mdl.novel.sections[scId].time is not None:
            dispTime = PyCalendar.time_disp(
                self._mdl.novel.sections[scId].time)
        else:
            dispTime = ''

        nodeValues = [''] * len(self.columns)
        nodeTags = []
        if self._mdl.novel.sections[scId].scType > 1:
            stageLevel = self._mdl.novel.sections[scId].scType - 1
            nodeTags.append(f'stage{stageLevel}')
        else:
            positionStr = ''
            if self._mdl.novel.sections[scId].scType == 1:
                nodeTags.append('unused')
            else:
                if isEpigraph:
                    nodeTags.append('epigraph')
                elif self.coloringMode == 1:
                    nodeTags.append(
                        f'status{self._mdl.novel.sections[scId].status}'
                    )
                elif self.coloringMode == 2 and self._mdl.novel.workPhase:
                    if (self._mdl.novel.sections[scId].status
                        == self._mdl.novel.workPhase
                    ):
                        nodeTags.append('On_schedule')
                    elif (self._mdl.novel.sections[scId].status
                          < self._mdl.novel.workPhase
                    ):
                        nodeTags.append('Behind_schedule')
                    else:
                        nodeTags.append('Before_schedule')
                elif self.coloringMode == 3:
                    crId = self._mdl.novel.sections[scId].viewpoint
                    if crId:
                        color = self._mdl.novel.characters[crId].color
                        if color:
                            self.tree.tag_configure(
                                f'{crId}_color',
                                foreground=color,
                            )
                            nodeTags.append(f'{crId}_color')
                try:
                    position = round(100 * position / self._wordsTotal, 1)
                    positionStr = f'{position}%'
                except:
                    pass

            if self._section_is_highlighted(self._mdl.novel.sections[scId]):
                nodeTags.append('highlighted')
                self.highlightedElements.append(scId)

            nodeValues[self._colPos['po']] = positionStr
            nodeValues[self._colPos['wc']] = (
                self._mdl.novel.sections[scId].wordCount
            )
            nodeValues[self._colPos['st']] = STATUS[
                self._mdl.novel.sections[scId].status
            ]
            try:
                nodeValues[self._colPos['vp']] = (
                    self._mdl.novel.characters[
                        self._mdl.novel.sections[scId].viewpoint
                    ].title
                )
            except:
                nodeValues[self._colPos['vp']] = NOT_ASSIGNED

            nodeValues[self._colPos['sc']] = (
                self._SCENE[self._mdl.novel.sections[scId].scene]
            )
            nodeValues[self._colPos['dt']] = self._get_date_or_day(scId)
            nodeValues[self._colPos['tm']] = dispTime
            nodeValues[self._colPos['dr']] = PyCalendar.get_duration_str(
                self._mdl.novel.sections[scId])

            scPlotlineShortNames = []
            scPlotPointTitles = []
            scPlotlines = self._mdl.novel.sections[scId].scPlotLines
            for plId in scPlotlines:
                shortName = self._mdl.novel.plotLines[plId].shortName
                if not shortName in scPlotlineShortNames:
                    scPlotlineShortNames.append(shortName)
            for ppId in self._mdl.novel.sections[scId].scPlotPoints:
                if len(scPlotlineShortNames) == 1:
                    scPlotPointTitles.append(
                        self._mdl.novel.plotPoints[ppId].title)
                else:
                    plId = self._mdl.novel.sections[scId].scPlotPoints[ppId]
                    scPlotPointTitles.append(
                        f'{self._mdl.novel.plotLines[plId].shortName}: '
                        f'{self._mdl.novel.plotPoints[ppId].title}'
                    )
            nodeValues[self._colPos['ac']] = list_to_string(
                scPlotlineShortNames)
            nodeValues[self._colPos['tp']] = list_to_string(
                scPlotPointTitles)

        nodeValues[self._colPos['nt']] = (
            f'{self._get_notes_indicator(self._mdl.novel.sections[scId])}'
            f'{self._get_comment_indicator(self._mdl.novel.sections[scId])}'
        )

        try:
            nodeValues[self._colPos['tg']] = list_to_string(
                self._mdl.novel.sections[scId].tags)
        except:
            pass
        return to_string(
            self._mdl.novel.sections[scId].title
        ), nodeValues, tuple(nodeTags)

    def _on_close_branch(self, event):
        self._update_node_values(self.tree.selection()[0], collect=True)

    def _on_open_branch(self, event):
        self._update_node_values(self.tree.selection()[0], collect=False)

    def _on_select_node(self, event):
        try:
            nodeId = self.tree.selection()[0]
        except IndexError:
            return

        self._history.append_node(nodeId)
        self._ui.on_change_selection(nodeId)

    def _element_is_highlighted(self, element):
        if self._highlightTag is not None:
            return self._highlightTag in element.tags

        return False

    def _section_is_highlighted(self, section):
        if self._highlightTag is not None:
            return self._highlightTag in section.tags

        elif self._highlightViewpoint is not None:
            return self._highlightViewpoint == section.viewpoint

        elif self._highlightRelated is not None:
            if (
                self._highlightRelated in section.characters
                or self._highlightRelated in section.locations
                or self._highlightRelated in section.items
                or self._highlightRelated in section.scPlotLines
                or self._highlightRelated in section.scPlotPoints
            ):
                return True

        return False

    def _update_node_values(self, nodeId, collect=False):
        if nodeId.startswith(CHAPTER_PREFIX):
            positionStr = self.tree.item(nodeId)['values'][self._colPos['po']]
            __, nodeValues, __ = self._get_chapter_row_data(
                nodeId, position=None, collect=collect)
            nodeValues[self._colPos['po']] = positionStr
            self.tree.item(nodeId, values=nodeValues)
            return

        if nodeId.startswith(PLOT_LINE_PREFIX):
            __, nodeValues, __ = self._get_plot_line_row_data(
                nodeId, collect=collect)
            self.tree.item(nodeId, values=nodeValues)
            return



class MainView(Observer, MsgBoxes, SubController, MainMenu):
    _MIN_WINDOW_WIDTH = 400
    _MIN_WINDOW_HEIGHT = 200

    def __init__(self, model, controller, title):
        self._mdl = model
        self._ctrl = controller

        self.root = tk.Tk()
        self.root.minsize(self._MIN_WINDOW_WIDTH, self._MIN_WINDOW_HEIGHT)
        self.root.protocol("WM_DELETE_WINDOW", self._ctrl.on_quit)
        self.root.title(title)
        self.title = title
        colorProbe = tk.Label(self.root)
        self.colorFg = colorProbe.cget('fg')
        self.colorBg = colorProbe.cget('bg')
        del colorProbe

        self._mdl.add_observer(self)

        self.mainWindow = ttk.Frame()
        self.mainWindow.pack(expand=True, fill='both')

        self._create_status_bar()

        self.guiStyle = ttk.Style()
        if prefs.get('root_geometry', None):
            self.root.geometry(prefs['root_geometry'])

        self._create_path_bar()

        set_icon(self.root, icon='novelibre')
        self.icons = Icons()


        self.appWindow = ttk.Frame(self.mainWindow)
        self.appWindow.pack(expand=True, fill='both')

        self.leftFrame = ttk.Frame(self.appWindow)
        self.leftFrame.pack(side='left', expand=True, fill='both')

        self.tv = TreeViewer(
            self.leftFrame,
            self._mdl,
            self,
        )

        self._mdl.add_observer(self.tv)
        self._ctrl.register_client(self.tv)
        self.tv.pack(expand=True, fill='both')

        self.middleFrame = ttk.Frame(
            self.appWindow,
            width=prefs['middle_frame_width'],
        )
        self.middleFrame.pack_propagate(0)

        self.contentsView = ContentsViewer(
            self.middleFrame,
            self._mdl,
            self._ctrl,
        )
        self._mdl.add_observer(self.contentsView)
        self._ctrl.register_client(self.contentsView)
        if prefs['show_contents']:
            self.middleFrame.pack(side='left', expand=False, fill='both')

        self.rightFrame = ttk.Frame(
            self.appWindow,
            width=prefs['right_frame_width'],
        )
        self.rightFrame.pack_propagate(0)
        if prefs['show_properties']:
            self.rightFrame.pack(expand=True, fill='both')

        self.propertiesView = PropertiesViewer(
            self.rightFrame,
            self._mdl,
            self,
            self._ctrl,
        )
        self.propertiesView.pack(expand=True, fill='both')
        self._propWinDetached = False
        if prefs['detach_prop_win']:
            self._detach_properties_frame()
        self._mdl.add_observer(self.propertiesView)
        self._ctrl.register_client(self.propertiesView)

        self.create_menus()

        self.toolbar = Toolbar(self, self._ctrl)
        self._ctrl.register_client(self.toolbar)

    @property
    def selectedNode(self):
        return self.tv.tree.selection()[0]

    @property
    def selectedNodes(self):
        return self.tv.tree.selection()

    def lock(self):
        self.restore_status()
        self.pathBar.set_locked()
        self.fileMenu.entryconfig(_('Unlock'), state='normal')
        self.fileMenu.entryconfig(_('Lock'), state='disabled')

    def on_change_selection(self, nodeId):
        self.propertiesView.show_properties(nodeId)
        self.contentsView.see(nodeId)
        self.root.event_generate('<<selection_changed>>', when='tail')

    def on_close(self):
        self.root.title(self.title)
        self.show_path('')
        self.pathBar.set_normal()

    def on_quit(self):

        prefs['show_markup'] = self.contentsView.showMarkup.get()

        if self._propWinDetached:
            prefs['prop_win_geometry'
                  ] = self._propertiesWindow.winfo_geometry()
        prefs['root_geometry'] = self.root.winfo_geometry()
        self.root.quit()

    def refresh(self):
        self.set_title()

    def restore_status(self, event=None):
        self.statusBar.restore_status()

    def set_status(self, message, colors=None):
        if message is not None:
            self.infoHowText = self.statusBar.show_message(message, colors)

    def set_title(self):
        if self._mdl.novel is None:
            return

        if self._mdl.novel.title:
            titleView = self._mdl.novel.title
        else:
            titleView = _('Untitled project')
        if self._mdl.novel.authorName:
            authorView = self._mdl.novel.authorName
        else:
            authorView = _('Unknown author')
        self.root.title(f'{titleView} {_("by")} {authorView} - {self.title}')

    def show_path(self, message):
        self.pathBar.config(text=message)

    def start(self):
        self.root.mainloop()

    def toggle_contents_view(self, event=None):
        if self.middleFrame.winfo_manager():
            self.middleFrame.pack_forget()
            prefs['show_contents'] = False
        else:
            self.middleFrame.pack(
                after=self.leftFrame,
                side='left',
                expand=False,
                fill='both',
            )
            prefs['show_contents'] = True
        return 'break'

    def toggle_properties_view(self, event=None):
        if self.rightFrame.winfo_manager():
            self.propertiesView.apply_changes()
            self.rightFrame.pack_forget()
            prefs['show_properties'] = False
        elif not self._propWinDetached:
            self.rightFrame.pack(side='left', expand=False, fill='both')
            prefs['show_properties'] = True
        return 'break'

    def toggle_properties_window(self, event=None):
        if self._propWinDetached:
            self._dock_properties_frame()
        else:
            self._detach_properties_frame()
        self.root.event_generate('<<RebuildPropertiesView>>')
        return 'break'

    def unlock(self):
        self.restore_status()
        self.pathBar.set_normal()
        self.fileMenu.entryconfig(_('Unlock'), state='disabled')
        self.fileMenu.entryconfig(_('Lock'), state='normal')

    def update_status(self, statusText=''):
        self.statusBar.update_status(statusText)

    def _about(self):
        self.show_info(
            message=f'novelibre {self._ctrl.plugins.majorVersion}',
            detail=__doc__,
            title=_('About novelibre'),
        )

    def choose_color(self, title='', initialcolor=None):
        color = colorchooser.askcolor(
            title=title,
            color=initialcolor,
        )
        if color is None:
            return None

        return color[1]

    def _create_path_bar(self):
        self.pathBar = PathBar(
            self.root,
            self._mdl,
            text='',
            anchor='w',
            padx=5,
            pady=3,
        )
        self.pathBar.pack(expand=False, fill='both')
        self._mdl.add_observer(self.pathBar)

        self.pathBar.COLOR_NORMAL_BG = self.colorBg
        self.pathBar.COLOR_NORMAL_FG = self.colorFg
        self.pathBar.COLOR_MODIFIED_BG = prefs['color_modified_bg']
        self.pathBar.COLOR_MODIFIED_FG = prefs['color_modified_fg']
        self.pathBar.COLOR_LOCKED_BG = prefs['color_locked_bg']
        self.pathBar.COLOR_LOCKED_FG = prefs['color_locked_fg']

    def _create_status_bar(self):
        self.statusBar = StatusBar(
            self.root,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self.statusBar.pack(expand=False, fill='both')
        self.statusBar.bind(MOUSE.LEFT_CLICK, self.statusBar.restore_status)

        self.statusBar.COLOR_NORMAL_BG = self.colorBg
        self.statusBar.COLOR_NORMAL_FG = self.colorFg
        self.statusBar.COLOR_SUCCESS_BG = prefs['color_status_success_bg']
        self.statusBar.COLOR_SUCCESS_FG = prefs['color_status_success_fg']
        self.statusBar.COLOR_ERROR_BG = prefs['color_status_error_bg']
        self.statusBar.COLOR_ERROR_FG = prefs['color_status_error_fg']
        self.statusBar.COLOR_NOTIFICATION_BG = (
            prefs['color_status_notification_bg']
        )
        self.statusBar.COLOR_NOTIFICATION_FG = (
            prefs['color_status_notification_fg']
        )

    def _detach_properties_frame(self, event=None):
        self.propertiesView.apply_changes()
        if self._propWinDetached:
            return

        if self.rightFrame.winfo_manager():
            self.rightFrame.pack_forget()
        self._propertiesWindow = tk.Toplevel()
        self._propertiesWindow.geometry(prefs['prop_win_geometry'])
        set_icon(self._propertiesWindow, icon='pLogo32', default=False)

        self.propertiesView.pack_forget()
        self._mdl.delete_observer(self.propertiesView)
        self._ctrl.unregister_client(self.propertiesView)
        self.propertiesView = PropertiesViewer(
            self._propertiesWindow, self._mdl, self, self._ctrl)
        self._mdl.add_observer(self.propertiesView)
        self._ctrl.register_client(self.propertiesView)
        self.propertiesView.pack(expand=True, fill='both')

        self._propertiesWindow.bind(
            KEYS.DETACH_PROPERTIES[0], self._dock_properties_frame)
        self._propertiesWindow.protocol(
            "WM_DELETE_WINDOW", self._dock_properties_frame)
        prefs['detach_prop_win'] = True
        self._propWinDetached = True
        try:
            self.propertiesView.show_properties(self.tv.tree.selection()[0])
        except IndexError:
            pass
        return 'break'

    def _dock_properties_frame(self, event=None):
        self.propertiesView.apply_changes()
        if not self._propWinDetached:
            return

        if not self.rightFrame.winfo_manager():
            self.rightFrame.pack(side='left', expand=False, fill='both')

        prefs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()

        self._propertiesWindow.destroy()
        self._mdl.delete_observer(self.propertiesView)
        self._ctrl.unregister_client(self.propertiesView)
        self.propertiesView = PropertiesViewer(
            self.rightFrame,
            self._mdl,
            self,
            self._ctrl,
        )
        self._mdl.add_observer(self.propertiesView)
        self._ctrl.register_client(self.propertiesView)
        self.propertiesView.pack(expand=True, fill='both')
        self.root.lift()

        prefs['show_properties'] = True
        prefs['detach_prop_win'] = False
        self._propWinDetached = False
        try:
            self.propertiesView.show_properties(self.tv.tree.selection()[0])
        except IndexError:
            pass
        return 'break'




class ZippedNovxOpener(NovxOpener):

    NOVX_EXTENSIONS = [
        '.novx',
    ]
    ZIP_EXTENSIONS = [
        '.zip',
    ]

    @classmethod
    def get_xml_root(cls, filePath, majorVersion, minorVersion):
        __, extension = os.path.splitext(filePath)
        try:
            if not extension in cls.ZIP_EXTENSIONS:
                raise RuntimeError('File type is not supported')

            with zipfile.ZipFile(filePath, 'r') as z:
                fileNames = z.namelist()
                xmlRoot = None
                for fileName in fileNames:
                    __, extension = os.path.splitext(fileName)
                    if extension in cls.NOVX_EXTENSIONS:
                        with z.open(fileName, 'r') as f:
                            xmlStr = f.read()
                        xmlRoot = ET.fromstring(xmlStr)
                        break

                if xmlRoot is None:
                    raise RuntimeError('File type is not supported')

        except Exception as ex:
            normPath = norm_path(filePath)
            raise RuntimeError(
                f'{_("Cannot process file")}: "{normPath}" - {str(ex)}'
            )

        if xmlRoot.tag != 'novx':
            msg = _("No valid xml root element found in file")
            raise RuntimeError(f'{msg}: "{norm_path(filePath)}".')

        fileMajorVersion, fileMinorVersion = cls._get_file_version(
            xmlRoot,
            filePath,
        )
        fileMajorVersion, fileMinorVersion = cls._upgrade_file_version(
            xmlRoot,
            fileMajorVersion,
            fileMinorVersion,
        )
        cls._check_version(
            fileMajorVersion,
            fileMinorVersion,
            filePath,
            majorVersion,
            minorVersion,
        )
        return xmlRoot



class ZippedNovxFile(NovxFile):

    DESCRIPTION = _('Zipped novelibre project')
    EXTENSION = '.zip'

    fileOpener = ZippedNovxOpener

    def write(self):
        raise NotImplementedError


class NovxService:

    def change_word_counter(self, wordCounter):
        Section.wordCounter = wordCounter

    def get_novx_dtd_version(self):
        return (
            NovxFile.MAJOR_VERSION,
            NovxFile.MINOR_VERSION
        )

    def get_novelibre_home_url(self):
        return HOME_URL

    def get_novx_file_extension(self):
        return NovxFile.EXTENSION

    def get_word_counter(self):
        return Section.wordCounter

    def get_zipped_novx_file_extension(self):
        return ZippedNovxFile.EXTENSION

    def new_basic_element(self, **kwargs):
        return BasicElement(**kwargs)

    def new_chapter(self, **kwargs):
        return Chapter(**kwargs)

    def new_character(self, **kwargs):
        return Character(**kwargs)

    def new_novel(self, **kwargs):
        kwargs['tree'] = kwargs.get('tree', NvTree())
        return Novel(**kwargs)

    def new_novx_file(self, filePath, **kwargs):
        return NovxFile(filePath, **kwargs)

    def new_nv_tree(self, **kwargs):
        return NvTree(**kwargs)

    def new_plot_line(self, **kwargs):
        return PlotLine(**kwargs)

    def new_plot_point(self, **kwargs):
        return PlotPoint(**kwargs)

    def new_section(self, **kwargs):
        return Section(**kwargs)

    def new_world_element(self, **kwargs):
        return WorldElement(**kwargs)

    def new_zipped_novx_file(self, filePath, **kwargs):
        return ZippedNovxFile(filePath, **kwargs)

import math


class Moon:

    @classmethod
    def get_phase_day(cls, isoDate):
        try:
            y, m, d = isoDate.split('-')
            year = int(y)
            month = int(m)
            day = int(d)
            r = year % 100
            r %= 19
            if r > 9:
                r -= 19
            r = ((r * 11) % 30) + month + day
            if month < 3:
                r += 2
            if year < 2000:
                r -= 4
            else:
                r -= 8.3
            r = math.floor(r + 0.5) % 30
            if r < 0:
                r += 30
        except:
            r = None
        return r

    @classmethod
    def get_phase_string(cls, isoDate):
        moonViews = (
            '🌑🌑🌒🌒🌒🌒🌓🌓🌓🌓🌔🌔🌔🌔🌕'
            '🌕🌕🌖🌖🌖🌖🌗🌗🌗🌗🌘🌘🌘🌘🌑'
        )
        moonFractions = '00¼¼¼¼½½½½¾¾¾¾111¾¾¾¾½½½½¼¼¼¼0'
        moonPhaseDay = cls.get_phase_day(isoDate)
        if moonPhaseDay is not None:
            display = (
                f'{moonPhaseDay} '
                f'{moonViews[moonPhaseDay]} '
                f'{moonFractions[moonPhaseDay]}'
            )
        else:
            display = ''
        return display



class NvService(NovxService):

    def final_document_class(self):
        return OdtWExport

    def get_moon_phase_str(self, isoDate):
        return Moon.get_phase_string(isoDate)

    def new_configuration(self, **kwargs):
        return Configuration(**kwargs)

    def new_hovertip(self, anchor_widget, text):
        return Hovertip(anchor_widget, text)


class NvModel:

    def __init__(self):
        self._observers = []
        self._isModified = False

        self.tree = None
        self.prjFile = None
        self.novel = None

        self.trashBin = None
        self.wordCount = 0

        self.nvService = NvService()

    @property
    def isModified(self):
        return self._isModified

    @isModified.setter
    def isModified(self, setFlag):
        self._isModified = setFlag
        self.notify_observers()

    def add_new_chapter(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(SECTION_PREFIX):
            targetNode = self.tree.parent(targetNode)
        if targetNode.startswith(CHAPTER_PREFIX):
            index = self.tree.index(targetNode) + 1
            targetNode = self.tree.parent(targetNode)
        chId = new_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[chId] = self.nvService.new_chapter(
            title=kwargs.get('title', f'{_("New Chapter")} ({chId})'),
            desc='',
            chLevel=2,
            chType=kwargs.get('chType', 0),
            noNumber=kwargs.get('NoNumber', False),
            hasEpigraph=kwargs.get('hasEpigraph', False),
            isTrash=False,
            on_element_change=self.on_element_change,
        )
        self.tree.insert(CH_ROOT, index, chId)
        return chId

    def add_new_character(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(CHARACTER_PREFIX):
            index = self.tree.index(targetNode) + 1
        crId = new_id(self.novel.characters, prefix=CHARACTER_PREFIX)
        self.novel.characters[crId] = self.nvService.new_character(
            title=kwargs.get('title', f'{_("New Character")} ({crId})'),
            desc='',
            aka='',
            notes='',
            bio='',
            goals='',
            fullName='',
            isMajor=kwargs.get('isMajor', False),
            on_element_change=self.on_element_change,
        )
        self.tree.insert(CR_ROOT, index, crId)
        return crId

    def add_new_item(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(ITEM_PREFIX):
            index = self.tree.index(targetNode) + 1
        itId = new_id(self.novel.items, prefix=ITEM_PREFIX)
        self.novel.items[itId] = self.nvService.new_world_element(
            title=kwargs.get('title', f'{_("New Item")} ({itId})'),
            desc='',
            aka='',
            on_element_change=self.on_element_change,
        )
        self.tree.insert(IT_ROOT, index, itId)
        return itId

    def add_new_location(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(LOCATION_PREFIX):
            index = self.tree.index(targetNode) + 1
        lcId = new_id(self.novel.locations, prefix=LOCATION_PREFIX)
        self.novel.locations[lcId] = self.nvService.new_world_element(
            title=kwargs.get('title', f'{_("New Location")} ({lcId})'),
            desc='',
            aka='',
            on_element_change=self.on_element_change,
        )
        self.tree.insert(LC_ROOT, index, lcId)
        return lcId

    def add_new_part(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(SECTION_PREFIX):
            targetNode = self.tree.parent(targetNode)
        if targetNode.startswith(CHAPTER_PREFIX):
            index = self.tree.index(targetNode) + 1
            targetNode = self.tree.parent(targetNode)
        chId = new_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[chId] = self.nvService.new_chapter(
            title=kwargs.get('title', f'{_("New Part")} ({chId})'),
            desc='',
            chLevel=1,
            chType=kwargs.get('chType', 0),
            noNumber=kwargs.get('NoNumber', False),
            hasEpigraph=kwargs.get('hasEpigraph', False),
            isTrash=False,
            on_element_change=self.on_element_change,
        )
        self.tree.insert(CH_ROOT, index, chId)
        return chId

    def add_new_plot_line(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(PLOT_LINE_PREFIX):
            index = self.tree.index(targetNode) + 1
        plId = new_id(self.novel.plotLines, prefix=PLOT_LINE_PREFIX)
        self.novel.plotLines[plId] = self.nvService.new_plot_line(
            title=kwargs.get('title', f'{_("New Plot line")} ({plId})'),
            desc='',
            shortName=plId,
            on_element_change=self.on_element_change,
        )
        self.tree.insert(PL_ROOT, index, plId)
        return plId

    def add_new_plot_point(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        index = 'end'
        if targetNode.startswith(PLOT_POINT_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(PLOT_LINE_PREFIX):
            parent = targetNode
        else:
            return

        ppId = new_id(self.novel.plotPoints, prefix=PLOT_POINT_PREFIX)
        self.novel.plotPoints[ppId] = self.nvService.new_plot_point(
            title=kwargs.get('title', f'{_("New Plot point")} ({ppId})'),
            desc='',
            on_element_change=self.on_element_change,
        )
        self.tree.insert(parent, index, ppId)
        return ppId

    def add_new_project_note(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(PRJ_NOTE_PREFIX):
            index = self.tree.index(targetNode) + 1
        pnId = new_id(self.novel.projectNotes, prefix=PRJ_NOTE_PREFIX)
        self.novel.projectNotes[pnId] = self.nvService.new_basic_element(
            title=kwargs.get('title', f'{_("New Note")} ({pnId})'),
            desc='',
            on_element_change=self.on_element_change,
        )
        self.tree.insert(PN_ROOT, index, pnId)
        return pnId

    def add_new_section(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        if targetNode.startswith(SECTION_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(CHAPTER_PREFIX):
            parent = targetNode
            index = 'end'
        else:
            return

        parentType = self.novel.chapters[parent].chType
        if parentType != 0:
            newType = parentType
        else:
            newType = kwargs.get('scType', 0)
        scId = new_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[scId] = self.nvService.new_section(
            title=kwargs.get('title', f'{_("New Section")} ({scId})'),
            desc=kwargs.get('desc', ''),
            scType=newType,
            scene=kwargs.get('scene', 0),
            status=kwargs.get('status', 1),
            appendToPrev=kwargs.get('appendToPrev', False),
            on_element_change=self.on_element_change,
        )
        self.novel.sections[scId].sectionContent = '<p></p>'
        self.tree.insert(parent, index, scId)
        return scId

    def add_new_stage(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        if targetNode.startswith(SECTION_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(CHAPTER_PREFIX):
            parent = targetNode
            index = 0
        else:
            return

        scId = new_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[scId] = self.nvService.new_section(
            title=kwargs.get('title', f'{_("Stage")}'),
            desc=kwargs.get('desc', ''),
            scType=kwargs.get('scType', 3),
            status=0,
            scene=0,
            on_element_change=self.on_element_change,
        )
        self.tree.insert(parent, index, scId)
        return scId

    def add_observer(self, client):
        if not client in self._observers:
            self._observers.append(client)

    def clone_section(self, scId):

        if not scId.startswith(SECTION_PREFIX):
            return

        original = self.novel.sections[scId]
        clone = self.nvService.new_section(
            on_element_change=self.on_element_change,
            title=f"{_('Clone of')} {original.title}",
            desc=original.desc,
            links=original.links.copy(),
            fields=original.fields.copy(),
            notes=original.notes,
            tags=original.tags[:],
            scType=1,
            scene=original.scene,
            status=original.status,
            appendToPrev=original.appendToPrev,
            viewpoint=original.viewpoint,
            goal=original.goal,
            conflict=original.conflict,
            outcome=original.outcome,
            plotlineNotes=original.plotlineNotes.copy(),
            scDate=original.date,
            scTime=original.time,
            day=original.day,
            lastsMinutes=original.lastsMinutes,
            lastsHours=original.lastsHours,
            lastsDays=original.lastsDays,
            characters=original.characters[:],
            locations=original.locations[:],
            items=original.items[:],
        )
        clone.sectionContent = original.sectionContent
        clone.scPlotLines = original.scPlotLines[:]
        parent = self.tree.parent(scId)
        index = self.tree.index(scId) + 1
        cloneId = new_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[cloneId] = clone
        self.tree.insert(parent, index, cloneId)
        for plId in clone.scPlotLines:
            sections = self.novel.plotLines[plId].sections
            sections.append(cloneId)
            self.novel.plotLines[plId].sections = sections
        return cloneId

    def close_project(self):
        self._isModified = False
        self.tree.on_element_change = self.tree.do_nothing
        self.novel = None
        self.prjFile = None

    def create_project(self, tree):
        self.novel = self.nvService.new_novel(
            title='',
            desc='',
            authorName='',
            wordTarget=0,
            wordCountStart=0,
            languageCode='',
            countryCode='',
            renumberChapters=False,
            renumberParts=False,
            renumberWithinParts=False,
            romanChapterNumbers=False,
            romanPartNumbers=False,
            saveWordCount=True,
            workPhase=None,
            chapterHeadingPrefix=f"{_('Chapter')} ",
            chapterHeadingSuffix='',
            partHeadingPrefix=f"{_('Part')} ",
            partHeadingSuffix='',
            noSceneField1=NO_SCENE_FIELD_1_DEFAULT,
            noSceneField2=NO_SCENE_FIELD_2_DEFAULT,
            noSceneField3=NO_SCENE_FIELD_3_DEFAULT,
            otherSceneField1=OTHER_SCENE_FIELD_1_DEFAULT,
            otherSceneField2=OTHER_SCENE_FIELD_2_DEFAULT,
            otherSceneField3=OTHER_SCENE_FIELD_3_DEFAULT,
            crField1=CR_FIELD_1_DEFAULT,
            crField2=CR_FIELD_2_DEFAULT,
            tree=tree,
            on_element_change=self.on_element_change,
        )
        self.novel.check_locale()
        self.prjFile = NvWorkFile('')
        self.prjFile.novel = self.novel
        self._initialize_tree(self.on_element_change)

    def delete_element(self, elemId, trash=True):

        def waste_sections(elemId):
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    arcReferences = self.novel.sections[elemId].scPlotLines
                    tpReferences = self.novel.sections[elemId].scPlotPoints
                    self.novel.sections[elemId].scPlotLines = []
                    self.novel.sections[elemId].scPlotPoints = {}
                    for plId in arcReferences:
                        sections = self.novel.plotLines[plId].sections
                        sections.remove(elemId)
                        self.novel.plotLines[plId].sections = sections
                    for ppId in tpReferences:
                        self.novel.plotPoints[ppId].sectionAssoc = None
                    if trash:
                        self.tree.move(elemId, self.trashBin, 0)
                        self.novel.sections[elemId].scType = 1
                    else:
                        del self.novel.sections[elemId]
                        self.tree.delete(elemId)
                else:
                    del self.novel.sections[elemId]
                    self.tree.delete(elemId)
            else:
                for childNode in self.tree.get_children(elemId):
                    waste_sections(childNode)
                del self.novel.chapters[elemId]

        if elemId == self.trashBin:
            for scId in self.tree.get_children(elemId):
                del self.novel.sections[scId]
            del self.novel.chapters[elemId]
            self.tree.delete(elemId)
            self.trashBin = None
        elif elemId.startswith(CHARACTER_PREFIX):
            del self.novel.characters[elemId]
            self.tree.delete(elemId)
            for scId in self.novel.sections:
                try:
                    scCharacters = self.novel.sections[scId].characters
                    scCharacters.remove(elemId)
                    self.novel.sections[scId].characters = scCharacters
                except:
                    pass
        elif elemId.startswith(LOCATION_PREFIX):
            del self.novel.locations[elemId]
            self.tree.delete(elemId)
            for scId in self.novel.sections:
                try:
                    scLocations = self.novel.sections[scId].locations
                    scLocations.remove(elemId)
                    self.novel.sections[scId].locations = scLocations
                except:
                    pass
        elif elemId.startswith(ITEM_PREFIX):
            del self.novel.items[elemId]
            self.tree.delete(elemId)
            for scId in self.novel.sections:
                try:
                    scItems = self.novel.sections[scId].items
                    scItems.remove(elemId)
                    self.novel.sections[scId].items = scItems
                except:
                    pass
        elif elemId.startswith(PLOT_LINE_PREFIX):
            if self.novel.plotLines[elemId].sections:
                for scId in self.novel.plotLines[elemId].sections:
                    self.novel.sections[scId].scPlotLines.remove(elemId)
                for ppId in self.tree.get_children(elemId):
                    scId = self.novel.plotPoints[ppId].sectionAssoc
                    if scId is not None:
                        del(self.novel.sections[scId].scPlotPoints[ppId])
                    del self.novel.plotPoints[ppId]
            del self.novel.plotLines[elemId]
            self.tree.delete(elemId)
        elif elemId.startswith(PLOT_POINT_PREFIX):
            scId = self.novel.plotPoints[elemId].sectionAssoc
            if scId is not None:
                del(self.novel.sections[scId].scPlotPoints[elemId])
            del self.novel.plotPoints[elemId]
            self.tree.delete(elemId)
        elif elemId.startswith(PRJ_NOTE_PREFIX):
            del self.novel.projectNotes[elemId]
            self.tree.delete(elemId)
        else:
            if trash and self.trashBin is None:
                self.trashBin = new_id(
                    self.novel.chapters,
                    prefix=CHAPTER_PREFIX,
                )
                self.novel.chapters[self.trashBin] = (
                    self.nvService.new_chapter(
                        title=_('Trash'),
                        desc='',
                        chLevel=2,
                        chType=1,
                        noNumber=True,
                        hasEpigraph=False,
                        isTrash=True,
                        on_element_change=self.on_element_change,
                    )
                )
                self.tree.append(CH_ROOT, self.trashBin)
            if elemId.startswith(SECTION_PREFIX):
                if self.tree.parent(elemId) == self.trashBin:
                    del self.novel.sections[elemId]
                    self.tree.delete(elemId)
                else:
                    waste_sections(elemId)
            else:
                waste_sections(elemId)
                self.tree.delete(elemId)
            if trash:
                self.set_type(1, [self.trashBin])

    def delete_observer(self, client):
        if client in self._observers:
            self._observers.remove(client)

    def get_color(self, elemId):
        prefix = elemId[:2]
        try:
            return self.novel.elementsByPrefix[prefix][elemId].color

        except KeyError:
            return None

    def get_counts(self):
        partCount = 0
        chapterCount = 0
        sectionCount = 0
        wordCount = 0
        for chId in self.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chType == 0:
                for scId in self.tree.get_children(chId):
                    if self.novel.sections[scId].scType == 0:
                        sectionCount += 1
                        wordCount += self.novel.sections[scId].wordCount
                if self.novel.chapters[chId].chLevel == 1:
                    partCount += 1
                else:
                    chapterCount += 1
        self.wordCount = wordCount
        return wordCount, sectionCount, chapterCount, partCount

    def get_status_counts(self):
        counts = [None, 0, 0, 0, 0, 0]
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                if self.novel.sections[scId].status is not None:
                    counts[self.novel.sections[scId].status
                           ] += self.novel.sections[scId].wordCount
        return counts

    def join_sections(self, scId0, scId1):

        def join_str(text0, text1, newline='\n'):
            if text0 is None:
                text0 = ''
            if text1 is None:
                text1 = ''
            if text0 or text1:
                text0 = f'{text0}{newline}{text1}'.strip()
            return text0

        def join_lst(list0, list1):
            if list1:
                for elemId in list1:
                    if not list0:
                        list0 = []
                    if not elemId in list0:
                        list0.append(elemId)

        if not scId1.startswith(SECTION_PREFIX):
            return

        if (
            self.novel.sections[scId1].scType
            != self.novel.sections[scId0].scType
        ):
            raise RuntimeError(_('The sections are not of the same type'))

        if self.novel.sections[scId1].characters:
            if self.novel.sections[scId1].characters:
                if self.novel.sections[scId0].characters:
                    if (
                        self.novel.sections[scId1].viewpoint
                        != self.novel.sections[scId0].viewpoint
                    ):
                        raise RuntimeError(
                            _('The sections have different viewpoints')
                        )

                else:
                    self.novel.sections[scId0].characters.append(
                        self.novel.sections[scId1].viewpoint
                    )

        joinedTitles = (
            f'{self.novel.sections[scId0].title}'
            f' & {self.novel.sections[scId1].title}'
        )
        self.novel.sections[scId0].title = joinedTitles

        content0 = self.novel.sections[scId0].sectionContent
        content1 = self.novel.sections[scId1].sectionContent
        self.novel.sections[scId0].sectionContent = join_str(
            content0, content1, newline='')

        self.novel.sections[scId0].desc = join_str(
            self.novel.sections[scId0].desc,
            self.novel.sections[scId1].desc
        )
        self.novel.sections[scId0].goal = join_str(
            self.novel.sections[scId0].goal,
            self.novel.sections[scId1].goal
        )
        self.novel.sections[scId0].conflict = join_str(
            self.novel.sections[scId0].conflict,
            self.novel.sections[scId1].conflict
        )
        self.novel.sections[scId0].outcome = join_str(
            self.novel.sections[scId0].outcome,
            self.novel.sections[scId1].outcome
        )
        self.novel.sections[scId0].notes = join_str(
            self.novel.sections[scId0].notes,
            self.novel.sections[scId1].notes
        )

        join_lst(
            self.novel.sections[scId0].characters,
            self.novel.sections[scId1].characters
        )
        join_lst(
            self.novel.sections[scId0].locations,
            self.novel.sections[scId1].locations
        )
        join_lst(
            self.novel.sections[scId0].items,
            self.novel.sections[scId1].items
        )
        join_lst(
            self.novel.sections[scId0].tags,
            self.novel.sections[scId1].tags
        )

        for scPlotLine in self.novel.sections[scId1].scPlotLines:
            self.novel.plotLines[scPlotLine].sections.remove(scId1)
            if not scId0 in self.novel.plotLines[scPlotLine].sections:
                self.novel.plotLines[scPlotLine].sections.append(scId0)
            if not scPlotLine in self.novel.sections[scId0].scPlotLines:
                self.novel.sections[scId0].scPlotLines.append(scPlotLine)

        for ppId in self.novel.sections[scId1].scPlotPoints:
            self.novel.plotPoints[ppId].sectionAssoc = scId0
            self.novel.sections[scId0].scPlotPoints[ppId] = (
                self.novel.sections[scId1].scPlotPoints[ppId]
            )

        try:
            lastsMin1 = int(self.novel.sections[scId1].lastsMinutes)
        except:
            lastsMin1 = 0
        try:
            lastsMin0 = int(self.novel.sections[scId0].lastsMinutes)
        except:
            lastsMin0 = 0
        hoursLeft, lastsMin0 = divmod((lastsMin0 + lastsMin1), 60)
        self.novel.sections[scId0].lastsMinutes = str(lastsMin0)
        try:
            lastsHours1 = int(self.novel.sections[scId1].lastsHours)
        except:
            lastsHours1 = 0
        try:
            lastsHours0 = int(self.novel.sections[scId0].lastsHours)
        except:
            lastsHours0 = 0
        daysLeft, lastsHours0 = divmod(
            (lastsHours0 + lastsHours1 + hoursLeft), 24
        )
        self.novel.sections[scId0].lastsHours = str(lastsHours0)
        try:
            lastsDays1 = int(self.novel.sections[scId1].lastsDays)
        except:
            lastsDays1 = 0
        try:
            LastsDays0 = int(self.novel.sections[scId0].lastsDays)
        except:
            LastsDays0 = 0
        LastsDays0 = LastsDays0 + lastsDays1 + daysLeft
        self.novel.sections[scId0].lastsDays = str(LastsDays0)
        del(self.novel.sections[scId1])
        self.tree.delete(scId1)

    def move_node(self, node, targetNode):
        if node == self.trashBin:
            return

        if (
            node.startswith(PLOT_POINT_PREFIX)
            and self.tree.parent(targetNode) != self.tree.parent(node)
        ):
            return

        if node[:2] == targetNode[:2]:
            self.tree.move(
                node,
                self.tree.parent(targetNode),
                self.tree.index(targetNode),
            )
            return

        if (
            node.startswith(SECTION_PREFIX)
            and targetNode.startswith(CHAPTER_PREFIX)
        ):
            if not self.tree.get_children(targetNode):
                self.tree.move(node, targetNode, 0)
            elif self.tree.prev(targetNode):
                self.tree.move(node, self.tree.prev(targetNode), 'end')

    def notify_observers(self):
        for client in self._observers:
            client.refresh()

    def on_element_change(self):
        self.isModified = True

    def open_project(self, filePath):
        self.novel = self.nvService.new_novel(
            tree=self.tree,
            noSceneField1=NO_SCENE_FIELD_1_DEFAULT,
            noSceneField2=NO_SCENE_FIELD_2_DEFAULT,
            noSceneField3=NO_SCENE_FIELD_3_DEFAULT,
            otherSceneField1=OTHER_SCENE_FIELD_1_DEFAULT,
            otherSceneField2=OTHER_SCENE_FIELD_2_DEFAULT,
            otherSceneField3=OTHER_SCENE_FIELD_3_DEFAULT,
            crField1=CR_FIELD_1_DEFAULT,
            crField2=CR_FIELD_2_DEFAULT,
        )
        self.prjFile = NvWorkFile(filePath)
        self.prjFile.novel = self.novel
        self.prjFile.read()
        if self.prjFile.wcLogUpdate and self.novel.saveWordCount:
            self.isModified = True
        else:
            self.isModified = False
        self._initialize_tree(self.on_element_change)

    def renumber_chapters(self):
        ROMAN = [
            (1000, 'M'),
            (900, 'CM'),
            (500, 'D'),
            (400, 'CD'),
            (100, 'C'),
            (90, 'XC'),
            (50, 'L'),
            (40, 'XL'),
            (10, 'X'),
            (9, 'IX'),
            (5, 'V'),
            (4, 'IV'),
            (1, 'I'),
        ]

        def number_to_roman(n):
            result = []
            for (arabic, roman) in ROMAN:
                (factor, n) = divmod(n, arabic)
                result.append(roman * factor)
                if n == 0:
                    break

            return "".join(result)

        chapterCount = 0
        partCount = 0
        for chId in self.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].noNumber:
                continue

            if self.novel.chapters[chId].chType != 0:
                continue

            if self.novel.chapters[chId].chLevel == 2:
                if not self.novel.renumberChapters:
                    continue

            else:
                if self.novel.renumberWithinParts:
                    chapterCount = 0
                if not self.novel.renumberParts:
                    continue

            headingPrefix = ''
            headingSuffix = ''
            if self.novel.chapters[chId].chLevel == 2:
                chapterCount += 1
                if self.novel.romanChapterNumbers:
                    number = number_to_roman(chapterCount)
                else:
                    number = str(chapterCount)
                if self.novel.chapterHeadingPrefix is not None:
                    headingPrefix = self.novel.chapterHeadingPrefix
                if self.novel.chapterHeadingSuffix is not None:
                    headingSuffix = self.novel.chapterHeadingSuffix
            else:
                partCount += 1
                if self.novel.romanPartNumbers:
                    number = number_to_roman(partCount)
                else:
                    number = str(partCount)
                if self.novel.partHeadingPrefix is not None:
                    headingPrefix = self.novel.partHeadingPrefix
                if self.novel.partHeadingSuffix is not None:
                    headingSuffix = self.novel.partHeadingSuffix
            self.novel.chapters[chId].title = (
                f'{headingPrefix}{number}'
                f'{headingSuffix}'
            )

    def reset_tree(self):
        self.tree.reset()
        self.trashBin = None

    def save_project(self, filePath=None):
        if filePath is not None:
            self.prjFile.filePath = filePath
        self.prjFile.write()
        self.isModified = False

    def set_color(self, color, elemIds):
        for elemId in elemIds:
            prefix = elemId[:2]
            try:
                self.novel.elementsByPrefix[prefix][elemId].color = color
            except KeyError:
                pass

    def set_level(self, newLevel, elemIds):
        for elemId in elemIds:
            if elemId.startswith(CHAPTER_PREFIX):
                self.novel.chapters[elemId].chLevel = newLevel
            elif elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType > 1:
                    self.novel.sections[elemId].scType = newLevel + 1

    def set_character_status(self, isMajor, elemIds):
        for crId in elemIds:
            if crId.startswith(CHARACTER_PREFIX):
                self.novel.characters[crId].isMajor = isMajor
            elif crId == CR_ROOT:
                self.set_character_status(
                    isMajor,
                    self.tree.get_children(crId)
                )

    def set_completion_status(self, newStatus, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    self.novel.sections[elemId].status = newStatus
            elif (
                elemId.startswith(CHAPTER_PREFIX)
                or elemId.startswith(CH_ROOT)
            ):
                self.set_completion_status(
                    newStatus,
                    self.tree.get_children(elemId)
                )

    def set_type(self, newType, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    parentType = (
                        self.novel.chapters[self.tree.parent(elemId)].chType
                    )
                    if parentType > 0:
                        newType = parentType
                    self.novel.sections[elemId].scType = newType
            elif elemId.startswith(CHAPTER_PREFIX):
                chapter = self.novel.chapters[elemId]
                if chapter.isTrash:
                    newType = 1
                chapter.chType = newType
                if newType > 0:
                    self.set_type(newType, self.tree.get_children(elemId))

    def set_viewpoint(self, crId, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    self.novel.sections[elemId].viewpoint = crId
            elif (
                elemId.startswith(CHAPTER_PREFIX)
                or elemId.startswith(CH_ROOT)
            ):
                self.set_viewpoint(
                    crId,
                    self.tree.get_children(elemId)
                )

    def _initialize_tree(self, on_element_change):

        def initialize_branch(node):
            for elemId in self.tree.get_children(node):
                prefix = elemId[:2]
                try:
                    self.novel.elementsByPrefix[prefix][
                        elemId
                    ].on_element_change = on_element_change
                except KeyError:
                    initialize_branch(elemId)
                if elemId.startswith(CHAPTER_PREFIX):
                    if self.novel.chapters[elemId].isTrash:
                        self.trashBin = elemId
                    initialize_branch(elemId)
                elif elemId.startswith(PLOT_LINE_PREFIX):
                    initialize_branch(elemId)

        self.trashBin = None
        initialize_branch('')
        self.novel.on_element_change = on_element_change
        self.tree.on_element_change = on_element_change


PLUGIN_PATH = f'{sys.path[0]}/plugin'


class MainController(SubController, Commands):

    def __init__(self, title, tempDir):
        super().__init__()
        self._internalLockFlag = False
        self._clients = []
        self.tempDir = tempDir

        self._mdl = NvModel()
        self._mdl.add_observer(self)

        self._ui = MainView(self._mdl, self, title)
        self.register_client(self._ui)

        self._mdl.tree = self._ui.tv.tree


        self.dataImporter = DataImporter(self._mdl, self._ui, self)
        self.docImporter = DocImporter(self._mdl, self._ui, self)
        self.fileSplitter = FileSplitter(self._mdl, self._ui, self)
        self.fileManager = FileManager(self._mdl, self._ui, self)
        self.elementManager = ElementManager(self._mdl, self._ui, self)
        self.linkProcessor = LinkProcessor(self._mdl, self._ui, self)
        self.clipboardManager = ClipboardManager(self._mdl, self._ui, self)

        self.plugins = PluginCollection(self._mdl, self._ui, self)

        self.plugins.load_plugins(PLUGIN_PATH)
        self.register_client(self.plugins)

        self._bind_events()

        self.disable_menu()
        self._ui.tv.reset_view()

    @property
    def isLocked(self):
        return self._internalLockFlag

    def check_lock(self):
        if self.isLocked:
            if self._ui.ask_yes_no(
                message=_('Unlock?'),
                detail=f"{_('The project is locked')}."
            ):
                self.unlock()
                return False
            else:
                return True
        else:
            return False

    def disable_menu(self):
        for client in self._clients:
            client.disable_menu()

    def enable_menu(self):
        for client in self._clients:
            client.enable_menu()

    def get_launchers(self):
        return launchers

    def get_preferences(self):
        return prefs

    def get_view(self):
        return self._ui

    def lock(self, event=None):
        if self._mdl.isModified and not self._internalLockFlag:
            if self._ui.ask_yes_no(
                message=_('Save and lock?'),
                detail=f"{_('There are unsaved changes')}."
            ):
                self.save_project()
            else:
                return False

        if self._mdl.prjFile.filePath is None:
            return False

        self._internalLockFlag = True
        for client in self._clients:
            client.lock()
        self._mdl.prjFile.lock()
        return True

    def on_close(self, doNotSave=False):
        self.update_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.prjFile:
            pidfile = f'{self._mdl.prjFile.filePath}.pid'
        else:
            pidfile = ''
        if self._mdl.isModified and not doNotSave:
            doSave = self._ui.ask_yes_no_cancel(_('Save changes?'))
            if doSave is None:
                return None

            elif doSave:
                if not self.fileManager.save_project():
                    self._ui.show_error(
                        message=_('Cannot save the project')
                    )
                    return False

        for client in self._clients:
            client.on_close()

        self._mdl.close_project()

        self.unlock()

        self.update_status('')
        self.disable_menu()

        try:
            os.remove(pidfile)
        except FileNotFoundError:
            pass
        return True

    def on_open(self):
        for client in self._clients:
            client.on_open()

    def on_quit(self, event=None):
        try:
            if self._mdl.prjFile is not None:
                if not self.on_close():
                    return 'break'

            for client in self._clients:
                client.on_quit()
        except Exception as ex:
            self._ui.show_error(
                message=_('Unhandled exception on exit'),
                detail=str(ex)
            )
            self._ui.root.quit()
        return 'break'

    def register_client(self, client):
        if not client in self._clients:
            self._clients.append(client)

    def refresh(self):
        self.update_status()

    def unlock(self, event=None):
        self._internalLockFlag = False
        for client in self._clients:
            client.unlock()
        if self._mdl.prjFile is not None:
            self._mdl.prjFile.unlock()
            if self._mdl.prjFile.has_changed_on_disk():
                if self._ui.ask_yes_no(
                    message=_('File has changed on disk. Reload?')
                ):
                    self.open_project(filePath=self._mdl.prjFile.filePath)
        return 'break'

    def unregister_client(self, client):
        if client in self._clients:
            self._clients.remove(client)

    def update_status(self, statusText=None):
        if self._mdl.novel is not None and not statusText:
            (
                wordCount,
                sectionCount,
                chapterCount,
                partCount
            ) = self._mdl.get_counts()
            line = _('{0} parts, {1} chapters, {2} sections, {3} words')
            statusText = line.format(
                partCount,
                chapterCount,
                sectionCount,
                wordCount
            )
            self.wordCount = wordCount
        self._ui.update_status(statusText)

    def _bind_events(self):

        event_callbacks = {
            KEYS.ADD_CHILD[0]: self.add_new_child,
            KEYS.ADD_ELEMENT[0]: self.add_new_element,
            KEYS.ADD_PARENT[0]: self.add_new_parent,
            KEYS.CHAPTER_LEVEL[0]: self._ui.tv.show_chapter_level,
            KEYS.DETACH_PROPERTIES[0]: self._ui.toggle_properties_window,
            KEYS.FOLDER[0]: self.open_project_folder,
            KEYS.LOCK_PROJECT[0]: self.lock,
            KEYS.OPEN_HELP[0]: self.open_help,
            KEYS.OPEN_PROJECT[0]: self.open_project,
            KEYS.REFRESH_TREE[0]: self.refresh_tree,
            KEYS.RELOAD_PROJECT[0]: self.reload_project,
            KEYS.RESTORE_BACKUP[0]: self.restore_backup,
            KEYS.RESTORE_STATUS[0]: self._ui.restore_status,
            KEYS.SAVE_AS[0]: self.save_as,
            KEYS.SAVE_PROJECT[0]: self.save_project,
            KEYS.TOGGLE_PROPERTIES[0]: self._ui.toggle_properties_view,
            KEYS.TOGGLE_VIEWER[0]: self._ui.toggle_contents_view,
            KEYS.UNLOCK_PROJECT[0]: self.unlock,
        }
        if PLATFORM == 'win':
            event_callbacks.update({
                MOUSE.BACK_CLICK: self._ui.tv.go_back,
                MOUSE.FORWARD_CLICK: self._ui.tv.go_forward,
            })
        else:
            event_callbacks.update({
                KEYS.QUIT_PROGRAM[0]: self.on_quit,
            })
        for sequence, callback in event_callbacks.items():
            self._ui.root.bind(sequence, callback)

        event_callbacks = {
            '<<TreeviewClose>>': self._ui.tv._on_close_branch,
            '<<TreeviewOpen>>': self._ui.tv._on_open_branch,
            '<<TreeviewSelect>>': self._ui.tv._on_select_node,
            KEYS.BACK[0]: self._ui.tv.go_back,
            KEYS.COPY[0]: self.copy_element,
            KEYS.CUT[0]: self.cut_element,
            KEYS.DELETE[0]: self.delete_elements,
            KEYS.FORWARD[0]: self._ui.tv.go_forward,
            KEYS.NEXT[0]: self._ui.tv.load_next,
            KEYS.PASTE[0]: self.paste_element,
            KEYS.PREVIOUS[0]: self._ui.tv.load_prev,
            MOUSE.MOVE_NODE: self.move_node,
            MOUSE.RIGHT_CLICK: self._ui.contextMenu.open,
        }
        for sequence, callback in event_callbacks.items():
            self._ui.tv.tree.bind(sequence, callback)

DEFAULT_COLORS = dict(
    color_1st_edit='DarkGoldenrod4',
    color_2nd_edit='DarkGoldenrod3',
    color_before_schedule='lime green',
    color_behind_schedule='magenta',
    color_chapter='green',
    color_comment_tag='lemon chiffon',
    color_done='DarkGoldenrod2',
    color_draft='black',
    color_highlight='lavender',
    color_inactive_bg='light gray',
    color_locked_bg='dim gray',
    color_locked_fg='light gray',
    color_modified_bg='goldenrod1',
    color_modified_fg='maroon',
    color_notes_bg='lemon chiffon',
    color_notes_fg='black',
    color_note_tag='bisque',
    color_on_schedule='black',
    color_outline='dark orchid',
    color_separator='light gray',
    color_stage='red',
    color_status_error_bg='red',
    color_status_error_fg='white',
    color_status_notification_bg='yellow',
    color_status_notification_fg='black',
    color_status_success_bg='green',
    color_status_success_fg='white',
    color_text_bg='white',
    color_text_fg='black',
    color_unused='gray',
    color_xml_tag='cornflower blue',
)

SETTINGS = dict(
    arcs_width=55,
    backup_dir='',
    coloring_mode='',
    column_order='wc;vp;sy;st;nt;dt;tm;dr;tg;po;ac;pt;ar',
    date_width=70,
    duration_width=55,
    gco_height=4,
    gui_theme='',
    import_mode='0',
    icon_set='icons',
    index_card_height=13,
    last_open='',
    middle_frame_width=400,
    nt_width=20,
    points_width=300,
    prop_win_geometry='299x716+260+260',
    ps_width=50,
    right_frame_width=350,
    root_geometry='1200x800',
    scene_width=40,
    status_width=100,
    tags_width=100,
    time_width=40,
    title_width=400,
    vp_width=100,
    wc_width=50,
)
SETTINGS.update(DEFAULT_COLORS)
OPTIONS = dict(
    ask_doc_open=True,
    color_tree=True,
    detach_prop_win=False,
    enable_backup=False,
    enable_hovertips=True,
    large_icons=False,
    localize_date=True,
    lock_on_export=False,
    show_auto_numbering=False,
    show_ch_links=False,
    show_contents=True,
    show_cr_field_1=True,
    show_cr_field_2=True,
    show_cr_field_3=True,
    show_cr_links=False,
    show_date_time=False,
    show_it_links=False,
    show_language_settings=False,
    show_lc_links=False,
    show_markup=False,
    show_narrative_time=False,
    show_pl_links=False,
    show_plot=False,
    show_plotline_notes=False,
    show_pn_links=False,
    show_pp_links=False,
    show_pr_links=False,
    show_properties=True,
    show_relationships=False,
    show_renamings=False,
    show_sc_links=False,
    show_scene=False,
    show_st_links=False,
    show_writing_progress=False,
    warn_before_reopening=True,
)


def main():
    major = sys.version_info.major
    minor = sys.version_info.minor
    if  major != 3 or minor < 7:
        raise Exception(
            'Wrong Python version installed: {}.{}. ' \
            'Must be 3.7 or newer.'.format(major, minor)
        )

    os.makedirs(INSTALL_DIR, exist_ok=True)
    configDir = f'{INSTALL_DIR}/config'
    os.makedirs(configDir, exist_ok=True)
    tempDir = f'{INSTALL_DIR}/temp'
    os.makedirs(tempDir, exist_ok=True)

    configuration = Configuration(
        settings=SETTINGS,
        options=OPTIONS,
        filePath=f'{configDir}/novx.ini',
    )
    try:
        configuration.read()
    except:
        pass
    prefs.update(configuration.settings)
    prefs.update(configuration.options)

    launcherConfig = JustSettings(filePath=f'{configDir}/launchers.ini')
    launcherConfig.read()
    launchers.update(launcherConfig.settings)

    app = MainController('novelibre 5.60.0', tempDir)
    ui = app.get_view()

    try:
        sourcePath = sys.argv[1]
    except:
        sourcePath = ''
    if not sourcePath or not os.path.isfile(sourcePath):
        sourcePath = prefs['last_open']
    if sourcePath and os.path.isfile(sourcePath):
        app.open_project(filePath=sourcePath)

    ui.start()

    for keyword in prefs:
        if keyword in configuration.options:
            configuration.options[keyword] = prefs[keyword]
        elif keyword in configuration.settings:
            configuration.settings[keyword] = prefs[keyword]
    configuration.write()

    launcherConfig.settings = launchers
    launcherConfig.write()

    for file in os.scandir(tempDir):
        try:
            os.remove(file)
        except:
            pass


if __name__ == '__main__':
    main()
